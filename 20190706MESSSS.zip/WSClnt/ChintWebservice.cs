﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WSClnt.Chint;
using System.Collections;
using WSClnt;
using InspectMainLib;
using AppLayerLib;
using Newtonsoft.Json;

//add by tony 17.04.21
namespace WSClnt.Chint
{
    [Serializable]
    class LoginUser
    {

        //登录名 数据来源：从外部系统中获取
        public string LoginName { get; set; }
        //密码 数据来源：从外部系统中获取
        public string Password { get; set; }
        //工位ID，SPI传入MES “SPI” 数据来源：固定值 “SPI”
        public string GXID { get; set; }
        //员工ID,返回给SPI 数据来源：接口返回
        public string YGID { get; set; }
        //操作权限：是否是当前外部系统的管理员 数据来源：接口返回 说明： 1：是外部系统的管理员；0：不是外部系统的管理员。
        public string CZQX { get; set; }

    }

    [Serializable]
    class DataInfo
    {
        //条码，SPI传入MES 数据来源：从外部系统中获取
        public string TXM { get; set; }
        //生产作业单号,返回给SPI，保存时给MES 数据来源：验证时为空，验证后由接口返回，保存时不能为空。
        public string SCZYDID { get; set; }
        //工位ID，SPI传入MES “SPI” 数据来源：固定值
        public string GXID { get; set; }
        //员工ID ，之前返回 数据来源：接口返回
        public string YGID { get; set; }
        //员工姓名
        public string YGXM { get; set; }


        //检测结论 数据来源：外部系统检测完成后获取。

        // 说明：    1：合格；0：不合格。验证时为空，保存时不能为空。
        //public string  CPZT{ get; set; }
        public string GXZT { get; set; }
        //不合格原因 数据来源：外部系统检测完成后获取。
        public string BHGYY { get; set; }
        //产品id 
        public string CPID { get; set; }
        public string KHID { get; set; }
        public string TTID { get; set; }
        //检测数据  数组样式 数据来源：外部系统检测完成后获取。说明：   为对应数据检测数据项model的数组
        public JianCData[] JianCData { get; set; }

        //表示该板一共有几块拼版
        public string totalArrayCount { get; set; }

        //表示当前传入的barcode是此板中的第几块拼板的barcode，如果无法获得就为空
        public string barcodeArrayIndex { get; set; }

        //表示生成的csv文件在机台设备中的绝对路径
        public string inspectDetailFile { get; set; } 
    }

    [Serializable]
    class JianCData
    {
        //检测项目（唯一标识）根据不同的工序自定义名称 数据来源：外部系统检测完成后获取。 
        //说明：厂家必须提供所有检测项目与标识的对应关系 高度、面积、体积等
        public string BS { get; set; }
        //位置
        public string WZ { get; set; }
        //检测结果
        public string JCJG { get; set; }
        //检测结论 说明：  1：合格；0：不合格。
        public string JCJL { get; set; }
    }

    [Serializable]
    class Result
    {
        public bool Status { get; set; }
        public string Message { get; set; }
        public string Detail { get; set; }
    }

    [Serializable]
    class ResultDetail
    {
        //登录名 数据来源：从外部系统中获取
        public string LoginName { get; set; }
        //密码 数据来源：从外部系统中获取
        public string Password { get; set; }
        //工位ID，SPI传入MES “SPI” 数据来源：固定值 “SPI”
        public string GXID { get; set; }

        //员工ID,返回给SPI 数据来源：接口返回
        public string YGID { get; set; }
        //员工姓名，SPI传入MES “SPI” 数据来源：固定值 “SPI”
        public string YGXM { get; set; }
        //系统权限：new
        public string XTQX { get; set; }
        //操作权限：是否是当前外部系统的管理员 数据来源：接口返回 说明： 1：是外部系统的管理员；0：不是外部系统的管理员。
        public string CZQX { get; set; }
        //
        //条码，SPI传入MES 数据来源：从外部系统中获取
        public string TXM { get; set; }
        //生产作业单号,返回给SPI，保存时给MES 数据来源：验证时为空，验证后由接口返回，保存时不能为空。
        public string SCZYDID { get; set; }
        //工位ID，SPI传入MES “SPI” 数据来源：固定值
        public string GXZT { get; set; }
        //产品id 
        public string CPID { get; set; }
        //检测结论 数据来源：外部系统检测完成后获取。 
        // 说明：    1：合格；0：不合格。验证时为空，保存时不能为空。
        public string CPZT { get; set; }
        // public string GXZT { get; set; }
        public string KHID { get; set; }

        //不合格原因 数据来源：外部系统检测完成后获取。
        public string BHGYY { get; set; }

        //检测数据  数组样式 数据来源：外部系统检测完成后获取。说明：为对应数据检测数据项model的数组
        public JianCData[] JianCData { get; set; }
    }


    class ChintWebservice
    {
        public static string C_GXID = "SPI";

        public static readonly string MATHOD_NAME = "CommonService";

        public static readonly string[] MODEL_NAME = new string[] { "LoginUser", "DataInfo" };

        public static readonly string[] FUNCTION_NAME = new string[] { "Login", "Verification", "Save" };

        public string _WebServiceAddress = "";

        public ChintWebservice() { }

        public ChintWebservice(String AsAddress)
        {
            _WebServiceAddress = AsAddress;
        }

        ~ChintWebservice() { }

        public string DoLogin(string AsLoginName, String AsPassword, out Result result, out ResultDetail resultDetail)
        {
            LoginUser user = new LoginUser();
            user.LoginName = AsLoginName;
            user.Password = AsPassword;
            user.GXID = C_GXID;
            string submitJson = "";
            result = new Result();
            resultDetail = new ResultDetail();
            try
            {
                submitJson = JsonConvert.SerializeObject(user);                
                Hashtable htParams = new Hashtable();
                htParams.Add("json", submitJson);
                htParams.Add("model", MODEL_NAME[0]);
                htParams.Add("function", FUNCTION_NAME[0]);
                string sSoapResult = SoapOperator.DoSoapWebService(_WebServiceAddress, MATHOD_NAME, htParams);
                if (!string.IsNullOrEmpty(sSoapResult))
                {                    
                    DoDeserializeObject(sSoapResult, ref result, ref resultDetail);
                    if (result.Status)
                    {
                        return "TRUE";
                    }
                    else 
                    {
                        return result.Message;
                    }
                    
                }
                else
                {
                    return "WebService返回出错：返回为空";
                }
            }
            catch (Exception ex)
            {
                return "WebService调用出错";
            }

        }

        public string DoValidateBarcode(string AsUserId, string AsBarcode, out Result result, out ResultDetail resultDetail)
        {
            DataInfo dataInfo = new DataInfo();
            dataInfo.YGID = AsUserId;
            dataInfo.TXM = AsBarcode;
            dataInfo.GXID = C_GXID;
            string submitJson = "";

            result = new Result();
            resultDetail = new ResultDetail();
            resultDetail.JianCData = new JianCData[1];
            try
            {
                submitJson = JsonConvert.SerializeObject(dataInfo);
                //streamWrt.WriteLine("DoBeforeInspect submitJson=" + submitJson);
                Hashtable htParams = new Hashtable();
                htParams.Add("json", submitJson);
                htParams.Add("model", MODEL_NAME[1]);
                htParams.Add("function", FUNCTION_NAME[1]);
                string sSoapResult = SoapOperator.DoSoapWebService(_WebServiceAddress, MATHOD_NAME, htParams);
                if (!string.IsNullOrEmpty(sSoapResult))
                {

                    DoDeserializeObject(sSoapResult, ref result, ref resultDetail);
                    if (result.Status)
                    {
                        return "TRUE";
                    }
                    else
                    {
                        return result.Message;
                    }
                }
                else
                {
                    return "WebService返回出错：返回为空";
                }
            }
            catch (Exception ex)
            {
                return "WebService调用出错";
            }
        }


        public string DoUploadInspect(string AsUserId, string AsczdId, string APcbBarcode, JudgeRes res,
            string Abhgyy, string Acpid, string Akhid, string Aygxm, string Attid,
            int AiTotalArrayCount, string AiBarcodeArrayIndex, string AsInspectDetailFile,
            out Result result, out ResultDetail resultDetail)
        {
            DataInfo dataInfo = new DataInfo();
            dataInfo.YGID = AsUserId;
            dataInfo.TXM = APcbBarcode;
            dataInfo.GXID = C_GXID;
            dataInfo.SCZYDID = AsczdId;

            dataInfo.GXZT = GetGXZTResult(res);
            dataInfo.BHGYY = Abhgyy;
            dataInfo.CPID = Acpid;
            dataInfo.KHID = Akhid;
            dataInfo.YGXM = Aygxm;
            dataInfo.TTID = Attid;
            dataInfo.totalArrayCount = AiTotalArrayCount.ToString();
            dataInfo.barcodeArrayIndex = AiBarcodeArrayIndex;
            dataInfo.inspectDetailFile = AsInspectDetailFile;

            dataInfo.JianCData = new JianCData[1];

            result = new Result();
            resultDetail = new ResultDetail();
            resultDetail.JianCData = new JianCData[1];

            string submitJson = "";
            try
            {
                submitJson = JsonConvert.SerializeObject(dataInfo);
                //streamWrt.WriteLine("DoAfterInspect submitJson=" + submitJson);
                Hashtable htParams = new Hashtable();
                htParams.Add("json", submitJson);
                htParams.Add("model", MODEL_NAME[1]);
                htParams.Add("function", FUNCTION_NAME[2]);
                string sSoapResult = SoapOperator.DoSoapWebService(_WebServiceAddress, MATHOD_NAME, htParams);
                if (!string.IsNullOrEmpty(sSoapResult))
                {
                    DoDeserializeObject(sSoapResult, ref result, ref resultDetail);
                    if (result.Status)
                    {
                        return "TRUE";
                    }
                    else
                    {
                        return result.Message;
                    }
                }
                else
                {
                    return "WebService返回出错：返回为空";
                }
            }
            catch (Exception ex)
            {
                return "WebService调用出错";
            }
        }

        //检测结论
        private string GetGXZTResult(JudgeRes res)
        {
            switch (res)
            {
                case JudgeRes.Good:
                    return "1";
                case JudgeRes.NG:
                    return "0";
                case JudgeRes.Pass:
                    return "1";
                default:
                    return "0";
            }

        }

        private void DoDeserializeObject(string resultStr, ref Result result, ref ResultDetail resultDetail)
        {
            try
            {
                if (!string.IsNullOrEmpty(resultStr))
                {
                    result = JsonConvert.DeserializeObject<Result>(resultStr);
                    if (!string.IsNullOrEmpty(result.Detail))
                    {
                        resultDetail = JsonConvert.DeserializeObject<ResultDetail>(result.Detail);
                    }
                }
            }
            catch (Exception ex)
            {
                
            }
        }

    }
}
