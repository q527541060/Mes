﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
namespace UIInfo
{
    public class fArrUICharts
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public int count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement(ElementName = "fArrUICharts")]
        public List<UIInfo.fArrUIChartsValue> lstfArrUICharts { get; set; }

        public fArrUICharts()
        {
            count = 0;
            lstfArrUICharts = new List<UIInfo.fArrUIChartsValue>();
        }
    }
    public class fArrUIChartsValue
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement]
        public float fValue { get; set; }

        public fArrUIChartsValue()
        {
            Name = string.Empty;
            fValue = 0.0F;
        }
    }

    public class Data
    {
        [XmlElement]
        public int bridgeQty { get; set; }
        [XmlElement]
        public int copQty { get; set; }
        [XmlElement]
        public long defectPads { get; set; }
        [XmlElement]
        public int defectPCB { get; set; }
        [XmlElement]
        public int excessQty { get; set; }
        [XmlElement]
        public float fYieldRes { get; set; }
        [XmlElement]
        public long goodPads { get; set; }
        [XmlElement]
        public int goodPCB { get; set; }
        [XmlElement]
        public int insurQty { get; set; }
        [XmlElement]
        public long lDefectArrays { get; set; }
        [XmlElement]
        public long lGoodArrays { get; set; }
        [XmlElement]
        public int lowAreaQty { get; set; }
        [XmlElement]
        public int lowHeightQty { get; set; }
        [XmlElement]
        public long lTotalArrays { get; set; }
        [XmlElement]
        public int missingQty { get; set; }
        [XmlElement]
        public int overAreaQty { get; set; }
        [XmlElement]
        public int overHeightQty { get; set; }
        [XmlElement]
        public int padErrorQty { get; set; }
        [XmlElement]
        public int shapeErrorQty { get; set; }
        [XmlElement]
        public int shiftXQty { get; set; }
        [XmlElement]
        public int shiftYQty { get; set; }
        [XmlElement]
        public int smearedQty { get; set; }
        [XmlElement]
        public long totalPads { get; set; }
        [XmlElement]
        public int totalPCB { get; set; }

        [XmlElement]
        public UIInfo.fArrUICharts fArrUICharts { get; set; }

        public Data()
        {
            fArrUICharts = new UIInfo.fArrUICharts();
        }
    }
}


namespace WSClnt
{
    public class DataExportJiang
    {
        public string SaveUIInfoXML(InspectMainLib.SPCSummary AspcSummary, string AstrFileName)
        {
            String strMsg = PubStaticParam.RS_EMPTY;
            try
            {
                String strDir = Path.GetDirectoryName(AstrFileName);
                if (Directory.Exists(Path.GetDirectoryName(strDir)) == false)//Q.F.2018.04.02
                {
                    Directory.CreateDirectory(strDir);
                }

                UIInfo.Data uiInfoXmlData = new UIInfo.Data();
                uiInfoXmlData.bridgeQty = AspcSummary.bridgeQty;
                uiInfoXmlData.copQty = AspcSummary.copQty;
                uiInfoXmlData.defectPads = AspcSummary.defectPads;
                uiInfoXmlData.defectPCB = AspcSummary.defectPCB;
                uiInfoXmlData.excessQty = AspcSummary.excessQty;

                uiInfoXmlData.fYieldRes = AspcSummary.fYieldRes;
                uiInfoXmlData.goodPads = AspcSummary.goodPads;
                uiInfoXmlData.goodPCB = AspcSummary.goodPCB;
                uiInfoXmlData.insurQty = AspcSummary.insurQty;
                uiInfoXmlData.lDefectArrays = AspcSummary.lDefectArrays;
                uiInfoXmlData.lGoodArrays = AspcSummary.lGoodArrays;
                uiInfoXmlData.lowAreaQty = AspcSummary.lowAreaQty;
                uiInfoXmlData.lowHeightQty = AspcSummary.lowHeightQty;
                uiInfoXmlData.lTotalArrays = AspcSummary.lTotalArrays;
                uiInfoXmlData.missingQty = AspcSummary.missingQty;
                uiInfoXmlData.overAreaQty = AspcSummary.overAreaQty;
                uiInfoXmlData.overHeightQty = AspcSummary.overHeightQty;
                uiInfoXmlData.padErrorQty = AspcSummary.padErrorQty;
                uiInfoXmlData.shapeErrorQty = AspcSummary.shapeErrorQty;
                uiInfoXmlData.shiftXQty = AspcSummary.shiftXQty;
                uiInfoXmlData.shiftYQty = AspcSummary.shiftYQty;
                uiInfoXmlData.smearedQty = AspcSummary.smearedQty;
                uiInfoXmlData.totalPads = AspcSummary.totalPads;
                uiInfoXmlData.totalPCB = AspcSummary.totalPCB;

                int iArraUIChartsCount = AspcSummary.fArrUIChart.Length;
                uiInfoXmlData.fArrUICharts.count = iArraUIChartsCount;
                for (int i = 1; i <= iArraUIChartsCount; i++)
                {
                    UIInfo.fArrUIChartsValue UIChart = new UIInfo.fArrUIChartsValue();
                    UIChart.Name = "UICharts Id " + i;
                    UIChart.fValue = AspcSummary.fArrUIChart[i - 1];
                    uiInfoXmlData.fArrUICharts.lstfArrUICharts.Add(UIChart); ;
                }

                //string strXMLFile = Path.Combine("D:\\EYSPI\\DataExport", AstrDir + PubStaticParam.RS_XML_EXT);
                //Q.F.2018.04.02
                string strXMLTempFile = Path.Combine(PubStaticParam.RS_strTmpFileDir, "SaveUIInfoXML" + PubStaticParam.RS_XML_EXT);
                XMLHelper.SaveObj2XMLFile(uiInfoXmlData, AstrFileName, strXMLTempFile);
                
            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultInspectionStationForWEIXIN)" + ex.Message.ToString();
            }
            finally
            {
                //                 if (AappSettingData.enPadDebug)
                //                 {
                //                     JsonHelper.SaveObject2JsonFile(mfeMainInfo, AstrDir);
                //                 }
            }
            return strMsg;
        }
        public string GetUIInfoXML(ref InspectMainLib.SPCSummary AspcSummary, string AstrUIInfoXMLFile)
        {
            String strMsg = PubStaticParam.RS_EMPTY;
            try
            {
                UIInfo.Data UIInfoData = GetUIInfoXML(AstrUIInfoXMLFile);
                AspcSummary.bridgeQty = UIInfoData.bridgeQty;
                AspcSummary.copQty = UIInfoData.copQty;
                AspcSummary.defectPads = UIInfoData.defectPads;
                AspcSummary.defectPCB = UIInfoData.defectPCB;
                AspcSummary.excessQty = UIInfoData.excessQty;
                AspcSummary.fYieldRes = UIInfoData.fYieldRes;
                AspcSummary.goodPads = UIInfoData.goodPads;
                AspcSummary.goodPCB = UIInfoData.goodPCB;
                AspcSummary.insurQty = UIInfoData.insurQty;
                AspcSummary.lDefectArrays = UIInfoData.lDefectArrays;
                AspcSummary.lGoodArrays = UIInfoData.lGoodArrays;
                AspcSummary.lowAreaQty = UIInfoData.lowAreaQty;
                AspcSummary.lowHeightQty = UIInfoData.lowHeightQty;
                AspcSummary.lTotalArrays = UIInfoData.lTotalArrays;
                AspcSummary.missingQty = UIInfoData.missingQty;
                AspcSummary.overAreaQty = UIInfoData.overAreaQty;
                AspcSummary.overHeightQty = UIInfoData.overHeightQty;
                AspcSummary.padErrorQty = UIInfoData.padErrorQty;
                AspcSummary.shapeErrorQty = UIInfoData.shapeErrorQty;
                AspcSummary.shiftXQty = UIInfoData.shiftXQty;
                AspcSummary.shiftYQty = UIInfoData.shiftYQty;
                AspcSummary.smearedQty = UIInfoData.smearedQty;
                AspcSummary.totalPads = UIInfoData.totalPads;
                AspcSummary.totalPCB = UIInfoData.totalPCB;

                for (int i = 0; i < UIInfoData.fArrUICharts.count; i++)
                {
                    AspcSummary.fArrUIChart[i] = UIInfoData.fArrUICharts.lstfArrUICharts[i].fValue;
                }
            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultInspectionStationForWEIXIN)" + ex.Message.ToString();
            }
            return strMsg;
        }
        private UIInfo.Data GetUIInfoXML(string AstrUIInfoXMLFile)
        {
            
            UIInfo.Data uiInfo = new UIInfo.Data();
            if (File.Exists(AstrUIInfoXMLFile) == true)//Q.F.2018.04.02
            {                
                try
                {
                    uiInfo = XMLHelper.ReadXMLFile2Obj<UIInfo.Data>(AstrUIInfoXMLFile);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return uiInfo;
        }


    }
}
