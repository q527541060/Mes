﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InspectMainLib;
using AppLayerLib;
using System.IO;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using Microsoft.Office.Interop.Excel;
using ImgCSCoreIM;
using MySql.Data.MySqlClient;
using System.Data;
using DAL_SPC;
using System.Collections;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Imaging;



namespace WSClnt
{
    public class DataExportLin
    {

        private static readonly string TEST_COLUMN_TITLE = "PadID,Component,Type,Area(%),Height,Volume(%),XOffset,YOffset,PadSize(X),PadSize(Y),Area,Height(%),Volume,Result,Errcode,PinNum,Barcode,Date,Time,ArrayID";
        private static readonly string C1_COLUMN_TITLE = "PadID,Component,Type,Area(%),Height,Volume(%),XOffset,YOffset,PadSize(X),PadSize(Y),Area,Height(%),Volume,Result,Errcode,PinNum,Barcode,Date,Time,ArrayID,VolumeL(%)";
        private static readonly string RS_PCB_SERIALNO_PATH = @"D:\EYSPI\DataExport\TmpDir";
        private static readonly string RS_PCB_SERIALNO_FILENAME = "PCBSerialNo.txt";
        private static readonly string RS_TABSPLIT = "\t";
       // public static string _strSPCDataFolder = PubStaticParam.RS_STR_TEMPCSVPATH;
        public static string _strSPCDataFolder = DAL_SPC.PubParams.RS_STR_TEMPCSVPATH ;
        public static string _strSPCDataFolder_Backup = @"D:\EYSPI\SPCData_CSV_Backup";
        private static readonly string RS_SPLIT = ",";
        private readonly string RS_NEW_LINE = "\r\n";
        private readonly string RS_DATETIME_Format = "yyyy-MM-dd HH:mm:ss";
        protected string _strPCBPadResultFormat = "G{0}N{1}P{2}";
        private static int _iBrcdMaxLength = 45;
        private static string _strSPIDBConnString = PubStaticParam._strSPIdbConnectionString;
        private static int _iCommandTimeout = PubStaticParam._intCommandTimeout;

        private Basefunction baseFunction = new Basefunction();
        private static DataExportDP _dePeng = new DataExportDP();
        private int _iReadPCBID = 0;
        DataBeanEx.MySQLBean _beanMySql = new DataBeanEx.MySQLBean();
        #region 保存数据到csv


        public string SaveDataExport_CSV(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
          InspectConfig.ConfigData AConfigData,
            ref ST_SPC_CSV_SavePara AlstSavePara

        )
        {
            string strMsg = string.Empty;
            try
            {

                if (ABrdRes.jugResult == JudgeRes.Unmeasured)
                {
                    LogRecord("PCBID=" + ABrdRes.pcbID.ToString()+ ",Result=Unmeasured");
                    return "Unmeasured";
                }
                AlstSavePara.stCSVParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData,APcbGeneralInfo, ABrdRes);

                if (AlstSavePara.stCSVParam.EnSaveCSV == false)
                {
                    LogRecord("EnSaveCSV = false");
                    return "EnSaveCSV = false";
                }
                    
                //if (!string.IsNullOrEmpty(AlstSavePara.stCSVParam.SaveCSV_Path) && AlstSavePara.stCSVParam.SaveCSV_Path.Trim() != "")
                //    _strSPCDataFolder = AlstSavePara.stCSVParam.SaveCSV_Path;
                string pcbID = ABrdRes.pcbID.ToString();
                //if (_iReadPCBID == 0)
                //{
                //    _iReadPCBID = GetLastPCBID(AappSettingData);
                //}
                //else
                //{
                //    _iReadPCBID++;
                //}
                // pcbID = _iReadPCBID.ToString();
                //ABrdRes.pcbID = _iReadPCBID;
                string strFolder = Path.Combine(_strSPCDataFolder, pcbID + "_temp");
                if (Directory.Exists(strFolder))
                    Directory.Delete(strFolder, true);

                Directory.CreateDirectory(strFolder);
                AlstSavePara.strSavePath = strFolder;

                _dePeng.SaveSPCINI(ref AappSettingData, strFolder, AConfigData, APcbGeneralInfo,ABrdRes);
                //tbBoard
                strMsg += TransToCSV_tbBoard(ref ABrdRes, AappSettingData, strFolder);
                //tbBarcode
                strMsg += TransToCSV_tbBarcode(ref ABrdRes, ref  APcbGeneralInfo.PanelResults[0].arrStrBrcd, AappSettingData, APcbGeneralInfo, strFolder);
                strMsg += TransToCSV_tbPadMeasure(ref APads, ref ABrdRes, AappSettingData, AConfigData, ref AlstSavePara, strFolder);
                SaveRVIni(AlstSavePara.stCSVParam.SaveCSV_Path, AlstSavePara.stCSVParam.SaveCSV_BackUpPath, AappSettingData.stSPCParams.SaveCSV_MaxDays);
            }
            catch (Exception ex)
            {
                strMsg += "SaveDataExport_CSV" + ex.Message;

            }
            if (strMsg != "")
                LogRecord("SaveDataExport_CSV" + strMsg);
            return strMsg;


        }


        //private string TransToCSV_tbPadMeasure(ref Pad[] APads, ref SPCBoardRes ABrdRes, AppSettingData AappSettingData,
        //   InspectConfig.ConfigData AConfigData, ref ST_SPC_CSV_SavePara AlstSavePara, string AstrFolder)
        //{
        //    String strMsg = String.Empty;
        //    try
        //    {

        //        if (APads == null || APads.Length == 0)
        //            return "APads is null or empty";
        //        if (AlstSavePara.lstSavePadImgPara == null)
        //            AlstSavePara.lstSavePadImgPara = new List<ST_SPC_CSV_SavePadImgPara>();

        //        bool bUse1DImage = false;
        //        if (AConfigData._VAHMsrPara_bFastMode == true && AConfigData._checkGage == false)
        //        { bUse1DImage = true; }

        //        // DataRow drData = null;
        //        bool bSave2DImage = false;
        //        bool bSave3DImage = false;
        //        int iSaveCount = 0;
        //        int iSaveCountReal = 0;
        //        int iImgWidth = 0, iImgHeight = 0, iImgLength = 0, j = 0;
        //        short shColorPer = 0;

        //        ImgCSCoreIM.ColorFactorParams stColorFactors = AappSettingData.stColorFactorParams;


        //        string pcbID = ABrdRes.pcbID.ToString();
        //        //string strFolder = Path.Combine(_strSPCDataFolder, pcbID);
        //        //if (!Directory.Exists(strFolder))
        //        //    Directory.CreateDirectory(strFolder);
        //        string strFilePath_NG = Path.Combine(AstrFolder, "tbPadMeasure_NG_temp");
        //        if (File.Exists(strFilePath_NG))
        //            File.Delete(strFilePath_NG);
        //        string strFilePath_Good = Path.Combine(AstrFolder, "tbPadMeasure_Good_temp");
        //        if (File.Exists(strFilePath_Good))
        //            File.Delete(strFilePath_Good);

        //        StringBuilder strBld_NG = new StringBuilder();
        //        StringBuilder strBld_Good = new StringBuilder();
        //        StringBuilder strBld = new StringBuilder();
        //        StringBuilder strBld_Change = new StringBuilder();
        //        #region header
        //        //strBld_NG.Append("PCBID" + RS_SPLIT);
        //        //strBld_NG.Append("PadID" + RS_SPLIT);
        //        //strBld_NG.Append("LineNo" + RS_SPLIT);
        //        //strBld_NG.Append("JobIndex" + RS_SPLIT);
        //        //strBld_NG.Append("PadIndex" + RS_SPLIT);
        //        //strBld_NG.Append("ABSHeight" + RS_SPLIT);
        //        //strBld_NG.Append("ABSArea" + RS_SPLIT);
        //        //strBld_NG.Append("ABSVolume" + RS_SPLIT);
        //        //strBld_NG.Append("ShiftX" + RS_SPLIT);
        //        //strBld_NG.Append("ShiftY" + RS_SPLIT);
        //        //strBld_NG.Append("PerHeight" + RS_SPLIT);
        //        //strBld_NG.Append("PerArea" + RS_SPLIT);
        //        //strBld_NG.Append("PerVolume" + RS_SPLIT);
        //        //strBld_NG.Append("BridgeType" + RS_SPLIT);
        //        //strBld_NG.Append("DefectType" + RS_SPLIT);
        //        //strBld_NG.Append("JudgeRes" + RS_SPLIT);
        //        //strBld_NG.Append("BaseType" + RS_SPLIT);
        //        //strBld_NG.Append("ABSShape" + RS_SPLIT);
        //        //strBld_NG.Append("PadArea" + RS_SPLIT);
        //        //strBld_NG.Append("ArrayIDIndex" + RS_SPLIT);
        //        //strBld_NG.Append(RS_NEW_LINE);

        //        //strBld_Good.Append("PCBID" + RS_SPLIT);
        //        //strBld_Good.Append("PadID" + RS_SPLIT);
        //        //strBld_Good.Append("LineNo" + RS_SPLIT);
        //        //strBld_Good.Append("JobIndex" + RS_SPLIT);
        //        //strBld_Good.Append("PadIndex" + RS_SPLIT);
        //        //strBld_Good.Append("ABSHeight" + RS_SPLIT);
        //        //strBld_Good.Append("ABSArea" + RS_SPLIT);
        //        //strBld_Good.Append("ABSVolume" + RS_SPLIT);
        //        //strBld_Good.Append("ShiftX" + RS_SPLIT);
        //        //strBld_Good.Append("ShiftY" + RS_SPLIT);
        //        //strBld_Good.Append("PerHeight" + RS_SPLIT);
        //        //strBld_Good.Append("PerArea" + RS_SPLIT);
        //        //strBld_Good.Append("PerVolume" + RS_SPLIT);
        //        //strBld_Good.Append("BridgeType" + RS_SPLIT);
        //        //strBld_Good.Append("DefectType" + RS_SPLIT);
        //        //strBld_Good.Append("JudgeRes" + RS_SPLIT);
        //        //strBld_Good.Append("BaseType" + RS_SPLIT);
        //        //strBld_Good.Append("ABSShape" + RS_SPLIT);
        //        //strBld_Good.Append("PadArea" + RS_SPLIT);
        //        //strBld_Good.Append("ArrayIDIndex" + RS_SPLIT);
        //        //strBld_Good.Append(RS_NEW_LINE);
        //        #endregion
        //        string strImage_G;

        //        for (int i = 0, n = APads.Length; i != n; ++i)
        //        {

        //            if (baseFunction.bPadIsSkip(APads[i]))
        //            {

        //                continue;
        //            }
        //            //if (APads[i].res.jugRes == JudgeRes.Pass)
        //            //{
        //            //    strBld_Change.Append(APads[i].padID + RS_SPLIT);
        //            //    strBld_Change.Append(APads[i].padID + RS_SPLIT);
        //            //    continue;
        //            //}

        //            if (APads[i].res.jugRes == JudgeRes.Good)
        //            {
        //                strBld = strBld_Good;
        //            }
        //            else if (APads[i].res.jugRes == JudgeRes.NG || APads[i].res.jugRes == JudgeRes.Pass)
        //            {
        //                strBld = strBld_NG;
        //            }
        //            else
        //                continue;




        //            APads[i].res.measuredValue.perHeight = APads[i].res.measuredValue.height /
        //                (APads[i].stencilHeight * 1000);


        //            strBld.Append(pcbID + RS_SPLIT);
        //            strBld.Append(APads[i].padID + RS_SPLIT);
        //            if (string.IsNullOrEmpty(AappSettingData.LineName))
        //                AappSettingData.LineName = "";
        //            strBld.Append(AappSettingData.LineName.Trim() + RS_SPLIT);
        //            strBld.Append(ABrdRes.iJobIndex + RS_SPLIT);
        //            strBld.Append(i + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.height + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.area + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.vol + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.offsetX + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.offsetY + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.perHeight + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.perArea + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.perVol + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.bridgeType + RS_SPLIT);
        //            strBld.Append(Convert.ToInt32(APads[i].res.jugDefectType) + RS_SPLIT);
        //            int iJugRes = Convert.ToInt32(APads[i].res.jugRes);
        //            if (APads[i].res.jugRes == JudgeRes.Pass)
        //                iJugRes = Convert.ToInt32(JudgeRes.NG);
        //            strBld.Append(iJugRes + RS_SPLIT);
        //            strBld.Append(APads[i].baseType + RS_SPLIT);
        //            strBld.Append(APads[i].res.measuredValue.maxMeanHeightDelta + RS_SPLIT);
        //            strBld.Append(APads[i].spi2DRes.sPadAreaPerc + RS_SPLIT);
        //            strBld.Append(APads[i].arrayIDIndex + RS_SPLIT);

        //            strImage_G = "";
        //            if (AConfigData._checkGage == false && AappSettingData.stSPCParams.bEnSPCAccelerate == true)
        //            {
        //                byte[] byteImg2d_G = DAL_SPC.PubFunction.ObjectToBytes(APads[i].spi2DRes);//_imgBinCSBaseF.DoSerializeObject(APads[i].spi2DRes);
        //                strImage_G = Convert.ToBase64String(byteImg2d_G);
        //            }
        //            strBld.Append(strImage_G + RS_SPLIT);
        //            strBld.Append(APads[i].strArrayID + RS_SPLIT);

        //            if (iSaveCount < AappSettingData.reviewListMaxCount)
        //            {
        //                SavePadImage(APads[i], bUse1DImage, AappSettingData, out bSave2DImage, out bSave3DImage);
        //                if (bSave2DImage || bSave3DImage)
        //                {
        //                    ++iSaveCount;

        //                    //if (bSave2DImage)
        //                    //    AlstPadID.lstPadID_2D.Add(APads[i].iPadIndex);
        //                    //if (bSave3DImage)
        //                    //    AlstPadID.lstPadID_3D.Add(APads[i].iPadIndex);

        //                    AlstSavePara.lstSavePadImgPara.Add(new ST_SPC_CSV_SavePadImgPara
        //                    {
        //                        PadID = APads[i].padID,
        //                        iPadIndex = APads[i].iPadIndex,
        //                        bSave2D = bSave2DImage,
        //                        bSave3D = bSave3DImage
        //                    });
        //                }

        //            }
        //            else
        //            {
        //                bSave2DImage = false;
        //                bSave3DImage = false;
        //            }
        //            #region image
        //            //if (bSave2DImage || bSave3DImage)
        //            //{


        //            //if (AConfigData._checkGage == false)
        //            //{
        //            //    if (AappSettingData.stSPCParams.bEnSPCAccelerate == false)//Q.F.2017.04.26 for testing
        //            //    {
        //            //        iImgWidth = APads[i].res.measuredValue.iImg2DWidth;
        //            //        iImgHeight = APads[i].res.measuredValue.iImg2DHeight;
        //            //        if (stColorFactors.byRGB2DFactorR != 100)
        //            //        {
        //            //            iImgLength = iImgWidth * iImgHeight;
        //            //            byte[] RChanged = new byte[iImgLength];
        //            //            shColorPer = (short)(stColorFactors.byRGB2DFactorR * 1.28);
        //            //            for (j = 0; j < iImgLength; ++j)
        //            //            {
        //            //                RChanged[j] = (byte)((APads[i].res.measuredValue.img2D_R_1D[j] * shColorPer) >> 7);
        //            //            }
        //            //            drData["Img2D_R"] = _imgAlgBinary.GetBytesFrByt2D(RChanged, iImgWidth, iImgHeight);
        //            //        }
        //            //        else
        //            //        {
        //            //            drData["Img2D_R"] = _imgAlgBinary.GetBytesFrByt2D(APads[i].res.measuredValue.img2D_R_1D, iImgWidth, iImgHeight);
        //            //        }


        //            //        drData["Img2D_G"] = _imgAlgBinary.GetBytesFrByt2D(APads[i].res.measuredValue.img2D_G_1D, iImgWidth, iImgHeight);
        //            //        drData["Img2D_B"] = _imgAlgBinary.GetBytesFrByt2D(APads[i].res.measuredValue.img2D_B_1D, iImgWidth, iImgHeight);
        //            //        drData["Img2D_Gray"] = _inspAlgCor.GetBytesFrShrt2D(APads[i].res.measuredValue, bUse1DImage);
        //            //    }
        //            //    else
        //            //    {
        //            //        byte[] aByJPG = null;
        //            //        strMsg = _imgCSCR.GetStreamFrPad(APads[i], AappSettingData, ImageFormat.Jpeg, out aByJPG);
        //            //        if (!String.IsNullOrEmpty(strMsg))
        //            //        {
        //            //            MessageBox.Show(strMsg);
        //            //            return 0;
        //            //        }
        //            //        if (aByJPG != null)
        //            //            drData["Img2D_R"] = aByJPG;

        //            //        iSaveCountReal++;
        //            //    }
        //            //}
        //            //else
        //            //{
        //            //    //Q.F.2017.02.03
        //            //    drData["Img2D_R"] = _inspAlgCor.GetBytesFrByt2D(APads[i], 0, bUse1DImage);

        //            //    drData["Img2D_G"] = _inspAlgCor.GetBytesFrByt2D(APads[i], 1, bUse1DImage);

        //            //    drData["Img2D_B"] = _inspAlgCor.GetBytesFrByt2D(APads[i], 2, bUse1DImage);

        //            //    drData["Img2D_Gray"] = _inspAlgCor.GetBytesFrShrt2D(APads[i], bUse1DImage);


        //            //}

        //            //drData["Img2D_Gray"] = _imgBinCSBaseF.DoCompress(_inspAlgCor.GetBytesFrShrt2D(APads[i].res.measuredValue, bUse1DImage));
        //            // }
        //            //if (bSave3DImage)
        //            //{
        //            //    drData["Img3DHeight"] = _inspAlgCor.GetBytesFrFlt2D(APads[i].res.measuredValue, bUse1DImage);
        //            //}
        //            //ADataTable.Rows.Add(drData);
        //            #endregion

        //            strBld.Append(RS_NEW_LINE);
        //        }

        //        //ST_SPC_CSVParam csvParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData);
        //        //_dePeng.SavePadImage(APads, lstPadID_2D, lstPadID_3D, strFolder,ref AappSettingData, csvParam,12);

        //        StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath_NG, FileMode.Append), Encoding.Default);
        //        streamWrt.Write(strBld_NG);
        //        streamWrt.Close();
        //        streamWrt.Dispose();

        //        StreamWriter streamWrt_G = new StreamWriter(new FileStream(strFilePath_Good, FileMode.Append), Encoding.Default);
        //        streamWrt_G.Write(strBld_Good);
        //        streamWrt_G.Close();
        //        streamWrt_G.Dispose();

        //        //if (AlstSavePara.stCSVParam.RVUIStatus == (byte)ENM_RVUIStatus.None)
        //        //{
        //        //    UpdateFolderName(AstrFolder, "none");

        //        //}
        //    }
        //    catch (System.Exception ex)
        //    {
        //        // MessageBox.Show("Error in save SPC data Board table!->" + ex.ToString());
        //        strMsg += "TransToCSV_tbPadMeasure:" + ex.ToString();

        //    }
        //    finally
        //    {
        //        //if (!string.IsNullOrEmpty(strMsg))
        //        //    _imgBinCSBaseF.LogRecord(PubStaticParam.RS_DATABASE_LOG, "Mode:" + AMode.ToString() + ";" + strMsg, false);
        //    }
        //    return strMsg;
        //}

        private string TransToCSV_tbPadMeasure(ref Pad[] APads, ref SPCBoardRes ABrdRes, AppSettingData AappSettingData,
           InspectConfig.ConfigData AConfigData, ref ST_SPC_CSV_SavePara AlstSavePara, string AstrFolder)
        {
            String strMsg = String.Empty;
            try
            {

                if (APads == null || APads.Length == 0)
                    return "APads is null or empty";
                if (AlstSavePara.lstSavePadImgPara == null)
                    AlstSavePara.lstSavePadImgPara = new List<ST_SPC_CSV_SavePadImgPara>();

                bool bUse1DImage = false;
                if (AConfigData._VAHMsrPara_bFastMode == true && AConfigData._checkGage == false)
                { bUse1DImage = true; }

                // DataRow drData = null;
                bool bSave2DImage = false;
                bool bSave3DImage = false;
                int iSaveCount = 0;


                //  ImgCSCoreIM.ColorFactorParams stColorFactors = AappSettingData.stColorFactorParams;


                string pcbID = ABrdRes.pcbID.ToString();
                //string strFolder = Path.Combine(_strSPCDataFolder, pcbID);
                //if (!Directory.Exists(strFolder))
                //    Directory.CreateDirectory(strFolder);
                string strFilePath_NG = Path.Combine(AstrFolder, "tbPadMeasure_NG_temp");
                if (File.Exists(strFilePath_NG))
                    File.Delete(strFilePath_NG);
                string strFilePath_Good = Path.Combine(AstrFolder, "tbPadMeasure_Good_temp");
                if (File.Exists(strFilePath_Good))
                    File.Delete(strFilePath_Good);

                StringBuilder strBld_NG = new StringBuilder();
                StringBuilder strBld_Good = new StringBuilder();
                StringBuilder strBld = new StringBuilder();
                StringBuilder strBld_Change = new StringBuilder();
                #region header
                //strBld_NG.Append("PCBID" + RS_SPLIT);
                //strBld_NG.Append("PadID" + RS_SPLIT);
                //strBld_NG.Append("LineNo" + RS_SPLIT);
                //strBld_NG.Append("JobIndex" + RS_SPLIT);
                //strBld_NG.Append("PadIndex" + RS_SPLIT);
                //strBld_NG.Append("ABSHeight" + RS_SPLIT);
                //strBld_NG.Append("ABSArea" + RS_SPLIT);
                //strBld_NG.Append("ABSVolume" + RS_SPLIT);
                //strBld_NG.Append("ShiftX" + RS_SPLIT);
                //strBld_NG.Append("ShiftY" + RS_SPLIT);
                //strBld_NG.Append("PerHeight" + RS_SPLIT);
                //strBld_NG.Append("PerArea" + RS_SPLIT);
                //strBld_NG.Append("PerVolume" + RS_SPLIT);
                //strBld_NG.Append("BridgeType" + RS_SPLIT);
                //strBld_NG.Append("DefectType" + RS_SPLIT);
                //strBld_NG.Append("JudgeRes" + RS_SPLIT);
                //strBld_NG.Append("BaseType" + RS_SPLIT);
                //strBld_NG.Append("ABSShape" + RS_SPLIT);
                //strBld_NG.Append("PadArea" + RS_SPLIT);
                //strBld_NG.Append("ArrayIDIndex" + RS_SPLIT);
                //strBld_NG.Append(RS_NEW_LINE);

                //strBld_Good.Append("PCBID" + RS_SPLIT);
                //strBld_Good.Append("PadID" + RS_SPLIT);
                //strBld_Good.Append("LineNo" + RS_SPLIT);
                //strBld_Good.Append("JobIndex" + RS_SPLIT);
                //strBld_Good.Append("PadIndex" + RS_SPLIT);
                //strBld_Good.Append("ABSHeight" + RS_SPLIT);
                //strBld_Good.Append("ABSArea" + RS_SPLIT);
                //strBld_Good.Append("ABSVolume" + RS_SPLIT);
                //strBld_Good.Append("ShiftX" + RS_SPLIT);
                //strBld_Good.Append("ShiftY" + RS_SPLIT);
                //strBld_Good.Append("PerHeight" + RS_SPLIT);
                //strBld_Good.Append("PerArea" + RS_SPLIT);
                //strBld_Good.Append("PerVolume" + RS_SPLIT);
                //strBld_Good.Append("BridgeType" + RS_SPLIT);
                //strBld_Good.Append("DefectType" + RS_SPLIT);
                //strBld_Good.Append("JudgeRes" + RS_SPLIT);
                //strBld_Good.Append("BaseType" + RS_SPLIT);
                //strBld_Good.Append("ABSShape" + RS_SPLIT);
                //strBld_Good.Append("PadArea" + RS_SPLIT);
                //strBld_Good.Append("ArrayIDIndex" + RS_SPLIT);
                //strBld_Good.Append(RS_NEW_LINE);
                #endregion
                string strImage_G;

                if (string.IsNullOrEmpty(AappSettingData.LineName))
                    AappSettingData.LineName = "";
                bool bSaveSPI2DRes = false;
                if (AConfigData._checkGage == false && AappSettingData.stSPCParams.bEnSPCAccelerate == true)
                    bSaveSPI2DRes = true;

                Stopwatch sw = new Stopwatch();
                sw.Start();
                for (int i = 0, n = APads.Length; i != n; ++i)
                {

                    if (baseFunction.bPadIsSkip(APads[i]))
                    {

                        continue;
                    }
                    //if (APads[i].res.jugRes == JudgeRes.Pass)
                    //{
                    //    strBld_Change.Append(APads[i].padID + RS_SPLIT);
                    //    strBld_Change.Append(APads[i].padID + RS_SPLIT);
                    //    continue;
                    //}

                    if (APads[i].res.jugRes == JudgeRes.Good)
                    {
                        strBld = strBld_Good;
                    }
                    else if (APads[i].res.jugRes == JudgeRes.NG || APads[i].res.jugRes == JudgeRes.Pass)
                    {
                        strBld = strBld_NG;
                    }
                    else
                        continue;



                    if (APads[i].stencilHeight != null && APads[i].stencilHeight != 0)
                        APads[i].res.measuredValue.perHeight = APads[i].res.measuredValue.height /
                                                                     (APads[i].stencilHeight * 1000);


                    strBld.Append(pcbID + RS_SPLIT);
                    strBld.Append(APads[i].padID + RS_SPLIT);

                    strBld.Append(AappSettingData.LineName.Trim() + RS_SPLIT);
                    strBld.Append(ABrdRes.iJobIndex + RS_SPLIT);
                    strBld.Append(i + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.height + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.area + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.vol + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.offsetX + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.offsetY + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.perHeight + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.perArea + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.perVol + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.bridgeType + RS_SPLIT);
                    strBld.Append(Convert.ToInt32(APads[i].res.jugDefectType) + RS_SPLIT);
                    int iJugRes = Convert.ToInt32(APads[i].res.jugRes);
                    if (APads[i].res.jugRes == JudgeRes.Pass)
                        iJugRes = Convert.ToInt32(JudgeRes.NG);
                    strBld.Append(iJugRes + RS_SPLIT);
                    strBld.Append(APads[i].baseType + RS_SPLIT);
                    strBld.Append(APads[i].res.measuredValue.maxMeanHeightDelta + RS_SPLIT);
                    strBld.Append(APads[i].spi2DRes.sPadAreaPerc + RS_SPLIT);
                    strBld.Append(APads[i].arrayIDIndex + RS_SPLIT);

                    strImage_G = "";
                    if (bSaveSPI2DRes)
                    {
                        byte[] byteImg2d_G = DAL_SPC.PubFunction.ObjectToBytes(APads[i].spi2DRes);//_imgBinCSBaseF.DoSerializeObject(APads[i].spi2DRes);
                        strImage_G = Convert.ToBase64String(byteImg2d_G);
                    }
                    strBld.Append(strImage_G + RS_SPLIT);
                    strBld.Append(APads[i].strArrayID + RS_SPLIT);

                    if (iSaveCount < AappSettingData.reviewListMaxCount)
                    {
                        bSave2DImage = false;
                        bSave3DImage = false;
                        SavePadImage(APads[i], bUse1DImage, AappSettingData, out bSave2DImage, out bSave3DImage);
                        if (bSave2DImage || bSave3DImage)
                        {
                            ++iSaveCount;

                            AlstSavePara.lstSavePadImgPara.Add(new ST_SPC_CSV_SavePadImgPara
                            {
                                PadID = APads[i].padID,
                                iPadIndex = APads[i].iPadIndex,
                                bSave2D = bSave2DImage,
                                bSave3D = bSave3DImage
                            });
                        }
                    }
                    strBld.Append(RS_NEW_LINE);
                }
                sw.Stop();
                if (AappSettingData.enPadDebug)
                    LogRecord("循环时间" + sw.ElapsedMilliseconds);
                sw.Restart();

                StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath_NG, FileMode.Append), Encoding.Default);
                streamWrt.Write(strBld_NG);
                streamWrt.Close();
                streamWrt.Dispose();

                StreamWriter streamWrt_G = new StreamWriter(new FileStream(strFilePath_Good, FileMode.Append), Encoding.Default);
                streamWrt_G.Write(strBld_Good);
                streamWrt_G.Close();
                streamWrt_G.Dispose();

                sw.Stop();
                if (AappSettingData.enPadDebug)
                    LogRecord("保存时间" + sw.ElapsedMilliseconds);
                //if (AlstSavePara.stCSVParam.RVUIStatus == (byte)ENM_RVUIStatus.None)
                //{
                //    UpdateFolderName(AstrFolder, "none");

                //}
            }
            catch (System.Exception ex)
            {
                // MessageBox.Show("Error in save SPC data Board table!->" + ex.ToString());
                strMsg += "TransToCSV_tbPadMeasure:" + ex.ToString();
                LogRecord(strMsg);
            }
            finally
            {

            }
            return strMsg;
        }



        public string TransToCSV_tbPadMeasure_CR(ref Pad[] APads, ref SPCBoardRes ABrdRes, PCBGeneralInfo APCBGeneralInfo,AppSettingData AappSettingData, InspectConfig.ConfigData AConfigData)
        {
            String strMsg = String.Empty;
            string strFolder = string.Empty;
            try
            {
                //if (!string.IsNullOrEmpty(AappSettingData.stSPCParams.SaveCSV_Path) && AappSettingData.stSPCParams.SaveCSV_Path.Trim() != "")
                //    _strSPCDataFolder = AappSettingData.stSPCParams.SaveCSV_Path;
                ST_SPC_CSVParam csvParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData,APCBGeneralInfo, ABrdRes);
                if (csvParam.EnSaveCSV == false)
                    return strMsg;
                //if (!string.IsNullOrEmpty(csvParam.SaveCSV_Path) && csvParam.SaveCSV_Path.Trim() != "")
                //    _strSPCDataFolder = csvParam.SaveCSV_Path;


                string pcbID = ABrdRes.pcbID.ToString();
                strFolder = Path.Combine(_strSPCDataFolder, pcbID + "_temp");
               
                string strFile_RV = Path.Combine(strFolder, "tbPadMeasure_ChangeResult_RV");
                if (File.Exists(strFile_RV))
                {
                    if (csvParam.RVUIStatus == 1 || ( csvParam.RVUIStatus == 2 && csvParam.RVPriority == 0))
                    {
                        strMsg += "RV Confirmed";
                        LogRecord(strMsg);
                        return strMsg;

                    }
                }


                if (!Directory.Exists(strFolder))
                {
                    strMsg += "folder " + strFolder + " not exists";
                    LogRecord(strMsg);
                    return strMsg;
                }

                string strFilePath = Path.Combine(strFolder, "tbPadMeasure_ChangeResult");
                if (File.Exists(strFilePath))
                    File.Delete(strFilePath);
                StringBuilder strBld_Change = new StringBuilder();
                if (APads == null || APads.Length == 0)
                {
                    StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath, FileMode.Append), Encoding.Default);
                    streamWrt.Write(strBld_Change);
                    streamWrt.Close();
                    streamWrt.Dispose();
                    //Directory.Move(strFolder, strFolder + "_Finish");

                    strMsg = "APads is null or empty";
                    if(AappSettingData.enPadDebug)
                        LogRecord(strMsg);
                    goto end;
                }




                //string strFilePath_Skip = Path.Combine(strFolder, "tbPadMeasure_Skip");
                //if (File.Exists(strFilePath_Skip))
                //    File.Delete(strFilePath_Skip);


                // StringBuilder strBld_Skip = new StringBuilder();

                for (int i = 0, n = APads.Length; i != n; ++i)
                {

                    //if (baseFunction.bPadIsSkip(APads[i]))
                    //{
                    //    strBld_Skip.Append(APads[i].padID + RS_SPLIT);

                    //}
                    //else

                    if (APads[i].res.jugRes == JudgeRes.Pass)
                    {
                        strBld_Change.Append(APads[i].padID + RS_SPLIT);

                    }


                }
                StreamWriter streamWrt2 = new StreamWriter(new FileStream(strFilePath, FileMode.Append), Encoding.Default);
                streamWrt2.Write(strBld_Change);
                streamWrt2.Close();
                streamWrt2.Dispose();

                //StreamWriter streamWrt_G = new StreamWriter(new FileStream(strFilePath_Skip, FileMode.Append), Encoding.Default);
                //streamWrt_G.Write(strBld_Skip);
                //streamWrt_G.Close();
                //streamWrt_G.Dispose();


                //Directory.Move(strFolder, strFolder + "_Finish");
                if (AappSettingData.enPadDebug)
                    LogRecord("CR文件保存完毕");
            }
            catch (Exception ex)
            {
                // MessageBox.Show("Error in save SPC data Board table!->" + ex.ToString());
                strMsg += "TransToCSV_tbPadMeasure_CR:" + ex.ToString();
                LogRecord(strMsg);
            }
            finally
            {
                //if (!string.IsNullOrEmpty(strMsg))
                //    _imgBinCSBaseF.LogRecord(PubStaticParam.RS_DATABASE_LOG, "Mode:" + AMode.ToString() + ";" + strMsg, false);
            }

        end:
            strMsg += UpdateTbBoard(strFolder, ABrdRes, AappSettingData);
            UpdateFolderName(strFolder, "uiconfirm");

            return strMsg;
        }


        public static string UpdateFileName(string AstrFolder)
        {
            string strMsg = string.Empty;
            try
            {
                DirectoryInfo di = new DirectoryInfo(AstrFolder);
                FileInfo[] arrFiles = di.GetFiles("tbPadMeasure_*");
                foreach (var file in arrFiles)
                {
                    if (file.Name == "tbPadMeasure_NG_temp")
                        file.MoveTo(Path.Combine(AstrFolder, "tbPadMeasure_NG"));
                    else if (file.Name == "tbPadMeasure_Good_temp")
                        file.MoveTo(Path.Combine(AstrFolder, "tbPadMeasure_Good"));
                }
                UpdateFolderName(AstrFolder, "image");
            }
            catch (Exception ex)
            {
                strMsg = "UpdateFileName:" + ex.Message;
                throw;
            }

            return strMsg;
        }

        public static string UpdateFolderName(string AstrFolder, string AstrAction)
        {
            string strMsg = string.Empty;
            if (!Directory.Exists(AstrFolder) || !AstrFolder.EndsWith("_temp"))
                return strMsg;
            string fileName;
            try
            {
                bool bUIConfirmed = false;
                switch (AstrAction)
                {
                    case "image":
                        fileName = Path.Combine(AstrFolder, "uiconfirm");
                        if (File.Exists(fileName))
                        {
                            bUIConfirmed = true;

                        }
                        //else
                        //{
                        //    fileName = Path.Combine(AstrFolder, "image");
                        //    StringBuilder strBld = new StringBuilder();
                        //    StreamWriter streamWrt_G = new StreamWriter(new FileStream(fileName, FileMode.Append), Encoding.Default);
                        //    streamWrt_G.Write(strBld);
                        //    streamWrt_G.Close();
                        //    streamWrt_G.Dispose();
                        //}
                        break;
                    case "uiconfirm":
                        fileName = Path.Combine(AstrFolder, "image");
                        if (File.Exists(fileName))
                        {
                            bUIConfirmed = true;

                        }
                        //else
                        //{
                        //    fileName = Path.Combine(AstrFolder, "uiconfirm");
                        //    StringBuilder strBld = new StringBuilder();
                        //    StreamWriter streamWrt_G = new StreamWriter(new FileStream(fileName, FileMode.Append), Encoding.Default);
                        //    streamWrt_G.Write(strBld);
                        //    streamWrt_G.Close();
                        //    streamWrt_G.Dispose();
                        //}
                        break;
                    case "none":
                        if (Directory.Exists(AstrFolder) && AstrFolder.EndsWith("_temp"))
                        {
                           Directory.Move(AstrFolder, AstrFolder.Substring(0, AstrFolder.IndexOf("_temp")) + "_Finish");                             
                            //CopyFolder(AstrFolder, AstrFolder.Substring(0, AstrFolder.IndexOf("_temp")) + "_Finish");
                            //Directory.Delete(AstrFolder,true);
                        }
                        
                        return strMsg;
                }
                bool bFinish = false;
                if (bUIConfirmed)
                {
                    ST_SPC_CSVParam stParam = _dePeng.ReadSPCINI(AstrFolder);

                    switch (stParam.RVUIStatus)
                    {
                        case (byte)ENM_RVUIStatus.OnlyUI:
                            bFinish = true;
                            break;
                        case (byte)ENM_RVUIStatus.OnlyRV:
                            break;
                        case (byte)ENM_RVUIStatus.BothHave:
                            bFinish = true;
                            break;
                        case (byte)ENM_RVUIStatus.None:
                            break;
                    }

                }
                if (bFinish)
                {
                    if (Directory.Exists(AstrFolder) && AstrFolder.EndsWith("_temp"))
                    {
                        Directory.Move(AstrFolder, AstrFolder.Substring(0, AstrFolder.IndexOf("_temp")) + "_Finish");
                        //CopyFolder(AstrFolder, AstrFolder.Substring(0, AstrFolder.IndexOf("_temp")) + "_Finish");
                        //Directory.Delete(AstrFolder,true);
                    }
                        
                }
                    
                else
                {
                    fileName = "";
                    switch (AstrAction)
                    {
                        case "image":
                            fileName = Path.Combine(AstrFolder, "image");
                            break;
                        case "uiconfirm":
                            fileName = Path.Combine(AstrFolder, "uiconfirm");
                            break;
                    }
                    if (fileName.Trim() != "" && !File.Exists(fileName))
                    {
                        StringBuilder strBld = new StringBuilder();
                        StreamWriter streamWrt_G = new StreamWriter(new FileStream(fileName, FileMode.Append), Encoding.Default);
                        streamWrt_G.Write(strBld);
                        streamWrt_G.Close();
                        streamWrt_G.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                strMsg = "UpdateFolderName:" + ex.Message;
                throw;
            }

            return strMsg;
        }

        private string TransToCSV_tbBoard(ref SPCBoardRes ABrdRes, AppSettingData AappSettingData, string AstrFolder)
        {
            string strMsg = string.Empty;
            try
            {
                string pcbID = ABrdRes.pcbID.ToString();
                //string strFolder = Path.Combine(_strSPCDataFolder, pcbID);
                //if (!Directory.Exists(strFolder))
                //    Directory.CreateDirectory(strFolder);
                string strFilePath = Path.Combine(AstrFolder, "tbBoard");
                if (File.Exists(strFilePath))
                    File.Delete(strFilePath);

                StringBuilder strBld = new StringBuilder();
                //header
                //strBld.Append("PCBID" + RS_SPLIT);
                //strBld.Append("JobIndex" + RS_SPLIT);
                //strBld.Append("BlockID" + RS_SPLIT);
                //strBld.Append("InspectTimeStamp" + RS_SPLIT);
                //strBld.Append("StartTime" + RS_SPLIT);
                //strBld.Append("EndTime" + RS_SPLIT);
                //strBld.Append("Result" + RS_SPLIT);
                //strBld.Append("PCBBarcode" + RS_SPLIT);
                //strBld.Append("OPConfirmed" + RS_SPLIT);
                //strBld.Append("Squeege" + RS_SPLIT);
                //strBld.Append("VendorID" + RS_SPLIT);
                //strBld.Append("LineNo" + RS_SPLIT);
                //strBld.Append("LotNo" + RS_SPLIT);
                //strBld.Append("LaneNo" + RS_SPLIT);
                //strBld.Append("StencilID" + RS_SPLIT);
                //strBld.Append(RS_NEW_LINE);
                //value
                strBld.Append(pcbID + RS_SPLIT);
                strBld.Append(ABrdRes.iJobIndex + RS_SPLIT);
                //strBld.Append(68 + RS_SPLIT);
                strBld.Append(ABrdRes.blockID + RS_SPLIT);
                strBld.Append(ABrdRes.startTime + RS_SPLIT);
                strBld.Append(ABrdRes.startTime + RS_SPLIT);
                strBld.Append(ABrdRes.endTime + RS_SPLIT);
                strBld.Append(Convert.ToInt32(ABrdRes.jugResult) + RS_SPLIT);
                strBld.Append(GetStrByMaxLength(ABrdRes.pcbBarcode) + RS_SPLIT);
                strBld.Append(0 + RS_SPLIT);
                strBld.Append(ABrdRes.squeegeDir.ToString() + RS_SPLIT);
                strBld.Append(string.Format(_strPCBPadResultFormat, ABrdRes.stPcbNGINfo.iPadsNumGood,
                        ABrdRes.stPcbNGINfo.iPadsNumNG,
                        ABrdRes.stPcbNGINfo.iPadsNumPass) + RS_SPLIT);
                if (string.IsNullOrEmpty(AappSettingData.LineName))
                    AappSettingData.LineName = "";
                strBld.Append(AappSettingData.LineName.Trim() + RS_SPLIT);
                if (!String.IsNullOrEmpty(AappSettingData.strLotNumber))
                    strBld.Append(AappSettingData.strLotNumber.Trim() + RS_SPLIT);
                else
                    strBld.Append(RS_SPLIT);

                strBld.Append(ABrdRes.LaneNo + 1 + RS_SPLIT);
                strBld.Append(ABrdRes.stencilID);



                StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath, FileMode.Append), Encoding.Default);
                streamWrt.Write(strBld);
                streamWrt.Close();
                streamWrt.Dispose();

            }
            catch (System.Exception ex)
            {
                strMsg = ex.Message;

                //MessageBox.Show("Error in save SPC data Board table!->" + ex.ToString());
                //return 1043;

            }
            finally
            {
            }
            return strMsg;
        }

        private string TransToCSV_tbBarcode(ref SPCBoardRes ABrdRes, ref string[] AarrStrBrcd
             , AppSettingData AappSettingData, ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, string AstrFolder)
        {

            string strMsg = string.Empty;
            try
            {
                StringBuilder strBld = new StringBuilder();
                if (AarrStrBrcd != null && AarrStrBrcd.Length > 0)
                {

                    byte byLaneNo = (byte)ABrdRes.LaneNo;
                    byte ADestLaneNo = (byte)((byLaneNo + 1) % 2);
                    bool bDestLanHasPCBID = false;

                    //if (ABrdRes.enmCopyBarcodeMode == ENM_CopyBarcodeMode.CopyToAnother
                    //        && AappSettingData.conv3StageFirstClmpPos == ADestLaneNo)
                    //{

                    //    BHasPCBID(ABrdRes.iAnotherLanePcbID, out bDestLanHasPCBID);
                    //    if (AappSettingData.enPadDebug)
                    //        LogRecord("byLaneNo" + byLaneNo + ";enmCopyBarcodeMode:" + ABrdRes.enmCopyBarcodeMode.ToString()
                    //             + ";conv3StageFirstClmpPos:" + AappSettingData.conv3StageFirstClmpPos
                    //             + "CurPCBID/AnotherPCBID:" + ABrdRes.pcbID + "/" + ABrdRes.iAnotherLanePcbID
                    //             + "bDestLanHasPCBID:" + bDestLanHasPCBID.ToString());

                    //    UpdateBoardBarcode(ABrdRes.iAnotherLanePcbID, ABrdRes.pcbBarcode);
                    //}

                    string strArrayID = "";
                    int iArrayIDIndex = 0;

                    string pcbID = ABrdRes.pcbID.ToString();
                    string strBarCode, strArrayBarCode;
                    for (int a = 0, iLength = AarrStrBrcd.Length; a < iLength; ++a)
                    {
                        strArrayID = "";
                        iArrayIDIndex = a;




                        //if(AappSettingData.bUseCamBrcd == true)
                        if (AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseCamBrcd == true
                            || AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].useManualBarcode == true)
                        {
                            if (a == 0
                                && APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                                && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                                continue;


                        }
                        else
                        {
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                                && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                            {
                                iArrayIDIndex = a + 1;
                            }
                            if (iArrayIDIndex >= APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length)
                                continue;

                        }
                        strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[iArrayIDIndex].strArrayID;
                        if (string.IsNullOrEmpty(strArrayID))
                        {
                            strArrayID = "";
                        }




                        //header
                        //strBld.Append("PCBID" + RS_SPLIT);
                        //strBld.Append("LineNo" + RS_SPLIT);
                        //strBld.Append("BarCode" + RS_SPLIT);
                        //strBld.Append("ArrayBarCode" + RS_SPLIT);
                        //strBld.Append("ArrayID" + RS_SPLIT);
                        //strBld.Append("IndexSerNo" + RS_SPLIT);
                        //strBld.Append(RS_NEW_LINE);
                        //value
                        strBld.Append(pcbID + RS_SPLIT);
                        if (string.IsNullOrEmpty(AappSettingData.LineName))
                            AappSettingData.LineName = "";
                        strBld.Append(AappSettingData.LineName.Trim() + RS_SPLIT);
                        strBarCode = strArrayBarCode = "";
                        if (ABrdRes.pcbBarcode != null)
                        {
                            strBarCode = GetStrByMaxLength(ABrdRes.pcbBarcode);

                        }
                        strBld.Append(strBarCode + RS_SPLIT);
                        if (!string.IsNullOrEmpty(AarrStrBrcd[a]))
                        {
                            strArrayBarCode = GetStrByMaxLength(AarrStrBrcd[a]);
                        }
                        strBld.Append(strArrayBarCode + RS_SPLIT);
                        strBld.Append(strArrayID + RS_SPLIT);
                        strBld.Append(a);
                        strBld.Append(RS_NEW_LINE);

                        //if (bDestLanHasPCBID == true)
                        //{
                        //    strBld.Append(ABrdRes.iAnotherLanePcbID + RS_SPLIT);
                        //    if (string.IsNullOrEmpty(AappSettingData.LineName))
                        //        AappSettingData.LineName = "";
                        //    strBld.Append(AappSettingData.LineName.Trim() + RS_SPLIT);
                        //    strBarCode = strArrayBarCode = "";
                        //    if (ABrdRes.pcbBarcode != null)
                        //    {
                        //        strBarCode = GetStrByMaxLength(ABrdRes.pcbBarcode);
                        //    }
                        //    strBld.Append(strBarCode + RS_SPLIT);
                        //    if (!string.IsNullOrEmpty(AarrStrBrcd[a]))
                        //    {
                        //        strArrayBarCode = GetStrByMaxLength(AarrStrBrcd[a]);
                        //    }
                        //    strBld.Append(strArrayBarCode + RS_SPLIT);
                        //    strBld.Append(strArrayID + RS_SPLIT);
                        //    strBld.Append(a);
                        //    strBld.Append(RS_NEW_LINE);

                        //}
                    }

                    string strFilePath = Path.Combine(AstrFolder, "tbBarcode");
                    if (File.Exists(strFilePath))
                        File.Delete(strFilePath);


                    StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath, FileMode.Append), Encoding.Default);
                    streamWrt.Write(strBld);
                    streamWrt.Close();
                    streamWrt.Dispose();



                }

            }
            catch (System.Exception ex)
            {
                strMsg = ex.Message;
            }
            finally
            {
            }
            return strMsg;
        }

        private int BHasPCBID(int AiPCBID, out bool bHasPCBID)
        {
            bHasPCBID = false;
            try
            {
                System.Data.DataTable dtBoard = _beanMySql.GetDataTableFrSQL(string.Format("SELECT * FROM  tbBoard WHERE PCBID = {0}", AiPCBID));
                if (dtBoard == null || dtBoard.Rows == null || dtBoard.Rows.Count == 0)
                {
                    bHasPCBID = false;
                    return 0;

                }
                else
                {
                    bHasPCBID = true;
                    return 0;
                }
                //return 0;
            }
            catch (System.Exception ex)
            {
                LogRecord("HasPCBID\n" + ex.ToString());
                return -1;
            }

            //return 0;
        }

        private void UpdateBoardBarcode(int AiPCBID, string AstrPCBBarcode)
        {
            try
            {
                string strSql = string.Format("UPDATE TBBoard  Set PCBBarcode = '{0}' where  PCBID = {1}", AstrPCBBarcode, AiPCBID);
                ExecuteNonQuery(strSql);
            }
            catch (Exception ex)
            {
                LogRecord("UpdateBoardBarcode:" + ex.Message);
            }
        }

        public List<Pad_RV> GetNGPads(string AstrFileName, string AstrFileName_Pass)
        {
            List<Pad_RV> lstPads = new List<Pad_RV>();
            FileStream fs = new FileStream(AstrFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            string strLine = "";
            string[] aryLine = null;

            string[] arrPass = null;

            if (AstrFileName_Pass != "" && File.Exists(AstrFileName_Pass))
            {
                string strPass = File.ReadAllText(AstrFileName_Pass);
                if (strPass.Trim() != "")
                    arrPass = strPass.Split(',');

            }

            StringBuilder sb = new StringBuilder(PubStaticParam._iStringBuilderCapacity, PubStaticParam._iStringBuilderMaxCapacity);

            while ((strLine = sr.ReadLine()) != null)
            {
                aryLine = strLine.Split(',');
                if (aryLine.Length >= 21)
                {
                    if (arrPass != null && arrPass.Contains(aryLine[1]))
                    {
                    }
                    else
                    {
                        lstPads.Add(new Pad_RV
                        {
                            PadID = Convert.ToInt32(aryLine[1]),
                            ArrayID = string.IsNullOrEmpty(aryLine[21]) ? -1 : Convert.ToInt32(aryLine[21])
                        });
                    }

                }
            }

            sr.Close();
            fs.Close();
            return lstPads;
        }

        private string UpdateTbBoard(string AstrFolder, SPCBoardRes ABrdRes, AppSettingData AappSettingData)
        {
            string strMsg = string.Empty;

            string strFile = Path.Combine(AstrFolder, "tbBoard");
            if (!File.Exists(strFile))
                return "tbBoard.csv is not exists";

            try
            {
                FileStream fs = new FileStream(strFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;
                DateTime dtTemp;

                StringBuilder strBld = new StringBuilder();
                while ((strLine = sr.ReadLine()) != null)
                {
                    if (strLine.Trim() != "")
                    {

                        aryLine = strLine.Split(',');
                        aryLine[6] = Convert.ToInt32(ABrdRes.jugResult).ToString();
                        aryLine[8] = "1";

                        string strOperator = string.Empty;
                        string strOperatorName = string.Empty;
                        if (!string.IsNullOrEmpty(AappSettingData.strDataExpOperator))
                            strOperator = AappSettingData.strDataExpOperator;
                        if (string.IsNullOrEmpty(ABrdRes.operatorName))
                            strOperatorName = "";
                        else
                            strOperatorName = ABrdRes.operatorName;
                        if (AappSettingData.stSPCParams.bSaveMESOperator == false)
                            strOperator = strOperatorName;

                        if (aryLine.Length >= 18)
                        {
                            aryLine[15] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                            aryLine[16] = strOperator;
                            aryLine[17] = "1";
                            for (int i = 0; i < aryLine.Length; i++ )
                            {
                                if(i==aryLine.Length-1)
                                    strBld.Append(aryLine[i]);
                                else
                                    strBld.Append(aryLine[i] + RS_SPLIT);
                            }
                        }
                        else
                        {
                            foreach (string str in aryLine)
                            {
                                strBld.Append(str + RS_SPLIT);
                            }
                            //aryLine[15]
                            strBld.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + RS_SPLIT);
                            //16
                            strBld.Append(strOperator + RS_SPLIT);
                            //17  OPConfirmedSource
                            strBld.Append(1);

                        }


                        break;

                    }


                }
                if (strBld.Length > 0)
                {
                    sr.Close();
                    fs.Close();

                    File.Delete(strFile);
                    Thread.Sleep(200);
                    StreamWriter streamWrt = new StreamWriter(new FileStream(strFile, FileMode.Append), Encoding.Default);
                    streamWrt.Write(strBld);
                    streamWrt.Close();
                    streamWrt.Dispose();
                }


            }
            catch (Exception ex)
            {
                strMsg += ex.Message;
                throw ex;
            }


            return strMsg;

        }


        public System.Data.DataTable GetRVBoardResult(SPCBoardRes ABrdRes, PCBGeneralInfo APCBGeneralInfo, AppSettingData AappSettingData, InspectConfig.ConfigData AConfigData)
        {
            System.Data.DataTable dtBoard = null;
            try
            {
                ST_SPC_CSVParam csvParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData,APCBGeneralInfo, ABrdRes);
                if (csvParam.EnSaveCSV == false)
                {
                    LogRecord("GetRVBoardResult-->csvParam.EnSaveCSV == false");
                    return dtBoard;
                }

                //if (!string.IsNullOrEmpty(csvParam.SaveCSV_Path) && csvParam.SaveCSV_Path.Trim() != "")
                //    _strSPCDataFolder = csvParam.SaveCSV_Path;


                string pcbID = ABrdRes.pcbID.ToString();
                string AstrFolder = Path.Combine(_strSPCDataFolder, pcbID + "_temp");

                dtBoard = new System.Data.DataTable();
                dtBoard.Columns.Add("OPConfirmed");
                dtBoard.Columns.Add("OPConfirmedSource");
                dtBoard.Columns.Add("Result");

                if (!Directory.Exists(AstrFolder))
                {
                    //AstrFolder = Path.Combine(_strSPCDataFolder, pcbID + "_Finish");
                    //if (!Directory.Exists(AstrFolder))
                    //{ 

                    //}
                    dtBoard.Rows.Add(1);
                    dtBoard.Rows[0]["OPConfirmed"] =1;
                    dtBoard.Rows[0]["OPConfirmedSource"] = 2;
                    dtBoard.Rows[0]["Result"] = 2;
                    return dtBoard;
                }
                 
                string strRVFile = Path.Combine(AstrFolder, "rvconfirm");
                if (!File.Exists(strRVFile))
                {
                    return dtBoard;
                }

              
                strRVFile = Path.Combine(AstrFolder, "tbBoard");
                if (!File.Exists(strRVFile))
                {
                    LogRecord(strRVFile + " not exist");
                    return dtBoard;
                }
                FileStream fs = new FileStream(strRVFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;

                while ((strLine = sr.ReadLine()) != null)
                {

                    aryLine = strLine.Split(',');
                    if (aryLine.Length >= 18)
                    {
                        dtBoard.Rows.Add(1);
                        dtBoard.Rows[0]["OPConfirmed"] = aryLine[8];
                        dtBoard.Rows[0]["OPConfirmedSource"] = aryLine[17];
                        dtBoard.Rows[0]["Result"] = aryLine[6];
                        break;
                    }
                }
                sr.Close();
                fs.Close();



            }
            catch (Exception ex)
            {
                LogRecord("GetRVBoardResult:" + ex.Message);
                throw;
            }

            return dtBoard;
        }


        public System.Data.DataTable GetRVPadResult(SPCBoardRes ABrdRes, PCBGeneralInfo APCBGeneralInfo, AppSettingData AappSettingData, InspectConfig.ConfigData AConfigData)
        {
            System.Data.DataTable dtPad = new System.Data.DataTable();
            try
            {
                ST_SPC_CSVParam csvParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData,APCBGeneralInfo, ABrdRes);
                if (csvParam.EnSaveCSV == false)
                {
                    LogRecord("GetRVPadResult-->csvParam.EnSaveCSV == false");
                    return dtPad;
                }

                //if (!string.IsNullOrEmpty(csvParam.SaveCSV_Path) && csvParam.SaveCSV_Path.Trim() != "")
                //    _strSPCDataFolder = csvParam.SaveCSV_Path;
                string pcbID = ABrdRes.pcbID.ToString();
                string AstrFolder = Path.Combine(_strSPCDataFolder, pcbID + "_temp");
                if (!Directory.Exists(AstrFolder))
                {
                    //AstrFolder = Path.Combine(_strSPCDataFolder, pcbID + "_Finish");
                    return dtPad;
                }
                  



                string strRVFile = Path.Combine(AstrFolder, "tbPadMeasure_ChangeResult_RV");
                if (!File.Exists(strRVFile))
                {
                    LogRecord(strRVFile + " not exist");
                    return dtPad;
                }

                dtPad.Columns.Add("PadIndex");
                dtPad.Columns.Add("JudgeRes");
                FileStream fs = new FileStream(strRVFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;

                while ((strLine = sr.ReadLine()) != null)
                {

                    aryLine = strLine.Split(',');
                    if (aryLine.Length >= 3)
                    {
                        if (Convert.ToInt32(aryLine[1]) == 2)
                        {
                            dtPad.Rows.Add(1);
                            dtPad.Rows[0]["PadIndex"] = aryLine[2];
                            dtPad.Rows[0]["JudgeRes"] = aryLine[1];
                        }


                    }
                }
                sr.Close();
                fs.Close();

            }
            catch (Exception ex)
            {
                LogRecord("GetRVBoardResult:" + ex.Message);
                throw;
            }

            return dtPad;
        }

        //RV
        //     public string TransToCSV_tbPadMeasure_CR_RV(ref Pad_RV[] APads, string AstrFolder)
        //     {
        //         String strMsg = String.Empty;
        //         try
        //         {
        //             if (APads == null || APads.Length == 0)
        //             {
        //                 //Directory.Move(AstrFolder, AstrFolder + "_Finish");
        //                 strMsg = "APads is null or empty";
        //                 goto End;
        //             }
        //             // string pcbID = ABrdRes.pcbID.ToString();
        //             // string strFolder = Path.Combine(_strSPCDataFolder, AiPCBID.ToString());
        //             if (!Directory.Exists(AstrFolder))
        //                 Directory.CreateDirectory(AstrFolder);
        //             string strFilePath = Path.Combine(AstrFolder, "tbPadMeasure_ChangeResult_RV");
        //             if (File.Exists(strFilePath))
        //                 File.Delete(strFilePath);

        //             //string strFilePath_Skip = Path.Combine(AstrFolder, "tbPadMeasure_Skip_RV");
        //             //if (File.Exists(strFilePath_Skip))
        //             //    File.Delete(strFilePath_Skip);

        //             StringBuilder strBld_Change = new StringBuilder();
        //           //  StringBuilder strBld_Skip = new StringBuilder();

        //             for (int i = 0; i < APads.Length; i++)
        //             {

        //                 //if (APads[i].jugRes == Convert.ToInt32(JudgeRes.Skipped))
        //                 //{
        //                 //    strBld_Skip.Append(APads[i].PadID + RS_SPLIT);
        //                 //}
        //                  if (APads[i].jugRes == Convert.ToInt32(JudgeRes.Pass))
        //                 {
        //                     strBld_Change.Append(APads[i].PadID + RS_SPLIT);
        //                 }

        //             }
        //             StreamWriter streamWrt = new StreamWriter(new FileStream(strFilePath, FileMode.Append), Encoding.Default);
        //             streamWrt.Write(strBld_Change);
        //             streamWrt.Close();
        //             streamWrt.Dispose();

        //             //StreamWriter streamWrt_G = new StreamWriter(new FileStream(strFilePath_Skip, FileMode.Append), Encoding.Default);
        //             //streamWrt_G.Write(strBld_Skip);
        //             //streamWrt_G.Close();
        //             //streamWrt_G.Dispose();

        //             //Directory.Move(AstrFolder, AstrFolder + "_Finish");
        //         }
        //         catch (System.Exception ex)
        //         {
        //             // MessageBox.Show("Error in save SPC data Board table!->" + ex.ToString());
        //             strMsg = "Exception:" + ex.ToString();

        //         }
        //         finally
        //         {
        //             //if (!string.IsNullOrEmpty(strMsg))
        //             //    _imgBinCSBaseF.LogRecord(PubStaticParam.RS_DATABASE_LOG, "Mode:" + AMode.ToString() + ";" + strMsg, false);
        //         }

        //End:
        //         strMsg += UpdateTbBoard(AstrFolder, ABrdRes, AappSettingData);
        //          UpdateFolderName(AstrFolder, "RVconfirm");
        //         return strMsg;
        //     }
        //     //RV
        public Pad[] ReadPadInfoFromCSV_RV(string AstrFileName, string AstrFileName_Pass, bool AbAfterUIConfirmed = false)
        {
            List<Pad> lstPads = new List<Pad>();
            if (AbAfterUIConfirmed && !File.Exists(AstrFileName_Pass))
                return lstPads.ToArray();
            FileStream fs = new FileStream(AstrFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            string strLine = "";
            string[] aryLine = null;
            // string[] arrSkip = null;
            string[] arrPass = null;
            //if (File.Exists(AstrFileName_Skip))
            //{
            //    string strSkip = File.ReadAllText(AstrFileName_Skip);
            //    arrSkip = strSkip.Split(',');
            //}
            if (File.Exists(AstrFileName_Pass))
            {
                string strPass = File.ReadAllText(AstrFileName_Pass);
                if (strPass.Trim() != "")
                    arrPass = strPass.Split(',');
            }

            StringBuilder sb = new StringBuilder(PubStaticParam._iStringBuilderCapacity, PubStaticParam._iStringBuilderMaxCapacity);
            int iJudgeResult;
            while ((strLine = sr.ReadLine()) != null)
            {

                aryLine = strLine.Split(',');
                if (aryLine.Length >= 21)
                {
                    Pad pad = new Pad();
                    pad.padID = Convert.ToInt32(aryLine[1]);
                    pad.res = new PadRes();
                    pad.res.measuredValue = new Value3DSPI();
                    pad.res.measuredValue.height = Convert.ToDouble(aryLine[5]);
                    pad.res.measuredValue.area = Convert.ToDouble(aryLine[6]);
                    pad.res.measuredValue.vol = Convert.ToDouble(aryLine[7]);
                    pad.res.measuredValue.offsetX = Convert.ToDouble(aryLine[8]);
                    pad.res.measuredValue.offsetY = Convert.ToDouble(aryLine[9]);
                    pad.res.measuredValue.perHeight = Convert.ToDouble(aryLine[10]);
                    pad.res.measuredValue.perArea = Convert.ToDouble(aryLine[11]);
                    pad.res.measuredValue.perVol = Convert.ToDouble(aryLine[12]);
                    pad.res.measuredValue.bridgeType = Convert.ToByte(aryLine[13]);
                    pad.res.jugDefectType = (DefectType)Convert.ToInt32(aryLine[14]);

                    pad.baseType = Convert.ToInt32(aryLine[16]);
                    pad.res.measuredValue.maxMeanHeightDelta = Convert.ToDouble(aryLine[17]);
                    pad.spi2DRes = new ImageProcessingCPP.SPI2DRes();
                    pad.spi2DRes.sPadAreaPerc = Convert.ToInt16(aryLine[18]);
                    pad.arrayIDIndex = Convert.ToInt16(aryLine[19]);
                    if (aryLine[20].Trim() != "")
                    {
                        pad.spi2DRes =
                           (ImageProcessingCPP.SPI2DRes)PubFunction.DoDeserializeByte2Object(Convert.FromBase64String(aryLine[20]));
                    }
                    iJudgeResult = Convert.ToInt32(aryLine[15]);
                    if (arrPass != null && arrPass.Contains(aryLine[1]))
                        iJudgeResult = 2;
                    //if (arrSkip != null && arrSkip.Contains(aryLine[1]))
                    //    iJudgeResult = 4;
                    pad.res.jugRes = (JudgeRes)iJudgeResult;
                    lstPads.Add(pad);

                }

            }
            //if (sb.Length > 0)
            //    ExecuteNonQuery(sb);

            sr.Close();
            fs.Close();

            return lstPads.ToArray();

        }

        public string SavePadImage(
         InspectMainLib.Pad[] APads,
         InspectMainLib.SPCBoardRes ABrdRes,
            //List<int> AlstPadIndex_2D,
            //List<int> AlstPadIndex_3D, 
         ST_SPC_CSV_SavePara AstSavePara,
         AppSettingData AappSettingData,
         ST_SPC_CSVParam AParams,
         int AiMaxThreadNum = 12)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();


            //if (AappSettingData.enPadDebug)
            //{
            //    LogRecord(" PadID:"+ AstSavePara.lstSavePadImgPara[0].PadID.ToString());
            //}
            if (ABrdRes.jugResult == JudgeRes.Unmeasured)
            {
                LogRecord("PCBID=" + ABrdRes.pcbID.ToString()+",Result=Unmeasured");
                return "Unmeasured";
            }
            InspectMainLib.InspectAlgCore _inspAlgCor = new InspectMainLib.InspectAlgCore();
            string strMsg = string.Empty;
            if (!Directory.Exists(AstSavePara.strSavePath)) return (strMsg = "No Folder");
            string strFolder = AstSavePara.strSavePath;
            string strImage = Path.Combine(strFolder, "images");
            if (Directory.Exists(strImage) == false)
            {
                Directory.CreateDirectory(strImage);
            }
            //if (AappSettingData.enPadDebug)
            //{
            //    LogRecord("收到接口SavePadImage=>参数 2D_3D AlstPadIndex分别长度:" + AstSavePara.lstSavePadImgPara.Count.ToString());
            //}
            if (APads == null || APads.Length <= 0)
            {
                strMsg = "APads_IS_NULL";
                goto Update;
            }

            try
            {
                //System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcesses();
                //if (AiMaxThreadNum > processes.Length)
                //{
                //    AiMaxThreadNum = processes.Length;
                //}
                //create subfolder
                int i = 0, iPadIndex0 = 0;
                List<int> lstPadIndex_3DIn2D = new List<int>();
                //List<int> lstPadIndex_3DNotIn2D = new List<int>();
                int iCount =0;
                if( AstSavePara.lstSavePadImgPara != null)
                    iCount= AstSavePara.lstSavePadImgPara.Count;


                //if (AappSettingData.enPadDebug)
                //{
                //    LogRecord("lstPadIndex_3DIn2D长度:" + lstPadIndex_3DIn2D.Count + "");
                //}
                if (iCount == 0)
                {
                    strMsg = "lstSavePadImgPara_IS_NULL";
                    goto Update;
                }
                //gen 2D Img
                int iProcessorCount = Environment.ProcessorCount - 1;
                if (iProcessorCount <= 0)
                    iProcessorCount = 1;
                //int iPadIndex = 0;
                bool bIsRbyte = false;
                ST_SPC_CSV_PadImg[] lstPad2D3D = new ST_SPC_CSV_PadImg[iCount];
                string strImageFile = Path.Combine(strImage, "1" + ".imageData");
                if (iCount > 0)
                {
                    //Basefunction[] baseFunctions = new Basefunction[iProcessorCount];
                    Parallel.ForEach(Partitioner.Create(0, iCount, ((int)(iCount / iProcessorCount) + 1)), range =>
                    {
                        int index = 0;
                        int iPadIndex = 0;
                        //string strImageFile = string.Empty;
                        for (int a = range.Item1; a < range.Item2; a++)
                        {
                            iPadIndex = AstSavePara.lstSavePadImgPara[a].iPadIndex;
                            lstPad2D3D[a] = new ST_SPC_CSV_PadImg();
                            lstPad2D3D[a].PadID = APads[iPadIndex].padID;
                            if (AstSavePara.lstSavePadImgPara[a].bSave2D)
                            {

                                if (AParams.CheckGage)
                                {

                                    lstPad2D3D[a].arrByR = _inspAlgCor.GetBytesFrByt2D(APads[iPadIndex], 0, false);
                                    lstPad2D3D[a].arrByG = _inspAlgCor.GetBytesFrByt2D(APads[iPadIndex], 1, false);

                                    lstPad2D3D[a].arrByB = _inspAlgCor.GetBytesFrByt2D(APads[iPadIndex], 2, false);

                                    lstPad2D3D[a].arrByGr = _inspAlgCor.GetBytesFrShrt2D(APads[iPadIndex], false);
                                }
                                else
                                {
                                    //byte[] aByJPG = null;
                                    strMsg = Basefunction.GetStreamFrPad(APads[iPadIndex], AappSettingData, ImageFormat.Jpeg, out lstPad2D3D[a].arrByR);
                                    // = aByJPG;
                                    //stSPCPadImg.arrByR = APads[iPadIndex].res.measuredValue.img2D_R_1D;
                                    //stSPCPadImg.arrByG = APads[iPadIndex].res.measuredValue.img2D_G_1D;
                                    //stSPCPadImg.arrByB = APads[iPadIndex].res.measuredValue.img2D_B_1D;
                                    //stSPCPadImg.arrSHGr = APads[iPadIndex].res.measuredValue.proc3DGrayData_1D;
                                }
                            }
                            else
                            {
                                lstPad2D3D[a].arrByR = null;
                                lstPad2D3D[a].arrByG = null;
                                lstPad2D3D[a].arrByB = null;
                                lstPad2D3D[a].arrByGr = null;
                                lstPad2D3D[a].arrSHGr = null;
                            }
                            if (AstSavePara.lstSavePadImgPara[a].bSave3D)
                            {
                                //if (lstPadIndex_3DIn2D.Contains(iPadIndex))
                                //{
                                lstPad2D3D[a].arrBy3D = _inspAlgCor.GetBytesFrFlt2D(APads[iPadIndex].res.measuredValue, !AParams.CheckGage);
                                //}
                                //if (lstPad2D3D[a].arrByR != null && lstPad2D3D[a].arrByR.Length > 0)
                                //{
                                //    lstPad2D3D[a] = stSPCPadImg;
                                //    bIsRbyte = true;
                                //}
                            }
                            else
                            {
                                lstPad2D3D[a].arrBy3D = null;
                            }

                        }
                    });
                    //if (lstPad2D3D.Length > 0 && bIsRbyte)
                    //{
                    //    BinaryFormatter formatter = new BinaryFormatter();
                    //    FileStream stream = new FileStream(strImageFile1, FileMode.Create, FileAccess.Write, FileShare.None);
                    //    //stream = new FileStream(AstrFilePath, FileMode.Create);
                    //    //SoapFormatter formatter = new SoapFormatter();
                    //    formatter.Serialize(stream, lstPad2D3D);
                    //    stream.Close();
                    //    stream.Dispose();
                    //    if (AappSettingData.enPadDebug)
                    //    {
                    //        SaveLogsYouJiaInfo("序列化2D3D成功:iPadIndex：", 0 + "");
                    //    }
                    //}
                }

                if (lstPad2D3D != null && lstPad2D3D.Length > 0)
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    FileStream stream = new FileStream(strImageFile, FileMode.Create, FileAccess.Write, FileShare.None);
                    //stream = new FileStream(AstrFilePath, FileMode.Create);
                    //SoapFormatter formatter = new SoapFormatter();
                    formatter.Serialize(stream, lstPad2D3D);
                    stream.Close();
                    stream.Dispose();
                    if (AappSettingData.enPadDebug)
                    {
                        LogRecord("序列化成功:iPadIndex："+ 0 + "");
                    }
                }
            }
            catch (System.Exception ex)
            {
                strMsg += "SavePadImage=>[error]" + ex.Message;
                LogRecord("异常:" + strMsg);
            }
        Update:

            UpdateFileName(strFolder);
            if (AstSavePara.stCSVParam.RVUIStatus == (byte)ENM_RVUIStatus.None || (ABrdRes.jugResult == JudgeRes.Good || ABrdRes.jugResult == JudgeRes.Skipped))
            {
                UpdateFolderName(strFolder, "none");

            }
            // sw.Stop();
            if (AappSettingData.enPadDebug)
            {
                LogRecord("序列化 .UpdateFileName UpdateFolderName:"+ "end..");
            }
            return strMsg;
        }
        #endregion

        #region csv to DB

        public string UploadToDBFromCsv(string AstrFolder )
        {
            string strMsg = string.Empty;
            try
            {
                string strIni=Path.Combine(AstrFolder,_dePeng. RS_SPCINI_FILENAME);
                if (!File.Exists(strIni))
                {
                    Directory.Delete(AstrFolder,true);
                    return "ini not exists";
                }
                string pcbID = AstrFolder.Substring(AstrFolder.LastIndexOf(@"\") + 1);
                pcbID = pcbID.Substring(0, pcbID.IndexOf("_Finish"));
                ST_SPC_CSVParam csvParam = _dePeng.ReadSPCINI(AstrFolder);
                if (csvParam.bySPCDataBaseType == (byte)SPCSAVEMODE.CSV)
                {
                    string strCSV = csvParam.SaveCSV_Path;
                    if (strCSV.Trim() != "")
                    {
                        if (!Directory.Exists(strCSV))
                            Directory.CreateDirectory(strCSV);
                        strCSV = Path.Combine(strCSV, pcbID);
                        if (Directory.Exists(strCSV))
                            Directory.Delete(strCSV, true);
                        //Directory.Move(AstrFolder, strCSV);
                        CopyFolder(AstrFolder,strCSV);
                        Thread.Sleep(300);
                        Directory.Delete(AstrFolder,true);
                    }
                    
                    return "CSV Mode";
                }                
                else if (csvParam.EnUpLoadCSV == false)
                    return "EnUpLoadCSV=false";

               
                StringBuilder strBld = new StringBuilder();
                strBld.AppendLine(string.Format("delete from tbBoard where PCBID={0};", pcbID));
                strBld.AppendLine(string.Format("delete from tbBarcode where PCBID={0};", pcbID));
                strBld.AppendLine(string.Format("delete from tbPadMeasure where PCBID={0};", pcbID));
                ExecuteNonQuery(strBld);
                strMsg += InsertDataToDBFromCSV_tbBoard(Path.Combine(AstrFolder, "tbBoard"));
                strMsg += InsertDataToDBFromCSV_tbBarcode(Path.Combine(AstrFolder, "tbBarcode"));
                strMsg += InsertDataToDBFromCSV_tbPadMeasure(Path.Combine(AstrFolder, "tbPadMeasure_NG"), Path.Combine(AstrFolder, "tbPadMeasure_ChangeResult"));
                strMsg += InsertDataToDBFromCSV_tbPadMeasure(Path.Combine(AstrFolder, "tbPadMeasure_Good"));

                ST_SPC_CSVParam csvParam_RV =  ReadRVINI(_strSPCDataFolder);
                string AstrBackupFolder = _strSPCDataFolder_Backup;
                if (!string.IsNullOrEmpty(csvParam.SaveCSV_BackUpPath))
                    AstrBackupFolder = csvParam.SaveCSV_BackUpPath;
            
                
                if (!Directory.Exists(AstrBackupFolder))
                    Directory.CreateDirectory(AstrBackupFolder);
                string strBackup = Path.Combine(AstrBackupFolder, pcbID);
                if (Directory.Exists(strBackup))
                    Directory.Delete(strBackup, true);
                //DirectoryInfo diFrom = new DirectoryInfo(AstrFolder);
                //diFrom.MoveTo(strBackup);
                CopyFolder(AstrFolder, strBackup);
                Thread.Sleep(300);
                Directory.Delete(AstrFolder,true);
            }
            catch (Exception ex)
            {
                strMsg = ex.Message;
            }
            LogRecord("UploadToDBFromCsv" + strMsg);
            return strMsg;
        }

        public string InsertDataToDBFromCSV_tbBoard(string AstrFileName)
        {
            string strFuncName = "tbBoard:";
            if (!File.Exists(AstrFileName))
                return strFuncName + "File no exist";
            string strMsg = string.Empty;
            try
            {
                FileStream fs = new FileStream(AstrFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;
                DateTime dtTemp;
                string strInspectTimeStamp, strStartTime, strEndTime, strOPConfirmTime;
                StringBuilder sb = new StringBuilder(PubStaticParam._iStringBuilderCapacity, PubStaticParam._iStringBuilderMaxCapacity);

                while ((strLine = sr.ReadLine()) != null)
                {

                    aryLine = strLine.Split(',');
                    if (aryLine.Length >= 15)
                    {
                        strInspectTimeStamp = strStartTime = strEndTime = strOPConfirmTime = "null";
                        if (DateTime.TryParse(aryLine[3], out dtTemp))
                            strInspectTimeStamp = "'" + dtTemp.ToString(RS_DATETIME_Format) + "'";
                        if (DateTime.TryParse(aryLine[4], out dtTemp))
                            strStartTime = "'" + dtTemp.ToString(RS_DATETIME_Format) + "'";
                        if (DateTime.TryParse(aryLine[5], out dtTemp))
                            strEndTime = "'" + dtTemp.ToString(RS_DATETIME_Format) + "'";

                        string strOperator = "";
                        string strOPConfirmedSource = "";
                        if (aryLine.Length >= 18)
                        {
                            if (DateTime.TryParse(aryLine[15], out dtTemp))
                                strOPConfirmTime = "'" + dtTemp.ToString(RS_DATETIME_Format) + "'";
                            strOperator= aryLine[16];
                            strOPConfirmedSource = aryLine[17];
                        }
                      
                        sb.Append(string.Format(@"insert into tbBoard(PCBID,JobIndex,BlockID,InspectTimeStamp,StartTime,EndTime,Result,PCBBarcode,OPConfirmed,Squeege,VendorID,LineNo,LotNo,LaneNo,StencilID
                                                ,OPConfirmedSource,OPConfirmTime,Operator)values
                                                    ({0},{1},'{2}',{3},{4},{5},{6},'{7}',{8},'{9}','{10}','{11}','{12}','{13}','{14}' ,'{15}',{16},'{17}');"
                                             , aryLine[0], aryLine[1], aryLine[2], strInspectTimeStamp, strStartTime, strEndTime, aryLine[6], aryLine[7], aryLine[8], aryLine[9], aryLine[10], aryLine[11], aryLine[12], aryLine[13], aryLine[14], strOPConfirmedSource,strOPConfirmTime, strOperator));

                        if (sb.Length > PubStaticParam._iStringBuilderCapacity * 5)
                        {
                            ExecuteNonQuery(sb);
                            sb.Clear();

                        }
                    }

                }
                if (sb.Length > 0)
                    ExecuteNonQuery(sb);

                sr.Close();
                fs.Close();
            }
            catch (Exception ex)
            {
                strMsg = strFuncName + ex.Message;
            }
            return strMsg;


        }

        public string InsertDataToDBFromCSV_tbBarcode(string AstrFileName)
        {
            string strFuncName = "tbBarcode:";
            if (!File.Exists(AstrFileName))
                return strFuncName + "File no exist";
            string strMsg = string.Empty;
            try
            {
                FileStream fs = new FileStream(AstrFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;

                StringBuilder sb = new StringBuilder(PubStaticParam._iStringBuilderCapacity, PubStaticParam._iStringBuilderMaxCapacity);

                while ((strLine = sr.ReadLine()) != null)
                {

                    aryLine = strLine.Split(',');
                    if (aryLine.Length >= 6)
                    {

                        sb.Append(string.Format(@"insert into tbBarcode(PCBID,LineNo,BarCode,ArrayBarCode,ArrayID,IndexSerNo)values
                                                    ({0},'{1}','{2}','{3}',{4},{5});"
                                             , aryLine[0], aryLine[1], aryLine[2], aryLine[3], aryLine[4], aryLine[5]));


                        if (sb.Length > PubStaticParam._iStringBuilderCapacity * 5)
                        {
                            ExecuteNonQuery(sb);
                            sb.Clear();

                        }
                    }

                }
                if (sb.Length > 0)
                    ExecuteNonQuery(sb);

                sr.Close();
                fs.Close();

            }
            catch (Exception ex)
            {
                strMsg = strFuncName + ex.Message;
            }
            return strMsg;


        }

        public string InsertDataToDBFromCSV_tbPadMeasure(string AstrFileName, string AstrFileName_Pass = "")
        {

            if (!File.Exists(AstrFileName))
                return AstrFileName + " File no exist";
            string strMsg = string.Empty;
            try
            {
                FileStream fs = new FileStream(AstrFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                string strLine = "";
                string[] aryLine = null;
                //string[] arrSkip = null;
                string[] arrPass = null;
                //if (File.Exists(AstrFileName_Skip))
                //{
                //    string strSkip = File.ReadAllText(AstrFileName_Skip);
                //    if (strSkip.Trim() != "")
                //        arrSkip = strSkip.Split(',');
                //}

                // ui 确认
                if (AstrFileName_Pass != "" && AstrFileName.EndsWith("_NG") && File.Exists(AstrFileName_Pass))
                {
                    string strPass = File.ReadAllText(AstrFileName_Pass);
                    if (strPass.Trim() != "")
                        arrPass = strPass.Split(',');

                }
                string strFolder = AstrFileName.Substring(0, AstrFileName.LastIndexOf(@"\"));
                // rv 确认
                List<Pad_RV> lstPadRV = new List<Pad_RV>();
                if (AstrFileName_Pass != "" &&  AstrFileName.EndsWith("_NG") && File.Exists(AstrFileName_Pass)==false)
                {
                    string strRVFile = Path.Combine(strFolder, "tbPadMeasure_ChangeResult_RV");
                    if (File.Exists(strRVFile))
                    {

                        FileStream fs_RV = new FileStream(strRVFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                        StreamReader sr_RV = new StreamReader(fs_RV, Encoding.UTF8);
                        while ((strLine = sr_RV.ReadLine()) != null)
                        {

                            aryLine = strLine.Split(',');
                            if (aryLine.Length > 2)
                            {
                                lstPadRV.Add(new Pad_RV
                                {
                                    PadID = Convert.ToInt32(aryLine[0]),
                                    jugRes = Convert.ToInt32(aryLine[1]),
                                    DefectTypeIndex = Convert.ToInt32(aryLine[2])
                                });
                            }
                        }
                        fs_RV.Close();
                        sr_RV.Close();
                    }
 
                }
              
               

                StringBuilder sb = new StringBuilder(PubStaticParam._iStringBuilderCapacity, PubStaticParam._iStringBuilderMaxCapacity);

                string strPadID, Img2D_R, Img2D_G, Img2D_B, Img2D_Gray, Img3DHeight;
                int iJudgeResult;
             string strDefectTypeIndex;
              
               // read ini
                ST_SPC_CSVParam csvParam = _dePeng.ReadSPCINI(strFolder);
                ST_SPC_CSV_PadImg[] arrPadImg = null;
                // 读取图片  
                _dePeng.LoadPadImage(csvParam, strFolder, 1, ref arrPadImg, 12);

                ST_SPC_CSV_PadImg stPadImg;

                DAL_SPC.MySQLHelper mysqlHelper = new MySQLHelper();
                DAL_SPC.ImageDataHelper imgDataHelper = new DAL_SPC.ImageDataHelper();
                System.Data.DataTable dtPad = new System.Data.DataTable();
                string strPadDT = "select * from tbPadMeasure where 1<>1";
                if (csvParam.CheckGage)
                {
                    dtPad = _beanMySql.GetDataTableFrSQL(strPadDT);
 
                }
                while ((strLine = sr.ReadLine()) != null)
                {

                    aryLine = strLine.Split(',');
                    if (aryLine.Length >= 21)
                    {
                        strPadID = aryLine[1];
                        //if (arrSkip != null && arrSkip.Contains(strPadID))
                        //    continue;
                        iJudgeResult = Convert.ToInt32(aryLine[15]);
                        strDefectTypeIndex= aryLine[14];
                        if (arrPass != null)// ui  NG-->Pass
                        {
                            if( arrPass.Contains(strPadID))
                                iJudgeResult = 2;        

                        }else if(lstPadRV.Count > 0)
                        {
                            var padRV = lstPadRV.FirstOrDefault(p => p.PadID == Convert.ToInt32(strPadID));
                            if (padRV.PadID != 0)
                            {
                                iJudgeResult = padRV.jugRes;
                                strDefectTypeIndex=padRV.DefectTypeIndex.ToString();
                            }
                        }
                                           
                       

                        Img2D_R = Img2D_G = Img2D_B = Img2D_Gray = Img3DHeight = "null";
                        if (aryLine[20].Trim() != "")
                            Img2D_G = "'" + aryLine[20] + "'";

                        stPadImg=new ST_SPC_CSV_PadImg();
                        if (arrPadImg != null && arrPadImg.Length > 0)
                        {
                            stPadImg = arrPadImg.FirstOrDefault(img => img.PadID == Convert.ToInt32(strPadID));
                            if (stPadImg.PadID != 0)
                            {
                                 
                                if (stPadImg.arrByG != null)
                                {
                                    Img2D_R = "'" + Encoding.Default.GetString(stPadImg.arrByR) + "'";
                                    Img2D_G = "'" + Encoding.Default.GetString(stPadImg.arrByG) + "'";
                                    Img2D_B = "'" + Encoding.Default.GetString(stPadImg.arrByB) + "'";
                                    Img2D_Gray = "'" + Encoding.Default.GetString(stPadImg.arrByGr) + "'";
                                }else
                                    Img2D_R = "'" + mysqlHelper.GetStringFromByte(imgDataHelper.Compress(stPadImg.arrByR)) + "'";

                                Img3DHeight = "'z" + mysqlHelper.GetStringFromByte(imgDataHelper.Compress(stPadImg.arrBy3D)) + "'";
                            }
                         
                        }

                        if (csvParam.CheckGage)
                        {
                            dtPad.Rows.Add(1);
                            #region add fields

                            

                            dtPad.Rows[dtPad.Rows.Count-1]["PCBID"]=aryLine[0];
                            dtPad.Rows[dtPad.Rows.Count-1]["PadID"]=aryLine[1];
                            dtPad.Rows[dtPad.Rows.Count-1]["LineNo"]=aryLine[2];
                            dtPad.Rows[dtPad.Rows.Count-1]["JobIndex"]=aryLine[3];
                            dtPad.Rows[dtPad.Rows.Count-1]["PadIndex"]=aryLine[4];
                            dtPad.Rows[dtPad.Rows.Count-1]["ABSHeight"]=aryLine[5];
                            dtPad.Rows[dtPad.Rows.Count-1]["ABSArea"]=aryLine[6];
                            dtPad.Rows[dtPad.Rows.Count-1]["ABSVolume"]=aryLine[7];
                            dtPad.Rows[dtPad.Rows.Count-1]["ShiftX"]=aryLine[8];
                            dtPad.Rows[dtPad.Rows.Count-1]["ShiftY"]=aryLine[9];
                            dtPad.Rows[dtPad.Rows.Count-1]["PerHeight"]=aryLine[10];
                            dtPad.Rows[dtPad.Rows.Count-1]["PerArea"]=aryLine[11];
                            dtPad.Rows[dtPad.Rows.Count-1]["PerVolume"]=aryLine[12];
                            dtPad.Rows[dtPad.Rows.Count-1]["BridgeType"]=aryLine[13];
                            dtPad.Rows[dtPad.Rows.Count-1]["DefectType"]=aryLine[14];
                            dtPad.Rows[dtPad.Rows.Count-1]["JudgeRes"]=iJudgeResult;
                            dtPad.Rows[dtPad.Rows.Count-1]["BaseType"]=aryLine[16];
                            dtPad.Rows[dtPad.Rows.Count-1]["ABSShape"]=aryLine[17]; 
                            dtPad.Rows[dtPad.Rows.Count-1]["PadArea"]=aryLine[18];
                            dtPad.Rows[dtPad.Rows.Count-1]["ArrayIDIndex"]=aryLine[19];

                             if (stPadImg.PadID != 0)
                            {
                                 
                                if (stPadImg.arrByG != null)
                                {
                                    
                                    dtPad.Rows[dtPad.Rows.Count-1]["Img2D_R"]=stPadImg.arrByR;
                                    dtPad.Rows[dtPad.Rows.Count-1]["Img2D_G"]=stPadImg.arrByG;
                                    dtPad.Rows[dtPad.Rows.Count-1]["Img2D_B"]=stPadImg.arrByB;
                                    dtPad.Rows[dtPad.Rows.Count-1]["Img2D_Gray"]=stPadImg.arrByGr;

                                }else
                                     dtPad.Rows[dtPad.Rows.Count-1]["Img2D_R"] =  imgDataHelper.Compress(stPadImg.arrByR) ;

                                dtPad.Rows[dtPad.Rows.Count - 1]["Img3DHeight"] = stPadImg.arrBy3D;
                              
                            }

                          
                            #endregion
                        }
                        else {
                            sb.Append(string.Format(@"insert into  tbPadMeasure(PCBID,PadID,LineNo,JobIndex,PadIndex,ABSHeight,ABSArea,ABSVolume,ShiftX,ShiftY,PerHeight,PerArea,PerVolume
                                              ,BridgeType,DefectType,JudgeRes,BaseType,ABSShape,PadArea,ArrayIDIndex,Img2D_R, Img2D_G, Img2D_B, Img2D_Gray, Img3DHeight)values
                                                    ({0},{1},'{2}',{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19} ,{20},{21},{22},{23},{24});"
                                            , aryLine[0], aryLine[1], aryLine[2], aryLine[3], aryLine[4], aryLine[5], aryLine[6], aryLine[7], aryLine[8], aryLine[9], aryLine[10], aryLine[11], aryLine[12]
                                            , aryLine[13], strDefectTypeIndex, iJudgeResult, aryLine[16], aryLine[17], aryLine[18], aryLine[19], Img2D_R, Img2D_G, Img2D_B, Img2D_Gray, Img3DHeight));

                            if (sb.Length > PubStaticParam._iStringBuilderCapacity * 5)
                            {
                                ExecuteNonQuery(sb);
                                sb.Clear();

                            }

                        }
                       
                    }

                }
                if (csvParam.CheckGage)
                {
                    UpdateDataTable(dtPad, strPadDT);
                }
                else if (sb.Length > 0)
                {
                    ExecuteNonQuery(sb);
                }
                

                sr.Close();
                fs.Close();
            }
            catch (Exception ex)
            {
                strMsg = "tbPadMeasure" + ex.Message;
            }
            return strMsg;

        }


        #endregion

        #region GetLastPCBID

        public int GetLastPCBID(AppSettingData AappSettingData)
        {


            int iMaxPCBID = 1;
            try
            {
                if (AappSettingData.stSPCParams.spcSaveModeType == SPCSAVEMODE.CSV)
                {
                    iMaxPCBID = GetLastPCBID_CSV(AappSettingData);
                    int pcbID = GetLastPCBID_CSV(_strSPCDataFolder);
                    if (pcbID > iMaxPCBID)
                        iMaxPCBID = pcbID;
                }
                else if (AappSettingData.stSPCParams.spcSaveModeType == SPCSAVEMODE.V2)
                {
                    iMaxPCBID = GetLastPCBID_V2();
                    int pcbID = GetLastPCBID_CSV(_strSPCDataFolder);
                    if (pcbID > iMaxPCBID)
                        iMaxPCBID = pcbID;
                }
            }
            catch (Exception ex)
            {
                if (AappSettingData.enPadDebug)
                    LogRecord("GetLastPCBID=" + ex.Message);
                throw;
            }

            if (AappSettingData.enPadDebug)
                LogRecord("iMaxPCBID=" + iMaxPCBID);
            return iMaxPCBID;

        }

        public int GetLastPCBID_V2()
        {
            int iMaxPCBID = 1;
            try
            {
                string strSQLSelectMaxPCBID = "SELECT MAX(PCBID) AS PCBID FROM TBBoard";

                List<string> lstFieldValue = _beanMySql.GetFieldValueFrSQL(strSQLSelectMaxPCBID);
                if (lstFieldValue.Count > 0)
                {
                    if (!string.IsNullOrEmpty(lstFieldValue[0]))
                        iMaxPCBID = Convert.ToInt32(lstFieldValue[0]) + 1;
                }

            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return iMaxPCBID;

        }

        public int GetLastPCBID_CSV(AppSettingData AappSettingData)
        {
            int iMaxPCBID = 1;
            try
            {
                string csvPath = _strSPCDataFolder;
                if (!string.IsNullOrEmpty(AappSettingData.stSPCParams.SaveCSV_Path) && Directory.Exists(AappSettingData.stSPCParams.SaveCSV_Path))
                    csvPath = AappSettingData.stSPCParams.SaveCSV_Path;
                if (!Directory.Exists(csvPath))
                    return iMaxPCBID;
                string[] arrList = Directory.GetDirectories(csvPath);
                if (arrList == null || arrList.Length <= 0)
                    return iMaxPCBID;
                List<DirectoryInfo> lstDI = new List<DirectoryInfo>();
                foreach (string path in arrList)
                {
                    lstDI.Add(new DirectoryInfo(path));

                }
                DirectoryInfo[] arrDI = lstDI.ToArray();
                SortAsFolderCreationTime(ref arrDI);
                string pcbID = arrDI[0].Name;
                if (pcbID.EndsWith("_Finish"))
                    pcbID = pcbID.Substring(0, pcbID.IndexOf("_Finish"));
                else if (pcbID.EndsWith("_temp"))
                    pcbID = pcbID.Substring(0, pcbID.IndexOf("_temp"));
                iMaxPCBID = Convert.ToInt32(pcbID) + 1;

            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return iMaxPCBID;

        }

        public int GetLastPCBID_CSV(string AstrFolder)
        {
            int iMaxPCBID = 1;
            try
            {
                string csvPath = AstrFolder;
                if (!Directory.Exists(csvPath))
                    return iMaxPCBID;
                string[] arrList = Directory.GetDirectories(csvPath);
                if (arrList == null || arrList.Length <= 0)
                    return iMaxPCBID;
                List<DirectoryInfo> lstDI = new List<DirectoryInfo>();
                foreach (string path in arrList)
                {
                    lstDI.Add(new DirectoryInfo(path));

                }
                DirectoryInfo[] arrDI = lstDI.ToArray();
                SortAsFolderCreationTime(ref arrDI);
                string pcbID = arrDI[0].Name;
                if (pcbID.EndsWith("_Finish"))
                    pcbID = pcbID.Substring(0, pcbID.IndexOf("_Finish"));
                else if (pcbID.EndsWith("_temp"))
                    pcbID = pcbID.Substring(0, pcbID.IndexOf("_temp"));
                iMaxPCBID = Convert.ToInt32(pcbID) + 1;

            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return iMaxPCBID;

        }
        #endregion


        #region base function

        private static void CopyFolder(string from, string to)
        {
            if (!Directory.Exists(to))
                Directory.CreateDirectory(to);
            // 子文件夹
            foreach (string sub in Directory.GetDirectories(from))
                CopyFolder(sub + "\\",Path.Combine( to , Path.GetFileName(sub) ) );
            // 文件
            foreach (string file in Directory.GetFiles(from))
                File.Copy(file, Path.Combine( to , Path.GetFileName(file)), true);
        }
        private bool UpdateDataTable(  System.Data.DataTable AdttbUpdate, string AstrSQLSel)
        {
            bool bCorr = true;
            //if (false)
            {

                MySqlConnection connMySQL = new MySqlConnection(_strSPIDBConnString);
                MySqlDataAdapter daptMySQL = null;
                MySqlCommandBuilder cmdMySQL = null;
                MySqlTransaction tranMySQL = null;
                try
                {

                    connMySQL.Open();
                    tranMySQL = connMySQL.BeginTransaction();
                    daptMySQL = new MySqlDataAdapter(AstrSQLSel, connMySQL);
                    daptMySQL.SelectCommand.Transaction = tranMySQL;

                    cmdMySQL = new MySqlCommandBuilder(daptMySQL);


                    daptMySQL.Update(AdttbUpdate);
                    tranMySQL.Commit();
                    connMySQL.Close();

                }
                catch (Exception ex)
                {
                    bCorr = false;

                    throw ex;

                }
                finally
                {
                    if (connMySQL != null)
                    {
                        connMySQL.Close();
                    }
                    if (cmdMySQL != null)
                        cmdMySQL.Dispose();
                    if (daptMySQL != null)
                        daptMySQL.Dispose();
                    if (tranMySQL != null)
                        tranMySQL.Dispose();
                    if (connMySQL != null)
                    {
                        connMySQL.Dispose();
                    }

                }
            }
            //bCorr = false;
            return bCorr;
        }
        public int ExecuteNonQuery(StringBuilder sb)
        {
            MySqlConnection connMySQL = new MySqlConnection(_strSPIDBConnString);
            MySqlCommand cmdMySQL = new MySqlCommand();
            int intReturn = 0;
            try
            {
                if (sb.Length > 0)
                {
                    connMySQL.Open();
                    cmdMySQL = connMySQL.CreateCommand();
                    cmdMySQL.CommandTimeout = _iCommandTimeout;
                    cmdMySQL.CommandText = "START TRANSACTION;" + sb + "COMMIT;";
                    intReturn = cmdMySQL.ExecuteNonQuery();
                }
                return intReturn;
            }
            catch (Exception ex)
            {
                // PubParams._log.WriteErr(cmdMySQL.CommandText + "|" + ex.ToString());
                throw ex;
            }
            finally
            {
                if (connMySQL.State != ConnectionState.Closed)
                {
                    connMySQL.Close();
                    connMySQL.Dispose();
                }
                cmdMySQL.Dispose();

            }

        }

        public int ExecuteNonQuery(string strSQL)
        {
            MySqlConnection connMySQL = new MySqlConnection(_strSPIDBConnString);
            MySqlCommand cmdMySQL = new MySqlCommand();
            int intReturn = 0;
            try
            {
                if (!string.IsNullOrEmpty(strSQL))
                {
                    connMySQL.Open();
                    cmdMySQL = connMySQL.CreateCommand();
                    cmdMySQL.CommandTimeout = PubStaticParam._intCommandTimeout;
                    cmdMySQL.CommandText = strSQL;
                    intReturn = cmdMySQL.ExecuteNonQuery();
                }
                return intReturn;
            }
            catch (Exception ex)
            {
                // PubParams._log.WriteErr(cmdMySQL.CommandText + "|" + ex.ToString());
                throw ex;
            }
            finally
            {
                if (connMySQL.State != ConnectionState.Closed)
                {
                    connMySQL.Close();
                    connMySQL.Dispose();
                }
                cmdMySQL.Dispose();
            }

        }

        private String GetStrByMaxLength(String AstrSrc)
        {
            String strRes;
            if (String.IsNullOrEmpty(AstrSrc))
            {
                strRes = "";
            }
            else
            {
                if (AstrSrc.Length > _iBrcdMaxLength)
                {
                    strRes = AstrSrc.Substring(0, _iBrcdMaxLength - 1);
                }
                else
                {
                    strRes = AstrSrc;
                }
            }
            return strRes;
        }

        public void SortAsFolderCreationTime(ref DirectoryInfo[] dirs)
        {
            Array.Sort(dirs, delegate(DirectoryInfo x, DirectoryInfo y) { return y.CreationTime.CompareTo(x.CreationTime); });
        }

        public static void LogRecord(string strMsg)
        {
            string filePath = @"D:\EYSPI\Bin\SPILogs\Lin";
            if (!Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }
            string logPath = Path.Combine(filePath, DateTime.Now.ToString("yyyy-MM-dd") + ".txt");
            try
            {
                if (!File.Exists(logPath))
                {
                    using (FileStream fs = new FileStream(logPath, FileMode.Create))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        sw.WriteLine("时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                        sw.WriteLine("内容：" + strMsg);
                        sw.WriteLine("**************************************************");
                        sw.WriteLine();
                        sw.Flush();
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    while (IsFileInUse(logPath))
                    {
                        Thread.Sleep(100);
                    }
                    using (FileStream fs = new FileStream(logPath, FileMode.Append))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        sw.WriteLine("时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                        sw.WriteLine("内容：" + strMsg);
                        sw.WriteLine("**************************************************");
                        sw.WriteLine();
                        sw.Flush();
                        sw.Close();
                        sw.Dispose();
                    }
                }

            }
            catch (IOException ex)
            {
                throw ex;
            }
        }

        public static bool IsFileInUse(string fileName)
        {
            bool inUse = true;

            FileStream fs = null;
            try
            {
                if (File.Exists(fileName) == true)
                {
                    fs = new FileStream(fileName, FileMode.Open, FileAccess.Read,

                    FileShare.None);
                }

                inUse = false;
            }
            catch
            {

            }
            finally
            {
                if (fs != null)
                    fs.Close();
            }
            return inUse;//true表示正在使用,false没有使用  
        }

        private int SavePadImage(Pad APad, bool AbbUse1DImage, AppSettingData AappSettingData,
          out bool AoutBSave2DImage, out bool AoutBSave3DImage)
        {

            AoutBSave2DImage = false;
            AoutBSave3DImage = false;

            if (APad.bNotCheck3DResult == false)//Q.F.2018.06.08
            {
                if (AbbUse1DImage == false)
                {
                    if (APad.res.measuredValue.extMatrixData == null)
                        return 1037;
                    if ((APad.res.measuredValue.extMatrixData.GetLength(0) == 0) ||
                        (APad.res.measuredValue.extMatrixData.GetLength(1) == 0))
                        return 1037;
                }
                else
                {

                    if (APad.res.measuredValue.extMatrixData_1D == null)
                        return 1037;
                    if ((APad.res.measuredValue.shExtMatrixHeight == 0) ||
                        (APad.res.measuredValue.shExtMatrixWidth == 0))
                        return 1037;
                }
            }
            if (
                ((AappSettingData.saveDefectImage == true) && (APad.res.jugRes == JudgeRes.NG || APad.res.jugRes == JudgeRes.Pass))
                ||
                 ((AappSettingData.saveGoodImage == true) && (APad.res.jugRes == JudgeRes.Good))
                 )
            {

                AoutBSave2DImage = AappSettingData.saveImage2D;

                if (APad.bNotCheck3DResult == false)//Q.F.2018.06.08
                    AoutBSave3DImage = AappSettingData.saveImage3D;
                else
                    AoutBSave3DImage = false;
            }
            return 0;
        }

        public string CopyFile()
        {
            string strMsg = string.Empty;
            try
            {
                string strOrigFile = @"D:\EYSPI\Bin\Config\AppSetting.bin";
                string strDestFolder = @"D:\EYSPI\Bin\AutoAPPConfig";
                if (!Directory.Exists(strDestFolder))
                    Directory.CreateDirectory(strDestFolder);
                string strDestFilePath = Path.Combine(strDestFolder, "AppSetting.bin");
                File.Copy(strOrigFile, strDestFilePath,true);
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                strMsg += ex.Message;
            }
            return strMsg;
           
        }


        private string RS_RVINI_SEC = "RV";
        private string RS_RVCINI_CSVPath = "CSVPath";
        private string RS_RVCINI_CSVPathBackup = "CSVPath_Backup";
        private string RS_RVCINI_MaxDays = "MaxDay";
        private string RS_RVINI_FILENAME = "RVSetting.ini";
        public ST_SPC_CSVParam ReadRVINI(String AstrDir)
        {
            //save StSPCParams
            ST_SPC_CSVParam stSPC_CSVParam = new ST_SPC_CSVParam();
            if (Directory.Exists(AstrDir) == false)
            {
                return stSPC_CSVParam;
            }
            string iniFile = Path.Combine(_strSPCDataFolder, RS_RVINI_FILENAME);
            if (File.Exists(iniFile))
            {

                stSPC_CSVParam.SaveCSV_MaxDays = int.Parse(INIFileHelper.ReadIniData(RS_RVINI_SEC, RS_RVCINI_MaxDays, string.Empty, iniFile));
                stSPC_CSVParam.SaveCSV_Path = INIFileHelper.ReadIniData(RS_RVINI_SEC, RS_RVCINI_CSVPath, string.Empty, iniFile);

                stSPC_CSVParam.SaveCSV_BackUpPath = INIFileHelper.ReadIniData(RS_RVINI_SEC, RS_RVCINI_CSVPathBackup, string.Empty, iniFile);

            }
            else
            {
                throw new Exception(" FILE_SPCINI_IS_NOT_EXIST!");
            }
            return stSPC_CSVParam;
            //spcSaveModeType
        }
        private void SaveRVIni(string AstrCSVPath, string AstrCSVPath_Backup,int AiMaxDay)
        {
            try
            {
                string iniFile = Path.Combine(DAL_SPC.PubParams.RS_STR_TEMPCSVPATH, RS_RVINI_FILENAME);
                if (File.Exists(iniFile) == false)
                {
                    using (FileStream fs = new FileStream(iniFile, FileMode.Create))
                    {
                    }
                }
                INIFileHelper.WriteIniData(RS_RVINI_SEC, RS_RVCINI_CSVPath, AstrCSVPath, iniFile);
                INIFileHelper.WriteIniData(RS_RVINI_SEC, RS_RVCINI_CSVPathBackup, AstrCSVPath_Backup, iniFile);
                INIFileHelper.WriteIniData(RS_RVINI_SEC, RS_RVCINI_MaxDays, AiMaxDay.ToString(), iniFile);
            }
            catch (Exception ex)
            {
                LogRecord("SaveRVIni"+ex.Message);
                 
            }
           
        }

        public string DeleteBackupPCBFolder( )
        {
            string strMsg = "";
            
            try
            {
                ST_SPC_CSVParam csvParam = ReadRVINI(_strSPCDataFolder);
                int AiMaxBackupDay = csvParam.SaveCSV_MaxDays;
                if (AiMaxBackupDay == 0)
                {
                    strMsg = "MaxBackupDay=0";
                    LogRecord(strMsg);
                    return strMsg;
                }
                
                string AstrFrUIBackUpPath = _strSPCDataFolder_Backup;
                if (!string.IsNullOrEmpty(csvParam.SaveCSV_BackUpPath))
                    AstrFrUIBackUpPath = csvParam.SaveCSV_BackUpPath;
               
                if (!string.IsNullOrEmpty(AstrFrUIBackUpPath) && Directory.Exists(AstrFrUIBackUpPath))
                {
                    string[] arrStr = Directory.GetDirectories(AstrFrUIBackUpPath);
                    if (arrStr != null && arrStr.Length > 0)
                    {
                        List<DirectoryInfo> lstDI = new List<DirectoryInfo>();
                        foreach (string path in arrStr)
                        {
                            lstDI.Add(new DirectoryInfo(path));

                        }
                        DirectoryInfo[] arrDI = lstDI.ToArray();
                        SortAsFolderCreationTime(ref arrDI, "asc");

                        DateTime dtEnd = DateTime.Now.AddDays(-AiMaxBackupDay);

                        bool test = true;
                        foreach (var di in arrDI)
                        {
                            if (test)
                            {
                                LogRecord("dtEnd:"+dtEnd.ToString("yyyy-MM-dd HH:mm:ss"));
                                LogRecord("di.CreationTime :" + di.CreationTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                test = false;
                            }
                            if (di.CreationTime < dtEnd)
                            {
                                di.Delete(true);
                                LogRecord("DeleteFolder:" + di.FullName);
                            }
                            else
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                strMsg += ex.Message;
            }
            LogRecord("strMsg:" + strMsg);
            return strMsg;
           
        }

        private void SortAsFolderCreationTime(ref DirectoryInfo[] dirs, string AstrAsc)
        {
            Array.Sort(dirs, delegate(DirectoryInfo x, DirectoryInfo y)
            {
                if (AstrAsc == "asc")
                    return x.CreationTime.CompareTo(y.CreationTime);
                else
                    return y.CreationTime.CompareTo(x.CreationTime);
            });
        }

        
        #endregion


        #region Customer 1
        public string SaveDataExport_C1(InspectMainLib.Pad[] APads, SPCBoardRes ABrdRes,
              ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, AppSettingData AappSettingData,
              string AstrDir, string AstrClntName, string AstrLotNumber)
        {
            string strMsg, strArrayStatus, strArrayBarcode, strArrayId, strResult;
            strMsg = strArrayStatus = strArrayBarcode = strArrayId = strResult = string.Empty;
            int iArrayCount = 0;
            try
            {
                //check dir
                if (baseFunction.DirCheck(ref AstrDir) == -1)
                {
                    strMsg += PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }
                string strTemp = PubStaticParam.RS_strTmpFileDir;
                if (Directory.Exists(strTemp) == false)
                {
                    Directory.CreateDirectory(strTemp);
                }
                string tmpFile = Path.Combine(strTemp, PubStaticParam.RS_DataExportTempFile);

                #region 重要字段取值
                string lineNumber = AappSettingData.LineName;
                string jobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                string startTime = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                string strBoardcode = baseFunction.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                strResult = "Unmeasured";
                switch (ABrdRes.jugResult)
                {
                    case JudgeRes.Good:
                        strResult = "Good";
                        break;
                    case JudgeRes.NG:
                        strResult = "NG";
                        break;
                    case JudgeRes.Pass:
                        strResult = "Pass";
                        break;
                    case JudgeRes.Skipped:
                        strResult = "Skipped";
                        break;
                }
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                #endregion

                StringBuilder strBuilder = new StringBuilder();
                strBuilder.Append("Model name" + PubStaticParam.RS_CommaSplit + "Line number" + PubStaticParam.RS_CommaSplit
                                 + "Lot number" + PubStaticParam.RS_LineEnd);

                strBuilder.Append(jobName + PubStaticParam.RS_CommaSplit + lineNumber + PubStaticParam.RS_CommaSplit
                                 + AstrLotNumber + PubStaticParam.RS_LineEnd);

                strBuilder.Append("Board Status" + PubStaticParam.RS_CommaSplit + strResult + PubStaticParam.RS_CommaSplit +
                                    "Board Barcode" + PubStaticParam.RS_CommaSplit + strBoardcode +
                                    PubStaticParam.RS_LineEnd);


                #region  array
                if (bISArrayPCB && iArrayCount > 0)
                {
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            strArrayId = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;

                            if (string.IsNullOrEmpty(strArrayBarcode)
                                || string.Equals(strArrayBarcode, PubStaticParam.RS_NOREAD, StringComparison.InvariantCultureIgnoreCase))
                            {
                                if (strArrayId.Length == 1)
                                {
                                    strArrayBarcode = strBoardcode + "0" + strArrayId;
                                }
                                else
                                {
                                    strArrayBarcode = strBoardcode + PubStaticParam.RS_UnderLineSplit + strArrayId;
                                }
                            }
                            strBuilder.Append("ArrayID" + PubStaticParam.RS_CommaSplit + strArrayId + PubStaticParam.RS_CommaSplit +
                                            "Array Status" + PubStaticParam.RS_CommaSplit + strArrayStatus + PubStaticParam.RS_CommaSplit +
                                            "Array Barcode" + PubStaticParam.RS_CommaSplit + strArrayBarcode + PubStaticParam.RS_LineEnd
                                        );
                        }
                    }
                }
                #endregion

                strBuilder.Append("DateTime" + PubStaticParam.RS_CommaSplit + ABrdRes.startTime.ToString("yyyy/MM/dd HH:mm") + PubStaticParam.RS_LineEnd
                                   );

                #region pad info
                strBuilder.Append(C1_COLUMN_TITLE + PubStaticParam.RS_LineEnd);
                for (int i = 0; i < APads.Length; i++)
                {
                    if (baseFunction.bPadIsSkip(APads[i]) == true || APads[i].check == false)
                    {
                        continue;
                    }

                    //PadID
                    strBuilder.Append(APads[i].padID + PubStaticParam.RS_CommaSplit);
                    //ComponentID
                    strBuilder.Append(APads[i].componentID + PubStaticParam.RS_CommaSplit);
                    //Type
                    strBuilder.Append("C" + PubStaticParam.RS_CommaSplit);
                    //Area(%)
                    strBuilder.Append(APads[i].res.measuredValue.perArea.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Height
                    strBuilder.Append(APads[i].res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Volume(%)
                    strBuilder.Append(APads[i].res.measuredValue.perVol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //XOffset
                    strBuilder.Append(APads[i].res.measuredValue.offsetX.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //YOffset
                    strBuilder.Append(APads[i].res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //PadSize(X)
                    strBuilder.Append(APads[i].sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //PadSize(Y)
                    strBuilder.Append(APads[i].sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Area
                    strBuilder.Append(APads[i].res.measuredValue.area.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Height(%)
                    strBuilder.Append(APads[i].res.measuredValue.perHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Volume
                    strBuilder.Append(APads[i].res.measuredValue.vol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
                    //Result
                    strBuilder.Append(APads[i].res.jugRes + PubStaticParam.RS_CommaSplit);
                    //Errcode
                    string strErrcode = PubStaticParam.RS_EMPTY;
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        strErrcode = baseFunction.GetPadErrorCodeStr(APads[i], AappSettingData);
                    }
                    strBuilder.Append(strErrcode + PubStaticParam.RS_CommaSplit);
                    //PinNum
                    strBuilder.Append(APads[i].pinNumber + PubStaticParam.RS_CommaSplit);
                    //Barcode
                    strBuilder.Append(strBoardcode + PubStaticParam.RS_CommaSplit);
                    //Date
                    strBuilder.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE) + PubStaticParam.RS_CommaSplit);
                    //Time
                    strBuilder.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME) + PubStaticParam.RS_CommaSplit);
                    //ArrayID
                    strBuilder.Append(APads[i].strArrayID + PubStaticParam.RS_CommaSplit);
                    //VolumeL(%)
                    strBuilder.Append(APads[i].res.measuredValue.perVol + PubStaticParam.RS_LineEnd);

                }
                #endregion
                string strFileName = jobName + PubStaticParam.RS_UnderLineSplit + strBoardcode + PubStaticParam.RS_UnderLineSplit
                             + ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_CSV_EXT; ;
                string strCsvFile = Path.Combine(AstrDir, strFileName);

                SaveDataToFile(tmpFile, strCsvFile, strBuilder);

            }
            catch (Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }

            return strMsg;
        }
        #endregion

        #region  东莞辰达

        private int GetPCBSerialNo()
        {
            int iSerialNo = 0;
            string path = Path.Combine(RS_PCB_SERIALNO_PATH, RS_PCB_SERIALNO_FILENAME);
            if (File.Exists(path))
            {
                string strContent = File.ReadAllText(path);
                if (!string.IsNullOrEmpty(strContent) && strContent.Contains("_"))
                {
                    string strDate = strContent.Substring(0, strContent.IndexOf("_"));
                    if (strDate == DateTime.Today.ToString("yyyyMMdd"))
                    {
                        iSerialNo = Convert.ToInt32(strContent.Substring(strContent.IndexOf("_") + 1));
                    }
                }
            }

            return iSerialNo;
        }

        private void SavePCBSerialNo(int AintPCBCount)
        {
            if (!Directory.Exists(RS_PCB_SERIALNO_PATH))
                Directory.CreateDirectory(RS_PCB_SERIALNO_PATH);
            string strContent = DateTime.Today.ToString("yyyyMMdd") + "_" + AintPCBCount;
            string path = Path.Combine(RS_PCB_SERIALNO_PATH, RS_PCB_SERIALNO_FILENAME);
            if (File.Exists(path))
            {
                StreamWriter sw = new StreamWriter(path);
                sw.Write(strContent);
                sw.Close();
            }
            else
            {
                using (FileStream fs = new FileStream(path, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs);
                    sw.Write(strContent);
                    sw.Close();
                }
            }
        }



        public string SaveDataExport_ChenDa(InspectMainLib.Pad[] APads, SPCBoardRes ABrdRes,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, AppSettingData AappSettingData,
            string AstrDir, string AstrClntName)
        {

            string strMsg, strArrayStatus, strArrayBarcode, strArrayId, strResult, strImgPath, strPCBSerialNo, strShift;
            strMsg = strArrayStatus = strArrayBarcode = strArrayId = strResult = strImgPath = strPCBSerialNo = strShift = string.Empty;
            int iArrayCount = 0;
            float fStencilHeight = 0;
            try
            {
                //工单号
                string strLotNumber = AappSettingData.strLotNumber;
                //班次  这个需要加字段
                strShift = "A";// AappSettingData.stDataExpVT.strShift;

                //check dir
                if (baseFunction.DirCheck(ref AstrDir) == -1)
                {
                    strMsg += PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }
                string strTemp = PubStaticParam.RS_strTmpFileDir;
                if (Directory.Exists(strTemp) == false)
                {
                    Directory.CreateDirectory(strTemp);
                }
                string tmpFile = Path.Combine(strTemp, PubStaticParam.RS_DataExportTempFile);

                #region 重要字段取值
                string lineNumber = AappSettingData.LineName;
                string jobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                string startTime = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                string strBoardcode = baseFunction.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                strResult = "Unmeasured";
                switch (ABrdRes.jugResult)
                {
                    case JudgeRes.Good:
                        strResult = "Good";
                        break;
                    case JudgeRes.NG:
                        strResult = "NG";
                        break;
                    case JudgeRes.Pass:
                        strResult = "Pass";
                        break;
                    case JudgeRes.Skipped:
                        strResult = "Skipped";
                        break;
                }
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                #endregion

                #region pad info
                Application app = new Application();
                Workbooks wbks = app.Workbooks;
                _Workbook _wbk = wbks.Add(Missing.Value);
                Sheets shs = _wbk.Sheets;
                _Worksheet _wsh = (_Worksheet)shs.get_Item(1);
                _wsh.Name = strBoardcode;

                _wsh.Cells[4, 1] = "PadID";
                _wsh.Cells[4, 2] = "Component";
                _wsh.Cells[4, 3] = "Type";
                _wsh.Cells[4, 4] = "Area(%)";
                _wsh.Cells[4, 5] = "Height";
                _wsh.Cells[4, 6] = "Volume(%)";
                _wsh.Cells[4, 7] = "XOffset";
                _wsh.Cells[4, 8] = "YOffset";
                _wsh.Cells[4, 9] = "PadSize(X)";
                _wsh.Cells[4, 10] = "PadSize(Y)";
                _wsh.Cells[4, 11] = "Area";
                _wsh.Cells[4, 12] = "Height(%)";
                _wsh.Cells[4, 13] = "Volume";
                _wsh.Cells[4, 14] = "Result";
                _wsh.Cells[4, 15] = "Errcode";
                _wsh.Cells[4, 16] = "PinNum";
                _wsh.Cells[4, 17] = "Barcode";
                _wsh.Cells[4, 18] = "Date";
                _wsh.Cells[4, 19] = "Time";
                _wsh.Cells[4, 20] = "ArrayID";
                _wsh.Cells[4, 21] = "不良图片对应编号";

                int iCount = 0;
                for (int i = 0; i < APads.Length; i++)
                {
                    if (baseFunction.bPadIsSkip(APads[i]) == true || APads[i].check == false)
                    {
                        continue;
                    }
                    //钢网厚度
                    if (fStencilHeight == 0 && APads[i].stencilHeight != null && APads[i].stencilHeight != 0)
                    {
                        fStencilHeight = APads[i].stencilHeight;
                    }
                    //PadID                 
                    _wsh.Cells[5 + iCount, 1] = APads[i].padID;
                    //ComponentID                 
                    _wsh.Cells[5 + iCount, 2] = APads[i].componentID;
                    //Type                  
                    _wsh.Cells[5 + iCount, 3] = PubStaticParam.RS_EMPTY;
                    //Area(%)               
                    _wsh.Cells[5 + iCount, 4] = APads[i].res.measuredValue.perArea.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Height                
                    _wsh.Cells[5 + iCount, 5] = APads[i].res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Volume(%)               
                    _wsh.Cells[5 + iCount, 6] = APads[i].res.measuredValue.perVol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //XOffset                  
                    _wsh.Cells[5 + iCount, 7] = APads[i].res.measuredValue.offsetX.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //YOffset           
                    _wsh.Cells[5 + iCount, 8] = APads[i].res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //PadSize(X)              
                    _wsh.Cells[5 + iCount, 9] = APads[i].sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //PadSize(Y)          
                    _wsh.Cells[5 + iCount, 10] = APads[i].sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Area               
                    _wsh.Cells[5 + iCount, 11] = APads[i].res.measuredValue.area.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Height(%)            
                    _wsh.Cells[5 + iCount, 12] = APads[i].res.measuredValue.perHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Volume             
                    _wsh.Cells[5 + iCount, 13] = APads[i].res.measuredValue.vol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                    //Result               
                    _wsh.Cells[5 + iCount, 14] = APads[i].res.jugRes;
                    //Errcode
                    string strErrcode = PubStaticParam.RS_EMPTY;
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        strErrcode = baseFunction.GetPadErrorCodeStr(APads[i], AappSettingData);
                    }
                    _wsh.Cells[5 + iCount, 15] = strErrcode;
                    //PinNum               
                    _wsh.Cells[5 + iCount, 16] = APads[i].pinNumber;
                    //Barcode
                    _wsh.Cells[5 + iCount, 17] = strBoardcode;
                    //Date              
                    _wsh.Cells[5 + iCount, 18] = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                    //Time                
                    _wsh.Cells[5 + iCount, 19] = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                    //ArrayID                
                    _wsh.Cells[5 + iCount, 20] = APads[i].strArrayID;
                    //不良图片对应编号
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        strImgPath = Path.Combine(ABrdRes.strDataExportSavePadImagePath, APads[i].padID + ".jpg");

                        _wsh.Cells[5 + iCount, 21] = strImgPath;
                    }
                    iCount++;

                }
                #endregion

                #region StringBuilder

                _wsh.Cells[1, 1] = "Model name";
                _wsh.Cells[1, 2] = "Line number";
                _wsh.Cells[1, 3] = "工单号";
                _wsh.Cells[1, 4] = "钢网厚度";
                _wsh.Cells[1, 5] = "pcb板流水号";
                _wsh.Cells[1, 6] = "班次";

                //pcb板流水号
                if (lineNumber.Length > 1)
                {
                    strPCBSerialNo = lineNumber.Substring(0, 1) + lineNumber.Substring(lineNumber.Length - 1, 1);
                }
                else if (lineNumber.Length == 1)
                {
                    strPCBSerialNo = lineNumber;
                }
                strPCBSerialNo += ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                int pcbCount = GetPCBSerialNo();
                pcbCount++;
                strPCBSerialNo += pcbCount.ToString("0000");
                SavePCBSerialNo(pcbCount);
                //pcb板流水号

                _wsh.Cells[2, 1] = jobName;
                _wsh.Cells[2, 2] = lineNumber;
                _wsh.Cells[2, 3] = strLotNumber;
                _wsh.Cells[2, 4] = fStencilHeight;
                _wsh.Cells[2, 5] = strPCBSerialNo;
                _wsh.Cells[2, 6] = strShift;

                _wsh.Cells[3, 1] = "Board Status";
                _wsh.Cells[3, 2] = strResult;


                #endregion

                string strFileName = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_UnderLineSplit
                                    + strBoardcode + ".xls";
                strFileName = Path.Combine(AstrDir, strFileName);

                app.AlertBeforeOverwriting = false;
                string strVersion = app.Version;
                int iFormatNo;
                if (Convert.ToDouble(strVersion) < 12)
                    iFormatNo = -4143;
                else
                    iFormatNo = 56;

                _wsh.SaveAs(strFileName, iFormatNo, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Missing.Value, Missing.Value, Missing.Value);

                app.Quit();
                app = null;

            }
            catch (Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }

            return strMsg;
        }





        public string SaveDataExport_ChenDa_old(InspectMainLib.Pad[] APads, SPCBoardRes ABrdRes,
             ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, AppSettingData AappSettingData,
             string AstrDir, string AstrClntName)
        {

            string strMsg, strArrayStatus, strArrayBarcode, strArrayId, strResult, strImgPath, strPCBSerialNo, strShift;
            strMsg = strArrayStatus = strArrayBarcode = strArrayId = strResult = strImgPath = strPCBSerialNo = strShift = string.Empty;
            int iArrayCount = 0;
            float fStencilHeight = 0;
            try
            {
                //工单号
                string strLotNumber = AappSettingData.strLotNumber;
                //班次  这个需要加字段
                strShift = "A";// AappSettingData.stDataExpVT.strShift;

                //check dir
                if (baseFunction.DirCheck(ref AstrDir) == -1)
                {
                    strMsg += PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }
                string strTemp = PubStaticParam.RS_strTmpFileDir;
                if (Directory.Exists(strTemp) == false)
                {
                    Directory.CreateDirectory(strTemp);
                }
                string tmpFile = Path.Combine(strTemp, PubStaticParam.RS_DataExportTempFile);

                #region 重要字段取值
                string lineNumber = AappSettingData.LineName;
                string jobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                string startTime = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                string strBoardcode = baseFunction.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                strResult = "Unmeasured";
                switch (ABrdRes.jugResult)
                {
                    case JudgeRes.Good:
                        strResult = "Good";
                        break;
                    case JudgeRes.NG:
                        strResult = "NG";
                        break;
                    case JudgeRes.Pass:
                        strResult = "Pass";
                        break;
                    case JudgeRes.Skipped:
                        strResult = "Skipped";
                        break;
                }
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                #endregion

                #region pad info
                StringBuilder strBuilder_pad = new StringBuilder();
                string strColumnTitle = "PadID\tComponent\tType\tArea(%)\tHeight\tVolume(%)\tXOffset\tYOffset\tPadSize(X)\tPadSize(Y)\tArea\tHeight(%)\tVolume\tResult\tErrcode\tPinNum\tBarcode\tDate\tTime\tArrayID\t不良图片对应编号";
                strBuilder_pad.Append(strColumnTitle + PubStaticParam.RS_LineEnd);
                for (int i = 0; i < APads.Length; i++)
                {
                    if (baseFunction.bPadIsSkip(APads[i]) == true || APads[i].check == false)
                    {
                        continue;
                    }
                    //钢网厚度
                    if (fStencilHeight == 0 && APads[i].stencilHeight != null && APads[i].stencilHeight != 0)
                    {
                        fStencilHeight = APads[i].stencilHeight;
                    }

                    //PadID
                    strBuilder_pad.Append(APads[i].padID + RS_TABSPLIT);
                    //ComponentID
                    strBuilder_pad.Append(APads[i].componentID + RS_TABSPLIT);
                    //Type
                    strBuilder_pad.Append(PubStaticParam.RS_EMPTY + RS_TABSPLIT);
                    //Area(%)
                    strBuilder_pad.Append(APads[i].res.measuredValue.perArea.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Height
                    strBuilder_pad.Append(APads[i].res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Volume(%)
                    strBuilder_pad.Append(APads[i].res.measuredValue.perVol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //XOffset
                    strBuilder_pad.Append(APads[i].res.measuredValue.offsetX.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //YOffset
                    strBuilder_pad.Append(APads[i].res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //PadSize(X)
                    strBuilder_pad.Append(APads[i].sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //PadSize(Y)
                    strBuilder_pad.Append(APads[i].sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Area
                    strBuilder_pad.Append(APads[i].res.measuredValue.area.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Height(%)
                    strBuilder_pad.Append(APads[i].res.measuredValue.perHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Volume
                    strBuilder_pad.Append(APads[i].res.measuredValue.vol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + RS_TABSPLIT);
                    //Result
                    strBuilder_pad.Append(APads[i].res.jugRes + RS_TABSPLIT);
                    //Errcode
                    string strErrcode = PubStaticParam.RS_EMPTY;
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        strErrcode = baseFunction.GetPadErrorCodeStr(APads[i], AappSettingData);
                    }
                    strBuilder_pad.Append(strErrcode + RS_TABSPLIT);
                    //PinNum
                    strBuilder_pad.Append(APads[i].pinNumber + RS_TABSPLIT);
                    //Barcode
                    strBuilder_pad.Append(strBoardcode + RS_TABSPLIT);
                    //Date
                    strBuilder_pad.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE) + RS_TABSPLIT);
                    //Time
                    strBuilder_pad.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME) + RS_TABSPLIT);
                    //ArrayID
                    strBuilder_pad.Append(APads[i].strArrayID + RS_TABSPLIT);
                    //不良图片对应编号
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        strImgPath = Path.Combine(ABrdRes.strDataExportSavePadImagePath, APads[i].padID + ".jpg");
                        strBuilder_pad.Append(strImgPath);
                    }
                    strBuilder_pad.Append(PubStaticParam.RS_LineEnd);


                }
                #endregion

                #region StringBuilder
                StringBuilder strBuilder = new StringBuilder();
                strBuilder.Append("Model name" + RS_TABSPLIT + "Line number" + RS_TABSPLIT
                                 + "工单号" + RS_TABSPLIT + "钢网厚度" + RS_TABSPLIT
                                 + "pcb板流水号" + RS_TABSPLIT + "班次" + PubStaticParam.RS_LineEnd);
                //pcb板流水号
                if (lineNumber.Length > 1)
                {
                    strPCBSerialNo = lineNumber.Substring(0, 1) + lineNumber.Substring(lineNumber.Length - 1, 1);
                }
                else if (lineNumber.Length == 1)
                {
                    strPCBSerialNo = lineNumber;
                }
                strPCBSerialNo += ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                int pcbCount = GetPCBSerialNo();
                pcbCount++;
                strPCBSerialNo += pcbCount.ToString("0000");
                SavePCBSerialNo(pcbCount);
                //pcb板流水号
                strBuilder.Append(jobName + RS_TABSPLIT + lineNumber + RS_TABSPLIT
                                 + strLotNumber + RS_TABSPLIT + fStencilHeight + RS_TABSPLIT
                                 + strPCBSerialNo + RS_TABSPLIT + strShift + PubStaticParam.RS_LineEnd);

                strBuilder.Append("Board Status" + RS_TABSPLIT + strResult + PubStaticParam.RS_LineEnd);

                strBuilder.Append(strBuilder_pad.ToString());
                #endregion

                string strFileName = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_UnderLineSplit
                                    + strBoardcode + ".xls";
                strFileName = Path.Combine(AstrDir, strFileName);

                SaveDataToFile(tmpFile, strFileName, strBuilder);

            }
            catch (Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }

            return strMsg;
        }

        #endregion

        #region others
        public string SaveDataExport(InspectMainLib.Pad[] APads,
      SPCBoardRes ABrdRes,
      ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
      AppSettingData AappSettingData,
      string AstrDir,
      string AstrClntName
         )
        {
            string strMsg, strArrayStatus, strArrayBarcode, strArrayId, strResult;
            strMsg = strArrayStatus = strArrayBarcode = strArrayId = strResult = string.Empty;
            int iArrayCount = 0;
            try
            {
                //check dir
                if (baseFunction.DirCheck(ref AstrDir) == -1)
                {
                    strMsg += PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }
                string strTemp = PubStaticParam.RS_strTmpFileDir;
                if (Directory.Exists(strTemp) == false)
                {
                    Directory.CreateDirectory(strTemp);
                }
                string tmpFile = Path.Combine(strTemp, PubStaticParam.RS_DataExportTempFile);

                #region 重要字段取值
                string lineNumber = AappSettingData.LineName;
                string jobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                string startTime = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                string strBoardcode = baseFunction.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                strResult = "Unmeasured";
                switch (ABrdRes.jugResult)
                {
                    case JudgeRes.Good:
                        strResult = "Good";
                        break;
                    case JudgeRes.NG:
                        strResult = "NG";
                        break;
                    case JudgeRes.Pass:
                        strResult = "Pass";
                        break;
                    case JudgeRes.Skipped:
                        strResult = "Skipped";
                        break;
                }
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                #endregion

                if (bISArrayPCB == false)//整板
                {
                    #region 整板
                    StringBuilder strBuilder = new StringBuilder();
                    strBuilder.Append("Model name" + PubStaticParam.RS_CommaSplit + "Line number" + PubStaticParam.RS_LineEnd);
                    strBuilder.Append(jobName + PubStaticParam.RS_CommaSplit +
                                       lineNumber + PubStaticParam.RS_LineEnd);

                    strBuilder.Append("Board Status" + PubStaticParam.RS_CommaSplit + strResult + PubStaticParam.RS_CommaSplit +
                                        "Board Barcode" + PubStaticParam.RS_CommaSplit + strBoardcode +
                                        PubStaticParam.RS_LineEnd);

                    // pad info
                    strBuilder.Append(TEST_COLUMN_TITLE + PubStaticParam.RS_LineEnd);
                    for (int i = 0; i < APads.Length; i++)
                    {
                        strBuilder.Append(ExportPadInfo(APads[i], ABrdRes, AappSettingData, strBoardcode));
                    }

                    string strFileName = jobName + PubStaticParam.RS_UnderLineSplit + ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_CSV_EXT; ;
                    string strCsvFile = Path.Combine(AstrDir, strFileName);

                    SaveDataToFile(tmpFile, strCsvFile, strBuilder);
                    return strMsg;
                    #endregion
                }
                else if (iArrayCount > 0)//拼板
                {
                    #region 拼板

                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            if (strArrayStatus == "Skipped")
                            {
                                continue;
                            }
                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            strArrayId = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;

                            if (string.IsNullOrEmpty(strArrayBarcode)
                                    || string.Equals(strArrayBarcode, PubStaticParam.RS_NOREAD, StringComparison.InvariantCultureIgnoreCase))
                            {
                                strArrayBarcode = strBoardcode + PubStaticParam.RS_UnderLineSplit + strArrayId;
                            }

                            StringBuilder strBuilder = new StringBuilder();
                            strBuilder.Append("Model name" + PubStaticParam.RS_CommaSplit);

                            if (AappSettingData.stDataExpVT.bEnExportLaneNo == true)
                            {
                                strBuilder.Append("Line number" + PubStaticParam.RS_CommaSplit);
                                strBuilder.Append("LaneNo" + PubStaticParam.RS_LineEnd);
                            }
                            else
                            {
                                strBuilder.Append("Line number" + PubStaticParam.RS_LineEnd);
                            }
                            strBuilder.Append(jobName + PubStaticParam.RS_CommaSplit);
                            if (AappSettingData.stDataExpVT.bEnExportLaneNo == true)
                            {
                                strBuilder.Append(lineNumber + PubStaticParam.RS_CommaSplit);
                                strBuilder.Append(AappSettingData.stDataExpVT.stDELaneParams[ABrdRes.LaneNo].strUserDefinedLaneName + PubStaticParam.RS_LineEnd);
                            }
                            else
                            {
                                strBuilder.Append(lineNumber + PubStaticParam.RS_LineEnd);
                            }

                            strBuilder.Append("Board Status" + PubStaticParam.RS_CommaSplit + strResult + PubStaticParam.RS_CommaSplit + "Board Barcode" + PubStaticParam.RS_CommaSplit + strBoardcode + PubStaticParam.RS_LineEnd);
                            if (AappSettingData.stDataExpVT.bExpArrayInfo == true)
                            {
                                strBuilder.Append("ArrayID" + PubStaticParam.RS_CommaSplit + strArrayId + PubStaticParam.RS_CommaSplit +
                                                                            "Array Status" + PubStaticParam.RS_CommaSplit + strArrayStatus + PubStaticParam.RS_CommaSplit +
                                                                            "Array Barcode" + PubStaticParam.RS_CommaSplit + strArrayBarcode + PubStaticParam.RS_LineEnd
                                                                        );
                            }
                            // pad info
                            strBuilder.Append(TEST_COLUMN_TITLE + PubStaticParam.RS_LineEnd);
                            int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;
                            foreach (int padIndex in arrPadIndex)
                            {
                                strBuilder.Append(ExportPadInfo(APads[padIndex], ABrdRes, AappSettingData, strArrayBarcode));
                            }

                            string strFilePath = string.Empty;
                            if (AappSettingData.stDataExpVT.deFormat == ImgCSCoreIM.DataExportDefaultFormat.Default)
                            {
                                strFilePath = Path.Combine(AstrDir, strArrayBarcode + ".csv");
                            }
                            else if (AappSettingData.stDataExpVT.deFormat == ImgCSCoreIM.DataExportDefaultFormat.BarcodeBoardStatus)
                            {
                                strFilePath = Path.Combine(AstrDir, strArrayBarcode + PubStaticParam.RS_UnderLineSplit + strArrayStatus + ".csv");
                            }
                            else if (AappSettingData.stDataExpVT.deFormat == ImgCSCoreIM.DataExportDefaultFormat.DefaultTimeBarcode)
                            {
                                strFilePath = Path.Combine(AstrDir, startTime + PubStaticParam.RS_UnderLineSplit + strArrayBarcode + ".csv");
                            }

                            SaveDataToFile(tmpFile, strFilePath, strBuilder);
                        }
                    }
                    #endregion
                }

            }
            catch (Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }

            return strMsg;
        }


        private void SaveDataToFile(string tmpFile, string strFilePath, StringBuilder strBuilder)
        {
            using (FileStream fs = new FileStream(tmpFile, FileMode.Create))
            {
                StreamWriter sw = new StreamWriter(fs);
                sw.Write(strBuilder);
                sw.Close();
            }

            if (File.Exists(tmpFile))
            {
                File.Copy(tmpFile, strFilePath, true);
                Thread.Sleep(100);
                File.Delete(tmpFile);
            }

        }

        private string ExportPadInfo(Pad pad, SPCBoardRes ABrdRes,
         AppSettingData AappSettingData, string strArrayBarcode)
        {

            if (baseFunction.bPadIsSkip(pad) == true || pad.check == false)
            {
                return "";
            }
            StringBuilder strBuilder = new StringBuilder();

            //PadID
            strBuilder.Append(pad.padID + PubStaticParam.RS_CommaSplit);
            //ComponentID
            strBuilder.Append(pad.componentID + PubStaticParam.RS_CommaSplit);
            //Type
            strBuilder.Append(PubStaticParam.RS_EMPTY + PubStaticParam.RS_CommaSplit);
            //Area(%)
            strBuilder.Append(pad.res.measuredValue.perArea.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Height
            strBuilder.Append(pad.res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Volume(%)
            strBuilder.Append(pad.res.measuredValue.perVol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //XOffset
            strBuilder.Append(pad.res.measuredValue.offsetX.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //YOffset
            strBuilder.Append(pad.res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //PadSize(X)
            strBuilder.Append(pad.sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //PadSize(Y)
            strBuilder.Append(pad.sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Area
            strBuilder.Append(pad.res.measuredValue.area.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Height(%)
            strBuilder.Append(pad.res.measuredValue.perHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Volume
            strBuilder.Append(pad.res.measuredValue.vol.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_CommaSplit);
            //Result
            strBuilder.Append(pad.res.jugRes + PubStaticParam.RS_CommaSplit);
            //Errcode
            string strErrcode = PubStaticParam.RS_EMPTY;
            if (pad.res.jugRes == JudgeRes.NG)
            {
                strErrcode = baseFunction.GetPadErrorCodeStr(pad, AappSettingData);
            }
            strBuilder.Append(strErrcode + PubStaticParam.RS_CommaSplit);
            //PinNum
            strBuilder.Append(pad.pinNumber + PubStaticParam.RS_CommaSplit);
            //Barcode
            strBuilder.Append(strArrayBarcode + PubStaticParam.RS_CommaSplit);
            //Date
            strBuilder.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE) + PubStaticParam.RS_CommaSplit);
            //Time
            strBuilder.Append(ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME) + PubStaticParam.RS_CommaSplit);
            //ArrayID
            strBuilder.Append(pad.strArrayID + PubStaticParam.RS_LineEnd);

            return strBuilder.ToString();
        }

        #endregion


    }

    //public class DirComparer : System.Collections.IComparer
    //{
    //    public int Compare(object x, object y)
    //    {
    //        //比较字符串大小
    //        return y.ToString().CompareTo(x.ToString());
    //    }
    //}
}
