﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace WSClnt
{

    public struct StInspectBorad
    {
        public bool UploadFalg;//是否上传
        public string BarCode;//对应barcode
        public string Result;//检测结果
        public bool UploadResult;//是否上传成功
    }

    public struct StInspectArray
    {
        public bool UploadFalg;
        public string BarCode;
        public string Result;
        public bool UploadResult;
    }

    public struct StPadMeasure
    {
        public double Height;
        public double Area;
        public double Volume;
        public double ShiftX;
        public double ShiftY;
        public string BridgeType;
        public string BridgeTypeStr;
        public string DefectType;
        public string defectTypeStr;
        public string JudgeRes;
        public string JudgeResStr;

    }

    public struct StInspectPad
    {
        public bool UploadFlag;
        public StPadMeasure stPadMes;
        public string Result;
        public bool UploadResult;

    }
    public enum CLNTNAME
    {
        XWD = 0,
    }
    public class InspectUploadUtil
    {
        string _areaCode = ""; //拉别
        string _groupName = ""; //工序
        //

        string _ClntName = "";//客户单位名称
        string _WSAddress = "";//webservice地址 如：http://192.168.1.1/Webservice.asmx
        string _WSMethodName = "";//需要调用的接口方法名称
        //
        public static string CLNT_NAME_XWD = "XWD";//欣旺达
        public static string ClNT_XWD_METHOD = "GetTestOK";
        public const string STRING_TRUE = "TRUE";
        //
        public static string CLNT_NAME_HX = "HX";//海信
        public static string ClNT_HX_METHOD = "??";
        //
        bool _bDebugMode = false;// true;



        public InspectUploadUtil(string AsAddress, string AsClntName)
        {
            this._WSAddress = AsAddress;
            this._ClntName = AsClntName;
        }


        public string UploadInspect(string AMethodName, ref StInspectBorad[] AStBoardData, ref StInspectArray[] AStArrayData, ref StInspectPad[] AStPadData)
        {
            string strException = "";//Q.F.2016.07.26
            if (!string.IsNullOrEmpty(AMethodName))
                this._WSMethodName = AMethodName;
            //
            if (string.IsNullOrEmpty(_ClntName) || string.IsNullOrEmpty(_WSAddress)
                || (AStBoardData == null && AStArrayData == null && AStPadData == null))
            {
                strException = "Upload fail Parameters error";//Q.F.2016.07.26
                //throw new Exception(strException);//Q.F.2016.07.26  //modity by Tony 16-09-18
                return strException;//Q.F.2016.07.26

            }


            try
            {
                //upload board
                if (AStBoardData != null && AStBoardData.Length > 0)
                {
                    for (int i = 0; i < AStBoardData.Length; i++)
                    {
                        StInspectBorad stInsBoard = AStBoardData[i];
                        if (stInsBoard.UploadFalg)
                        {
                            string sInspectResult = GetBoardOrArrayInspectResult(stInsBoard.Result);
                            try
                            {
                                UploadWebService(this._WSAddress, AMethodName, sInspectResult);
                                stInsBoard.UploadResult = true;

                            }
                            catch (Exception ex)
                            {
                                stInsBoard.UploadResult = false;
                                strException = ex.ToString();//Q.F.2016.07.26
                                return strException;//Q.F.2016.07.26
                            }

                        }
                    }
                }
                //upload array

                if (AStArrayData != null && AStArrayData.Length > 0)
                {
                    for (int i = 0; i < AStArrayData.Length; i++)
                    {
                        StInspectArray stInsArray = AStArrayData[i];
                        if (stInsArray.UploadFalg)
                        {
                            string sInspectResult = GetBoardOrArrayInspectResult(stInsArray.Result);
                            try
                            {
                                UploadWebService(this._WSAddress, AMethodName, sInspectResult);
                                stInsArray.UploadResult = true;
                            }
                            catch (Exception ex)
                            {
                                stInsArray.UploadResult = false;
                                strException = ex.ToString();//Q.F.2016.07.26
                                return strException;//Q.F.2016.07.26
                            }

                        }
                    }
                }

                //upload pad
                if (AStPadData != null && AStPadData.Length > 0)
                {
                    for (int i = 0; i < AStPadData.Length; i++)
                    {
                        StInspectPad stInsPad = AStPadData[i];
                        if (stInsPad.UploadFlag)
                        {
                            //to do something;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.ToString());
                strException = ex.ToString();//Q.F.2016.07.26
                return strException;//Q.F.2016.07.26
            }
            return strException;//Q.F.2016.07.26
        }
        //
        public void UploadWebService(string AsAddress, string AsMethodName, string AInspectResult)
        {
            if (_bDebugMode) return;
            string sWSMethodName = AsMethodName;
            //
            if (_ClntName.Equals(InspectUploadUtil.CLNT_NAME_XWD))
            {
                Hashtable htParams = new Hashtable();
                htParams.Add("areaCode", this._areaCode);
                htParams.Add("groupName", this._groupName);
                htParams.Add("productNum", 1);
                htParams.Add("TestRes", AInspectResult);
                string wsReturn = SoapOperator.DoSoapWebService(AsAddress, string.IsNullOrEmpty(sWSMethodName) ? InspectUploadUtil.ClNT_XWD_METHOD : sWSMethodName, htParams);
                if (!wsReturn.Equals(STRING_TRUE))
                {
                    throw new Exception("Error DoSoapWebService Method Return :" + wsReturn);//modify by Tony 16-09-18
                }

            }
            else if (_ClntName.Equals(InspectUploadUtil.CLNT_NAME_HX))
            {
                return;
            }
            else
            {
                throw new Exception("Unkown Client Name Exception");//add by Tony 16-09-18
            }

        }
        //
        public string GetPadDefectResult(string AsDefectType)
        {
            if (string.IsNullOrEmpty(AsDefectType))
            {
                return "";
            }
            if (_ClntName.Equals(InspectUploadUtil.CLNT_NAME_HX))//海信
            {
                switch (AsDefectType)
                {
                    case "0":
                        return "WX"; //无锡
                    case "1":
                        return "SX";//少锡
                    case "2":
                        return "DX";//多锡
                    case "3":
                        return "PG";//高度偏高
                    case "4":
                        return "PD";//高度偏低
                    case "5":
                        return "PD";//面积偏多
                    case "6":
                        return "PS";//面积偏少
                    case "7":
                        return "PY";//X向偏移
                    case "8":
                        return "PY";//Y向偏移
                    case "9":
                        return "QJ";//桥接
                    case "10":
                        return "XX";//锡型不良
                    case "11":
                        return "WD";//污点
                    case "12":
                        return "GM";//共面
                    case "13":
                        return "MJ";//面积比例错误
                    default:
                        return "WX";
                }
            }
            else
            {
                return "";
            }
        }
        //
        public string GetBoardOrArrayInspectResult(string AsResult)
        {
            if (string.IsNullOrEmpty(AsResult))
            {
                return "";
            }
            if (_ClntName.Equals(InspectUploadUtil.CLNT_NAME_XWD))//欣旺达
            {
                switch (AsResult)
                {
                    case "0":
                        return "PASS";
                    case "1":
                        return "FAIL";
                    case "2":
                        return "PASS";
                    case "3":
                        return "";
                    default:
                        return "";
                }
            }
            else
            {
                return "";
            }
        }

        //
        public void SetAreaCode(string AsAreaCode)
        {
            this._areaCode = AsAreaCode;
        }

        public void SetGroupName(string AsGroupName)
        {
            this._groupName = AsGroupName;
        }
    }
}
