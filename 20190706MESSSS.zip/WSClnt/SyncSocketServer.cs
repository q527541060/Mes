﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace WSClnt
{
    /// <summary>
    /// 基于socket实现的同步TCP服务器
    /// </summary>
    public class SocketTCPServer
    {
        #region Fields
        /// <summary>
        /// 服务器程序允许的最大客户端连接数
        /// </summary>
        private int _maxClient;

        /// <summary>
        /// 当前的连接的客户端数
        /// </summary>
        private int _clientCount;

        /// <summary>
        /// 服务器使用的异步socket
        /// </summary>
        private Socket _serverSock;

        /// <summary>
        /// 客户端会话列表
        /// </summary>
        private List<SocketClientHandle> _clients;

        private bool disposed = false;

        #endregion

        #region Properties

        /// <summary>
        /// 服务器是否正在运行
        /// </summary>
        public bool IsRunning { get; private set; }
        /// <summary>
        /// 监听的IP地址
        /// </summary>
        public IPAddress Address { get; private set; }
        /// <summary>
        /// 监听的端口
        /// </summary>
        public int Port { get; private set; }
        /// <summary>
        /// 通信使用的编码
        /// </summary>
        public Encoding Encoding { get; set; }


        #endregion

        #region 构造函数
        /// <summary>
        /// 同步Socket TCP服务器
        /// </summary>
        /// <param name="listenPort">监听的端口</param>
        public SocketTCPServer(int listenPort)
            : this(IPAddress.Any, listenPort, 1024)
        {
        }

        /// <summary>
        /// 同步Socket TCP服务器
        /// </summary>\
        /// <param name="localEP">监听的终结点</param>
        public SocketTCPServer(IPEndPoint localEP)
            : this(localEP.Address, localEP.Port, 1024)
        {
        }

        /// <summary>
        /// 同步Socket TCP服务器
        /// </summary>
        /// <param name="localIPAddress">监听的IP地址</param>
        /// <param name="listenPort">监听的端口</param>
        /// <param name="maxClient">最大客户端数量</param>
        public SocketTCPServer(IPAddress localIPAddress, int listenPort, int maxClient)
        {
            try
            {
                this.Address = localIPAddress;
                this.Port = listenPort;
                this.Encoding = Encoding.Default;

                _maxClient = maxClient;
                _clients = new List<SocketClientHandle>();
                _serverSock = new Socket(localIPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            }
            catch (System.Exception ex)
            {
                throw (new Exception("TCPServer create error:" + ex.Message));
            }
        }


        #endregion

        #region Method
        /// <summary>
        /// 启动服务器
        /// </summary>
        public void Start()
        {
            if (!IsRunning)
            {
                IsRunning = true;
                _serverSock.Bind(new IPEndPoint(this.Address, this.Port));
                Thread thread = new Thread(StartListen);
                thread.Start();

            }
        }
        /// <summary>
        /// 开始进行监听
        /// </summary>
        private void StartListen()
        {
            _serverSock.Listen(1024);
            SocketClientHandle handle;
            while (IsRunning)
            {
                if (_clientCount >= _maxClient)
                {
                    //TODO 客户端过多异常
                    RaiseOtherException(null);
                }
                else
                {
                    try
                    {
                        Socket clientSock = _serverSock.Accept();
                        _clientCount++;
                        //TODO 创建一个处理客户端的线程并启动
                        handle = new SocketClientHandle(clientSock);
                        handle.TCPServerHandle = this;
                        _clients.Add(handle);
                        //使用线程池来操作
                        ThreadPool.QueueUserWorkItem(new WaitCallback(handle.RecevieData));
                    }
                    catch (SocketException ex)
                    {

                    }


                }
            }

        }
        /// <summary>
        /// 停止服务器
        /// </summary>
        public void Stop()
        {
            if (IsRunning)
            {
                IsRunning = false;

                _serverSock.Close();

            }
        }
        /// <summary>
        /// 发送函数
        /// </summary>
        public void Send(string msg, SocketClientHandle client)
        {
            if (client != null && client.IsConnect == true)
            {
                client.SendData(msg);
                RaiseCompletedSend(client);
            }

        }

        public void Send(byte[] msg, SocketClientHandle client)
        {
            if (client != null && client.IsConnect == true)
            {
                client.SendData(msg);
                RaiseCompletedSend(client);
            }

        }

        /// <summary>
        /// 关闭一个与客户端之间的会话
        /// </summary>
        /// <param name="handle">需要关闭的客户端会话对象</param>
        public void Close(SocketClientHandle handle)
        {
            if (handle != null)
            {
                _clients.Remove(handle);
                handle.Dispose();
                _clientCount--;
                //TODO 触发关闭事件

            }
        }
        /// <summary>
        /// 关闭所有的客户端会话,与所有的客户端连接会断开
        /// </summary>
        public void CloseAllClient()
        {
            foreach (SocketClientHandle handle in _clients)
            {
                handle.Dispose();
            }
            _clientCount = 0;
            _clients.Clear();
        }

        #endregion

        #region 事件

        /// <summary>
        /// 与客户端的连接已建立事件
        /// </summary>
        public event EventHandler<SocketEventArgs> ClientConnected;
        /// <summary>
        /// 与客户端的连接已断开事件
        /// </summary>
        public event EventHandler<SocketEventArgs> ClientDisconnected;

        /// <summary>
        /// 触发客户端连接事件
        /// </summary>
        /// <param name="state"></param>
        private void RaiseClientConnected(SocketClientHandle handle)
        {
            if (ClientConnected != null)
            {
                ClientConnected(this, new SocketEventArgs(handle));
            }
        }
        /// <summary>
        /// 触发客户端连接断开事件
        /// </summary>
        /// <param name="client"></param>
        private void RaiseClientDisconnected(Socket client)
        {
            if (ClientDisconnected != null)
            {
                ClientDisconnected(this, new SocketEventArgs("连接断开"));
            }
        }

        /// <summary>
        /// 接收到数据事件
        /// </summary>
        public event EventHandler<SocketEventArgs> DataReceived;

        public void RaiseDataReceived(SocketClientHandle handle)
        {
            if (DataReceived != null)
            {
                DataReceived(this, new SocketEventArgs(handle));
            }
        }

        /// <summary>
        /// 数据发送事件
        /// </summary>
        public event EventHandler<SocketEventArgs> CompletedSend;

        /// <summary>
        /// 触发数据发送事件
        /// </summary>
        /// <param name="state"></param>
        private void RaiseCompletedSend(SocketClientHandle handle)
        {
            if (CompletedSend != null)
            {
                CompletedSend(this, new SocketEventArgs(handle));
            }
        }


        /// <summary>
        /// 网络错误事件
        /// </summary>
        public event EventHandler<SocketEventArgs> NetError;
        /// <summary>
        /// 触发网络错误事件
        /// </summary>
        /// <param name="state"></param>
        private void RaiseNetError(SocketClientHandle handle)
        {
            if (NetError != null)
            {
                NetError(this, new SocketEventArgs(handle));
            }
        }

        /// <summary>
        /// 异常事件
        /// </summary>
        public event EventHandler<SocketEventArgs> OtherException;
        /// <summary>
        /// 触发异常事件
        /// </summary>
        /// <param name="state"></param>
        private void RaiseOtherException(SocketClientHandle handle, string descrip)
        {
            if (OtherException != null)
            {
                OtherException(this, new SocketEventArgs(descrip, handle));
            }
        }
        private void RaiseOtherException(SocketClientHandle handle)
        {
            RaiseOtherException(handle, "");
        }

        #endregion


        #region 释放
        /// <summary>
        /// Performs application-defined tasks associated with freeing, 
        /// releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release 
        /// both managed and unmanaged resources; <c>false</c> 
        /// to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    try
                    {
                        Stop();
                        if (_serverSock != null)
                        {
                            _serverSock = null;
                        }
                    }
                    catch (SocketException)
                    {
                        //TODO 异常
                    }
                }
                disposed = true;
            }
        }

        public static bool IsClientConnected(Socket Aclient)
        {
            try
            {
                return !(Aclient == null || (Aclient.Poll(1000, SelectMode.SelectRead) && (Aclient.Available == 0)) || !Aclient.Connected);
            }
            catch (ObjectDisposedException ode) { return false; }

        }
        #endregion
    }

    /// <summary>
    /// Socket 服务器用于处理客户端连接封装的客户端处理类
    /// </summary>
    public class SocketClientHandle : IDisposable
    {
        /// <summary>
        /// 与客户端相关联的socket
        /// </summary>
        private Socket _client;
        public SocketTCPServer TCPServerHandle { get; set; }

        private const int _receiveBufferLength = 1024 * 10;

        /// <summary>
        /// 标识是否与客户端相连接
        /// </summary>
        private bool _is_connect;

        public bool IsConnect
        {
            get { return _is_connect; }
            set { _is_connect = value; }
        }

        /// <summary>
        /// 数据接受缓冲区
        /// </summary>
        public byte[] _recvBuffer;

        public SocketClientHandle(Socket client)
        {
            this._client = client;
            _is_connect = true;
        }

        #region Method
        /// <summary>
        /// 接受来自客户端发来的数据
        /// </summary>
        public void RecevieData(Object state)
        {
            int len = -1;
            _recvBuffer = new byte[_receiveBufferLength];
            while (_is_connect)
            {
                try
                {
                    if (!SocketTCPServer.IsClientConnected(_client))
                    {
                        TCPServerHandle.Close(this);
                        break;
                    }
                    _recvBuffer = new byte[_receiveBufferLength];
                    len = _client.Receive(_recvBuffer);
                    if (len > 0)
                    {
                        TCPServerHandle.RaiseDataReceived(this);
                    }
                }
                catch (SocketException ex)
                {
                    Console.WriteLine("RecevieData error:" + ex.Message);
                }
            }
        }

        /// <summary>
        /// 向客户端发送数据
        /// </summary>
        public void SendData(string msg)
        {
            byte[] data = Encoding.Default.GetBytes(msg);
            try
            {
                _client.Send(data);
            }
            catch (Exception e)
            {
                throw (new System.Exception("SendData error:" + e.Message));
                //TODO 处理异常
            }
        }

        public void SendData(byte[] msg)
        {
            try
            {
                _client.Send(msg);
            }
            catch (Exception e)
            {
                throw (new System.Exception("SendData error:" + e.Message));
                //TODO 处理异常
            }
        }

        #endregion


        #region 事件


        //TODO 消息发送事件
        //TODO 数据收到事件
        //TODO 异常处理事件

        #endregion

        #region 释放
        /// <summary>
        /// Performs application-defined tasks associated with freeing, 
        /// releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            _is_connect = false;
            if (_client != null)
            {
                _client.Close();
                _client = null;
            }
            GC.SuppressFinalize(this);
        }

        #endregion

    }

    /// <summary>
    /// 同步Socket TCP服务器事件类
    /// </summary>
    public class SocketEventArgs : EventArgs
    {
        /// <summary>
        /// 提示信息
        /// </summary>
        public string _msg;

        /// <summary>
        /// 客户端状态封装类
        /// </summary>
        public SocketClientHandle _handle;

        /// <summary>
        /// 是否已经处理过了
        /// </summary>
        public bool IsHandled { get; set; }

        public SocketEventArgs(string msg)
        {
            this._msg = msg;
            IsHandled = false;
        }
        public SocketEventArgs(SocketClientHandle handle)
        {
            this._handle = handle;
            IsHandled = false;
        }
        public SocketEventArgs(string msg, SocketClientHandle handle)
        {
            this._msg = msg;
            this._handle = handle;
            IsHandled = false;
        }
    }
}
