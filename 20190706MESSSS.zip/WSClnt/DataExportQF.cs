﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Management;
using System.IO.Compression;
using System.Windows.Forms;
using InspectMainLib;
using AppLayerLib;
using System.Xml;
using System.Globalization;
using ImgCSCoreIM;

namespace WSClnt
{
    public partial class DataExport
    {      
       
        //Q.F.2016.11.07 for vitrox jabil
        private String SaveDataExpFileJABIL(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,        
         AppSettingData AappSettingData,
         string AstrDir  //export folder
         )
        {
            String strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }


                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strboardBarcode, RS_NOREAD))
                    strboardBarcode = "Barcode0";
             
                StringBuilder strBldBoard = new StringBuilder();               

                //serial number               
                strBldBoard.Append("S" + strboardBarcode + RS_LineEnd);
                //Tester Name             
                strBldBoard.Append("N" +AappSettingData.stDataExpVT.strTesterName + RS_LineEnd);
                //Customer             
                strBldBoard.Append("C" +AappSettingData.stDataExpVT.strCustomer + RS_LineEnd);
                //Division             
                strBldBoard.Append("I" +AappSettingData.stDataExpVT.strDivision + RS_LineEnd);
                //Board Style             
                strBldBoard.Append("B" + AappSettingData.stDataExpVT.strBoardStyle + RS_LineEnd);
                //Test Process          
                strBldBoard.Append("P" +AappSettingData.stDataExpVT.strTestProcess + RS_LineEnd);
                //Assembly  Number          
                strBldBoard.Append("n" +AappSettingData.stDataExpVT.strAssemblyNumber + RS_LineEnd);
                //Assembly  Revision          
                strBldBoard.Append("r" +AappSettingData.stDataExpVT.strAssemblyRevision + RS_LineEnd);
                //Assembly  Version          
                strBldBoard.Append("v" +AappSettingData.stDataExpVT.strAssemblyVersion + RS_LineEnd);
                //OperatorID 
                strBldBoard.Append("O" +AappSettingData.stDataExpVT.strOperatorID + RS_LineEnd);
                //Line 
                strBldBoard.Append("L" +AappSettingData.stDataExpVT.strLine + RS_LineEnd);
                //Site 
                strBldBoard.Append("p" +AappSettingData.stDataExpVT.iSite + RS_LineEnd);

                //info from pcb calculation
                //Test Status  P F A, good and pass => P
                String strInfo = "T";
                if(ABrdRes.jugResult == JudgeRes.NG)
                {
                    strInfo += "F";
                }
                else if(ABrdRes.jugResult == JudgeRes.Skipped)
                {
                    strInfo += "A";
                }else
                {
                    strInfo += "P";
                }
                strBldBoard.Append(strInfo + RS_LineEnd);
                //start and end time
                strInfo = "[";
                strInfo += ABrdRes.startTime.ToString("dd-MM-yyyy")
                    + " " + ABrdRes.startTime.ToString("HH:mm:ss");
                strBldBoard.Append(strInfo + RS_LineEnd);
                strInfo = "]";
                strInfo += ABrdRes.endTime.ToString("dd-MM-yyyy")
                    + " " + ABrdRes.endTime.ToString("HH:mm:ss");
                strBldBoard.Append(strInfo + RS_LineEnd);


                //Measure Label 
                strBldBoard.Append("M" +AappSettingData.stDataExpVT.strMeasureLable + RS_LineEnd);
                //Measure Data 
                strBldBoard.Append("d"+AappSettingData.stDataExpVT.strMeasureData + RS_LineEnd);

                //job Location
                strBldBoard.Append(">" + ABrdRes.jobName + RS_LineEnd);

                //calculation
                //byResUnit = 0: mm
                //byResUnit = 1: um
                //byResUnit = 2: mil
                float fmilDivider = 1000.0f;              
                //Q.F.2016.10.25
                if(AappSettingData.stDataExpVT.byResUnit == 1)
                {
                    fmilDivider = 1.0f;
                }
                else if(AappSettingData.stDataExpVT.byResUnit == 2)
                {
                    fmilDivider = 25.4f;
                }
              


                int i = 0, iLength = APads.Length; 
                int iCountNG = 0,iCountWarning = 0;   //warning count wait confirmed by vitrox
                double dSumHUM = 0, dSumVPerc = 0, dSumAPerc  = 0, dSumOXMM = 0, dSumOYMM = 0;
                float fPerc = 100;
                int iEntireCount = 0;
                InspectMainLib.Pad pad = null;
                for(; i != iLength; ++i)
                {
                    pad = APads[i];
                    // not cal these skipped pads
                    if(_wsBaseF.bPadIsSkip(pad))
                        continue;
                    if(pad.res.jugRes == JudgeRes.NG)
                    {
                        iCountNG++;
                    }
                    iEntireCount++;

                    dSumHUM += pad.res.measuredValue.height;
                    dSumVPerc += pad.res.measuredValue.perVol * fPerc;
                    dSumAPerc += pad.res.measuredValue.perArea * fPerc;
                    dSumOXMM += pad.res.measuredValue.offsetX;
                    dSumOYMM += pad.res.measuredValue.offsetY;

                }
                //avg
                if (iEntireCount != 0)
                {
                    dSumHUM /= iEntireCount;
                    dSumOXMM /= iEntireCount;
                    dSumOYMM /= iEntireCount;
                }


                //change the res unit
                //change from um to setting unit
                dSumHUM /= fmilDivider; 
                dSumOXMM = dSumOXMM * _fMM2UM / fmilDivider;
                dSumOYMM = dSumOYMM * _fMM2UM / fmilDivider;

                //NG count
                strBldBoard.Append("MCNT_FAILURE" + RS_LineEnd);
                strBldBoard.Append("d" + iCountNG + RS_LineEnd);

                //warning count
                strBldBoard.Append("MCNT_WARNING" + RS_LineEnd);
                strBldBoard.Append("d" + iCountWarning + RS_LineEnd);

                 //avg vol of entire pcb
                strBldBoard.Append("MAVG_VOL" + RS_LineEnd);
                strBldBoard.Append("d" + dSumVPerc.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);

                //avg height of entire pcb
                strBldBoard.Append("MAVG_Height" + RS_LineEnd);
                strBldBoard.Append("d" + dSumHUM.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);

                //avg offsetx of entire pcb
                strBldBoard.Append("MAVG_OffsetX" + RS_LineEnd);
                strBldBoard.Append("d" + dSumOXMM.ToString(RS_FLOATFORMAT_6Bit) + RS_LineEnd);

                 //avg offsety of entire pcb
                strBldBoard.Append("MAVG_OffsetY" + RS_LineEnd);
                strBldBoard.Append("d" + dSumOYMM.ToString(RS_FLOATFORMAT_6Bit) + RS_LineEnd);

                 //avg area of entire pcb
                strBldBoard.Append("MAVG_Area" + RS_LineEnd);
                strBldBoard.Append("d" + dSumAPerc.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                //Q.F.2016.11.14
                double dValue = 0;
                if (ABrdRes.jugResult == JudgeRes.NG)
                {
                    for (i = 0; i != iLength; ++i)
                    {
                        pad = APads[i];
                        // not cal these skipped pads
                        if (_wsBaseF.bPadIsSkip(pad))
                            continue;
                        if (pad.res.jugRes == JudgeRes.NG)
                        {
                            strInfo = ">" + pad.strArrayID + ":";
                            if (String.IsNullOrEmpty(pad.componentID))
                            {
                                strInfo += "NoName";
                            }
                            else
                            {
                                strInfo += pad.componentID;
                            }
                            strInfo += RS_UnderLine + pad.padID + RS_UnderLine;
                            switch (pad.res.jugDefectType)
                            {
                                case DefectType.Missing:
                                    {
                                        dValue = pad.res.measuredValue.perVol * fPerc;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }
                                case DefectType.Insufficient:
                                    {
                                        dValue = pad.res.measuredValue.perVol * fPerc;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }
                                case DefectType.Excess:
                                    {
                                        dValue = pad.res.measuredValue.perVol * fPerc;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }
                                case DefectType.OverHeight:
                                    {
                                        dValue = pad.res.measuredValue.height / fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }//高度偏高
                                case DefectType.LowHeight:
                                    {
                                        dValue = pad.res.measuredValue.height / fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }//高度偏低
                                case DefectType.OverArea:
                                    {
                                        dValue = pad.res.measuredValue.perArea * fPerc;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }//面积偏多
                                case DefectType.LowArea:
                                    {
                                        dValue = pad.res.measuredValue.perArea * fPerc;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    }//面积偏少
                                case DefectType.ShiftX:
                                    {
                                        dValue = pad.res.measuredValue.offsetX * _fMM2UM /fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_6Bit);
                                        break;
                                    }//X向偏移
                                case DefectType.ShiftY:
                                    {
                                        dValue = pad.res.measuredValue.offsetX * _fMM2UM / fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_6Bit);
                                        break;
                                    }//Y向偏移
                                case DefectType.Bridge:
                                    {
                                        dValue = pad.spec.brdgDistance / fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit) + RS_UnderLine;
                                        dValue = pad.spec.brdgMinWidth / fmilDivider;
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    };//桥接
                                case DefectType.ShapeError:
                                    {
                                        dValue = pad.res.measuredValue.maxMeanHeightDelta / fmilDivider;                                      
                                        strInfo += dValue.ToString(RS_FLOATFORMAT_4Bit);
                                        break;
                                    };//锡型不良
                                //case "11":
                                //    return "WD";//污点
                                //case "12":
                                //    return "GM";//共面
                                case DefectType.PadAreaError:
                                    {                                       
                                       strInfo += pad.spi2DRes.sPadAreaPerc.ToString(RS_FLOATFORMAT_4Bit);
                                       break;
                                    }; ;//面积比例错误
                                default:
                                    { break; }
                            }

                            strBldBoard.Append(pad.res.jugDefectType.ToString() + RS_LineEnd);
                            strBldBoard.Append(strInfo + RS_LineEnd); 


                        }
                     
                    }
                }


              
                String strStartTime = ABrdRes.startTime.Year.ToString("0000")
                                + ABrdRes.startTime.Month.ToString("00")
                                + ABrdRes.startTime.Day.ToString("00")
                                + ABrdRes.startTime.Hour.ToString("00")
                                + ABrdRes.startTime.Minute.ToString("00")
                                + ABrdRes.startTime.Second.ToString("00");               
              
                //at first gen tmp file in local
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);              
                streamWrt.Close();

                string strFileName = AstrDir + strboardBarcode + RS_UnderLine3 + strStartTime + RS_TXT_EXT;
                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }

            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTMsg + "(JABIL)" +  ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }


        private String SaveBadMarkSystemFileForJUKI(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         AppSettingData AappSettingData,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppMultiLan.AppLan Adict,  
         string AstrDir,  //export folder
         byte AbyLaneNo,
         string AstrClntName
         )
        {
            String strMsg = RS_EMPTY;
            try
            {
                if (ABrdRes.jugResult == JudgeRes.NG && AappSettingData.bBadMarkSystemIgnoreNGPCB)
                    return strMsg;


                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() + RS_UnderLine + RS_DATAEXPORTTEMPFILEBM;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                //Q.F.2017.01.11
                if (AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bENClearExportFolder == true)
                {
                    _wsBaseF.CheckAndDeleteDir(ref AstrDir, RS_XML_EXT);
                }

                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.AppendChild(XmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null));
                
                //XmlNode T_Root, T_ChildNode, TSubNode,TThirdNode;
                XmlElement  xEleUnit;
                
                xEleUnit = XmlDoc.CreateElement("Pwb");
                XmlDoc.AppendChild(xEleUnit);
                //T_Root = XmlDoc.DocumentElement;
                
                //Barcode
                InsertBarcodeEle(ref XmlDoc, ref xEleUnit, ref ABrdRes,
                    ref AappSettingData, ref  APcbGeneralInfo);
                
                //BadMark
                bool AbUseNGAsBadMark = false;
                int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, AbUseNGAsBadMark, Adict);
                InsertMarkEle(ref XmlDoc, ref xEleUnit, aIInfo);              
                
                XmlDoc.Save(tmpFile);

                String strFileName = AstrDir + Path.GetFileNameWithoutExtension(ABrdRes.jobName) + RS_UnderLine;
                int iMax = 100000;

                int iPcbID = ABrdRes.pcbID;// +99998;
                if(iPcbID  == 0)
                    iPcbID = 1;
                if(iPcbID >= iMax)
                {
                    iPcbID = iPcbID % iMax + 1;
                }  
                String strTmp = "0000" +  iPcbID;
                if (strTmp.Length > 5)
                {
                    int iIndex = strTmp.Length - 5;
                    if (iIndex > 4)
                    { 
                        iIndex = 4;
                    }
                    strTmp = strTmp.Substring(iIndex);
                }
                strFileName += strTmp + RS_XML_EXT;
                Thread.Sleep(20);
                if (File.Exists(tmpFile))
                {
                    String[] strLines = File.ReadAllLines(tmpFile);
                    File.Delete(tmpFile);
                    Thread.Sleep(20);
                    if (strLines != null)
                    {
                        for (int i = 0; i < strLines.Length; i++)
                        {
                            strLines[i] = strLines[i].TrimStart();
                        }
                    }
                 
                    //if (File.Exists(tmpFile))
                    {
                        File.WriteAllLines(tmpFile, strLines);
                        Thread.Sleep(20);
                        File.Copy(tmpFile, strFileName, true);
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTBadMarkMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }
        private XmlElement InsertMarkEle(ref XmlDocument AXmlDoc,
            ref XmlElement AXmlParentElement,
            int[] AaIInfo)
        {
            try
            {
                XmlElement XmlEleMark = AXmlDoc.CreateElement("Mark");
                AXmlParentElement.AppendChild(XmlEleMark);

                XmlElement XmlEleBadMark = AXmlDoc.CreateElement("BadMark");
                XmlEleMark.AppendChild(XmlEleBadMark);

                XmlElement XmlEleBadMarkCount = AXmlDoc.CreateElement("BadMarkCount");
                int iCount = 0;
                if (AaIInfo != null)
                    iCount = AaIInfo.Length;
                XmlEleBadMarkCount.SetAttribute("cnt", iCount.ToString());
                XmlEleBadMark.AppendChild(XmlEleBadMarkCount);

                XmlElement XmlEle = null;
                XmlElement XmlEleBadMarkRes = null;
                String strISNOTBadMark = "NONE";
                String strISBadMark = "DONE";  //Q.F.2016.12.03
                for (int i = 0; i != iCount; i++)
                {
                    XmlEle = AXmlDoc.CreateElement("BadMarkData");
                    XmlEle.SetAttribute("num", (i + 1).ToString());
                    XmlEleBadMark.AppendChild(XmlEle);

                    XmlEleBadMarkRes = AXmlDoc.CreateElement("BadMarkRecResult");
                    //XmlEleBadMarkRes.InnerText = AaIInfo[i].ToString();
                    //Q.F.2016.12.03
                    if (AaIInfo[i] == 0)
                    {
                        XmlEleBadMarkRes.InnerText = strISNOTBadMark;
                    }
                    else
                    {
                        XmlEleBadMarkRes.InnerText = strISBadMark;
                    }
                    XmlEle.AppendChild(XmlEleBadMarkRes);
                }
                return XmlEleMark;
            }
            catch (Exception ex)
            {
                return null;
            }
          
        }
        private XmlElement InsertBarcodeEle(ref XmlDocument AXmlDoc,
            ref XmlElement AXmlParentElement,
            ref  SPCBoardRes ABrdRes,
            ref AppSettingData AappSettingData,
            ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo
           )
        {
            try
            {

                XmlElement XmlEleBarcode = AXmlDoc.CreateElement("Barcode");
                AXmlParentElement.AppendChild(XmlEleBarcode);

                XmlElement XmlEleBarcodeCount = AXmlDoc.CreateElement("BarcodeCount");
                int iCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo,(byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (iCount > 1)
                {
                    iCount = APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length;
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                        && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                    {
                        iCount--;
                    }
                }
                XmlEleBarcodeCount.SetAttribute("cnt", iCount.ToString());
                XmlEleBarcode.AppendChild(XmlEleBarcodeCount);

              
                if (iCount >= 1)
                {
                    XmlElement XmlEle = null;
                    XmlElement XmlEleBarcodeString = null;
                    String strBarcode = RS_EMPTY;
                    if (iCount == 1)
                    {
                        strBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                        XmlEle = AXmlDoc.CreateElement("BarcodeData");
                        XmlEle.SetAttribute("num", "1");
                        XmlEleBarcode.AppendChild(XmlEle);

                        XmlEleBarcodeString = AXmlDoc.CreateElement("BarcodeString");
                        XmlEleBarcodeString.InnerText = strBarcode;
                        XmlEle.AppendChild(XmlEleBarcodeString);
                    }
                    else
                    {
                        int iArrayIDIndex = 0;
                        iCount = APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length;
                        for (int i = 0; i != iCount; i++)
                        {
                            iArrayIDIndex = i;
                            if (AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseCamBrcd == true
                                 || AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].useManualBarcode == true)
                            {
                                if (i == 0
                                    && APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                                    && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                                    continue;
                            }
                            else
                            {
                                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                                    && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                                {
                                    iArrayIDIndex = i + 1;
                                }
                                if (iArrayIDIndex >= APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length)
                                    continue;

                            }
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == true)
                            {
                                iArrayIDIndex++;
                            }

                            strBarcode = _wsBaseF.BarcodeDicision(APcbGeneralInfo.PanelResults[0].arrStrBrcd[i].Trim(),
                                                                 AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                            XmlEle = AXmlDoc.CreateElement("BarcodeData");
                            XmlEle.SetAttribute("num", iArrayIDIndex.ToString());
                            XmlEleBarcode.AppendChild(XmlEle);

                            XmlEleBarcodeString = AXmlDoc.CreateElement("BarcodeString");
                            XmlEleBarcodeString.InnerText = strBarcode;
                            XmlEle.AppendChild(XmlEleBarcodeString);
                        }
                    }
                }


                return XmlEleBarcode;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        //Q.F.2016.12.13
        private String SaveDispenserSystemForDefault(InspectMainLib.Marks AMarks,
            SPCBoardRes ABrdRes,
            AppSettingData AappSettingData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppMultiLan.AppLan Adict,
            string AstrDir,  //export folder
            byte AbyLaneNo,
            string AstrClntName
            )
        {
            String strMsg = RS_EMPTY;
            try
            {
                

                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() + RS_UnderLine + RS_DATAEXPORTTEMPFILEDispenser;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.AppendChild(XmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null));

                //XmlNode T_Root, T_ChildNode, TSubNode,TThirdNode;
                XmlElement xEleUnit;

                xEleUnit = XmlDoc.CreateElement("SPIData");
                XmlDoc.AppendChild(xEleUnit);
                

                //Message
                InsertMessageEle(ref XmlDoc, ref xEleUnit, ref ABrdRes,
                    ref AappSettingData);

               
                //Barcode
                InsertBarcodeEle(ref XmlDoc, ref xEleUnit, ref ABrdRes,
                    ref AappSettingData, ref  APcbGeneralInfo);

                //BadMark            
                InsertMarkEle(ref XmlDoc, ref xEleUnit, ref AMarks,ref APcbGeneralInfo);

                XmlDoc.Save(tmpFile);

                string strBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                String strStartTime = ABrdRes.startTime.Year.ToString("0000")
                                + ABrdRes.startTime.Month.ToString("00")
                                + ABrdRes.startTime.Day.ToString("00")
                                + ABrdRes.startTime.Hour.ToString("00")
                                + ABrdRes.startTime.Minute.ToString("00")
                                + ABrdRes.startTime.Second.ToString("00");

                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                String strFileName = AstrDir + strJobName + RS_UnderLine +
                    strBarcode + RS_UnderLine + strStartTime + RS_XML_EXT;            
                
                Thread.Sleep(20);
                if (File.Exists(tmpFile))
                {
                    if(AappSettingData.stDispenserSystemParams.bEnXMLTrimStartMarkInfo == true)
                    {
                        String[] strLines = File.ReadAllLines(tmpFile);
                        File.Delete(tmpFile);
                        Thread.Sleep(20);
                        if (strLines != null)
                        {
                            for (int i = 0; i < strLines.Length; i++)
                            {
                                strLines[i] = strLines[i].TrimStart();
                            }
                        }

                        //if (File.Exists(tmpFile))
                        {
                            File.WriteAllLines(tmpFile, strLines);
                            Thread.Sleep(20);
                        }
                        
                    }
                    File.Copy(tmpFile, strFileName, true);
                }

            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTDispenserMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }
        private XmlElement InsertMarkEle(ref XmlDocument AXmlDoc,
            ref XmlElement AXmlParentElement,            
            ref InspectMainLib.Marks AMarks,
            ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo
           )
        {
            try
            {

                XmlElement XmlEleMark = AXmlDoc.CreateElement("Mark");
                AXmlParentElement.AppendChild(XmlEleMark);

                XmlElement XmlEleMarkCount = AXmlDoc.CreateElement("MarkCount");
                int i = 0,iCount = 0, iGroupIndex = 0, iMarkIndex = 0,iNum = 0;
                if (APcbGeneralInfo.bEnGlbMarkGroup == false)//
                {
                    iCount = AMarks.MarkType0SeqIndex.Length;                    
                }
                else
                {
                    for (iGroupIndex = 0; iGroupIndex < AMarks.arrGlbMarkGroup.Length; iGroupIndex++)
                    {
                        iCount += AMarks.arrGlbMarkGroup[iGroupIndex].arrGlbMarkIndexSeq.Length;            
                    }
                }
                XmlEleMarkCount.SetAttribute("cnt", iCount.ToString());
                XmlEleMark.AppendChild(XmlEleMarkCount);

                XmlElement XmlEle = null;
                XmlElement XmlEleSub = null;

                //XmlEle = AXmlDoc.CreateElement("Unit");
                //XmlEle.InnerText = "MM";
                //XmlEle.AppendChild(XmlEle);

                float fPos = 0.0f;
                String strGlbMarkGroupID = "NONE";
                if (APcbGeneralInfo.bEnGlbMarkGroup == false)
                {
                    for (i = 0; i < iCount; i++)
                    {
                        iMarkIndex = AMarks.MarkType0SeqIndex[i];

                        XmlEle = AXmlDoc.CreateElement("MarkData");
                        iNum = (i + 1);
                        XmlEle.SetAttribute("num", iNum.ToString());
                        XmlEleMark.AppendChild(XmlEle);

                        XmlEleSub = AXmlDoc.CreateElement("X");
                        fPos =  AMarks.markList[iMarkIndex].posXmm;
                        XmlEleSub.SetAttribute("Origin", fPos.ToString(RS_FLOATFORMAT_4Bit));
                        fPos = AMarks.markList[iMarkIndex].posXmm + (float)AMarks.markList[iMarkIndex].markRes.shiftXmm;
                        XmlEleSub.InnerText = fPos.ToString(RS_FLOATFORMAT_4Bit);                            ;
                        XmlEle.AppendChild(XmlEleSub);

                        XmlEleSub = AXmlDoc.CreateElement("Y");
                        fPos = AMarks.markList[iMarkIndex].posYmm;
                        XmlEleSub.SetAttribute("Origin", fPos.ToString(RS_FLOATFORMAT_4Bit));
                        fPos = AMarks.markList[iMarkIndex].posYmm + (float)AMarks.markList[iMarkIndex].markRes.shiftYmm;
                        XmlEleSub.InnerText = fPos.ToString(RS_FLOATFORMAT_4Bit); ;
                        XmlEle.AppendChild(XmlEleSub);

                        XmlEleSub = AXmlDoc.CreateElement("GlbMarkGroupID");                   
                        XmlEleSub.InnerText = strGlbMarkGroupID;
                        XmlEle.AppendChild(XmlEleSub);
                    }
                }
                else
                {
                    iNum = 1;
                    for (iGroupIndex = 0; iGroupIndex < AMarks.arrGlbMarkGroup.Length; iGroupIndex++)
                    {
                        strGlbMarkGroupID = AMarks.arrGlbMarkGroup[iGroupIndex].strGlbMarkGroupID;
                        iCount = AMarks.arrGlbMarkGroup[iGroupIndex].arrGlbMarkIndexSeq.Length;
                        for (i = 0; i < iCount; i++)
                        {
                            iMarkIndex = AMarks.arrGlbMarkGroup[iGroupIndex].arrGlbMarkIndexSeq[i];

                            XmlEle = AXmlDoc.CreateElement("MarkData");                          
                            XmlEle.SetAttribute("num", iNum.ToString());
                            XmlEleMark.AppendChild(XmlEle);

                            XmlEleSub = AXmlDoc.CreateElement("X");
                            fPos = AMarks.markList[iMarkIndex].posXmm;
                            XmlEleSub.SetAttribute("Origin", fPos.ToString(RS_FLOATFORMAT_4Bit));
                            fPos = AMarks.markList[iMarkIndex].posXmm + (float)AMarks.markList[iMarkIndex].markRes.shiftXmm;
                            XmlEleSub.InnerText = fPos.ToString(RS_FLOATFORMAT_4Bit); ;
                            XmlEle.AppendChild(XmlEleSub);

                            XmlEleSub = AXmlDoc.CreateElement("Y");
                            fPos = AMarks.markList[iMarkIndex].posYmm;
                            XmlEleSub.SetAttribute("Origin", fPos.ToString(RS_FLOATFORMAT_4Bit));
                            fPos = AMarks.markList[iMarkIndex].posYmm + (float)AMarks.markList[iMarkIndex].markRes.shiftYmm;
                            XmlEleSub.InnerText = fPos.ToString(RS_FLOATFORMAT_4Bit); ;
                            XmlEle.AppendChild(XmlEleSub);

                            XmlEleSub = AXmlDoc.CreateElement("GlbMarkGroupID");
                            XmlEleSub.InnerText = strGlbMarkGroupID;
                            XmlEle.AppendChild(XmlEleSub);
                            iNum++;
                        }
                    }

                }

                return XmlEleMark;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        private XmlElement InsertMessageEle(ref XmlDocument AXmlDoc,
           ref XmlElement AXmlParentElement,
           ref  SPCBoardRes ABrdRes,     
           ref AppSettingData AappSettingData
          )
        {
            try
            {
                XmlElement XmlEleMessage = AXmlDoc.CreateElement("Message");
                XmlEleMessage.SetAttribute("version", "1.0");
                AXmlParentElement.AppendChild(XmlEleMessage);

                XmlElement XmlEle = null;

                XmlEle = AXmlDoc.CreateElement("JobName");
                string strFileName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                XmlEle.InnerText = strFileName;
                XmlEleMessage.AppendChild(XmlEle);

                XmlEle = AXmlDoc.CreateElement("Inspected_Date_and_Time");
                XmlEle.InnerText = ABrdRes.startTime.GetDateTimeFormats('s')[0].ToString();
                XmlEleMessage.AppendChild(XmlEle);

                string strBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                XmlEle = AXmlDoc.CreateElement("PanelID");
                XmlEle.InnerText = strBarcode;
                XmlEleMessage.AppendChild(XmlEle);

                XmlEle = AXmlDoc.CreateElement("InspectionResult");
                string strResult = _wsBaseF.GetJudgeResult(ABrdRes.jugResult, AappSettingData);
                XmlEle.InnerText = strResult.ToUpper();
                XmlEleMessage.AppendChild(XmlEle);

                return XmlEleMessage;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        private String SaveMountSystemFileForNPM(InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            AppSettingData AappSettingData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppMultiLan.AppLan Adict,           
            byte AbyLaneNo,
            bool bExportPCBSerialNum,
            string AstrClntName
            )
        {
            String strMsg = RS_EMPTY;
            try
            {
                //create dir
                String strDir = AappSettingData.stMountSystemWistron.stAPC.strExpPath;
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder!";
                    return strMsg;
                }
                String strDirERes = strDir + "Result";
                if (bExportPCBSerialNum == true)
                {
                    strMsg = GenPcbInfomationFileForNPM(AappSettingData, AbyLaneNo, strDirERes);
                    return strMsg;
                }  
                
                _wsBaseF.DirCheck(ref strDirERes);

                //gen pcb serial
                long lPcbSerialNum = 0;
                if (AbyLaneNo == 1)
                {
                    lPcbSerialNum = _lPcbSerialStartNumberBySPILane1ForNPM + _lPcbSerialNumberBySPILane1ForNPM;
                    if (_lPcbSerialNumberBySPILane1ForNPM == _lPcbSerialNumberBySPIMaximalForNPM)
                    {
                        _lPcbSerialNumberBySPILane1ForNPM = 0;
                    }
                    else
                    {
                        _lPcbSerialNumberBySPILane1ForNPM++;
                    }
                }
                else
                {
                    lPcbSerialNum = _lPcbSerialStartNumberBySPILane2ForNPM + _lPcbSerialNumberBySPILane2ForNPM;
                    if (_lPcbSerialNumberBySPILane2ForNPM == _lPcbSerialNumberBySPIMaximalForNPM)
                    {
                        _lPcbSerialNumberBySPILane2ForNPM = 0;
                    }
                    else
                    {
                        _lPcbSerialNumberBySPILane2ForNPM++;
                    }
                }
                //at first gen inspection reuslt file
                GenInspectionAndConFirmResultFileForNPM(
                    APads,
                    ABrdRes,
                    AappSettingData,
                    APcbGeneralInfo,
                    strDirERes,
                    lPcbSerialNum,
                    AbyLaneNo,
                    Adict);
                Thread.Sleep(200); 

                //second gen feedback file


                //third confirmation input result file

                MigratePcbInfomationFileForNPM(AappSettingData, lPcbSerialNum, AbyLaneNo);




                ////at last gen the pcb information file
                //GenPcbInfomationFileForNPM(strDirForPcbinfo,lPcbSerialNum,AbyLaneNo);



            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTMountMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }
        //gen pcb information file
        public string GenPcbInfomationFileForNPM(AppSettingData AappSettingData,
            byte AbyLaneNo, String AstrResDir)
        {
            string strMsg = "NPM Gen SRL File:";
            try
            {
                
                String strDir = AappSettingData.stMountSystemWistron.stAPC.strExpPath;
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder!";
                    return strMsg;
                }
                String strDirForPcbinfo = strDir + "NextOutPcb";
                if (AappSettingData.stMountSystemWistron.stAPC.bUseConveyor == true)
                {
                    strDirForPcbinfo = strDir + "NextNextOutPcb";
                }
                //_wsBaseF.DirCheck(ref strDirForPcbinfo);
                if (_wsBaseF.DirCheck(ref strDirForPcbinfo) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder:" + strDirForPcbinfo;
                    return strMsg;
                }
                strDirForPcbinfo += "Lane" + AbyLaneNo;
                if (_wsBaseF.DirCheck(ref strDirForPcbinfo) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder:" + strDirForPcbinfo;
                    return strMsg;
                }
                _wsBaseF.CheckAndDeleteDir(ref strDirForPcbinfo, RS_SRL_EXT);


               
                //Q.F.2017.01.03
                long lPCBSerialNum = 0;
                long LastPCB = 0;
                long LastLastPCB = 0;
                if (Directory.Exists(AstrResDir))
                {
                    if(AbyLaneNo == 1 && _lPcbSerialNumberBySPILane1ForNPM == 0)
                    {
                        LastLastPCB = _lPcbSerialNumberBySPILane1ForNPM;
                        String[] files = _wsBaseF.GetFiles(AstrResDir, RS_RST_EXT);
                        if (files != null && files.Length > 0)
                        {
                            files = _wsBaseF.SortArrayString(files, true);
                            for (int i = 0; i < files.Length; ++i)
                            {
                                LastPCB = Convert.ToInt64(Path.GetFileNameWithoutExtension(files[i]));
                                if (LastPCB >= _lPcbSerialStartNumberBySPILane2ForNPM)
                                {
                                    
                                    break;
                                }
                                LastLastPCB = LastPCB - _lPcbSerialStartNumberBySPILane1ForNPM;
                            }

                            if (LastLastPCB < _lPcbSerialNumberBySPIMaximalForNPM)
                            {
                                _lPcbSerialNumberBySPILane1ForNPM = LastLastPCB + 1;
                            }
                        }
                    }
                    if (AbyLaneNo == 2 && _lPcbSerialNumberBySPILane2ForNPM == 0)
                    {
                        LastLastPCB = _lPcbSerialNumberBySPILane2ForNPM;
                        String[] files = _wsBaseF.GetFiles(AstrResDir, RS_RST_EXT);
                        if (files != null && files.Length > 0)
                        {
                            files = _wsBaseF.SortArrayString(files, true);
                            for (int i = 0; i < files.Length; ++i)
                            {
                                LastPCB = Convert.ToInt64(Path.GetFileNameWithoutExtension(files[i]));
                                if (LastPCB < _lPcbSerialStartNumberBySPILane2ForNPM)
                                {
                                    continue;
                                }
                                LastLastPCB = LastPCB - _lPcbSerialStartNumberBySPILane2ForNPM;
                            }

                            if (LastLastPCB < _lPcbSerialNumberBySPIMaximalForNPM)
                            {
                                _lPcbSerialNumberBySPILane2ForNPM = LastLastPCB + 1;
                            }
                        }
                    }
                }

                if (AbyLaneNo == 1)
                {
                    lPCBSerialNum = _lPcbSerialStartNumberBySPILane1ForNPM + _lPcbSerialNumberBySPILane1ForNPM;                  
                }
                else
                {
                    lPCBSerialNum = _lPcbSerialStartNumberBySPILane2ForNPM + _lPcbSerialNumberBySPILane2ForNPM;                   
                }


                string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() +
                    RS_UnderLine + "SRL" + RS_DATAEXPORTTEMPFILEMount;

                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                string strFileName = strDirForPcbinfo + lPCBSerialNum + RS_SRL_EXT;
                if (File.Exists(strFileName))
                {
                    File.Delete(strFileName);                    
                }

                FileStream fs = new FileStream(tmpFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fs.Close();

                Thread.Sleep(20);
                File.Copy(tmpFile, strFileName, true);


                return strMsg;

            }
            catch (System.Exception ex)
            {
                strMsg += RS_DATAEXPORTMountMsg + ex.ToString();
                return strMsg;
            }

        }
   
    
        private int GenInspectionAndConFirmResultFileForNPM (
            InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            AppSettingData AappSettingData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            string AstrDir,
            long lPCBSerialNum,
            byte AbyLaneNo,
            AppMultiLan.AppLan Adict
            //bool bExportConfirmInfo//
            )
				 {

					 if(AappSettingData.stMountSystemWistron.stAPC.bEnAPC == false)
						 return 0;
					
					 try
					 {
                          string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() +
                              RS_UnderLine + RS_DATAEXPORTTEMPFILEMount;
                          string tmpFile1 = _strTmpFileDir + "\\" + AbyLaneNo.ToString()  +
                               RS_UnderLine + "CIR" + RS_DATAEXPORTTEMPFILEMount;
                          if (File.Exists(tmpFile))
                          {
                              File.Delete(tmpFile);
                          }
                          if (File.Exists(tmpFile1))
                          {
                              File.Delete(tmpFile1);
                          }
						 int i = 0,j = 0,k = 0,iCount = 0, iNum = 0,iPadIndex = 0;
                         float fMountX = 0f, fMountY = 0f;
                         float fGX = 0f, fGY = 0f, fSX = 0f, fSY = 0f;
                         float FHGnd = 0f, fGapX = 0f, fGapY = 0f, fHAve = 0;
                         float fHTop = 0f, fRcgSX = 0, fEcgSY = 0f;
                         
                         //BadMark
                         //Q.F.2017.02.23
                         bool bUseNGAsBadMark = APcbGeneralInfo.bNGPadAsBadMark;//(AappSettingData.stMountSystemWistron.stAPC.byBadMarkExpOption == 1);
                         int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, bUseNGAsBadMark, Adict);
						 if(aIInfo == null)
							 return -1;

						 String strDate = ABrdRes.startTime.ToString("yyyy/MM/dd") + "," +
                             ABrdRes.startTime.ToLongTimeString();

                         //get board barcode
                         String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                         //Q.F.2016.12.28       
                         int iBarcodeJdg = 0;
                         if (   AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseExtBrcd == false
                             && AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseCamBrcd == false
                             && AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].useManualBarcode == false)
                         {
                             iBarcodeJdg = 2;
                             strboardBarcode = RS_EMPTY;
                         }
                         else if (strboardBarcode.Equals(RS_NOREAD))
                         {
                             iBarcodeJdg = 1;
                             strboardBarcode = RS_EMPTY;
                         }

                         int iNgCode = 0;
                         switch (ABrdRes.jugResult)
                         {
                             case JudgeRes.Good:
                                 {
                                     iNgCode = 0;
                                     break;
                                 }
                             case JudgeRes.NG:
                                 {
                                     iNgCode = 1;
                                     break;
                                 }
                             case JudgeRes.Pass:
                                 {
                                     iNgCode = 0;//not 0  //Q.F.2019.01.30
                                     break;
                                 }
                             default:
                                 iNgCode = 101;
                                 break;
                         }
                         
						 //cal number of components
						 int iNumberOfComp = 0;
						 for(i = 0; i != APcbGeneralInfo.PanelResults[0].arrDataLst.Length;++i)
						 {
							 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs!=null)
							 {
								 iNumberOfComp+=APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs.Length;
							 }
						 }
					
						 //cal badmarkstring
						 String strBMInfo = RS_EMPTY;
						 for(i = 0; i != aIInfo.Length;++i)
						 {
							 if(aIInfo[i] == 0)
								 strBMInfo += "0";
							 else
								 strBMInfo += "1";

						 }
						
						 StringBuilder strBldBoard = new StringBuilder();					
						 strBldBoard.Append("[Index]" + RS_LineEnd);
						 strBldBoard.Append("Format=RstMask" + RS_LineEnd);
						 strBldBoard.Append("Version=" + AappSettingData.stMountSystemWistron.stAPC.strVersion + RS_LineEnd);
						 strBldBoard.Append("Machine=" + AappSettingData.stMountSystemWistron.stAPC.strMachine + RS_LineEnd);
						 strBldBoard.Append("Date=" + strDate + RS_LineEnd);
						 strBldBoard.Append("AuthorType=" + AappSettingData.stMountSystemWistron.stAPC.strAuthorType + RS_LineEnd);
						 strBldBoard.Append("Author=" + AappSettingData.stMountSystemWistron.stAPC.strAuthor + RS_LineEnd);

						 strBldBoard.Append("[BoardData]" + RS_LineEnd);
						 strBldBoard.Append("Lane=" + AbyLaneNo + RS_LineEnd);
                         strBldBoard.Append("NgCode=" + iNgCode + RS_LineEnd);
                         strBldBoard.Append("BarcodeJdg=" + iBarcodeJdg + RS_LineEnd);//Q.F.2016.12.28                         
						 strBldBoard.Append("BarcodeStr=" + strboardBarcode + RS_LineEnd);
						 strBldBoard.Append("BadmarkNum=" + aIInfo.Length + RS_LineEnd);
						 strBldBoard.Append("CircuitNum=" + iNumberOfComp + RS_LineEnd);


                         int iSolderNum = 0;
                         for (i = 0; i != APcbGeneralInfo.PanelResults[0].arrDataLst.Length; ++i)
                         {
                             if (APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs != null)
                             {
                                 for (j = 0; j < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs.Length; ++j)
                                 {
                                     if (APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j] != null)
                                     {
                                         if (APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices != null)
                                         {
                                             iSolderNum += APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices.Length;

                                         }
                                     }
                                 }
                             }
                         }


                         strBldBoard.Append("SolderNum=" + iSolderNum + RS_LineEnd);//APcbGeneralInfo.checkPadNum 


						 strBldBoard.Append("[BadMarkData]" + RS_LineEnd);
						 strBldBoard.Append("BadMark=" + strBMInfo + RS_LineEnd);
						 strBldBoard.Append("[PositionData]" + RS_LineEnd);
						 strBldBoard.Append("IDNUM" + RS_SingleSpace);
						 strBldBoard.Append("PNUM" + RS_SingleSpace);
						 strBldBoard.Append("CName" + RS_SingleSpace);
						 strBldBoard.Append("SolderNum" + RS_SingleSpace);
						 strBldBoard.Append("MountX" + RS_SingleSpace);
						 strBldBoard.Append("MountY" + RS_LineEnd);
						 iCount = 1;
                         int test = 0;
						 for(i = 0; i != APcbGeneralInfo.PanelResults[0].arrDataLst.Length;++i)
						 {
							 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs!=null)
							 {
								 for(j = 0; j < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs.Length;++j)
								 {
									 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j] != null)
									 {
										 strBldBoard.Append(iCount + RS_SingleSpace);
										 strBldBoard.Append(APcbGeneralInfo.PanelResults[0].arrDataLst[i].strArrayID + RS_SingleSpace);
										 strBldBoard.Append("\""+APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].strComPonentID+"\"" + RS_SingleSpace);
										 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices == null)
											 iNum = 0;
										 else
										 {
											 iNum = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices.Length;
                                            
                                             //Q.F.2017.02.12
                                             if (iNum > 0)
                                             {
                                                 iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices[0];
                                             
                                                 fMountX = APads[iPadIndex].fComponentXmmCad + APcbGeneralInfo.fComponentShiftXmm;
                                                 fMountY = APads[iPadIndex].fComponentYmmCad + APcbGeneralInfo.fComponentShiftYmm;
                                             }


										 }
										 strBldBoard.Append(iNum + RS_SingleSpace);
                                         test += iNum;

										 strBldBoard.Append(fMountX.ToString(RS_FLOATFORMAT_3Bit) + RS_SingleSpace);
                                         strBldBoard.Append(fMountY.ToString(RS_FLOATFORMAT_3Bit)  + RS_LineEnd);

										 ++iCount;
									 }
								 }
							 }
							 
						 }

                        // MessageBox.Show(test.ToString());


						 strBldBoard.Append("[SolderData]" + RS_LineEnd);
						 strBldBoard.Append("IDNUM" + RS_SingleSpace);
						 strBldBoard.Append("LINKID" + RS_SingleSpace);
						 strBldBoard.Append("GX" + RS_SingleSpace);
						 strBldBoard.Append("GY" + RS_SingleSpace);
						 strBldBoard.Append("SX" + RS_SingleSpace);
						 strBldBoard.Append("SY" + RS_SingleSpace);
						 strBldBoard.Append("NgCode" + RS_SingleSpace);
						 strBldBoard.Append("STS" + RS_SingleSpace);
						 strBldBoard.Append("HGnd" + RS_SingleSpace);
						 strBldBoard.Append("Area" + RS_SingleSpace);
						 strBldBoard.Append("GapX" + RS_SingleSpace);
						 strBldBoard.Append("GapY" + RS_SingleSpace);
						 strBldBoard.Append("HAve" + RS_SingleSpace);
						 strBldBoard.Append("Vol" + RS_SingleSpace);
						 strBldBoard.Append("HTop" + RS_SingleSpace);
						 strBldBoard.Append("RcgSX" + RS_SingleSpace);
						 strBldBoard.Append("RcgSY" + RS_LineEnd);		


                          //Q.F.2016.12.28
                         //->
                         StringBuilder strBldBoardConfirmed = new StringBuilder();
                         strBldBoardConfirmed.Append("[Index]" + RS_LineEnd);
                         strBldBoardConfirmed.Append("Format=CfmMask" + RS_LineEnd);
                         strBldBoardConfirmed.Append("Version=" + AappSettingData.stMountSystemWistron.stAPC.strVersion + RS_LineEnd);
                         strBldBoardConfirmed.Append("Machine=" + AappSettingData.stMountSystemWistron.stAPC.strMachine + RS_LineEnd);
                         strBldBoardConfirmed.Append("Date=" + strDate + RS_LineEnd);
                         strBldBoardConfirmed.Append("AuthorType=" + AappSettingData.stMountSystemWistron.stAPC.strAuthorType + RS_LineEnd);
                         strBldBoardConfirmed.Append("Author=" + AappSettingData.stMountSystemWistron.stAPC.strAuthor + RS_LineEnd);

                         strBldBoardConfirmed.Append("[SolderNGCfm]" + RS_LineEnd);
                         strBldBoardConfirmed.Append("IDNUM" + RS_SingleSpace);
                         strBldBoardConfirmed.Append("LINKID" + RS_SingleSpace);
                         strBldBoardConfirmed.Append("JDG" + RS_LineEnd);
                         //<-


						 iCount = 1;
						 iNum = 1;
						 float fTmp = 0;	
						 int iTmp = 0;
						 float fZero = 0;
                         int iSTS = 0;//Q.F.2016.12.28
                         int iJDG = 0;
                         int iArrayIDIndex = 0;
						 for(i = 0; i != APcbGeneralInfo.PanelResults[0].arrDataLst.Length;++i)
						 {
							 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs!=null)
							 {
								 for(j = 0; j < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs.Length;++j)
								 {
									 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j] != null)
									 {
										 if(APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j].arrIPadIndices != null)
										 {
											  for(k = 0; k < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j]
											  .arrIPadIndices.Length;++k)
											  {
												  strBldBoard.Append(iNum + RS_SingleSpace);												
												  strBldBoard.Append(iCount + RS_SingleSpace);	

												  iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrComponentIDs[j]
												  .arrIPadIndices[k];
                                                  iArrayIDIndex = APads[iPadIndex].arrayIDIndex;
                                                  
                                                  
                                                  fGX = APads[iPadIndex].posXmmCad - APads[iPadIndex].fComponentXmmCad;//Q.F.2017.02.13
                                                  //if (AappSettingData.stMountSystemWistron.stAPC.bEnReverseShiftX)
                                                  {
                                                      fGX *= -1;
                                                  }
                                                  strBldBoard.Append(fGX.ToString(RS_FLOATFORMAT_3Bit) + RS_SingleSpace);//GX
                                                  fGY = APads[iPadIndex].posYmmCad - APads[iPadIndex].fComponentYmmCad;//Q.F.2017.02.13
                                                  //if (AappSettingData.stMountSystemWistron.stAPC.bEnReverseShiftY)
                                                  {
                                                      fGY *= -1;
                                                  }
                                                  strBldBoard.Append(fGY.ToString(RS_FLOATFORMAT_3Bit) + RS_SingleSpace);//GY
                                                  //fTmp = (float)APads[iPadIndex].res.measuredValue.offsetX;
                                                  fTmp = (float)APads[iPadIndex].sizeXmmNew;//Q.F.2016.12.28
                                                  strBldBoard.Append(fTmp.ToString(RS_FLOATFORMAT_3Bit) + RS_SingleSpace);//SX
                                                  //fTmp = (float)APads[iPadIndex].res.measuredValue.offsetY;
                                                  fTmp = (float)APads[iPadIndex].sizeYmmNew;//Q.F.2016.12.28
                                                  strBldBoard.Append(fTmp.ToString(RS_FLOATFORMAT_3Bit) + RS_SingleSpace);//SY

                                                  iTmp = _wsBaseF.GetNGCodeOfPadInNPMFrPanasonic(ref APads[iPadIndex], APcbGeneralInfo);
												  strBldBoard.Append(iTmp + RS_SingleSpace);//NgCode 
                                                  strBldBoard.Append(iSTS + RS_SingleSpace);//STS
                                                  strBldBoard.Append(RS_POUND + RS_SingleSpace);//HGnd
												  fTmp = (float)APads[iPadIndex].res.measuredValue.perArea * 100;
                                                  strBldBoard.Append(fTmp.ToString(RS_FLOATFORMAT_1Bit) + RS_SingleSpace);//Area

                                                  //if(fTmp > _fZeroJudged)
                                                  if (iTmp < _wsBaseF.CINT_NPM_BADMARK_NGCODE)
                                                  {
                                                      //Q.F.2017.01.04
                                                      if (AappSettingData.stMountSystemWistron.stAPC.bEnCalShift == true)
                                                      {
                                                          //fGapX = (float)APads[iPadIndex].res.measuredValue.offsetX;
                                                          //fGapY = (float)APads[iPadIndex].res.measuredValue.offsetY;
                                                          fGapX = (float)APads[iPadIndex].res.measuredValue.fOffsetXOrgMM;
                                                          fGapY = (float)APads[iPadIndex].res.measuredValue.fOffsetYOrgMM;
                                                          if (AappSettingData.stMountSystemWistron.stAPC.bEnReverseShiftX)
                                                          {
                                                              fGapX *= -1;
                                                          }
                                                          if (AappSettingData.stMountSystemWistron.stAPC.bEnReverseShiftY)
                                                          {
                                                              fGapY *= -1;
                                                          }
                                                      }
                                                      else
                                                      {
                                                          fGapX = 0.0f;
                                                          fGapY = 0.0f;
                                                          GenTestAPCShift(APads[iPadIndex], ref fGapX, ref fGapY);

                                                      }
                                                      strBldBoard.Append(fGapX.ToString(RS_FLOATFORMAT_4Bit) + RS_SingleSpace);//GapX
                                                      strBldBoard.Append(fGapY.ToString(RS_FLOATFORMAT_4Bit) + RS_SingleSpace);//GapY

                                                      fTmp = (float)APads[iPadIndex].res.measuredValue.height * 0.001f;
                                                      strBldBoard.Append(fTmp.ToString(RS_FLOATFORMAT_4Bit) + RS_SingleSpace);//HAve

                                                      fTmp = (float)APads[iPadIndex].res.measuredValue.perVol * 100;
                                                      strBldBoard.Append(fTmp.ToString(RS_FLOATFORMAT_1Bit) + RS_SingleSpace);//Vol
                                                  }
                                                  else
                                                  {
                                                      strBldBoard.Append(RS_POUND + RS_SingleSpace);//GapX
                                                      strBldBoard.Append(RS_POUND + RS_SingleSpace);//GapY


                                                      strBldBoard.Append(RS_POUND + RS_SingleSpace);//HAve


                                                      strBldBoard.Append(RS_POUND + RS_SingleSpace);//Vol
                                                  }
                                                  strBldBoard.Append(RS_POUND + RS_SingleSpace);//HTop
												  strBldBoard.Append(RS_POUND + RS_SingleSpace);//RcgSX
                                                  strBldBoard.Append(RS_POUND + RS_LineEnd);//RcgSY

                                                  //Q.F.2016.12.28
                                                  //for confirmation file
                                                  if ((APads[iPadIndex].res.jugRes == JudgeRes.Pass
                                                      || APads[iPadIndex].res.jugRes == JudgeRes.NG)
                                                     // && APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[iArrayIDIndex].shBadMarkMode == 0
                                                      )
                                                  {
                                                      strBldBoardConfirmed.Append(iNum + RS_SingleSpace);
                                                      strBldBoardConfirmed.Append(iCount + RS_SingleSpace);
                                                      iJDG = 0;
                                                      if (iTmp < _wsBaseF.CINT_NPM_BADMARK_NGCODE)
                                                      {
                                                          if (APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                                          {
                                                              iJDG = 1;
                                                          }
                                                          else if (APads[iPadIndex].res.jugRes == JudgeRes.NG)
                                                          {
                                                              iJDG = 2;
                                                          }
                                                      }
                                                      
                                                      strBldBoardConfirmed.Append(iJDG + RS_LineEnd);
                                                  }

												  ++iNum;
											  }
										 }
										 ++iCount;
									 }
									

									
								 }
							 }
							
						 }

						 //String tmpFileName = _strTmpFileDir + "\\" + "MountSystem"+ _byLaneNo.ToString() + ".Tmp";
						 FileStream fs= new FileStream(tmpFile,FileMode.Create);
						 System.IO.StreamWriter streamWrt = new StreamWriter(fs,Encoding.Default);
						 streamWrt.Write(strBldBoard);				
						 streamWrt.Close();
						
						
						 String strfileName =  AstrDir  + lPCBSerialNum + RS_RST_EXT;
                         Thread.Sleep(20);
                         File.Copy(tmpFile, strfileName, true);

                         ////gen confirm file
                         //Thread.Sleep(20);
                         
                         //if (File.Exists(tmpFile))
                         //{
                         //    File.Delete(tmpFile);
                         //}
                         //Q.F.2017.01.03
                         if (AappSettingData.useReviewFunc == true)
                         {
                             if (ABrdRes.jugResult == JudgeRes.NG
                                 || ABrdRes.jugResult == JudgeRes.Pass)
                             {
                                 fs = new FileStream(tmpFile1, FileMode.Create);
                                 streamWrt = new StreamWriter(fs, Encoding.Default);
                                 streamWrt.Write(strBldBoardConfirmed);
                                 streamWrt.Close();

                                 strfileName = AstrDir + lPCBSerialNum + RS_CIR_EXT;
                                 Thread.Sleep(20);
                                 File.Copy(tmpFile1, strfileName, true);
                             }
                         }
					 }
					 catch (Exception ex)
					 {
					 	
					 }
					
					 return 0;
				 }
        //move pcb information file
        public string MigratePcbInfomationFileForNPM(AppSettingData AappSettingData,
            long lPCBSerialNum, byte AbyLaneNo)
        {
            string strMsg = "NPM Migrate SRL File:";
            try
            {

                String strDir = AappSettingData.stMountSystemWistron.stAPC.strExpPath;
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder!";
                    return strMsg;
                }
                String strDirForPcbinfo = strDir + "NextOutPcb";
                String strDirForPcbinfoPre = strDirForPcbinfo;
                if (AappSettingData.stMountSystemWistron.stAPC.bUseConveyor == true)
                {
                    strDirForPcbinfoPre = strDir + "NextNextOutPcb";
                }
                //_wsBaseF.DirCheck(ref strDirForPcbinfo);
                if (_wsBaseF.DirCheck(ref strDirForPcbinfo) == -1
                    || _wsBaseF.DirCheck(ref strDirForPcbinfoPre) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder:" + strDirForPcbinfo
                         + "/" + strDirForPcbinfoPre;
                    return strMsg;
                }
                strDirForPcbinfo += "Lane" + AbyLaneNo;
                strDirForPcbinfoPre += "Lane" + AbyLaneNo;
                if (_wsBaseF.DirCheck(ref strDirForPcbinfo) == -1
                    || _wsBaseF.DirCheck(ref strDirForPcbinfoPre) == -1)
                {
                    strMsg += RS_DATAEXPORTMountMsg + "No Folder:" + strDirForPcbinfo
                        + "/" + strDirForPcbinfoPre;
                    return strMsg;
                }
             //  
                //if (Directory.Exists(strDirForPcbinfo))//check whether file exist
                //{
                //    Directory.Delete(strDirForPcbinfo, true);
                //}
                //Thread.Sleep(50);
              
                //int iCount = 0;
                //while (!Directory.Exists(strDirForPcbinfo))
                //{
                //    Thread.Sleep(5);
                //    if (iCount > 100)
                //        break;
                //}
                if (strDirForPcbinfo.Equals(strDirForPcbinfoPre))
                {
                    strMsg += RS_DATAEXPORTMountMsg + "Folder Equals";
                    return strMsg;
                }
                _wsBaseF.CheckAndDeleteDir(ref strDirForPcbinfo, RS_SRL_EXT);
                string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() +
                    RS_UnderLine + "SRL" + RS_DATAEXPORTTEMPFILEMount;

                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                string strFileName = strDirForPcbinfo + lPCBSerialNum + RS_SRL_EXT;
                string strFileNamePre = strDirForPcbinfoPre + lPCBSerialNum + RS_SRL_EXT;
                if (File.Exists(strFileName))
                {
                    File.Delete(strFileName);
                }

                File.Copy(strFileNamePre, strFileName, true);
                Thread.Sleep(100);
                if (File.Exists(strFileNamePre))
                {
                    File.Delete(strFileNamePre);
                }

                return strMsg;

            }
            catch (System.Exception ex)
            {
                strMsg += RS_DATAEXPORTMountMsg + ex.ToString();
                return strMsg;
            }

        }

        public string ExportToMonitorSystemForWUHanFoxConn(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData,
            AppMultiLan.AppLan Adict,
            byte AbyLaneNo, string AstrClntName)
        {
            String strMsg = RS_EMPTY;
            try
            {
                strMsg = _wsBaseF.PingCheck(AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseAddress);
                 if (!String.IsNullOrEmpty(strMsg))
                 {
                     strMsg = RS_DATAEXPORTMonitorMsg + "(" + AstrClntName + ")"  + strMsg;
                     return strMsg;//Q.F.2017.05.31
                 }
              
                //SQLServerDAO sqldao = new SQLServerDAO("192.168.110.9","vidata","sa","123456");
                SQLServerDAO sqldao = new SQLServerDAO(AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseAddress,
                    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseName,
                    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseUserID,
                    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseUserPassword);

              
                ST_FOXCONN_TABLE_INFO stInfo = new ST_FOXCONN_TABLE_INFO();
                stInfo.info = new ST_SPI_EQUIP_INFO();
                stInfo.info.barcode = ABrdRes.pcbBarcode;
                stInfo.info.equipId = AappSettingData.LineName;
                stInfo.info.line = AappSettingData.LineName;
                stInfo.info.recipeId = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                stInfo.info.startTestTime = ABrdRes.startTime.ToString("yyyy/MM/dd hh:mm:ss");//ABrdRes.boardIsComingTime.ToString("yyyy/MM/dd hh:mm:ss");
                stInfo.info.endTextTime = ABrdRes.endTime.ToString("yyyy/MM/dd hh:mm:ss");//ABrdRes.boardOutBVTime.ToString("yyyy/MM/dd hh:mm:ss");

               
                System.TimeSpan tick = ABrdRes.boardOutBVTime.Subtract(ABrdRes.boardIsComingTime);
                System.TimeSpan preTick = new System.TimeSpan(0, 0, 0, 0, 600);           
                tick = tick.Subtract(preTick);
                if (tick.TotalSeconds > 0)
                    stInfo.info.realCycleTime = tick.TotalSeconds.ToString(RS_FLOATFORMAT_3Bit);
                else
                {
                    stInfo.info.realCycleTime = RS_ZERO;
                }
              
                //tick = ABrdRes.boardIsComingTime.Subtract(ABrdRes.lastBoardIsComingTime);
                //preTick = new System.TimeSpan(0, 0, 0, 0, 600);              
                //tick = tick.Subtract(preTick);

                //if (tick.TotalSeconds > 0)
                //    stInfo.info.tTime = tick.TotalSeconds.ToString(RS_FLOATFORMAT_3Bit);
                //else
                //{
                //    stInfo.info.tTime = RS_ZERO;
                //}
                stInfo.info.tTime = RS_ZERO;
                stInfo.info.waitingTime = RS_ZERO;
                //tick = ABrdRes.boardIsComingTime.Subtract(ABrdRes.boardOutLetTime);
                //preTick = new System.TimeSpan(0, 0, 0, 0, 600);
                //tick = tick.Subtract(preTick);
                ////stInfo.info.waitingTime = tick.TotalSeconds.ToString(RS_FLOATFORMAT_3Bit);
                //if (tick.TotalSeconds > 0)
                //    stInfo.info.waitingTime = tick.TotalSeconds.ToString(RS_FLOATFORMAT_3Bit);
                //else
                //{
                //    
                //}

                stInfo.info.result = ABrdRes.jugResult.ToString();
                stInfo.info.historyQuantity = ABrdRes.processedPCBNumber.ToString();
                //System.TimeSpan tick = ABrdRes.startTime.Subtract(ABrdRes.endTime);

                FileInfo info = new FileInfo(ABrdRes.jobName);
                stInfo.info.recipeDate = info.LastWriteTime.ToString("yyyy/MM/dd hh:mm:ss");

                //tick = ABrdRes.endTime.Subtract(ABrdRes.startTime);
                //preTick = new System.TimeSpan(0, 0, 0, 0, 600);              
                //tick = tick.Subtract(preTick);
               
                //if (tick.TotalSeconds < 0)
                    stInfo.info.processTime = ABrdRes.cycleTimeSec.ToString(RS_FLOATFORMAT_3Bit);
                //else
                //{
                //    stInfo.info.processTime = RS_ZERO;
                //}
                    stInfo.info.uiStart = RS_EMPTY;//Q.F.2017.04.10
                stInfo.info.uiClose = RS_EMPTY;
                strMsg = sqldao.InsertTable(E_FOXCONN_TABLE_NAME.SPI_INSPECTION_INFO, stInfo);
                 if (!String.IsNullOrEmpty(strMsg))
                 {
                     strMsg = RS_DATAEXPORTMonitorMsg + "(" + AstrClntName + ")"  + strMsg;
                 }
                                
                Thread.Sleep(200);
                //padinfo
                if(ABrdRes.jugResult == JudgeRes.NG
                    || ABrdRes.jugResult == JudgeRes.Pass)
                {
                    List<ST_SPI_EQUIP_ITEMS> lstItems = new List<ST_SPI_EQUIP_ITEMS>();
                    int iLength = APads.Length;
                    InspectMainLib.Pad pad = null;
                    String strModifyDate = DateTime.Now.ToString("yyyyMMddHHmmss");
                    for (int i = 0; i != iLength; ++i)
                    {
                        pad = APads[i];
                        // not cal these skipped pads
                        if (_wsBaseF.bPadIsSkip(pad))
                            continue;
                        if (pad.res.jugRes == JudgeRes.NG
                            || pad.res.jugRes == JudgeRes.Pass)
                        {
                            ST_SPI_EQUIP_ITEMS item = new ST_SPI_EQUIP_ITEMS();
                            item.line = AappSettingData.LineName;
                            item.equipId = AappSettingData.LineName;
                            item.barcode = ABrdRes.pcbBarcode;
                            item.padId = pad.padID.ToString();
                            item.component = pad.componentID;//Q.F.2017.04.10
                            if (string.IsNullOrEmpty(item.component))
                                item.component = RS_EMPTY;
                            item.arrayId = pad.strArrayID;
                            item.type = pad.packageType;
                            if (string.IsNullOrEmpty(item.type))//Q.F.2017.04.10
                                item.type = RS_EMPTY;
                            item.result = pad.res.jugRes.ToString();
                            //item.error = Adict.GetTranslate(pad.res.jugDefectType.ToString());
                            item.error = pad.res.jugDefectType.ToString();
                            item.errorCode = ((byte)(pad.res.jugDefectType)).ToString();
                            item.modifyDate = strModifyDate;
                            lstItems.Add(item);
                        }

                    }
                    if (lstItems.Count > 0)
                    {
                        stInfo.items = lstItems.ToArray();
                        strMsg = sqldao.InsertTable(E_FOXCONN_TABLE_NAME.SPI_INSPECTION_ITEMS, stInfo);
                        if (!String.IsNullOrEmpty(strMsg))
                        {
                            strMsg = RS_DATAEXPORTMonitorMsg + "(" + AstrClntName + ")"  + strMsg;
                        }
                        return strMsg;
                                
                    }
                }

               
              

                return strMsg;

            }
            catch (System.Exception ex)
            {
                strMsg += RS_DATAEXPORTMonitorMsg + "(" + AstrClntName + ")" + ex.ToString();
                return strMsg;
            }
            finally
            {
                
            }
        }

        private string SaveDataExpFileAPAITEK(
            InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppSettingData AappSettingData,
            string AstrDir, string AstrClntName
         )
        {
        
            string strMsg = RS_EMPTY;
            try
            {
              
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }              
                //check dir
                if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                {
                    strMsg += RS_DATAEXPORTMsg + "No Folder!";
                    return strMsg;
                }
             

                //<-
             
                int iLength = 0;
                string strStatusRes = RS_EMPTY;
                float fValue = 0.0f;

                string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (string.Equals(strboardBarcode, RS_NOREAD))
                {
                    strboardBarcode = RS_EMPTY;
                }
                int iBarcodeCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref  APcbGeneralInfo, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13                


                string strLinePre = RS_EMPTY;
                short shArrayNum = 1;
                string strResult = RS_EMPTY;
                StringBuilder strBldBoard = new StringBuilder();
                StringBuilder strBldPld = new StringBuilder();
                //first line      
                strLinePre = "SRFF File" + RS_SPLIT + AappSettingData.stDataExpVT.strDataExpIPAddress;//ip address//RS_SPLIT +
                strBldBoard.Append(strLinePre + RS_LineEnd);
       
                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                //strLinePre = RS_SPLIT + "SRFF File:" + strJobName;
                //strBldBoard.Append(strLinePre + RS_LineEnd);
                strLinePre = "Panel Name" + RS_SPLIT + strJobName;//RS_SPLIT + 
                strBldBoard.Append(strLinePre + RS_LineEnd);
                strLinePre = "Units" + RS_SPLIT + "Millimeters";//RS_SPLIT +
                strBldBoard.Append(strLinePre + RS_LineEnd);
                strLinePre = "Panel ID" + RS_SPLIT + strboardBarcode;//RS_SPLIT + 
                strBldBoard.Append(strLinePre + RS_LineEnd);
                string strDate = ABrdRes.startTime.ToString("dd/MM/yyyy");
                strLinePre = "Start_Date" + RS_SPLIT + strDate;//RS_SPLIT +
                strBldBoard.Append(strLinePre + RS_LineEnd);
                string strStartTime = ABrdRes.startTime.ToString("HH/mm/ss");
                strLinePre = "Start_Time" + RS_SPLIT + strStartTime;//RS_SPLIT +
                strBldBoard.Append(strLinePre + RS_LineEnd);
                strLinePre = "operator" + RS_SPLIT + AappSettingData.strDataExpOperator;//RS_SPLIT + 
                strBldBoard.Append(strLinePre + RS_LineEnd);

                strStartTime = ABrdRes.startTime.ToString("HH:mm:ss");
                strLinePre =  "Test status" + RS_SPLIT +_wsBaseF.GetJudgeResult(ABrdRes.jugResult,AappSettingData); ;//GetStatusResultFrHUIZHOUBYD((byte)ABrdRes.jugResult, byResultMode);
                strBldBoard.Append(strLinePre + RS_LineEnd);//RS_SPLIT +


                bool bHasArray = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;

                strBldPld.Append(// RS_SPLIT +
                   
                    "Date" + RS_SPLIT
                    + "Time" + RS_SPLIT
                    + "PanelId" + RS_SPLIT
                    //+ "Board" + RS_SPLIT
                    + "Location" + RS_SPLIT
                    + "PinNumber" + RS_SPLIT
                    //+ "HeightResult" + RS_SPLIT
                    + "Height" + RS_SPLIT
                    + "HeightUpFail" + RS_SPLIT
                    + "HeightLowFail" + RS_SPLIT
                    + "HeightTarget" + RS_SPLIT//stencilheight
                    //+ "AreaResult" + RS_SPLIT
                    + "Area" + RS_SPLIT
                    + "AreaUpFail" + RS_SPLIT
                    + "AreaLowFail" + RS_SPLIT
                    + "AreaTarget" + RS_SPLIT
                    //+ "VolumeResult" + RS_SPLIT
                    + "Volume" + RS_SPLIT
                    + "VolumeUpFail" + RS_SPLIT
                    + "VolumeLowFail" + RS_SPLIT
                    + "VolumeTarget" + RS_SPLIT//stencilheight
                    //+ "Valid" + RS_SPLIT//padjudgeres
                    //+ "RegResult" + RS_SPLIT//
                    + "XOffset" + RS_SPLIT
                    + "YOffset" + RS_SPLIT
                    //+ "RegShort%" + RS_SPLIT
                    //+ "RegLong%" + RS_SPLIT//
                    //+ "RegShort%Fail" + RS_SPLIT//
                    //+ "RegLong%Fail" + RS_SPLIT//
                    //+ "BridgeResult" + RS_SPLIT
                    //+ "BridgeLength" + RS_SPLIT
                    //+ "BridgeFail" + RS_SPLIT
                    //+ "Print Speed" + RS_SPLIT//
                    //+ "Print Pressure" + RS_SPLIT
                    //+ "Snap off speed" + RS_SPLIT
                    //+ "Print direction" + RS_SPLIT
                    //+ "Squeegee use count" + RS_SPLIT//
                    //+ "Print gap" + RS_SPLIT//
                    //+ "Squeegee angle" + RS_SPLIT//
                    //+ "PCB quantity setting for solder paste replenishing  " + RS_SPLIT//
                    //+ "PCB count start from screen stencil auto-cleaning" + RS_SPLIT
                    + "Array" + RS_SPLIT
                    + "Review" + RS_SPLIT//
                    + "ErrorCode" + RS_SPLIT//
                    + "ErrorContent" + RS_LineEnd);

                iLength = APads.Length;

                // for (iPadIndex = 0; iPadIndex != iLength; ++iPadIndex)
                bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true && AappSettingData.strUserDefinedErrorCodes != null;
                int iErrorCode = 0;
                string strArrayBarcode = String.Empty;
              //  strBldPld.Append(RS_LineEnd);//Q.F.2017.04.06
                foreach (InspectMainLib.Pad pad in APads)
                {
                    if (_wsBaseF.bPadIsSkip(pad) == true)
                    {
                        continue;
                    }
                    strBldPld.Append(strDate + RS_SPLIT);//Date //Q.F.2017.04.06//RS_SPLIT +
                    strBldPld.Append(strStartTime + RS_SPLIT);//time
                    //strBldPld.Append(strboardBarcode + RS_SPLIT);//PanelId
                    //if (string.IsNullOrEmpty(strboardBarcode))//
                    //    strBldPld.Append(RS_EMPTY + RS_SPLIT);
                    //else
                    //{
                    if (bHasArray == true
                        && AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseExtBrcd == false)//Q.F.2016.10.25
                    {
                        if (iBarcodeCount > 1)
                        {
                            strArrayBarcode =
                                _wsBaseF.BarcodeDicision(APcbGeneralInfo.PanelResults[0].arrStrBrcd[pad.arrayIDIndex].Trim(),
                                AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                            if (string.Equals(strArrayBarcode, RS_NOREAD))
                            {
                                strArrayBarcode = RS_EMPTY;
                            }
                        }
                        else
                        {
                            strArrayBarcode = strboardBarcode;
                        }
                    }
                    else
                    {
                        strArrayBarcode = strboardBarcode;//Q.F.2016.10.20
                    }
                    strBldPld.Append(strArrayBarcode + RS_SPLIT);
                    //}
                    //strBldPld.Append("IMAGE 1" + RS_SPLIT);//Board
                    if (string.IsNullOrEmpty(pad.componentID))//Location
                        strBldPld.Append(RS_NOREADNA + RS_SPLIT);
                    else
                    {
                        strBldPld.Append(pad.componentID + RS_SPLIT);
                    }
                    if (string.IsNullOrEmpty(pad.pinNumber))//Feature
                        strBldPld.Append(pad.padID + RS_SPLIT);
                    else
                    {
                        strBldPld.Append(pad.pinNumber + RS_SPLIT);
                    }
                    //height
                    //if (pad.res.measuredValue.height < pad.spec.heightL
                    //    || pad.res.measuredValue.height > pad.spec.heightH)
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    //}
                    //else
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    //}
                    //strBldPld.Append(strStatusRes + RS_SPLIT);
                    strBldPld.Append((pad.res.measuredValue.height * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.spec.heightH * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.spec.heightL * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.stencilHeight).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    //area
                    //if (pad.res.measuredValue.perArea < pad.spec.areaPerL
                    //    || pad.res.measuredValue.perArea > pad.spec.areaPerH)
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    //}
                    //else
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    //}
                    //strBldPld.Append(strStatusRes + RS_SPLIT);
                    strBldPld.Append((pad.res.measuredValue.area * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCadArea * pad.spec.areaPerH * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCadArea * pad.spec.areaPerL * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCadArea * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm

                    //volume
                    //if (pad.res.measuredValue.perVol < pad.spec.volPerL
                    //    || pad.res.measuredValue.perVol > pad.spec.volPerH)
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    //}
                    //else
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    //}
                    //strBldPld.Append(strStatusRes + RS_SPLIT);
                    strBldPld.Append((pad.res.measuredValue.vol * _fUM2MM * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCADVol * pad.spec.volPerH * _fUM2MM * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCADVol * pad.spec.volPerL * _fUM2MM * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm
                    strBldPld.Append((pad.res.measuredValue.fCADVol * _fUM2MM * _fUM2MM * _fUM2MM).ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//mm

                    strStatusRes =  _wsBaseF.GetJudgeResult(pad.res.jugRes, AappSettingData);
                    //if (pad.res.jugRes == JudgeRes.Pass)
                    //    strStatusRes = GetStatusResultFrHUIZHOUBYD(1, byResultMode);
                    //strBldPld.Append(strStatusRes + RS_SPLIT);//valid
                    //strBldPld.Append(RS_NOREADNA + RS_SPLIT);//RegResult

                    //xyoffset
                    strBldPld.Append(pad.res.measuredValue.offsetX.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//
                    strBldPld.Append(pad.res.measuredValue.offsetY.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);//

                    //strBldPld.Append(RS_ZERO + RS_SPLIT);//
                    //strBldPld.Append(RS_ZERO + RS_SPLIT);//
                    //strBldPld.Append(RS_ZERO + RS_SPLIT);//
                    //strBldPld.Append(RS_ZERO + RS_SPLIT);//
                    //if (pad.res.measuredValue.bridgeNo > 0 && pad.checkBridge == true)
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    //}
                    //else
                    //{
                    //    strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    //}
                    //strBldPld.Append(strStatusRes + RS_SPLIT);//
                    //strBldPld.Append(RS_ZERO + RS_SPLIT);//
                    //strBldPld.Append(RS_NOREADNA + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                    //strBldPld.Append(RS_EMPTY + RS_SPLIT);// 

                    //strBldPld.Append(pad.strArrayID + RS_SPLIT);//
                   // strStatusRes = GetStatusResultFrHUIZHOUBYD((byte)pad.res.jugRes, byResultModeForReview);//for another 
                    strBldPld.Append(pad.strArrayID + RS_SPLIT);
                    strStatusRes = _wsBaseF.GetJudgeResult(pad.res.jugRes, AappSettingData);
                    strBldPld.Append(strStatusRes + RS_SPLIT);//valid

                    if (pad.res.jugRes == JudgeRes.Good)
                    {
                        strBldPld.Append(RS_EMPTY + RS_SPLIT);//
                        strBldPld.Append(RS_EMPTY + RS_LineEnd);// 
                    }
                    else
                    {
                        strStatusRes = pad.res.jugDefectType.ToString("g");
                        if (bEnUserDefinedErrorCode)
                        {
                            System.Int32.TryParse(AappSettingData.strUserDefinedErrorCodes[(byte)(pad.res.jugDefectType)],
                                                out iErrorCode);

                        }
                        else
                        {
                            iErrorCode = (byte)(pad.res.jugDefectType);
                        }
                        strBldPld.Append(iErrorCode + RS_SPLIT);//
                        strBldPld.Append(strStatusRes + RS_LineEnd);// 

                    }

                }


                strStartTime = ABrdRes.startTime.Year.ToString("0000")
                                + ABrdRes.startTime.Month.ToString("00")
                                + ABrdRes.startTime.Day.ToString("00")
                                + ABrdRes.startTime.Hour.ToString("00")
                                + ABrdRes.startTime.Minute.ToString("00")
                                + ABrdRes.startTime.Second.ToString("00");
                string RS_CSV_EXT = ".spi.csv";
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Write(strBldPld);
                streamWrt.Close();

                string strFileName = AstrDir + strJobName + RS_UnderLine + strboardBarcode + RS_UnderLine + strStartTime;
                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName + RS_CSV_EXT, true);

                }               
            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTMountMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }

            return strMsg;
           
        }

        private String SaveBadMarkSystemFileForNXT(InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            AppSettingData AappSettingData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppMultiLan.AppLan Adict, 
            byte AbyLaneNo, 
            ImgCSCoreIM.WebServiceCmd Acmd,
            string AstrClntName       
        )
        {
            String strMsg = RS_EMPTY;
            try
            {
                if (ABrdRes != null && ABrdRes.jugResult == JudgeRes.NG && AappSettingData.bBadMarkSystemIgnoreNGPCB)
                    return strMsg;

                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + AbyLaneNo.ToString() + RS_UnderLine + RS_DATAEXPORTTEMPFILEBM;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                
                //Q.F.2017.01.11
                //if (AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bENClearExportFolder == true)
                //{
                //    _wsBaseF.CheckAndDeleteDir(AstrDir, RS_XML_EXT);
                //}
                byte byLaneNo = AbyLaneNo;
                if (ABrdRes != null)
                    byLaneNo = (byte)ABrdRes.LaneNo;
                if (Acmd == ImgCSCoreIM.WebServiceCmd.CheckConnection)
                {
                    byLaneNo =(byte)(AbyLaneNo - 1);
                    if (byLaneNo < 0)
                        byLaneNo = 0;
                }
                
                //if (File.Exists(tmpFile))
                //{
                //    File.Delete(tmpFile);
                //}
                //delete current res 
                String strFileNameRes = _strTmpFileDir + "\\" + String.Format(_strNXT2SPI, byLaneNo);
                if(File.Exists(strFileNameRes))
                    File.Delete(strFileNameRes);

                StringBuilder strBldBoard = new StringBuilder();        
                String strContent = RS_EMPTY;

                //CmdFileGenTime
                strContent = "CmdFileGenTime:" + DateTime.Now.ToString("yyyyMMdd");
                strBldBoard.AppendLine(strContent);

                //MachineServer
                strContent = "MachineServer:" + AappSettingData.stMountSystemWistron.stSystemBadMarkParams.strIPAddress;
                strBldBoard.AppendLine(strContent);

                //MachineName
                strContent = "MachineName:" + AappSettingData.stMountSystemWistron.stSystemBadMarkParams.strMachineName;
                strBldBoard.AppendLine(strContent);

                //ModuleNumber
                strContent = "ModuleNumber:" + AappSettingData.stMountSystemWistron.stSystemBadMarkParams.strModuleNumber;
                strBldBoard.AppendLine(strContent);

                //LaneIdx
                strContent = "LaneIdx:" + byLaneNo;
                strBldBoard.AppendLine(strContent);

                //Barcode - PanelID
                String strboardBarcode = RS_NOREAD;
                if (Acmd == ImgCSCoreIM.WebServiceCmd.SendFile)
                {
                    strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                        AappSettingData, (byte)byLaneNo);
                }
                // add by peng 20190712
                if (string.IsNullOrEmpty(strboardBarcode))
                {
                    strboardBarcode = DateTime.Now.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                }
                String strFileName = string.Empty;
                if (AappSettingData.enPadDebug)
                {
                    strFileName = _strTmpFileDir + "\\" + strboardBarcode + RS_TXT_EXT;//String.Format(_strSPI2NXT, byLaneNo);
                }
                else
                {
                    strFileName = _strTmpFileDir + "\\"  + String.Format(_strSPI2NXT, byLaneNo);
                }
                strContent = "PanelID:" + strboardBarcode;
                strBldBoard.AppendLine(strContent);
                //PanelBarcode
                strContent = "PanelBarcode:" + strboardBarcode;
                strBldBoard.AppendLine(strContent);

                //BadMarkInfor
                String strBMInfo = RS_EMPTY;// "0";           
                bool AbUseNGAsBadMark = false;
                int i = 0;
                if (Acmd == ImgCSCoreIM.WebServiceCmd.SendFile)
                {
                    int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, AbUseNGAsBadMark, Adict);
                    
                    for (i = 0; i != aIInfo.Length; ++i)
                    {
                        if (aIInfo[i] == 0)
                            strBMInfo += "0";
                        else
                            strBMInfo += "1";

                    }
                }
                else if (Acmd == ImgCSCoreIM.WebServiceCmd.CheckConnection)
                {
                    strBMInfo = "0";
                }
                strContent = "BadMarkInfor:" + strBMInfo;
                strBldBoard.AppendLine(strContent);

                //PanelBarcode
                strContent = "CMD:" + (int)Acmd;
                strBldBoard.AppendLine(strContent);



                

                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Close();

               
                if (File.Exists(tmpFile))
                {
                    if (_wsBaseF.BLinkToOtherMachineWithExConveyor(AappSettingData) == false
                        || Acmd == ImgCSCoreIM.WebServiceCmd.CheckConnection)
                    {
                        File.Copy(tmpFile, strFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                    else
                    {
                        GenPostScanFileNameForDataExport(byLaneNo, ABrdRes.pcbID, tmpFile, strFileName, "NXT");
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTBadMarkMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }

        private String GenDataExportAfterPostScanDefault(
            int AiPCBID,
            String AstrBarcode,
            AppSettingData AappSettingData,
            byte AbyLaneNo)
        {
            //StreamWriter sw = null;
            string strMsg = RS_EMPTY;
            try
            {
                string strDir = _strTmpFileDir + "\\" + RS_POSTSCAN_DIR + RS_UnderLine + AbyLaneNo;
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg =" Can Not Creat " + strDir;
                    return strMsg;
                }
                string strFileName = strDir + AiPCBID + RS_POSTSCAN_EXT;
                int iIndex = 0, i = 0, j = 0, iLength = 0;          
                if (File.Exists(strFileName))
                {
                    String[] strLines = File.ReadAllLines(strFileName);
                    string[] arrData = null;
                    File.Delete(strFileName);
                    string strTmp = RS_EMPTY;
                          
                    if (strLines != null && strLines.Length >= 1)
                    {
                        for (i = 0, iLength = strLines.Length; i < iLength; ++i)
                        {
                            iIndex = strLines[i].LastIndexOf(RS_POSTSCAN_BARCODE);
                            if (iIndex != -1)
                            {
                                strLines[i] = strLines[i].Replace(RS_POSTSCAN_BARCODE, AstrBarcode);
                                //arrData = strLines[i].Split(new char[1] { ',' }, StringSplitOptions.None);       
                                //if(arrData != null && arrData.Length > 0)
                                //{
                                //    for (j = 0; j < arrData.Length; ++j )
                                //    {
                                //        strTmp += arrData[j] + RS_SPLIT;
                                //        if (arrData[j].Equals(strBoardBarcode) == true)
                                //        {
                                //            strTmp += arrData[j] + RS_SPLIT + AstrBarcode;
                                //            break;
                                //        }

                                //    }
                                //    strLines[i] = strTmp;
                                //}
                            }
                        }
                    }

                    File.WriteAllLines(strFileName, strLines);

                    Thread.Sleep(100);
                    string strFileName1 = strDir + AiPCBID + RS_POSTSCANFILE_EXT;
                   
                    if (File.Exists(strFileName)
                        && File.Exists(strFileName1))
                    {
                        strLines = File.ReadAllLines(strFileName1);
                     
                        
                        if (strLines != null && strLines.Length >= 1)
                        {
                            iIndex = strLines[0].LastIndexOf(RS_POSTSCAN_BARCODE);
                            if (iIndex != -1)
                            {
                                strLines[0] = strLines[0].Replace(RS_POSTSCAN_BARCODE, AstrBarcode);
                            }
                            File.Copy(strFileName, strLines[0], true);
                            Thread.Sleep(100);
                        }

                        File.Delete(strFileName);
                        File.Delete(strFileName1);
                    }
                  
                }

            }
            catch (System.Exception ex)
            {
                strMsg = ex.Message.ToString();
            }
            finally
            {

                //if (sw != null)
                //    sw.Close();
            }
            return strMsg;
        }

        private String GenBarcodeErrorLogVT(
            ImgCSCoreIM.StBarcodeErrorLog AStBarcodeErrorLogParams,
          
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting   
            InspectConfig.ConfigData AConfigData,
            AppMultiLan.AppLan Adict)
        {
            String strMsg = RS_EMPTY;
            try
            {
                String strDir = AappSettingData.stUIOperations.StrBarcodeLogPath;
                  if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTBARCODELOGMsg + "No Folder!";
                    return strMsg;
                }

                 //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_BARCODELOGTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                byte byLaneNo = AStBarcodeErrorLogParams.byLaneNo;
                if (AappSettingData.arrBarcodeSetting[byLaneNo].bUseCamBrcd == false
                    || APcbGeneralInfo.camBarcodes.BarcodeList == null)
                {
                    strMsg = RS_DATAEXPORTBARCODELOGMsg + "No Barcode";
                    return strMsg;
                }
                StringBuilder strBldBoard = new StringBuilder();
                strBldBoard.Append("Serial No" + RS_SPLIT);
                strBldBoard.Append("Board" + RS_SPLIT);
                strBldBoard.Append("Status" + RS_SPLIT);
                strBldBoard.Append("Date" + RS_SPLIT);
                strBldBoard.Append("Time" + RS_LineEnd);

                DateTime dtTime= DateTime.Now;
                String strDate = dtTime.ToString("ddMMMyy",new CultureInfo("en-US"));
                String strTime = dtTime.ToString("h.mmt\\M", new CultureInfo("en-US"));
                String strFileTime = dtTime.ToString("ddMMyyyyHHmmss");    
                int iCount = APcbGeneralInfo.camBarcodes.BarcodeList.Count;
                String strValue = RS_EMPTY;
                String strPass = "Pass";
                String strNG= "Fail";
                int iBarIndex = 0;
                for (int a = 0; a < iCount; a++)
                {
                    iBarIndex = APcbGeneralInfo.camBarcodes.BarcodeArrayMotionSeqIndex[a];
                    if (iBarIndex != AStBarcodeErrorLogParams.iErrCamBarcodeIndex)
                    {
                        strValue = APcbGeneralInfo.camBarcodes.BarcodeList[iBarIndex].BarcodeRes.strDecodingStr;
                        strBldBoard.Append(strValue + RS_SPLIT);
                        strBldBoard.Append(APcbGeneralInfo.camBarcodes.BarcodeList[iBarIndex].strArrayID + RS_SPLIT);
                        strBldBoard.Append(strPass + RS_SPLIT);
                        strBldBoard.Append(strDate + RS_SPLIT);
                        strBldBoard.Append(strTime + RS_LineEnd);
                    }
                    else
                    {
                        strValue = "Error";
                        strBldBoard.Append(strValue + RS_SPLIT);
                        strBldBoard.Append(APcbGeneralInfo.camBarcodes.BarcodeList[iBarIndex].strArrayID + RS_SPLIT);
                        strBldBoard.Append(strNG + RS_SPLIT);
                        strBldBoard.Append(strDate + RS_SPLIT);
                        strBldBoard.Append(strTime + RS_LineEnd);
                        break;
                    }
                }
                  //at first gen tmp file in local
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);              
                streamWrt.Close();

             
                string strFileName = strDir + strFileTime + RS_CSV_EXT;
                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }
            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTBARCODELOGMsg + "(" + AappSettingData.stUIOperations.EMBarcodeLogFormat.ToString() + ")" + ex.ToString();
            }
            return strMsg;
        }
        private String GenSystemLogForPrinter(SPCBoardRes ABrdRes,
            AppSettingData AappSettingData, // ui setting   
            string AstrClntName)
        {
            String strMsg = RS_EMPTY;
            try
            {
                String strDir = ABrdRes.stPrinterSystemLog.strLogDir;
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTSystemLOGMsg + "No Folder!";
                    return strMsg;
                }
                strDir = Path.Combine(strDir, AstrClntName);
                if (_wsBaseF.DirCheck(ref strDir) == -1)
                {
                    strMsg += RS_DATAEXPORTSystemLOGMsg + "No Folder!";
                    return strMsg;
                }

                //at first gen tmp file in local
                string strFileName = "Lane" + (ABrdRes.LaneNo + 1) + RS_UnderLine +
                   ABrdRes.startTime.ToString("yyyyMMdd") + RS_UnderLine +
                   AstrClntName + RS_CSV_EXT;
                strFileName = Path.Combine(strDir, strFileName);

               
                StringBuilder strBldBoard = new StringBuilder();
                if (File.Exists(strFileName) == false)
                {
                    strBldBoard.Append("PCBID" + RS_SPLIT);
                    strBldBoard.Append("Barcode" + RS_SPLIT);
                    strBldBoard.Append("JobName" + RS_SPLIT);
                    strBldBoard.Append("Printer2SPIFile" + RS_SPLIT);
                    strBldBoard.Append("ReadPrinterFileTime" + RS_SPLIT);
                    strBldBoard.Append("SPI2PrinterFile" + RS_SPLIT);
                    strBldBoard.Append("GenSPIFileTime" + RS_SPLIT);
                    strBldBoard.Append("Squeege" + RS_SPLIT);
                    strBldBoard.Append("WipeCommand" + RS_SPLIT);
                    strBldBoard.Append("OffsetX" + RS_SPLIT);
                    strBldBoard.Append("OffsetY" + RS_SPLIT);
                    strBldBoard.Append("Theta" + RS_SPLIT);
                    strBldBoard.Append("ThetaCoRX" + RS_SPLIT);
                    strBldBoard.Append("ThetaCoRY" + RS_SPLIT);
                    strBldBoard.Append("Stretch" + RS_LineEnd);
                }
                
                strBldBoard.Append(ABrdRes.pcbID + RS_SPLIT);

                String strValue = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                    AappSettingData, (byte)ABrdRes.LaneNo);
                strBldBoard.Append(ABrdRes.pcbBarcode + RS_SPLIT);

                strValue = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                strBldBoard.Append(strValue + RS_SPLIT);

                //strValue = Path.GetFileNameWithoutExtension(ABrdRes.stPrinterSystemLog.strPrinterToSPIFileName);
                strValue = ABrdRes.stPrinterSystemLog.strPrinterToSPIFileName;
                strBldBoard.Append(strValue + RS_SPLIT);

                strValue = ABrdRes.stPrinterSystemLog.dtReadPrinterFile.ToString("yyyy/MM/dd HH:mm:ss");
                strBldBoard.Append(strValue + RS_SPLIT);

                strValue = ABrdRes.stPrinterSystemLog.strSPIToPrinterFileName;
                strBldBoard.Append(strValue + RS_SPLIT);

                strValue = ABrdRes.stPrinterSystemLog.dtGenSPIFile.ToString("yyyy/MM/dd HH:mm:ss");
                strBldBoard.Append(strValue + RS_SPLIT);


                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strSqueege + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strWipeCommand + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strOffsetX + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strOffsetY + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strTheta + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strThetaCoRX + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strThetaCoRY + RS_SPLIT);
                strBldBoard.Append(ABrdRes.stPrinterSystemLog.strStretch + RS_LineEnd);

                


                FileStream fs = new FileStream(strFileName, FileMode.Append);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Close();


               
                //if (File.Exists(tmpFile))
                //{
                //    if (File.Exists(strFileName) == false)
                //        File.Copy(tmpFile, strFileName, true);
                //    else
                //    {
                //        fs = new FileStream(strFileName, FileMode.Append);
                //        streamWrt = new StreamWriter(fs, Encoding.Default);
                //        streamWrt.wri
                //        streamWrt.Close();
                //    }
                //    Thread.Sleep(100);
                //    File.Delete(tmpFile);
                //}
            }
            catch (System.Exception ex)
            {
                strMsg = RS_DATAEXPORTSystemLOGMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            return strMsg;
        }
        private void GenTestAPCShift(InspectMainLib.Pad APad, ref float GX, ref float GY)
        {
            return;
            if (APad.res.measuredValue.height < 0.001f) return;
            bool bNeedLargerShiftX = (APad.res.jugRes == JudgeRes.NG && APad.res.jugDefectType == DefectType.ShiftX)? true : false;
            bool bNeedLargerShiftY = (APad.res.jugRes == JudgeRes.NG && APad.res.jugDefectType == DefectType.ShiftY) ? true : false;
            Random ran = new Random();
            float dRan = (float)ran.NextDouble();
            GX = dRan/2;          

            dRan = (float)ran.NextDouble();
            GY = dRan/2;


            GX *= 0.01f;
            GY *=  0.01f;
        }
        
    }
     
}
