﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace WSClnt
{
    public class AccessDBHelper
    {
        private static string _strRealTimeDBPath = "D:\\EYSPI\\RealTimeAccessData\\RealTime.mdb";
        public static string GetFieldValueFrAccess(string AstrSQLSelect )
        {
            string strRtn = string.Empty;
            //

            OleDbConnection conn = new OleDbConnection(string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Database Password=123", _strRealTimeDBPath)); //
            OleDbCommand cmd = conn.CreateCommand();
            OleDbDataReader dr;
            try
            {
                conn.Open();
                cmd.CommandText = AstrSQLSelect;
                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows) strRtn = dr[0].ToString();
                //
                return strRtn;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public static bool ExecuteNonQuery(string AstrSQL)
        {
            OleDbConnection conn = new OleDbConnection(string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Database Password=123", _strRealTimeDBPath)); //
            OleDbCommand cmd = conn.CreateCommand();
            try
            {
                conn.Open();              
                cmd.CommandText = AstrSQL;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
                conn.Dispose();
            }
        }
    }
}
