﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ImgCSCoreIM;
namespace WSClnt
{
    public class SQLServerDAO
    {
        private readonly string RS_SQL_SERVER_CONNECT_STR = "server={0};database={1};Uid={2};Pwd={3};";
        private readonly string RS_DATABASE_CONNECT_ERROR = "DataBase Connect Error";
        private readonly string RS_DATABASE_EXECUTE_ERROR = "DataBase Execute Error";
        private static readonly string RS_DATABASE_NAME = "VIData";
        private static readonly string RS_DATABASE_SCHEMA = "dbo";

        //add by Peng 20180101     
        private static readonly string RS_CHENDA_DATABASE_NAME = "MRAOI";
        private static readonly string RS_CHENDA_DATABASE_SCHEMA = "dbo";
        private static readonly string RS_CHENDA_DATABASE_TABLE_NAME = "t_spi";
        //
        
        //add by Peng 20180301
        public static  string RS_YINQU_DATABASE_NAME = "ums_db";
        private static readonly string RS_YINQU_DATABASE_SCHEMA = "dbo";
        private static readonly string RS_YINQU_DATABASE_TABLE_NAME = "T_SMT_SPIBadCollection";


        private SqlConnection _sqlConnect;
        private SqlCommand _sqlCommand;
        private string _sConnectSql = "";
        private bool _bIsConnectSuccess = false;
        //
        public string userName { get; set; }
        public string password { get; set; }
        public string dbName { get; set; }
        public string dbAddress { get; set; }
        //                 

        private readonly string RS_FEIGE_TABLE_SMTMA = "INSERT INTO [{0}].[" + RS_DATABASE_SCHEMA + "].[SMTMA] "+
            " ([MA01],[MA02],[MA03],[MA04],[MA05],[MA06]) VALUES ('{1}','{2}','{3}','{4}','{5}','{6}');";


        private readonly string RS_FOXCONN_TABLE_EQUIP_STATUS = "INSERT INTO [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_EQUIP_STATUS] " +
            " ([LINE],[EQUIP_ID],[EQUIP_AUTO],[EQUIP_START],[EQUIP_RUN],[EQUIP_STOP],[EQUIP_IDLE],[EQUIP_DOWN],[EQUIP_INITIALIZATION],[BY_PASS],[BOARD_ON],"+
            " [BOARD_IN],[BOARD_STOP],[BOARD_DOWN],[BOARD_READY_OUT],[BOARD_OUT],[PROCESS_NUMBER],[SIGNAL_TOWER_STATUS_R],[SIGNAL_TOWER_STATUS_Y],[SIGNAL_TOWER_STATUS_G],[EQUIP_ERROR_CODE])" +
            "  VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}');";

        private readonly string RS_FOXCONN_UPDATE_TABLE_EQUIP_STATUS = "UPDATE [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_EQUIP_STATUS] "+
            " set [EQUIP_AUTO] = {2},[EQUIP_START] = {3},[EQUIP_RUN] = {4},[EQUIP_STOP] = {5},[EQUIP_IDLE] = {6}, [EQUIP_DOWN]= {7},[EQUIP_INITIALIZATION] = {8},"+
            " [BY_PASS] = {9},[BOARD_ON] = {10},[BOARD_IN] = {11},[BOARD_STOP] = {12},[BOARD_DOWN] = {13},[BOARD_READY_OUT] = {14},[BOARD_OUT] = {15},"+
            " [PROCESS_NUMBER] = {16},[SIGNAL_TOWER_STATUS_R] = {17},[SIGNAL_TOWER_STATUS_Y] = {18}, [SIGNAL_TOWER_STATUS_G] = {19},[EQUIP_ERROR_CODE] = {20}"+
            " WHERE [LINE] = '{0}' AND [EQUIP_ID] = '{1}' "; //Q.F.2017.04.10

        private readonly string RS_FOXCONN_EQUIP_STATUS_EXIST = "SELECT [LINE] FROM [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_EQUIP_STATUS]  WHERE [LINE] = '{0}' AND [EQUIP_ID] = '{1}'";//Q.F.2017.04.10

        private readonly string RS_FOXCONN_TABLE_INSPECTION_INFO = "INSERT INTO [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] " +
            " ([LINE],[EQUIP_ID],[RECIPE_ID],[BARCODE],[START_TEST_TIME],[END_TEXT_TIME],[REAL_CYCLE_TIME],[HISTORY_QUANTITY],[RECIPE_DATE],[PROCESS_TIME],[T_TIME],[WAITING_TIME],[RESULT],[UI_START],[UI_CLOSE]) " +
            "  VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}');";

        //add Tony 17.5.11
        private readonly string RS_FOXCONN_TABLE_INSPECTION_INFO_EXIST = "SELECT [LINE] FROM [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] WHERE [LINE] = '{0}' AND [EQUIP_ID] = '{1}' ";

        private readonly string RS_FOXCONN_TABLE_INSPECTION_INFO_UPDATE_ALL = "UPDATE [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] "+
            " SET [RECIPE_ID]='{2}',[BARCODE]='{3}',[START_TEST_TIME]='{4}',[END_TEXT_TIME]='{5}',[REAL_CYCLE_TIME]='{6}',[HISTORY_QUANTITY]='{7}',[RECIPE_DATE]='{8}',[PROCESS_TIME]='{9}',[T_TIME]='{10}',[WAITING_TIME]='{11}',[RESULT]='{12}',[UI_START]='{13}',[UI_CLOSE]='{14}' "+
            " WHERE [LINE] = '{0}' AND [EQUIP_ID] = '{1}' ";

        private readonly string RS_FOXCONN_TABLE_INSPECTION_ITEMS = "INSERT INTO [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_ITEMS] " +
            " ([LINE],[EQUIP_ID],[BARCODE],[PadID],[COMPONENT],[ARRAY_ID],[TYPE],[RESULT],[ERROR],[ERROR_CODE],[MODIFY_DATE]) " +
            " VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}');";
        //private readonly string RS_FOXCONN_UPDATE_TABLE_INFO = "UPDATE [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] SET [T_TIME] = '{0}' ,[WAITING_TIME] = '{1}' " +
        //    " WHERE [LINE]='{2}' AND [EQUIP_ID]='{3}' AND [RECIPE_ID]='{4}' AND [BARCODE]='{5}' ";

        //private readonly string RS_FOXCONN_UPDATE_TABLE_INFO = "UPDATE [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] SET [END_TEXT_TIME] = '{0}',[REAL_CYCLE_TIME] = '{1}', [REAL_CYCLE_TIME] = '{1}',[T_TIME] = '{2}' ,[WAITING_TIME] = '{3}' " +
        //   " WHERE [LINE]='{4}' AND [EQUIP_ID]='{5}' AND [RECIPE_ID]='{6}' AND [BARCODE]='{7}' ";
        //modify Tony 17.5.11
        private readonly string RS_FOXCONN_UPDATE_TABLE_INFO = "UPDATE [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO] SET [REAL_CYCLE_TIME] = '{0}',[T_TIME] = '{1}' ,[WAITING_TIME] = '{2}' " +
           " WHERE [LINE]='{3}' AND [EQUIP_ID]='{4}' AND [RECIPE_ID]='{5}' AND [BARCODE]='{6}' ";

        // add Tony 17.5.11
        private readonly string RS_FOXCONN_DELETE_TABLE_ITEMS = "DELETE FROM [" + RS_DATABASE_NAME + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_ITEMS] WHERE [LINE]='{0}'and [EQUIP_ID]='{1}'";

        // add Peng 18.1.31
        private readonly string RS_CHENDA_TABLE_SMTMA = "INSERT INTO [" + RS_CHENDA_DATABASE_NAME + "].[" + RS_CHENDA_DATABASE_SCHEMA + "].["+RS_CHENDA_DATABASE_TABLE_NAME+"] " +
            " ([barcode],[linenumber],[classes],[testdate],[testtime],[productno],[modelno],[meshthick],[panelqty],[illno],[illposition],[illitem],[illqty],[testresult]) " +
            "  VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}');";
       //modity by Peng 180313
        private readonly string RS_YINQU_TABLE_INSERT_KY = "INSERT INTO [" + RS_YINQU_DATABASE_NAME + "].[" + RS_YINQU_DATABASE_SCHEMA + "].[" + RS_YINQU_DATABASE_TABLE_NAME + "] " +
            " ([UserCode],[ParentBarcode],[ChildBarcode],[ModelName],[Puzzle],[PadID],[Track],[Sysdate],[OperateConfirm],[OperateSysdate],[Result],[ProLine],[Batch],[SolderPasteType]," +
            " [Picture],[IP],[NGType],[Volume],[VolumeMax],[VolumeMin],[HeightValueType],[Height],[HeightMax],[HeightMin],[MaxHeight],[Area],[AreaMax],[AreaMin],[TinType],[ShiftValueType],[ShiftX],[ShiftXMax],[ShiftXMin],[ShiftY], " +
            " [ShiftYMax],[ShiftYMin],[AreaCpk],[VolumeCpk],[HeightCpk] ) " +
            "  VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}','{24}','{25}','{26}','{27}','{28}','{29}','{30}','{31}','{32}','{33}','{34}','{35}','{36}','{37}','{38}' );";
        private readonly string RS_YINQU_TABLE_INSERT = "INSERT INTO [" + RS_YINQU_DATABASE_NAME + "].[" + RS_YINQU_DATABASE_SCHEMA + "].[" + RS_YINQU_DATABASE_TABLE_NAME + "] " +
           " ([UserCode],[ParentBarcode],[ChildBarcode],[ModelName],[Puzzle],[PadID],[Track],[Sysdate],[OperateConfirm],[OperateSysdate],[Result],[ProLine],[Batch],[SolderPasteType]," +
           " [Picture],[IP],[NGType],[Volume],[VolumeMax],[VolumeMin],[HeightValueType],[Height],[HeightMax],[HeightMin],[MaxHeight],[Area],[AreaMax],[AreaMin],[TinType],[ShiftValueType],[ShiftX],[ShiftXMax],[ShiftXMin],[ShiftY], " +
           " [ShiftYMax],[ShiftYMin] ) " +
           "  VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}','{24}','{25}','{26}','{27}','{28}','{29}','{30}','{31}','{32}','{33}','{34}','{35}' );";

        public SQLServerDAO() { }

        ~SQLServerDAO()
        {
            try
            {
                if (this._sqlConnect.State == ConnectionState.Open)
                {
                    this._sqlConnect.Close();
                    this._sqlConnect.Dispose();
                }
               
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        //modify by tony 17.8.21
        //AsDatabaseVersion : 2005,2008,2010 etc
        public SQLServerDAO(string AsIPAddress, string AsDBName, string AsUserName, string AsPassword,int AsDatabaseVersion)
        {
            this.userName = AsUserName;
            this.password = AsPassword;
            this.dbName = AsDBName;
            this.dbAddress = AsIPAddress;
            
            //  Data Source=.;Initial Catalog=test;User ID=sa;Password=123456
            string strConn = "";
            if (AsDatabaseVersion == 2005) 
            {
                //strConn = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";
                //strConn = @"Data Server={0}//SQLEXPRESS;Initial Catalog={1};User ID={2};Password={3}";
                strConn = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";//2017/08.25
            }
            else
            {
                strConn = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";
            }
            
            if (string.IsNullOrEmpty(AsIPAddress) || string.IsNullOrEmpty(AsUserName))
            {
                throw new Exception(RS_DATABASE_CONNECT_ERROR);
            }
            try
            {
                // SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();

                //if (string.IsNullOrEmpty(AsDBName))
                //{
                //    scsb.DataSource = AsIPAddress;
                //}
                //else 
                //{
                //    scsb.DataSource = AsIPAddress + "\\" + AsDBName;
                //}
                strConn = string.Format(strConn, AsIPAddress, AsDBName, AsUserName, AsPassword);
                //scsb.IntegratedSecurity = false;
                //scsb.UserID = AsUserName;
                //scsb.Password = AsPassword;
                //scsb.InitialCatalog = "master";
                //this._sqlConnect = new SqlConnection(scsb.ConnectionString);
                this._sqlConnect = new SqlConnection(strConn);
                //this._sConnectSql = string.Format(RS_SQL_SERVER_CONNECT_STR, AsIPAddress, AsDBName, AsUserName, AsPassword);
                //this._sqlConnect = new SqlConnection(_sConnectSql);
                this._sqlConnect.Open();
                //this._sqlCommand = this._sqlConnect.CreateCommand();
            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.StackTrace);
               // throw new Exception(RS_DATABASE_CONNECT_ERROR);
                throw e1;
            }
        }

        public SQLServerDAO(string AsIPAddress, string AsDBName, string AsUserName, string AsPassword)
        {
            this.userName = AsUserName;
            this.password = AsPassword;
            this.dbName = AsDBName;
            this.dbAddress = AsIPAddress;
            //  Data Source=.;Initial Catalog=test;User ID=sa;Password=123456
            string strConn = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";
            if (string.IsNullOrEmpty(AsIPAddress) || string.IsNullOrEmpty(AsUserName))
            {
                throw new Exception(RS_DATABASE_CONNECT_ERROR);
            }
            try
            {
                // SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();

                //if (string.IsNullOrEmpty(AsDBName))
                //{
                //    scsb.DataSource = AsIPAddress;
                //}
                //else 
                //{
                //    scsb.DataSource = AsIPAddress + "\\" + AsDBName;
                //}
                strConn = string.Format(strConn, AsIPAddress, AsDBName, AsUserName, AsPassword);
                //scsb.IntegratedSecurity = false;
                //scsb.UserID = AsUserName;
                //scsb.Password = AsPassword;
                //scsb.InitialCatalog = "master";
                //this._sqlConnect = new SqlConnection(scsb.ConnectionString);
                this._sqlConnect = new SqlConnection(strConn);
                //this._sConnectSql = string.Format(RS_SQL_SERVER_CONNECT_STR, AsIPAddress, AsDBName, AsUserName, AsPassword);
                //this._sqlConnect = new SqlConnection(_sConnectSql);
                this._sqlConnect.Open();
                //this._sqlCommand = this._sqlConnect.CreateCommand();
            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.StackTrace);
                throw new Exception(RS_DATABASE_CONNECT_ERROR);
            }
        }
        //Q.F.2017.04.08
        public String CheckConnection(string AsIPAddress, string AsDBName, string AsUserName, string AsPassword)
        {
            string strConn = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";
            if (string.IsNullOrEmpty(AsIPAddress) || string.IsNullOrEmpty(AsUserName))
            {
                return RS_DATABASE_CONNECT_ERROR;
            }
            try
            {
                this.userName = AsUserName;
                this.password = AsPassword;
                this.dbName = AsDBName;
                this.dbAddress = AsIPAddress;
                strConn = string.Format(strConn, AsIPAddress, AsDBName, AsUserName, AsPassword);
                this._sqlConnect = new SqlConnection(strConn);
                this._sqlConnect.Open();
                return String.Empty;
            }
            catch (Exception e1)
            {
                //Console.WriteLine(e1.StackTrace);
                //throw new Exception(RS_DATABASE_CONNECT_ERROR);
                return RS_DATABASE_CONNECT_ERROR + e1.ToString();
            }
        }
        //Q.F.2017.04.08
        public void Disconnected()
        {
            try
            {
                if (this._sqlConnect.State == ConnectionState.Open)
                {
                    this._sqlConnect.Close();
                    this._sqlConnect.Dispose();
                }
            }
            catch (Exception e1)
            {
                // Console.WriteLine(e1.StackTrace);
            }
        }
        //Q.F.2017.04.08
        public void ResetRealTimeStatus(ref ST_SPI_EQUIP_STATUS Astatus)
        {
            string strOff = "0";

            //Astatus.line = strOff;
            //Astatus.equipId = strOff;
            Astatus.equipAuto = strOff;//如果不是bypass状态就为此状态
            Astatus.equipStart = strOff;///打开UI软件
            Astatus.equipRun = strOff;//运行测试、测试中
            Astatus.equipStop = strOff;//停止测试
            Astatus.equipIdle = strOff;//闲置
            Astatus.equipDown = strOff;//关闭UI
            Astatus.equipInit = strOff;//初始化
            Astatus.byPass = strOff;//当前byPass 模式
            Astatus.boardOn = strOff; //夹板上升
            Astatus.boardIn = strOff;//板子进入设备进板位
            Astatus.boardStop = strOff;//板子在停板位
            Astatus.boardDown = strOff;//夹板下降
            Astatus.boardReadyOut = strOff;//板子停在出板位
            Astatus.boardOut = strOff;//后段工位要板，板子出去
            Astatus.processNumber = strOff;
            Astatus.signalTowerStatusR = strOff; //灯塔状态red
            Astatus.signalTowerStatusY = strOff; //灯塔状态yellow
            Astatus.signalTowerStatusG = strOff; //灯塔状态Green
            Astatus.equipErrorCode = strOff;//设备错误code 1-7
        }

        public String UpdateInfoTable(ST_SPI_EQUIP_INFO AStInfo)
        {
            String strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string execSql = string.Format(RS_FOXCONN_UPDATE_TABLE_INFO, AStInfo.realCycleTime,AStInfo.tTime, AStInfo.waitingTime,
                    AStInfo.line, AStInfo.equipId, AStInfo.recipeId, AStInfo.barcode);
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();
                //Console.WriteLine(e1.StackTrace);
                //throw new Exception(RS_DATABASE_EXECUTE_ERROR);
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "UpdateInfo:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;
        }

        public String InsertTable(E_FOXCONN_TABLE_NAME AtableName, ST_FOXCONN_TABLE_INFO tableInfo)
        {
            String strMsg = "";
            switch (AtableName)
            {
                case E_FOXCONN_TABLE_NAME.SPI_EQUIP_STATUS:
                    strMsg = InsertTableStatus(tableInfo.status);
                    break;
                case E_FOXCONN_TABLE_NAME.SPI_INSPECTION_INFO:
                    strMsg = InsertTableInfo(tableInfo.info);
                    break;
                case E_FOXCONN_TABLE_NAME.SPI_INSPECTION_ITEMS:
                    strMsg = InsertTableItems(tableInfo.items);
                    break;
                default:
                    break;

            }
            return strMsg;
        }

        private String InsertTableStatus(ST_SPI_EQUIP_STATUS Astatus)
        {
            String strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();                
                this._sqlCommand.CommandType = CommandType.Text;
                string querySql = string.Format(RS_FOXCONN_EQUIP_STATUS_EXIST,Astatus.line,Astatus.equipId);
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandText = querySql; 
                string executeSql = "";
                if (this._sqlCommand.ExecuteScalar() == null)
                    executeSql = string.Format(RS_FOXCONN_TABLE_EQUIP_STATUS,
                        Astatus.line, Astatus.equipId, Astatus.equipAuto, Astatus.equipStart, Astatus.equipRun, Astatus.equipStop, Astatus.equipIdle, Astatus.equipDown,
                        Astatus.equipInit, Astatus.byPass, Astatus.boardOn, Astatus.boardIn, Astatus.boardStop, Astatus.boardDown, Astatus.boardReadyOut, Astatus.boardOut,
                        Astatus.processNumber, Astatus.signalTowerStatusR, Astatus.signalTowerStatusY, Astatus.signalTowerStatusG, Astatus.equipErrorCode);
                else
                    executeSql = string.Format(RS_FOXCONN_UPDATE_TABLE_EQUIP_STATUS, Astatus.line, Astatus.equipId, Astatus.equipAuto, Astatus.equipStart, Astatus.equipRun, Astatus.equipStop, Astatus.equipIdle, Astatus.equipDown,
                        Astatus.equipInit, Astatus.byPass, Astatus.boardOn, Astatus.boardIn, Astatus.boardStop, Astatus.boardDown, Astatus.boardReadyOut, Astatus.boardOut,
                        Astatus.processNumber, Astatus.signalTowerStatusR, Astatus.signalTowerStatusY, Astatus.signalTowerStatusG, Astatus.equipErrorCode);

                
                this._sqlCommand.CommandText = executeSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();
                //Console.WriteLine(e1.StackTrace);
                //throw new Exception(RS_DATABASE_EXECUTE_ERROR);
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "Status:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;
        }

        private String InsertTableInfo(ST_SPI_EQUIP_INFO Ainfo)
        {
            String strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string querySql = string.Format(RS_FOXCONN_TABLE_INSPECTION_INFO_EXIST, Ainfo.line, Ainfo.equipId);
                this._sqlCommand.CommandText = querySql;
                string execSql = "";
                if (this._sqlCommand.ExecuteScalar() != null)
                {
                    execSql = string.Format(RS_FOXCONN_TABLE_INSPECTION_INFO_UPDATE_ALL,
                        Ainfo.line, Ainfo.equipId, Ainfo.recipeId, Ainfo.barcode, Ainfo.startTestTime, Ainfo.endTextTime, Ainfo.realCycleTime,
                    Ainfo.historyQuantity, Ainfo.recipeDate, Ainfo.processTime, Ainfo.tTime, Ainfo.waitingTime, Ainfo.result, Ainfo.uiStart, Ainfo.uiClose);
                }
                else 
                {
                    execSql = string.Format(RS_FOXCONN_TABLE_INSPECTION_INFO,
                        Ainfo.line, Ainfo.equipId, Ainfo.recipeId, Ainfo.barcode, Ainfo.startTestTime, Ainfo.endTextTime, Ainfo.realCycleTime,
                        Ainfo.historyQuantity, Ainfo.recipeDate, Ainfo.processTime, Ainfo.tTime, Ainfo.waitingTime, Ainfo.result, Ainfo.uiStart, Ainfo.uiClose);
                
                }
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();
                //Console.WriteLine(e1.StackTrace);
                //throw new Exception(RS_DATABASE_EXECUTE_ERROR);

                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "Info:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;
        }

        private String InsertTableItems(ST_SPI_EQUIP_ITEMS[] Aitems)
        {
            String strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string execSql;
                foreach (ST_SPI_EQUIP_ITEMS items in Aitems)
                {
                    execSql = string.Format(RS_FOXCONN_TABLE_INSPECTION_ITEMS,
                    items.line, items.equipId, items.barcode, items.padId, items.component, items.arrayId, items.type,
                    items.result, items.error, items.errorCode, items.modifyDate);
                    this._sqlCommand.CommandText = execSql;
                    this._sqlCommand.ExecuteNonQuery();
                }
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();
                //Console.WriteLine(e1.StackTrace);
                //throw new Exception(RS_DATABASE_EXECUTE_ERROR);
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "Items:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }

            return strMsg;
        }

        //add Tony 17.5.11
        public string DeleteTableItems(string AsLine,string AsEquipId) 
        {
            String strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string execSql = string.Format(RS_FOXCONN_DELETE_TABLE_ITEMS, AsLine,AsEquipId);                
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();                
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();                
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "DeleteItems:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }

            return strMsg;
        }

        //tony 17.5.31
        public string InsertTableFeiGeSMTMA(string ADbName,string ABarcode,string AResult, string ALine,string ADate,string ATime,string ASPI) 
        {
            string strMsg = "";
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string execSql = string.Format(RS_FEIGE_TABLE_SMTMA,ADbName, ABarcode, AResult,  ALine, ADate, ATime, ASPI);
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception e1)
            {
                sqlTransaction.Rollback();                
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "FEIGE SMTMA:" + e1.ToString();
            }
            finally
            {
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }

            return strMsg;
        }

        public bool CreateDatabase(string AsDbAddress, string AsDefaultDb, string AsUserName, string AsPassword, string AsDbName, string AsDbFilePath)
        {
            if (string.IsNullOrEmpty(AsUserName) || string.IsNullOrEmpty(AsPassword))
                return false;
            bool ret = true;
            string dbName = AsDbName;
            string dbFilePath = AsDbFilePath;
            string defaultDb = AsDefaultDb;
            string address = AsDbAddress;
            if (string.IsNullOrEmpty(AsDbName))
            {
                dbName = RS_DATABASE_NAME;
            }
            if (string.IsNullOrEmpty(AsDbFilePath))
            {
                dbFilePath = "d:";
            }
            if (string.IsNullOrEmpty(defaultDb))
            {
                //defaultDb = "mssqlserver";
            }
            if (string.IsNullOrEmpty(address))
            {
                address = "localhost";
            }
            string sqlCheckDb = "SELECT * FROM SYSDATABASES WHERE NAME = '" + dbName + "';";
            string sqlDropDb = "DROP DATABASE " + dbName + ";";
            string sqlCreateDb = "CREATE DATABASE [" + dbName + "] on primary " +
                "(NAME = N'" + dbName + "',  FILENAME = N'" + dbFilePath + "\\" + dbName + ".mdf',SIZE = 5 MB, MAXSIZE = UNLIMITED ,FILEGROWTH = 1 MB ) " +
                " LOG ON (NAME = N'" + dbName + "_log', FILENAME = N'" + dbFilePath + "\\" + dbName + "_log.ldf', SIZE = 1MB, MAXSIZE = UNLIMITED,FILEGROWTH = 1MB)" +
                " COLLATE SQL_Latin1_General_CP1250_CI_AS";
            string sqlAlterDb = "ALTER DATABASE [" + dbName + "] SET COMPATIBILITY_LEVEL = 100";
            string sqlCreateTbStatus = "create table [" + dbName + "].[" + RS_DATABASE_SCHEMA + "].[SPI_EQUIP_STATUS](" +
                                    " LINE CHAR(10)  not null," +
                                    " EQUIP_ID VARCHAR(50)," +
                                    " EQUIP_AUTO BIT  not null," +
                                    " EQUIP_START BIT  not null," +
                                    " EQUIP_RUN BIT  not null," +
                                    " EQUIP_STOP BIT  not null," +
                                    " EQUIP_IDLE BIT  not null," +
                                    " EQUIP_DOWN BIT  not null," +
                                    " EQUIP_INITIALIZATION BIT  not null," +
                                    " BY_PASS BIT  not null," +
                                    " BOARD_ON BIT  not null," +
                                    " BOARD_IN BIT  not null," +
                                    " BOARD_STOP BIT  not null," +
                                    " BOARD_DOWN BIT  not null," +
                                    " BOARD_READY_OUT BIT  not null," +
                                    " BOARD_OUT BIT  not null," +
                                    " PROCESS_NUMBER CHAR(10)  not null," +
                                    " SIGNAL_TOWER_STATUS_R CHAR(10) not null," +
                                    " SIGNAL_TOWER_STATUS_Y CHAR(10) not null," +
                                    " SIGNAL_TOWER_STATUS_G CHAR(10) not null," +
                                    " EQUIP_ERROR_CODE BIT  not null)";
            string sqlCreateTbInfo = "create table [" + dbName + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_INFO](" +
                                    " LINE CHAR(10)  not null," +
                                    " EQUIP_ID VARCHAR(50) not null," +
                                    " RECIPE_ID  VARCHAR(50)," +
                                    " BARCODE VARCHAR(50)," +
                                    " START_TEST_TIME VARCHAR(50)," +
                                    " END_TEXT_TIME VARCHAR(50)," +
                                    " REAL_CYCLE_TIME CHAR(10)," +
                                    " HISTORY_QUANTITY VARCHAR(50)," +
                                    " RECIPE_DATE VARCHAR(50)," +
                                    " PROCESS_TIME CHAR(10)," +
                                    " T_TIME CHAR(10)," +
                                    " WAITING_TIME CHAR(10)," +
                                    " RESULT CHAR(10)," +
                                    " UI_START VARCHAR(50)," +
                                    " UI_CLOSE VARCHAR(50))";

            string sqlCreateTbItems = "create table [" + dbName + "].[" + RS_DATABASE_SCHEMA + "].[SPI_INSPECTION_ITEMS](" +
                                    " LINE CHAR(10) ," +
                                    " EQUIP_ID CHAR(10)," +
                                    " BARCODE VARCHAR(50)," +
                                    " PADID VARCHAR(50)," +
                                    " COMPONENT CHAR(10)," +
                                    " ARRAY_ID VARCHAR(50)," +
                                    " TYPE VARCHAR(50)," +
                                    " RESULT CHAR(10)," +
                                    " ERROR CHAR(10)," +
                                    " ERROR_CODE CHAR(10)," +
                                    " MODIFY_DATE VARCHAR(50))";
            try
            {
                //ceate db
                SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
                if (string.IsNullOrEmpty(AsDefaultDb))
                {
                    scsb.DataSource = address;
                }
                else
                {
                    scsb.DataSource = address + "\\" + defaultDb;
                }
                scsb.IntegratedSecurity = false;
                scsb.UserID = AsUserName;
                scsb.Password = AsPassword;
                scsb.InitialCatalog = "master";
                Console.WriteLine(scsb.ConnectionString);
                this._sqlConnect = new SqlConnection(scsb.ConnectionString);
                this._sqlConnect.Open();
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.CommandType = CommandType.Text;
                this._sqlCommand.CommandText = sqlCheckDb;
                SqlDataReader reader = this._sqlCommand.ExecuteReader();
                string dbname = "";
                while (reader.Read())
                {
                    dbname = (string)reader["NAME"];
                    Console.Write(reader["NAME"]);	// 打印出每个用户的用户名
                }
                reader.Close();
                //  = 
                if (!string.IsNullOrEmpty(dbname))
                {
                    //this._sqlCommand.CommandText = sqlDropDb;                    
                    //this._sqlCommand.ExecuteNonQuery();
                    //this._sqlCommand.CommandText = sqlCreateDb;
                    //this._sqlCommand.ExecuteNonQuery();
                    //this._sqlCommand.CommandText = sqlAlterDb;
                    //this._sqlCommand.ExecuteNonQuery();
                }

               
                //ceate table
                this._sqlCommand.CommandText = sqlCreateTbStatus;
                this._sqlCommand.ExecuteNonQuery();
                this._sqlCommand.CommandText = sqlCreateTbInfo;
                this._sqlCommand.ExecuteNonQuery();
                this._sqlCommand.CommandText = sqlCreateTbItems;
                this._sqlCommand.ExecuteNonQuery();
            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.Message);
                throw new Exception("Create Database error");
            }
            finally
            {
                this._sqlCommand.Dispose();
                this._sqlConnect.Close();
                this._sqlConnect.Dispose();
            }

            return ret;
        }

        //add Peng 18.01.31
        public string InsertTableForCHENDA(   string Asbarcode, string Aslinenumber, string Asclasses, string Astestdate, string Astesttime, string Asproductno
            , string Asmodelno, string Asmeshthick, string Aspanelqty, string Asillno, string Asillposition, string Asillitem,
            string Asillqty, string Astestresult)
        {
            string strMsg = string.Empty;
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                string execSql = string.Format(RS_CHENDA_TABLE_SMTMA, Asbarcode, Aslinenumber, Asclasses, Astestdate, Astesttime, Asproductno, Asmodelno,
                    Asmeshthick, Aspanelqty, Asillno, Asillposition, Asillitem, Asillqty, Astestresult,"1");
    
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                sqlTransaction.Rollback();
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "InsertTableForCHENDA" + ex.ToString();
            }
            finally
            {
                Disconnected();
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;


            
        }

        //modify By Peng 20180313
        //([UserCode],[ParentBarcode],[ChildBarcode],[ModelName],[Puzzle],[PadQty],[Track],[Sysdate],[OperateConfirm],[OperateSysdate],[Result],[ProLine],[Batch],[SolderPasteType],[Picture],[IP],
        //[Volume],[Height],[MaxHeight],[Area],[TinType],[shiftX],[ShiftY]) 
        //" [VolumeUpLow],[HeightUpLow],[AreaUpLow],[ShiftXY],[ReserveType] )  " +
        public string InsertTableForYINQU_KY(XiaMenYinQu YXpcbInfo)
        {
            string strMsg = string.Empty;
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                object[] obParam = new object[] { YXpcbInfo.userCodde, YXpcbInfo.parentBarcode, YXpcbInfo.childBarcode, YXpcbInfo.modelName, YXpcbInfo.puzzle, YXpcbInfo.padId, YXpcbInfo.track, YXpcbInfo.sysdate,
                    YXpcbInfo.operateConfirm, YXpcbInfo.operateSysdate, YXpcbInfo.result, YXpcbInfo.proLine, YXpcbInfo.batch, YXpcbInfo.solderPasteType, YXpcbInfo.picture, YXpcbInfo.ip,
                    YXpcbInfo.ngType, YXpcbInfo.volume, YXpcbInfo.volumeMax, YXpcbInfo.volumeMin, YXpcbInfo.heightValueType, YXpcbInfo.height, YXpcbInfo.heightMax,
                     YXpcbInfo.heightMin, YXpcbInfo.MaxHeight, YXpcbInfo.area, YXpcbInfo.areaMax, YXpcbInfo.areaMin, YXpcbInfo.tinType, YXpcbInfo.shiftValue, YXpcbInfo.shiftX, YXpcbInfo.shiftXMax, YXpcbInfo.shiftXmin, YXpcbInfo.shiftY,
                     YXpcbInfo.shiftYMax, YXpcbInfo.shiftYmin,YXpcbInfo.areaCPK,YXpcbInfo.volumeCPK,YXpcbInfo.heightCPK};
                string execSql = string.Format(RS_YINQU_TABLE_INSERT_KY, obParam);// modify 20180412 Peng
                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                sqlTransaction.Rollback();
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "InsertTableForYINQU_KY" + ex.ToString();
            }
            finally
            {
                Disconnected();
                
                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;

        }
        public string InsertTableForYINQU(XiaMenYinQu YXpcbInfo)
        {
            string strMsg = string.Empty;
            SqlTransaction sqlTransaction = this._sqlConnect.BeginTransaction();
            try
            {
                this._sqlCommand = this._sqlConnect.CreateCommand();
                this._sqlCommand.Transaction = sqlTransaction;
                this._sqlCommand.CommandType = CommandType.Text;
                object[] obParam = new object[] { YXpcbInfo.userCodde, YXpcbInfo.parentBarcode, YXpcbInfo.childBarcode, YXpcbInfo.modelName, YXpcbInfo.puzzle, YXpcbInfo.padId, YXpcbInfo.track, YXpcbInfo.sysdate,
                    YXpcbInfo.operateConfirm, YXpcbInfo.operateSysdate, YXpcbInfo.result, YXpcbInfo.proLine, YXpcbInfo.batch, YXpcbInfo.solderPasteType, YXpcbInfo.picture, YXpcbInfo.ip,
                    YXpcbInfo.ngType, YXpcbInfo.volume, YXpcbInfo.volumeMax, YXpcbInfo.volumeMin, YXpcbInfo.heightValueType, YXpcbInfo.height, YXpcbInfo.heightMax,
                     YXpcbInfo.heightMin, YXpcbInfo.MaxHeight, YXpcbInfo.area, YXpcbInfo.areaMax, YXpcbInfo.areaMin, YXpcbInfo.tinType, YXpcbInfo.shiftValue, YXpcbInfo.shiftX, YXpcbInfo.shiftXMax, YXpcbInfo.shiftXmin, YXpcbInfo.shiftY,
                     YXpcbInfo.shiftYMax, YXpcbInfo.shiftYmin};
                string execSql = string.Format(RS_YINQU_TABLE_INSERT, obParam);

                this._sqlCommand.CommandText = execSql;
                this._sqlCommand.ExecuteNonQuery();
                sqlTransaction.Commit();
                this._sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                sqlTransaction.Rollback();
                strMsg = "RS_DATABASE_EXECUTE_ERROR:" + "InsertTableForYINQU" + ex.ToString();
            }
            finally
            {
                Disconnected();

                if (this._sqlCommand != null) this._sqlCommand.Dispose();
            }
            return strMsg;

        } 
        //public bool CheckDbExist()
        //{
        //    bool bRet = false;
        //    if (string.IsNullOrEmpty(_sConnectSql) && (string.IsNullOrEmpty(this.dbName) || string.IsNullOrEmpty(this.dbAddress) || string.IsNullOrEmpty(this.userName)))
        //    {
        //        throw new Exception(RS_DATABASE_CONNECT_ERROR);
        //    }
        //    try
        //    {
        //        if (string.IsNullOrEmpty(_sConnectSql))
        //        {
        //            this._sConnectSql = string.Format(RS_SQL_SERVER_CONNECT_STR, this.dbAddress, this.dbName, this.userName, this.password);
        //        }

        //        this._sqlConnect = new SqlConnection(_sConnectSql);
        //        this._sqlConnect.Open();
        //        bRet = true;
        //    }
        //    catch (Exception e1)
        //    {
        //        Console.WriteLine(e1.StackTrace);
        //        throw new Exception(RS_DATABASE_CONNECT_ERROR);
        //    }
        //    finally
        //    {
        //        try
        //        {
        //            if (this._sqlConnect != null && this._sqlConnect.State == ConnectionState.Open)
        //            {
        //                this._sqlConnect.Close();
        //                this._sqlConnect.Dispose();
        //            }
        //        }
        //        catch (Exception e1) { }
        //    }
        //    return bRet;
        //}
    }
}
