﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace WSClnt
{
 public static   class XMLHelper
    {

        ///<summary>
        /// 保存obj到xml文件
        ///</summary>
        ///<param name="obj"></param>
        ///<param name="strFullPath"></param>
        ///<returns></returns>
        public static bool SaveObj2XMLFile<T>(T obj, string strXMLFullPath,string strTempFullPath ="" )
        {
            bool blnReturn = false;
            try
            {
                if (string.IsNullOrEmpty(strTempFullPath))
                {
                    strTempFullPath =Path.Combine( Path.GetTempPath(),Path.GetFileName(strXMLFullPath));
                }
                FileInfo fi = new FileInfo(strTempFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }

                FileStream xmlfile = new FileStream(strTempFullPath, FileMode.OpenOrCreate);
                XmlSerializer xml = new XmlSerializer(typeof(T));
                xml.Serialize(xmlfile, obj);
                xmlfile.Close();

                 fi = new FileInfo(strXMLFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }

                File.Copy(strTempFullPath, strXMLFullPath, true);
                File.Delete(strTempFullPath);
                blnReturn = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
            return blnReturn;
        }

        public static T ReadXMLFile2Obj<T>( string strXMLFullPath)
        {
            T tReturn   =default(T) ;
            FileStream XMLFileStream = null;//Q.F.2018.02.28
            try
            {
                if (!string.IsNullOrEmpty(strXMLFullPath)&&File.Exists(strXMLFullPath) )
                {
                    XMLFileStream = File.OpenRead(strXMLFullPath);
                    XmlSerializer xml = new XmlSerializer(typeof(T));
                    Object obj = xml.Deserialize(XMLFileStream);
                    tReturn = (T)Convert.ChangeType(obj, typeof(T));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (XMLFileStream != null)
                {
                    XMLFileStream.Close();
                }
            }
            return tReturn;
        }
    }
}
