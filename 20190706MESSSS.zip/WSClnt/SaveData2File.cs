﻿using System;
using System.Data;
using System.IO;
using System.Linq;

namespace WSClnt
{
    public static class SaveData2File
    {
        ///<summary>
        ///  table数据写入csv  返回错误信息. 无错误为string.empty
        ///</summary>
        ///<param name="dt"></param>
        ///<param name="fullPath"></param>
        ///<returns></returns>
        public static string SaveDataTable2CSVFile(DataTable dt, string strCSVFullPath, string strTempFullPath = "")
        {
            string strReturn = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(strTempFullPath))
                {
                    strTempFullPath = Path.Combine(Path.GetTempPath(), Path.GetFileName(strCSVFullPath));
                }
                FileInfo fi = new FileInfo(strTempFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }

                FileStream fs = new FileStream(strTempFullPath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
                string data = "";
                //文件是否已经存在 列名是否已经写入
                if (fs.Length < 3)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)//写入列名
                    {
                        data += dt.Columns[i].ColumnName.ToString();
                        if (i < dt.Columns.Count - 1)
                        {
                            data += ",";
                        }
                    }
                    sw.WriteLine(data);
                }
                for (int i = 0; i < dt.Rows.Count; i++) //写入各行数据
                {
                    data = "";
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        string str = dt.Rows[i][j].ToString();

                        //替换英文冒号 英文冒号需要换成两个冒号
                        str = str.Replace("\"", "\"\"");

                        //含逗号 冒号 换行符的需要放到引号中
                        if (str.Contains(',') || str.Contains('"') || str.Contains('\r') || str.Contains('\n'))
                        {
                            str = string.Format("\"{0}\"", str);
                        }
                        data += str;
                        if (j < dt.Columns.Count - 1)
                        {
                            data += ",";
                        }
                    }
                    sw.WriteLine(data);
                }
                sw.Close();
                fs.Close();

                 fi = new FileInfo(strCSVFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }
                File.Copy(strTempFullPath, strCSVFullPath, true);
                File.Delete(strTempFullPath);
            }
            catch (Exception ex)
            {
                strReturn += ex.Message.ToString();
                throw ex;
            }
            finally
            {

            }
            return strReturn;
        }
        ///<summary>
        ///  table数据写入txt  返回错误信息. 无错误为string.empty
        ///</summary>
        ///<param name="dt"></param>
        ///<param name="fullPath"></param>
        ///<returns></returns>
        public static string SaveDataTable2TXTFile(DataTable dt, string strTXTFullPath, string strTempFullPath = "")
        {
            string strReturn = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(strTempFullPath))
                {
                    strTempFullPath = Path.Combine(Path.GetTempPath(), Path.GetFileName(strTXTFullPath));
                }
                FileInfo fi = new FileInfo(strTempFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }

                FileStream fs = new FileStream(strTempFullPath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
                string data = "";
                //文件是否已经存在 列名是否已经写入
                if (fs.Length < 3)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)//写入列名
                    {
                        data += dt.Columns[i].ColumnName.ToString();
                        if (i < dt.Columns.Count - 1)
                        {
                            data += ",";
                        }
                    }
                    sw.WriteLine(data);
                }
                for (int i = 0; i < dt.Rows.Count; i++) //写入各行数据
                {
                    data = "";
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        string str = dt.Rows[i][j].ToString();

                        ////替换英文冒号 英文冒号需要换成两个冒号
                        //str = str.Replace("\"", "\"\"");

                        ////含逗号 冒号 换行符的需要放到引号中
                        //if (str.Contains(',') || str.Contains('"') || str.Contains('\r') || str.Contains('\n'))
                        //{
                        //    str = string.Format("\"{0}\"", str);
                        //}
                        data += str;
                        if (j < dt.Columns.Count - 1)
                        {
                            data += ",";
                        }
                    }
                    sw.WriteLine(data);
                }
                sw.Close();
                fs.Close();

                fi = new FileInfo(strTXTFullPath);
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }
                File.Copy(strTempFullPath, strTXTFullPath, true);
                File.Delete(strTempFullPath);
            }
            catch (Exception ex)
            {
                strReturn += ex.Message.ToString();
                throw ex;
            }
            finally
            {

            }
            return strReturn;
        }



    }
}
