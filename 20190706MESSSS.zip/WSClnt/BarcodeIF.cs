﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataBeanEx;

namespace WSClnt
{


    public class BarcodeIF
    {
        public const string CONST_PARAMETER_ERROR = "ParamError";

        public const string CONST_EMPTY_DATA_RESULT = "EmptyResult";

        public const string CONST_SUCCESS_RESULT = "success";

        private const string CONST_BARCODE_QUERY_SQL = "SELECT b.PCBID,b.IndexSerNo,b.ArrayID,b.ArrayBarCode FROM tbbarcode b WHERE b.PCBID = (SELECT MIN(b.PCBID) FROM tbbarcode b WHERE" +
                             " (b.ArrayBarCode = '{0}' or b.BarCode = '{0}' ) AND b.LineNo='{1}') ORDER BY b.ArrayID";

        private const string CONST_LASTBARCODE_QUERY_SQL = "SELECT b.PCBID,b.IndexSerNo,b.ArrayID,b.ArrayBarCode FROM tbbarcode b WHERE b.PCBID = (SELECT MAX(b.PCBID) FROM tbbarcode b WHERE" +
                             " (b.ArrayBarCode = '{0}' or b.BarCode = '{0}' ) AND b.LineNo='{1}') ORDER BY b.ArrayID";

        public struct StArrayBarcode
        {
            public string PcbId;//
            public string indexNo;//
            public string ArrayId;//pin板id
            public string ArrayBarcode;//pin板barcode
            public bool ReadResult;//读取状态
        }

        /* 
         * Author:Tony
         * CreateDate:2016-10-27
         * metodName:GetBarcode
         * parameter:  AsBarcode B面读到的某个barcode,AsPcbId 已生成的pcbid,AsLineNo 当前线体号，StArrayBarcode[] AstArrayBarcode 引用返回结果集
         * result:string 接口调用结果
         * 
         *  modified by peng 20180730     
         *  增加一个获取PCB倒排序  param:bArrayBarcodeIsFlashback if true: 倒序取最后一个PCB; else : 第一个PCB
         */
        public static String GetBarcode(string AsBarcode, string AsPcbId, string AsLineNo, ref StArrayBarcode[] AstArrayBarcode, bool bArrayBarcodeIsFlashback)
        {
            if (string.IsNullOrEmpty(AsBarcode) || string.IsNullOrEmpty(AsLineNo))
            {
                return CONST_PARAMETER_ERROR;
            }
            MySQLBean mySqlBean = new MySQLBean();
            string sQuerySql = string.Empty;
            if (bArrayBarcodeIsFlashback)
            {
                sQuerySql = string.Format(CONST_LASTBARCODE_QUERY_SQL, AsBarcode, AsLineNo);
            }
            else
            {
                sQuerySql = string.Format(CONST_BARCODE_QUERY_SQL, AsBarcode, AsLineNo);
            }
            DataTable dataTableResult = mySqlBean.GetDataTableFrSQL(sQuerySql);
            if (dataTableResult.Rows == null || dataTableResult.Rows.Count == 0)
            {
                return CONST_EMPTY_DATA_RESULT;
            }
            AstArrayBarcode = new StArrayBarcode[dataTableResult.Rows.Count];
            for (int i = 0; i < dataTableResult.Rows.Count; i++)
            {
                DataRow dataRow = dataTableResult.Rows[i];
                AstArrayBarcode[i].PcbId = dataRow[0].ToString();
                AstArrayBarcode[i].indexNo = dataRow[1].ToString();
                AstArrayBarcode[i].ArrayId = dataRow[2].ToString();
                Object barCodeObj = dataRow[3];
                if (barCodeObj == null || string.IsNullOrEmpty(barCodeObj.ToString()) || barCodeObj.ToString().Equals("NOREAD"))
                {
                    AstArrayBarcode[i].ReadResult = false;
                }
                else
                {
                    AstArrayBarcode[i].ArrayBarcode = barCodeObj.ToString();
                    AstArrayBarcode[i].ReadResult = true;
                }
            }
            return CONST_SUCCESS_RESULT;
        }



    }
}
