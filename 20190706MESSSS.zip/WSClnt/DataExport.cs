﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
  
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

using System.Management;
using System.IO.Compression;
using System.Diagnostics;
using InspectMainLib;
using AppLayerLib;
using ImgCSCoreIM;
namespace WSClnt
{
    public partial class DataExport
    {       
        private Basefunction _wsBaseF;
        private DataExportTony _deTony;
        private DataExportJoch _deJoch;
        private DataExportDP _deDP;
        private DataExportLin _deLin;

        private readonly string RS_ArrayIDForNOArray = "1";  // if no array, then array id use it.
        private readonly string RS_FileExt = ".*";
        private readonly string RS_SPLIT = ",";
        private readonly string RS_LineEnd = "\r\n";
        private readonly string RS_Space = "     ";
        private readonly string RS_SingleSpace = " ";
        private readonly string RS_EMPTY = "";
        private readonly string RS_UnderLine = "_";
        private readonly string RS_UnderLine3 = "___";
        private readonly string RS_MedianLine = "-";
        private readonly string RS_NOREAD = "NOREAD";
        private readonly string RS_NOREADNA = "N/A";
        private readonly string RS_ZERO = "0";
        private readonly string RS_PERC = "%";//Q.F.2017.04.21
        private readonly string RS_POUND = "#";
        private readonly string RS_FLOATFORMAT_1Bit = "0.0";
        private readonly string RS_FLOATFORMAT_3Bit = "0.000";
        private readonly string RS_FLOATFORMAT_4Bit = "0.0000";
        private readonly string RS_FLOATFORMAT_6Bit = "0.000000";
        private readonly string RS_BARCODELOGTEMPFILE = "BarcodeLog.Tmp";
        private readonly string RS_DATAEXPORTTEMPFILE = "DataExp.Tmp";
        private readonly string RS_DATAEXPORTTEMPFILEBM = "DataExpBM.Tmp";
        private readonly string RS_DATAEXPORTTEMPFILEDispenser = "DataExpDP.Tmp";
        private readonly string RS_DATAEXPORTTEMPFILEMount = "DataExpMNT.Tmp";
        private readonly string RS_DATAEXPORTMsg = "WSClnt_DataExport:  ";
        private readonly string RS_DATAEXPORTBadMarkMsg = "WSClnt_BadMark:  ";
        private readonly string RS_DATAEXPORTDispenserMsg = "WSClnt_Dispenser:  ";
        private readonly string RS_DATAEXPORTMountMsg = "WSClnt_Mount:  ";
        private readonly string RS_DATAEXPORTMonitorMsg = "WSClnt_Monitor:  ";
        private readonly string RS_DATAEXPORTPrinterMsg = "WSClnt_Printer:  ";
        private readonly string RS_DATAEXPORTBARCODELOGMsg = "WSClnt_BARCODELOG:  ";
        private readonly string RS_DATAEXPORTSystemLOGMsg = "WSClnt_SystemLOG:  ";
        private readonly string RS_TXT_EXT = ".txt";
        private readonly string RS_CSV_EXT = ".csv";
        private readonly string RS_XML_EXT = ".xml";//2016.11.26
        private readonly string RS_SRL_EXT = ".srl";//for NPM pcb info 
        private readonly string RS_RST_EXT = ".rst";//for NPM pcb info 
        private readonly string RS_FB_EXT = ".fb";//for NPM pcb info 
        private readonly string RS_CIR_EXT = ".cir";//for NPM pcb info 
        private string _strTmpFileDir = "D:\\EYSPI\\DataExport\\TmpDir";
        private string _strBadMarkSystemDir = "D:\\EYSPI\\DataExport\\BadMarkSystem";
        private float _fUM2MM = 0.001f;
        private float _fMM2UM = 1000f;
        private float _fZeroJudged = 0.001f;
        private string _strShareForAPCDir = "D:\\EYSPI\\DataExport\\ShareForAPC";


        //Q.F.2016.12.28
        private long _lPcbSerialNumberBySPILane1ForNPM = 0;// maximal 499999999
        private long _lPcbSerialNumberBySPILane2ForNPM = 0;// maximal 499999999
        private long _lPcbSerialNumberBySPIMaximalForNPM = 499999999;// maximal 499999999
        private long _lPcbSerialStartNumberBySPILane1ForNPM = 3000000000;// maximal 499999999
        private long _lPcbSerialStartNumberBySPILane2ForNPM = 3500000000;// maximal 499999999

        //Q.F.2017.06.13
        private string _strSPI2NXT = "SPI2NXTCMD_Idx{0}.txt";
        private string _strNXT2SPI = "NxtRes_Idx{0}.txt";

        //Q.F.2017.06.27
        private readonly string RS_POSTSCAN_DIR = "POSTSCAN";
        private readonly string RS_POSTSCAN_EXT = ".post";
        private readonly string RS_POSTSCAN_BARCODE = "POSTSCANBARCODE";
        private readonly string RS_POSTSCANFILE_EXT = ".file";
        private ImageProcessingCS.Basefunction _imgCSBaseF;
        protected int _iProcessorCount;
        public DataExport()
        {
            _wsBaseF = new Basefunction();
            if (!System.IO.Directory.Exists(_strTmpFileDir))
            {
                System.IO.Directory.CreateDirectory(_strTmpFileDir);
            }
            //Q.F.2016.12.28
            _wsBaseF.DirCheck(ref _strShareForAPCDir);
            String strDir = _strShareForAPCDir + "ShareForAPC_SPItoNPM";
            _wsBaseF.DirCheck(ref strDir);

            _deTony = new DataExportTony();
            _deJoch = new DataExportJoch();
            _imgCSBaseF = new ImageProcessingCS.Basefunction();
            _deDP = new DataExportDP();
            _deLin = new DataExportLin();
            _iProcessorCount = Environment.ProcessorCount;
            if (_iProcessorCount <= 0)
                _iProcessorCount = 1;
        }
        ~DataExport()
        {

        } 
      
       private bool BISFileNameNotDir( ref AppSettingData AappSettingData)
        {
            bool bEnable = false;
            if (AappSettingData.stDataExpVT.bEnExportUsingExternDLL == true)//Q.F.2019.04.1
            {
                switch (AappSettingData.csvFormat)
                {
                    case CSVFormat.ZDT:
                        {
                            //Q.F.2019.
                            if ((ENM_ZDTDaExportFormat)AappSettingData.stDataExpVT.byExportFormat == ENM_ZDTDaExportFormat.DLL
                                || (ENM_ZDTDaExportFormat)AappSettingData.stDataExpVT.byExportFormat == ENM_ZDTDaExportFormat.Default)
                            {
                                bEnable = true;
                            }
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
           

            return bEnable;
        }


        
        //interface with SPI UI
        [MethodImpl(MethodImplOptions.Synchronized)]
        public  string SaveDataExpFile(
            ref InspectMainLib.Pad[] APads,// record all pads info
            ref SPCBoardRes ABrdRes, // record the result of board pcb
            ref InspectMainLib.Marks AMarks,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting   
            InspectConfig.ConfigData AConfigData,
            AppMultiLan.AppLan Adict,  
            string AstrDir  //export folder           
            )
        {
            string jobName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
            String strPre = "Lane/JobName/Result " + (ABrdRes.LaneNo+ 1) + "/"
                                          + jobName + "/" + ABrdRes.jugResult.ToString() + ":"  ;
            string strMsg = RS_EMPTY;
            String strLog = RS_EMPTY;
            try
            {
                if (AappSettingData.stDataExpVT.aBDualLaneDisabled[ABrdRes.LaneNo] == true)
                {
                    strMsg += RS_DATAEXPORTMsg + "Close Lane:" + ABrdRes.LaneNo;
                    return strMsg;
                }
                //check dir
                if (BISFileNameNotDir(ref AappSettingData) == false)
                {
                    if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                    {
                        strMsg += RS_DATAEXPORTMsg + "No Folder!";
                        return strMsg;
                    }
                }
                //Q.F.2017.11.15
                if (AappSettingData.stDataExpVT.MaxSaveDays > 0)
                {
                    ImgCSCoreIM.StDeleteFileParam stParams = new ImgCSCoreIM.StDeleteFileParam();  
                    stParams.iMaxSaveDays  = AappSettingData.stDataExpVT.MaxSaveDays;
                    //stParams.iMaxSaveDays = 0 ;
                    if (stParams.sFileExtension == null)
                    {
                        stParams.sFileExtension = new List<string>();
                    }
                    stParams.sFileExtension.Add(ZhengZhouFoxconn.FileExtension);
                    //stParams.sFileExtension.Add(".jpg");

                    stParams.bDelDirectory = true;
                    stParams.iDelFileRecursiveLayer = 99;
                    stParams.sBaseDirectory = AstrDir;
                   // stParams.sBaseDirectory = "D:\\EYSPI\\DataExport\\Res\\Res1";
                    if (stParams.sSkipDirectory == null)
                    {
                        stParams.sSkipDirectory = new List<string>();
                    }
                    if (!String.IsNullOrEmpty(AappSettingData.stDataExpVT.strSaveFovImagePath))
                        stParams.sSkipDirectory.Add( AappSettingData.stDataExpVT.strSaveFovImagePath);

                    _wsBaseF.DeleteDataExportFile(stParams, out strLog);
                    if (String.IsNullOrEmpty(strLog) == false
                        && AappSettingData.enPadDebug == true)
                        _imgCSBaseF.LogRecord("DeleteFile",strLog,false);
                }
                strLog = String.Empty;
                switch (AappSettingData.csvFormat)
                {
                    case CSVFormat.JABIL:
                        {
                            strMsg += SaveDataExpFileJABIL(APads,
                                ABrdRes,
                                AappSettingData,
                                AstrDir  //export folder
                                );
                            break;
                        }
                    case CSVFormat.HanShineXml://Q.F.2016.11.14
                        {
                            ParmiXmlExport parmiXmlExp = new ParmiXmlExport();
                            strMsg += parmiXmlExp.SaveDataExport(APads,
                                ABrdRes,
                                AappSettingData,
                                AstrDir,  //export folder
                                "HanShineXml"
                                );
                            break;
                        }
                    case CSVFormat.HanShineTXT://Q.F.2016.11.25
                        {
                             
                            strMsg += _deTony.SaveDataExpFileHanShine(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "HanShineTXT"
                                );
                            break;
                        }
                    case CSVFormat.WuHanFoxconn://Q.F.2016.11.25
                        {
                            if(AappSettingData.stDataExpVT.bENCloseCurrentMES == false)
                            {
                                //strMsg += _deTony.SaveDataExpFileWuHanFoxconn(APads,
                                //                                ABrdRes,
                                //                                APcbGeneralInfo,
                                //                                AappSettingData,
                                //                                AstrDir,  //export folder
                                //                                "WuHanFoxconn"
                                //                                );
                                //Q.F.2019.01.07
                                strMsg += _deDP.SaveMESDataWuHanFox_Peng(APads,
                                                               ABrdRes,
                                                               APcbGeneralInfo,
                                                               AappSettingData,
                                                               AstrDir,  //export folder
                                                               "WuHanFoxconn"
                                                               );
                            }
                            else
                            {
                                strMsg += "Close Currrent MES";
                            }
                            break;


                        }
                    case CSVFormat.SzZechin://Q.F.2016.12.13
                        {
                             
                            strMsg += _deTony.SaveDataExpFileSzZechin(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "SzZechin",AMarks
                                );
                            break;
                        }
                    case CSVFormat.SunWoDa://Q.F.2017.04.07
                        {
                            if (AappSettingData.stDataExpVT.bEnSunWodaMES == false
                                || AappSettingData.stDataExpVT.aBDualLaneDisabled[ABrdRes.LaneNo] == true)//Q.F.2017.04.17
                                return "EnSunWodaMES  False, Lane:" + ABrdRes.LaneNo;
                            int iErrorInfo = 1;
                            strMsg += _deTony.SunWoDaWSUploadData(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AConfigData,
                                "SunWoDa",
                                out iErrorInfo,AMarks
                                );
                            if (iErrorInfo >= 4)
                                iErrorInfo = 3;
                            ABrdRes.stMesErrorInfo = (ImgCSCoreIM.MESErroInfo)iErrorInfo;
                            if (iErrorInfo == 0)
                            {
                                ABrdRes.stMesErrorInfo = ImgCSCoreIM.MESErroInfo.AlarmNotStop;
                            }
                            
                            break;
                        }
                    case CSVFormat.ZhengTai://Q.F.2017.04.22
                        {
                            if (AappSettingData.stDataExpVT.bEnSunWodaMES == false
                                || AappSettingData.stDataExpVT.aBDualLaneDisabled[ABrdRes.LaneNo] == true)//Q.F.2017.04.17
                                return "EnZhengTai  False";
                             
                            strMsg += _deTony.ChintWSWSUploadData(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "ZhengTai"
                                );
                            break;
                        }
                    //case CSVFormat.Zzfoxconn://Q.F.2017.04.07
                    //    {    
                    //        ImgCSCoreIM.StDeleteFileParam stParams = new ImgCSCoreIM.StDeleteFileParam();                            
                    //        stParams.iMaxSaveDays  = AappSettingData.stDataExpVT.MaxSaveDays;
                    //        stParams.sFileExtension = ZhengZhouFoxconn.FileExtension;
                    //        stParams.bDelDirectory = true;
                    //        stParams.iDelFileRecursiveLayer = 99;
                    //        stParams.sBaseDirectory = AstrDir;
                    //        stParams.sSkipDirectory = AappSettingData.stDataExpVT.strSaveFovImagePath;
                    //        strMsg += _deTony.SaveDataExpFileZzFoxconn(APads,
                    //            ABrdRes,
                    //            APcbGeneralInfo,
                    //            AappSettingData,
                    //            AstrDir,  //export folder
                    //            "ZzFoxconn",
                    //            stParams
                    //            );
                    //        break;
                    //    }
                    case CSVFormat.LongHuaFoxconn://Q.F.2017.04.21
                        {
                             
                            strMsg += _deTony.SaveDataExpFileLonghuaFoxconn(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "LongHuaFoxconn"
                                );
                            break;
                        }
                    case CSVFormat.XiSheng://Q.F.2017.04.21
                        {
                             
                            strMsg += _deTony.SaveDataExpFileCQXiSheng(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "XiSheng"
                                );
                            break;
                        }
                    case CSVFormat.APAITEK://Q.F.2017.05.31
                        {

                            strMsg += SaveDataExpFileAPAITEK(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "APAITEK"
                                );
                            break;
                        }
                    case CSVFormat.HIPAD://Q.F.2017.05.31
                        {

                            strMsg += _deTony.SaveDataExpFileJXHiPAD(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                "HIPAD"
                                );
                            break;
                        }
                    case CSVFormat.KuiChongHOLITECH://Q.F.2017.06.07
                        {

                            strMsg += _deTony.SaveDataExpFileKCHoliTech(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder                               
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }    
                    case CSVFormat.FEIGE://Q.F.2017.05.31
                        {
                            if (AappSettingData.stDataExpVT.bEnSunWodaMES == false
                               || AappSettingData.stDataExpVT.aBDualLaneDisabled[ABrdRes.LaneNo] == true)//Q.F.2017.04.17
                                return "EnFEIGE  False";

                            strMsg += _deTony.SaveDataExpFileFeiGe(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder
                                (byte)ABrdRes.LaneNo,
                               AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.PinRun://Q.F.2017.05.31
                        {                           

                            strMsg += _deJoch.SaveBarcodeForPINRUN(APads,
                                ABrdRes,                                 
                                APcbGeneralInfo,
                                AappSettingData,
                                Adict,
                                AstrDir,  //export folder                               
                                (byte)ABrdRes.LaneNo,
                               AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.JIETUO://Q.F.2017.05.31
                        {

                            strMsg += _deJoch.SaveBarcodeForJIETUO(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                Adict,
                                AstrDir,  //export folder                               
                                (byte)ABrdRes.LaneNo,
                               AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.SWTrulysEmi:
                        {                           

                            strMsg += _deTony.SaveDataExpFileSWTrulysEmi(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,  //export folder                              
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.SuZhouMFlex:
                        {

                            //strMsg += _deJoch.MESSaveResultInspectionStationForWEIXIN(APads,
                            //    ABrdRes,
                            //    APcbGeneralInfo,
                            //    AappSettingData,
                            //    Adict,
                            //    AstrDir,  //export folder                              
                            //    AappSettingData.csvFormat.ToString()
                            //    );
                            strMsg += _deDP.MESSaveResultForWEIXIN(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                Adict,
                                ABrdRes.pcbBarcode,
                                null,
                                ABrdRes.jobName,
                                AstrDir,  //export folder                              
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.HUIZHOUBYD2F:
                        {
                        //    strMsg += _deDP.SaveDataExpFileCSVHUIZHOUBluewayPe(
                        //       APads,
                        //       ABrdRes,
                        //       APcbGeneralInfo,
                        //       AappSettingData,
                        //       AConfigData,
                        //       AstrDir,
                        //       (byte)ABrdRes.LaneNo,
                        //       Adict
                        //      );
                        //    break;//Q.F.2018.05.23 for testing
                            //strMsg += _deJoch.SaveDataFileForBYDSecond(APads,
                            strMsg += _deDP.SaveDataFileForBYDSecond2(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                             
                                AstrDir,  //export folder                              
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.SZXinKen:
                        {
                            bool bNotHuaQIn = AappSettingData.debugPadIDList[0] == -5000? false: true;
                            if (bNotHuaQIn)
                            {
                                strMsg += _deJoch.SaveDataFileForSZXINKEN(APads,
                                   ABrdRes,
                                   APcbGeneralInfo,
                                   AappSettingData,
                                   Adict,
                                   AstrDir,  //export folder                              
                                   AappSettingData.csvFormat.ToString()
                                   );
                            }
                            else
                            {

                                strMsg += _deDP.SaveMesDataForXinKen(
                                    APads,
                                    ABrdRes,
                                    APcbGeneralInfo,
                                    AappSettingData,
                                    AConfigData,
                                    AstrDir
                                    );
                            }
                            break;
                        }
                    case CSVFormat.KSYuanSong:
                        {
                            
                            strMsg += _deJoch.MESSaveResultForYuanSong(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                               
                                AstrDir,  //export folder                              
                                AappSettingData.csvFormat.ToString(),
                                out strLog
                                );
                            break;
                        }
                    case CSVFormat.Punda://joch 2017.09.06
                        {

                            //strMsg += _deJoch.SaveBarcodeForPunda(APads,
                            //    ABrdRes,
                            //    APcbGeneralInfo,
                            //    AappSettingData,
                            //    Adict,
                            //    AstrDir,  //export folder            
                            //     (byte)ABrdRes.LaneNo,
                            //     AappSettingData.stDataExpVT.EMFileExtType,//Q.F.2017.11.08
                            //    AappSettingData.csvFormat.ToString()
                            //    );
                            break;
                        }
                    case CSVFormat.Punda_1FTY://joch 2017.09.06
                        {

                            strMsg += _deDP.SaveMesLogFileForPNDA_SHENZHEN(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                                
                                AstrDir,  //export folder           
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.KSCompal://joch 2017.09.06
                        {
                            if(AappSettingData.stDataExpVT.bENExportXML)
                            {
                                strMsg += _deJoch.MESSaveXMLFileForCompal(APads,
                                                                ABrdRes,
                                                                APcbGeneralInfo,
                                                                AappSettingData,
                                                                Adict,
                                                                AConfigData,
                                                                "",
                                                                AstrDir,  //export folder            
                                    // (byte)ABrdRes.LaneNo,
                                                                AappSettingData.csvFormat.ToString(),
                                                                out strLog
                                                                );
                            }
                            if (AappSettingData.stDataExpVT.bENExportCSV)
                            {
                                strMsg += _deDP.SaveDataForRenBao(APads,
                                                                ABrdRes,
                                                                APcbGeneralInfo,
                                                                AappSettingData,                                                              
                                                                AstrDir,  //export folder           
                                   
                                                                AappSettingData.csvFormat.ToString()
                                                             
                                                                );
                            }
                            break;
                        }
                    case CSVFormat.Techco3D://joch 2017.09.06
                        {

                            strMsg += _deJoch.SaveDataFileFor3DTechco(APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                            
                                AstrDir,  //export folder            
                                // (byte)ABrdRes.LaneNo,
                                AappSettingData.csvFormat.ToString(),
                                out strLog
                                );
                            break;
                        }
                    case CSVFormat.Sotrun://joch 2017.09.06
                        {
                            String strAsWLID = AappSettingData.stDataExpVT.strMachine;
                            String strAsWPID = AappSettingData.stDataExpVT.strProductID;
                            String strAsOpSide = AappSettingData.stDataExpVT.strOpSide;
                            String strAsOpID = AappSettingData.strDataExpOperator;

                            strMsg += _deJoch.MESSaveResultForSotrun(strAsWLID, strAsWPID, strAsOpSide, strAsOpID,
                                            APads,
                                            ABrdRes,
                                            APcbGeneralInfo,
                                            AappSettingData,
                                            AstrDir,  //export folder  
                                            AappSettingData.csvFormat.ToString()
                                            );
                           
                            break;
                        }
                    case CSVFormat.Zzfoxconn://joch 2017.09.06
                        {
                            //if (AappSettingData.stDataExpVT.bENCloseCurrentMES == false)
                            //{
                            //    strMsg += _deJoch.SaveDataFileForZZFoxConn(APads,
                            //                                    ABrdRes,
                            //                                    APcbGeneralInfo,
                            //                                    AappSettingData,
                            //                                    AstrDir,  //export folder            
                            //        // (byte)ABrdRes.LaneNo,
                            //                                    AappSettingData.csvFormat.ToString(),
                            //                                    out strLog
                            //                                    );
                            //    //Q.F.2018.03.02
                            //    if (ABrdRes.jugResult == JudgeRes.NG
                            //        && AappSettingData.stDataExpVT.bEnExportNGInfo)
                            //    {
                            //        strMsg += _deDP.SaveDataFileForLONGHUAFOX(
                            //            APads,
                            //        ABrdRes,
                            //        APcbGeneralInfo,
                            //        AappSettingData,
                            //        AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                            //    }
                            //}
                            //else
                            {
                                strMsg += _deJoch.SaveDataFileForZZFoxConn(APads,
                                                               ABrdRes,
                                                               APcbGeneralInfo,
                                                               AappSettingData,
                                                               AstrDir,  //export folder            
                                    // (byte)ABrdRes.LaneNo,
                                                               AappSettingData.csvFormat.ToString(),
                                                               out strLog
                                                               );
                            }
                           

                            break;
                        }
                    case CSVFormat.Szmtc://joch 2017.09.06
                        {

                            if (ABrdRes.LaneNo == 0)
                            {
                                strMsg += _deJoch.MESSaveDataFileForSZMTCLane1(APads,
                                    ABrdRes,
                                    APcbGeneralInfo,
                                    AappSettingData,
                                    Adict,          
                                    AConfigData,
                                    _strTmpFileDir,
                                    AstrDir,  //export folder   
                                    AappSettingData.csvFormat.ToString()
                                    );
                            }
                            else
                            {
                                strMsg += _deJoch.MESSaveDataFileForSZMTCLane2(APads,
                                   ABrdRes,
                                   APcbGeneralInfo,
                                   AappSettingData,
                                   Adict,
                                      AConfigData,
                                   _strTmpFileDir,
                                   AstrDir,  //export folder   
                                  AappSettingData.csvFormat.ToString()
                                   );
                            }
                            break;
                        }
                    case CSVFormat.HuaYi://Peng 2017.11.30
                        {
                            strMsg += _deDP.CheckMobileDataDa(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AappSettingData.csvFormat.ToString()
                                );
                          
                            break;
                        }
                    case CSVFormat.BYDBaoLong://Peng 2017.11.30
                        {
                            if (ABrdRes.LaneNo == 0)
                            {
                                strMsg += _deDP.ExDataFileForBYDLane1(
                                    APads,
                                    ABrdRes,
                                    APcbGeneralInfo,
                                    AappSettingData,                                
                                    _strTmpFileDir,
                                    AstrDir,  //export folder   
                                    AappSettingData.csvFormat.ToString()
                                    );
                            }
                            else
                            {
                                strMsg += _deDP.ExDataFileForBYDLane2(
                                   APads,
                                    ABrdRes,
                                    APcbGeneralInfo,
                                    AappSettingData,
                                    _strTmpFileDir,
                                    AstrDir,  //export folder   
                                    AappSettingData.csvFormat.ToString()
                                   );
                            }
                            break;
                        }
                    case CSVFormat.JuFei://Peng 2017.11.30
                        {
                            //switch ((ENM_JuFeiExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                            //{
                            //    case ENM_JuFeiExportFormat.JF_FactoryOnePc:
                            //        {
                            //            if (ABrdRes.LaneNo == 0)
                            //            {
                            //                strMsg += _deDP.ExDataFileForJUFEILane1(
                            //                    APads,
                            //                    ABrdRes,
                            //                    APcbGeneralInfo,
                            //                    AappSettingData,
                            //                    _strTmpFileDir,
                            //                    AstrDir
                            //                    );
                            //            }
                            //            else
                            //            {
                            //                strMsg += _deDP.ExDataFileForJUFEILane2(
                            //                   APads,
                            //                    ABrdRes,
                            //                    APcbGeneralInfo,
                            //                    AappSettingData,
                            //                    _strTmpFileDir,
                            //                    AstrDir  //export folder                                       
                            //                   );
                            //            }
                            //            break;
                            //        }
                            //    case ENM_JuFeiExportFormat.JF_FactoryTwoPc:
                            //        {
                            //            _deDP.ExDataFileForJF(APads,
                            //                ABrdRes,
                            //                APcbGeneralInfo,
                            //                AappSettingData,
                            //                AstrDir,
                            //                AappSettingData.csvFormat.ToString());
                            //            break;
                            //        }
                            //    default :
                            //        break;
                            //}
                            _deDP.ExDataFileForJF(APads,
                                            ABrdRes,
                                            APcbGeneralInfo,
                                            AappSettingData,
                                            AstrDir,
                                            AappSettingData.csvFormat.ToString());
                            break;
                        }
                    case CSVFormat.PangusCTK://Peng 2017.11.30
                        {
                            strMsg += _deDP.SaveExDataForCTK(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                              
                                  _strTmpFileDir,
                                    AstrDir  //export folder  
                                );

                            break;
                        }
                    case CSVFormat.OPPO://Peng 2017.11.30
                        {
                            strMsg += _deDP.ExDataForOPPO(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                                 
                                    AstrDir  //export folder  
                                );

                            break;
                        }
                    case CSVFormat.XINLISecond://Peng 2017.11.30
                        {
                            strMsg += _deDP.ExDataFileForXINLI(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                _strTmpFileDir,
                                AstrDir                              
                                );

                            break;
                        }
                    case CSVFormat.HuntKey://Peng 2017.01.15
                        {
                            strMsg += _deDP.SaveXMLFileForHANGJIA(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                               
                                AstrDir                              
                                );

                            break;
                        }
                    case CSVFormat.ATUE://Peng 2017.01.15
                        {
                            strMsg += _deDP.SaveDataForJZLH_ZHEJIANG(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.MEKTEC://Peng 2017.01.15
                        {
                            strMsg += _deDP.SaveDataForZIXIANG_SUZHOU(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );
                            strMsg += _deDP.SaveMesBadMarkInfoForZIXIANG_SUZHOU(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                               
                                AappSettingData.csvFormat.ToString(),
                                Adict
                                );
                            break;
                        }
                    case CSVFormat.WeiErManA://Peng 2018.02.09
                        {
                            switch ((ENM_WeiErManAExportFormat)AappSettingData.stDataExpVT.byWeiErManACustomer)
                            {
                                case ENM_WeiErManAExportFormat.ZHIDING:
                                    {
                                        strMsg += _deDP.SaveDataFileForZHIDING(
                                                               APads,
                                                               ABrdRes,
                                                               APcbGeneralInfo,
                                                               AappSettingData,
                                                               AConfigData,
                                                               AstrDir
                                                               );
                                        break;
                                    }
                                case ENM_WeiErManAExportFormat.AFNUO:
                                    {
                                        strMsg += _deDP.SaveDataFileForAFNUO(
                                                               APads,
                                                               ABrdRes,
                                                               APcbGeneralInfo,
                                                               AappSettingData,
                                                               AConfigData,
                                                               AstrDir
                                                               );
                                        break;
                                    }
                                default:
                                    {
                                        strMsg += _deDP.SaveDataFileForXINTAI(
                                                               APads,
                                                               ABrdRes,
                                                               APcbGeneralInfo,
                                                               AappSettingData,
                                                               AConfigData,
                                                               AstrDir
                                                               );
                                        break;
                                    } 
                            }
                           
                            break;
                        }
                    case CSVFormat.CHENGDA://Peng 2018.02.09
                        {
                            //strMsg += _deDP.UploadDataForCHENDA(
                            //    APads,
                            //    ABrdRes,
                            //    APcbGeneralInfo,
                            //    AappSettingData                              
                            //    );
                            strMsg += _deLin.SaveDataExport_ChenDa(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );
                            break;
                        }
                    case CSVFormat.PEIYING://Peng 2018.02.09
                        {
                            strMsg += _deDP.UpdUnitRecordForPEIYING(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData
                                );

                            break;
                        }
                    case CSVFormat.HUIZHOUBYD://Peng 2018.03.07
                    case CSVFormat.HUIZHOUBYD1://Peng 2018.03.07
                        {
                            //strMsg += _deDP.SaveDataExpFileCSVHUIZHOUBluewayPe(
                            //   APads,
                            //   ABrdRes,
                            //   APcbGeneralInfo,
                            //   AappSettingData,
                            //   AConfigData,
                            //   AstrDir,
                            //   (byte)ABrdRes.LaneNo,
                            //   Adict
                            //  );
                            //break;//q.F.2018.05.23 for testing
                            strMsg += _deDP.SaveDataFileCSVHUIZHOUBYD2DC6NEWLINEtmp(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AConfigData,
                                AstrDir,
                                Adict

                                );

                            break;
                        }
                    case CSVFormat.Intretech://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForYINQU2(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                              
                                AstrDir                             
                                );

                            break;
                        }
                    case CSVFormat.HuMenKanYuan://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForYINQU(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir
                                );

                            break;
                        }
                    case CSVFormat.BOSCH_SUZHOU://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForBOSCH(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir
                                );

                            break;
                        }
                    case CSVFormat.FuShiKangAXLS://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForLHFoxconnD9(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.KSLiXun://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveExForLiXun(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.QingXi://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveExForQingXi(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                CSVFormat.FuShiKangAXLS.ToString()
                                );

                            break;
                        }
                    case CSVFormat.USISH://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForHXDZ(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );
                            //Q.F.2018.11.07
                            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strBackUpExportedFilePath) == false)
                            {
                                strMsg += _deDP.SaveDataExeclForHXDZ(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AappSettingData.stDataExpVT.strBackUpExportedFilePath,
                                AappSettingData.csvFormat.ToString()
                                );
                            }
                            break;
                        }
                    case CSVFormat.DongSuo://Peng 2018.03.07
                        {
                            //log
                            strMsg += _deDP.SaveExportForDongShuo(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                               AappSettingData.csvFormat.ToString()
                                );
                            //throw to server
                            if (AappSettingData.stDataExpVT.bEnExportUsingExternDLL == true)
                            {
                                strMsg += _deDP.SaveDataResultToMesForDongShuo(
                                                                ABrdRes,
                                                                APcbGeneralInfo,
                                                                AappSettingData
                                                                );
                            }
                            break;
                        }
                    case CSVFormat.ZDT://Q.F.2016.11.25
                        {
                           // if (AappSettingData.stDataExpVT.bEnExportUsingExternDLL == true)
                            {
                                if ((ImgCSCoreIM.Em_MonitorLogType)
                                                                AappSettingData.stMonitorSystemParams.byLogFormat == ImgCSCoreIM.Em_MonitorLogType.ZDFoxconn_QHD)
                                {
                                    strMsg += _deTony.SendDataZhenDingQHDBDBoard(APads,
                                       ABrdRes,
                                       APcbGeneralInfo,
                                       AappSettingData,
                                       AstrDir,  //export folder
                                       AappSettingData.csvFormat.ToString()
                                       );
                                }
                                else
                                {

                                    strMsg += _deTony.SendDataZhenDingBDBoard(APads,
                                        ABrdRes,
                                        APcbGeneralInfo,
                                        AappSettingData,
                                        AstrDir,  //export folder
                                        AappSettingData.csvFormat.ToString()
                                        );
                                }
                                if (
                                    !(String.IsNullOrEmpty(strMsg)
                                    || String.Equals(strMsg.ToLower().Trim(), "true"))
                                    )
                                {
                                    string sCompanyID = AappSettingData.stDataExpVT.strCustomer;
                                    string sDeviceTypeID = AappSettingData.stDataExpVT.strTestType;
                                    string sEquipID = AappSettingData.stDataExpVT.strMachine;
                                    string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;

                                    strMsg += "\r\n公司名:" + sCompanyID + ";\r\n设备类型:" + sDeviceTypeID + ";\r\n设备ID:" + sEquipID + ";\r\nsDllPath:" + sDllPath;
                                    strMsg = "ZDT DLL 导出错误:\r\n" + strMsg;

                                }
                            }
                            //int iFtpIndex = 0;
                            //if (AappSettingData.stFTPSystemZDT.aBEnFtpConnecton != null
                            //    && AappSettingData.stFTPSystemZDT.aBEnFtpConnecton[iFtpIndex] == false
                            //    && (ENM_ZDTDaExportFormat)AappSettingData.stDataExpVT.byExportFormat == ENM_ZDTDaExportFormat.DLL)
                            //{
                            //    if ((ImgCSCoreIM.Em_MonitorLogType)
                            //                                    AappSettingData.stMonitorSystemParams.byLogFormat == ImgCSCoreIM.Em_MonitorLogType.ZDFoxconn_QHD)
                            //    {
                            //        //strMsg += _deTony.SendDataZhenDingQHDBDBoard(APads,
                            //        //   ABrdRes,
                            //        //   APcbGeneralInfo,
                            //        //   AappSettingData,
                            //        //   AstrDir,  //export folder
                            //        //   AappSettingData.csvFormat.ToString()
                            //        //   );
                            //    }
                            //    else
                            //    {

                            //        //strMsg += _deTony.SendDataZhenDingBDBoard(APads,
                            //        //    ABrdRes,
                            //        //    APcbGeneralInfo,
                            //        //    AappSettingData,
                            //        //    AstrDir,  //export folder
                            //        //    AappSettingData.csvFormat.ToString()
                            //        //    );
                            //    }
                            //}

                            break;


                        }
                    case CSVFormat.Foxconn_ChengDu://Q.F.2018.03.26
                        {

                            strMsg += _deDP.SaveEXFileForCDFOX(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                               AstrDir,
                               AappSettingData.csvFormat.ToString()
                               );

                            break;


                        }
                    case CSVFormat.BOE_HeFei://Q.F.2018.03.26
                        {
                            //switch((ImgCSCoreIM.EM_BOEFormat)AappSettingData.stDataExpVT.byExportFormat)
                            //{
                            //    case
                            strMsg += _deDP.SaveFileForHefeiJdf(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                               AConfigData,
                               AstrDir,
                               AappSettingData.csvFormat.ToString()
                               );

                            break;
                       // }

                        }
                    case CSVFormat.Foxconn_LHShunSin://Q.F.2018.03.26
                        {

                            strMsg += _deDP.SaveExFileForLHFoxH3(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                               Adict,
                               AstrDir,
                               AappSettingData.csvFormat.ToString()
                               );

                            break;


                        }
                    case CSVFormat.LITEON_DGChangAn://Q.F.2018.03.26
                        {
                            switch ((ENM_LITEONExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                            {
                                case ENM_LITEONExportFormat.DGChangAn_2:
                                    {
                                        if (AappSettingData.enPadDebug)
                                        {
                                            _deDP.SaveLogsYouJiaInfo("LITEON_DGChangAn start =>", (ABrdRes.LaneNo+1) + "");
                                        }
                                        strMsg += _deDP.UploadResultForGuangBao(
                                           APads,
                                           ABrdRes,
                                           APcbGeneralInfo,
                                           AappSettingData                                       
                                           );
                                        break;
                                    }
                                case ENM_LITEONExportFormat.DGChangAn:
                                    {
                                        strMsg += _deDP.SaveDataForGuangBao(
                                            APads,
                                            ABrdRes,
                                            APcbGeneralInfo,
                                            AappSettingData,
                                            AstrDir,
                                            AappSettingData.csvFormat.ToString()
                                            );
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }
                            }
                           

                            break;


                        }
                    case CSVFormat.YouJia_SuZhou://Q.F.2018.03.26
                        {

                            strMsg += _deDP.uploadDataForYouJia(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                               AstrDir
                               );

                            break;


                        }
                    case CSVFormat.HUIZHOUBlueway://Q.F.2018.03.26
                        {

                            strMsg += _deDP.SaveDataExpFileCSVHUIZHOUBluewayPe(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                               AConfigData,
                               AstrDir,
                                (byte)ABrdRes.LaneNo,
                               Adict,
                              AMarks
                              );

                            break;


                        }//SaveFileForDefaultTools
                    case CSVFormat.DefaultTools://Q.F.2018.03.26
                        {

                            strMsg += _deDP.SaveFileForDefaultTools(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,
                              
                               AstrDir,
                               AappSettingData.csvFormat.ToString()
                              );

                            break;


                        }//SaveFileForDefaultTools
                    case CSVFormat.Foxconn_GuiYang://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForGYFox(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.CYC_YUANCHANG://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForYuanCang(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.HOLITECH_JIANGXI://Peng 2018.03.07
                        {
                            if ((ENM_HOLITECH_Factory)AappSettingData.stDataExpVT.byExportFormat == ENM_HOLITECH_Factory.JiangXi)
                            {
                                strMsg += _deDP.SaveDataFileForHeLiTai(
                                                                APads,
                                                                ABrdRes,
                                                                APcbGeneralInfo,
                                                                AappSettingData,
                                                                AstrDir,
                                                                AappSettingData.csvFormat.ToString()
                                                                );
                            }
                            else if ((ENM_HOLITECH_Factory)AappSettingData.stDataExpVT.byExportFormat == ENM_HOLITECH_Factory.XinFeng)
                            {
                                strMsg += _deDP.SaveDataForXINFENGBYD(
                                                                APads,
                                                                ABrdRes,
                                                                APcbGeneralInfo,
                                                                AappSettingData,
                                                                AstrDir,
                                                                AappSettingData.csvFormat.ToString()
                                                                );
                            }
                            break;
                        }
                    case CSVFormat.BMTC://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataForZHAOCHI(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.BMTC_SamSung://Peng 2018.03.07
                        {
                            strMsg += _deDP.SaveDataExForZHAOCHISamsung(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                ABrdRes.strJobDividedDefaultPath,//Q.F.2019.07.11
                                //AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.LEINENG://Peng 2018.03.07
                        {
                            strMsg += _deDP.CheckBarcodeForLEINENG(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                //AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );
                            //strMsg +=  _deDP.SaveDataDefaultExport(
                            //   APads,
                            //   ABrdRes,
                            //   APcbGeneralInfo,
                            //   AappSettingData,
                            //   AstrDir,
                            //   AappSettingData.csvFormat.ToString()
                            //   );
                            break;
                        }
                    case CSVFormat.LINGQIDZ://Peng 2018.08.09
                        {
                            strMsg += _deDP.SaveDataExForLingqidz(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AConfigData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                            //strMsg += SaveMountSystemFileForNPM(
                            //       APads,
                            //       ABrdRes,
                            //       AappSettingData,
                            //       APcbGeneralInfo,
                            //       Adict,
                            //       (byte)ABrdRes.LaneNo,
                            //       false,
                            //       "NPM"
                            //       );
                            //break;
                        }
                    case CSVFormat.SZHengHai://Peng 2018.08.09
                        {
                            strMsg += _deDP.SaveDataForHENGHAI(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                               
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.TenBao_HZ://Peng 2018.08.09
                        {
                            strMsg += _deDP.SaveDataExForHZTB_ShenZhen(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.CHUNQIU://Peng 2019.01.23
                        {
                            strMsg += _deDP.SaveDataForChunQiu_SUZHOU(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.Coslight_ZH:
                        {
                            strMsg += _deDP.SaveDataForCoslight_ZH(
                                                            APads,
                                                            ABrdRes,
                                                            APcbGeneralInfo,
                                                            AappSettingData,
                                                            AstrDir,
                                                            AappSettingData.csvFormat.ToString()
                                                            );

                            break;
                        }
                    case CSVFormat.TengJie:  // add by peng 20190305
                            {
                                strMsg += _deDP.SaveDataForXMTJ(
                                                            APads,
                                                            ABrdRes,
                                                            APcbGeneralInfo,
                                                            AappSettingData,
                                                            AConfigData,
                                                            AstrDir,
                                                            AappSettingData.csvFormat.ToString()
                                                            );

                                break;
                            }
                    case CSVFormat.NVENTEC_ChongQin://Peng 2019.01.23
                        {
                            strMsg += _deDP.SaveDataForINVENTEC_ChongQin(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.csvFormat.ToString()
                                );

                            break;
                        }
                    case CSVFormat.HuaQin://Peng 2019.01.23
                        {
                            switch ((EM_HUAQINFormat)AappSettingData.stDataExpVT.byExportFormat)
                            {
                                case EM_HUAQINFormat.dongGuan:
                                    {
                                        strMsg += _deDP.SaveMesDataForXinKen(
                                            APads,
                                            ABrdRes,
                                            APcbGeneralInfo,
                                            AappSettingData,
                                            AConfigData,
                                            AstrDir
                                            );
                                        break;
                                    }
                                case EM_HUAQINFormat.nanChang:
                                    {
                                        strMsg += _deDP.UpLoadDataForHuaQinByNanChang(
                                            APads,
                                            ABrdRes,
                                            APcbGeneralInfo,
                                            AappSettingData,
                                            AstrDir
                                            );
                                        break;
                                    }
                            }
                            break;
                        }
                    case CSVFormat.HuaBei://Peng 2019.01.23
                        {
                            strMsg += _deDP.SaveExDataForHuaBei(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir
                                );

                            break;
                        }
                    case CSVFormat.DALiangDZ://Peng 2019.01.23
                        {
                            //strMsg += _deDP.SaveMesExForDaLiang(
                            //    APads,
                            //    ABrdRes,
                            //    APcbGeneralInfo,
                            //    AappSettingData,

                            //    AstrDir
                            //    );
                            //SaveMesXINLENSES_XIAMEN
                            strMsg += _deDP.SaveMesXINLENSES_XIAMEN(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir, AConfigData
                                );
                            break;
                        }
                    case CSVFormat.SzLianHeShengXin://Peng 2019.01.23
                        {
                            strMsg += _deDP.SaveMesDataForLianHeShengXin(                              
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir
                               
                                );

                            break;
                        }
                    case CSVFormat.BRIO://Peng 2019.01.23
                        {
                            strMsg += _deDP.SaveDataForBRIO(
                                 APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,                              
                                AstrDir    

                                );

                            break;
                        }
                    case CSVFormat.Hittech_SZ://Peng 2018.08.09
                        {
                            switch ((ENM_HittechExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                            {
                                case ENM_HittechExportFormat.QC:
                                    {
                                        if (AappSettingData.stDataExpVT.bENCloseCurrentMES == false)
                                        {
                                            strMsg += _deDP.SaveExportForHeErTai(
                                                                            APads,
                                                                            ABrdRes,
                                                                            APcbGeneralInfo,
                                                                            AappSettingData,
                                                                            AstrDir,
                                                                            AappSettingData.csvFormat.ToString()
                                                                            );
                                        }
                                        break;
                                    }
                                case ENM_HittechExportFormat.Production:
                                    {
                                        if (AappSettingData.stDataExpVT.bENCloseCurrentMES == false)
                                        {
                                            strMsg += _deDP.SaveDataExForHeErTai(
                                                                            APads,
                                                                            ABrdRes,
                                                                            APcbGeneralInfo,
                                                                            AappSettingData,
                                                                            AstrDir,
                                                                            AappSettingData.csvFormat.ToString()
                                                                            );
                                        }
                                        if (AappSettingData.stDataExpVT.bEnSecondMES == true)
                                        {
                                            strMsg += _deDP.SaveDataExHeErTaiNew(
                                                                            APads,
                                                                            ABrdRes,
                                                                            APcbGeneralInfo,
                                                                            AappSettingData,
                                                                            AConfigData,
                                                                            AappSettingData.stDataExpVT.strSecondMESPath,
                                                                            AappSettingData.csvFormat.ToString()
                                                                            );
                                        }
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }
                            }
                        
                            break;
                        }

                    default:
                        {
                            strMsg += _deDP.SaveDataDefaultExport(
                               APads,
                               ABrdRes,
                               APcbGeneralInfo,
                               AappSettingData,                              
                               AstrDir,                             
                               AappSettingData.csvFormat.ToString()
                               );
                            break;
                        }
                        
                }
                if (String.IsNullOrEmpty(strMsg)
                    || String.Equals(strMsg.ToLower().Trim(), "true"))//Q.F.2017.04.06
                {
                    strMsg = strPre + RS_DATAEXPORTMsg + "Success!";

                    ABrdRes.strDataExportErrMsg = RS_EMPTY;
                }
                else
                {
                    ABrdRes.strDataExportErrMsg = strPre +"\n"+ strMsg;
                }
                if (AappSettingData.debugPadIDList[0] == -1002)
                {
                    ABrdRes.strDataExportErrMsg = RS_EMPTY;
                }
                if (AappSettingData.debugPadIDList[0] == -5001)
                {
                    Stopwatch stop = new Stopwatch();
                    stop.Reset();
                    stop.Start();
                 
                    strMsg += "PCBID:" + ABrdRes.pcbID + "TransPCBINfoToCSV:";
                    DataExportLin de = new DataExportLin();
                    //List<ST_SPC_CSV_SavePadImgPara> lstPadID = new List<ST_SPC_CSV_SavePadImgPara>();
                    ST_SPC_CSV_SavePara stSavePara = new ST_SPC_CSV_SavePara();
                    string strFolder = string.Empty;
                    strMsg += "SaveDataExport_CSV:" + de.SaveDataExport_CSV(APads, ABrdRes, APcbGeneralInfo, AappSettingData, AConfigData, ref stSavePara);
                    Pad[] padTemp = APads;
                    ((Action)delegate
                    {
                        DataExportDP _dePeng = new DataExportDP();
                        //ST_SPC_CSVParam csvParam = _dePeng.SaveSPCINI(ref AappSettingData, AConfigData);
                      //  _dePeng.SavePadImage(padTemp, stSavePara, AappSettingData, stSavePara.stCSVParam, 12);
                    }).BeginInvoke(null, null);

                    strMsg += "TransToCSV_tbPadMeasure_CR:" + de.TransToCSV_tbPadMeasure_CR(ref APads, ref ABrdRes,APcbGeneralInfo, AappSettingData, AConfigData);
                    strMsg += " Time:" + stop.ElapsedMilliseconds.ToString();
                }
            }
            catch (System.Exception ex)
            {
               
                //record the error message to ui log file
                strMsg = strPre + ABrdRes.LaneNo + ":" + RS_DATAEXPORTMsg + ex.ToString();

                ABrdRes.strDataExportErrMsg = strMsg;
            }
            if (String.IsNullOrEmpty(strLog) == false)
            {
                _imgCSBaseF.LogRecord(AappSettingData.csvFormat.ToString(),strLog, false);
            }
            return strMsg;          
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public string SaveBadMarkSystemFile(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting       
            InspectConfig.ConfigData AconfigData, // ui setting   
            AppMultiLan.AppLan Adict,
            string AstrDir,  //export folder         
            byte AbyLaneNo, //1,2
            ImgCSCoreIM.WebServiceCmd Acmd
            )
        {     
            string strMsg = RS_EMPTY;
            try
            {
                //check dir
                if (!String.IsNullOrEmpty(AstrDir))
                {
                    if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                    {
                        strMsg += RS_DATAEXPORTBadMarkMsg + "No Folder!";
                        return strMsg;
                    }
                }
                //Q.F.2017.09.15
                if (AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bENClearExportFolder == true)
                {
                    _wsBaseF.CheckAndDeleteDir(ref AstrDir, RS_XML_EXT);
                }
                switch (AappSettingData.bmFormat)
                {
                    case BMFormat.Panasonic:
                        {
                            //if export file per global mark
                            strMsg += _deDP.GenGroupBadMarkInfomationFileForSongXiaCm(APads,
                               ABrdRes,
                                APcbGeneralInfo,
                               AappSettingData,
                               Adict,
                               AstrDir,  //export folder   
                               AappSettingData.bmFormat.ToString()
                               );
                            break;
                        }
                    case BMFormat.JUKI:
                        {
                            strMsg += SaveBadMarkSystemFileForJUKI(APads,
                                ABrdRes,
                                AappSettingData,
                                APcbGeneralInfo,
                                Adict,
                                AstrDir,  //export folder
                                AbyLaneNo,
                                "JUKI"
                                );
                            break;
                        }
                    case BMFormat.Samsung:
                        {
                           
                            if (AconfigData._conv3StageMode == false)
                            {
                                strMsg += _deJoch.MESSaveBadMarkFileForHanwhaLane1(APads,
                                    ABrdRes,
                                    APcbGeneralInfo,
                                    AappSettingData,                               
                                    Adict,
                                    AconfigData,
                                    _strTmpFileDir,
                                    AstrDir,  //export folder                                  
                                    "Samsung"
                                    );
                            }
                            else//for 1200 machine
                            {
                                if (ABrdRes.LaneNo == 0)
                                {
                                    strMsg += _deJoch.MESSaveBadMarkFileForHanwhaLane1(APads,
                                        ABrdRes,
                                        APcbGeneralInfo,
                                        AappSettingData,
                                        Adict,
                                        AconfigData,
                                        _strTmpFileDir,
                                        AstrDir,  //export folder   
                                        "Samsung"
                                        );
                                }
                                else
                                {
                                    strMsg += _deJoch.MESSaveBadMarkFileForHanwhaLane2(APads,
                                       ABrdRes,
                                       APcbGeneralInfo,
                                       AappSettingData,
                                       Adict,                                       
                                       _strTmpFileDir,
                                       AstrDir,  //export folder   
                                       "Samsung"
                                       );
                                }
                            }


                            break;
                        }
                    case BMFormat.NXT:
                        {
                            strMsg += SaveBadMarkSystemFileForNXT(APads,
                                ABrdRes,
                                AappSettingData,
                                APcbGeneralInfo,
                                Adict,                                
                                AbyLaneNo,
                                Acmd,
                                AappSettingData.bmFormat.ToString()
                                );
                            break;
                        }
                    case BMFormat.ASM:
                        {
                            strMsg += _deDP.GenPcbInfomationFileForXWD(APads,
                                ABrdRes,
                                 APcbGeneralInfo,
                                AappSettingData,                               
                                Adict,
                                AstrDir,  //export folder   
                                AappSettingData.bmFormat.ToString()
                                );
                            break;
                        }
                    case BMFormat.NXT_File:
                        {
                            strMsg += _deDP.SaveBarMarkFileForFuji(
                                ABrdRes,
                                AappSettingData,
                                 APcbGeneralInfo,
                            
                                AstrDir,  //export folder   
                                AappSettingData.bmFormat.ToString()
                                );
                            break;
                        }
                    default:
                        break;
                }
                if (String.IsNullOrEmpty(strMsg) && Acmd !=  ImgCSCoreIM.WebServiceCmd.CheckConnection)
                    strMsg = RS_DATAEXPORTBadMarkMsg + "Success!";

            }
            catch (System.Exception ex)
            {
                //record the error message to ui log file
                strMsg += RS_DATAEXPORTBadMarkMsg + ex.ToString();
            }

            return strMsg;
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public string SaveDispenserSystemFile(InspectMainLib.Marks AMarks,
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting        
            AppMultiLan.AppLan Adict,          
            byte AbyLaneNo //1,2
            )
        {
            string strMsg = RS_EMPTY;
            try
            {
                if (AappSettingData.stDispenserSystemParams.bEnLinkToDispenser == false)
                {
                    return strMsg;
                }

                string strDir = RS_EMPTY;

                if (AappSettingData.stDispenserSystemParams.bEnExportMarkInfo)
                {
                    //check dir
                    strDir = AappSettingData.stDispenserSystemParams.strPathLaneMarkInfo[AbyLaneNo - 1];
                    if (_wsBaseF.DirCheck(ref strDir) == -1)
                    {
                        strMsg += RS_DATAEXPORTDispenserMsg + "No Folder!";
                        return strMsg;
                    }
                    switch (AappSettingData.stDispenserSystemParams.csvFormat)
                    {
                        case ImgCSCoreIM.CSVDispenserSystem.Default:
                            {
                                strMsg += SaveDispenserSystemForDefault(AMarks,
                                    ABrdRes,
                                    AappSettingData,
                                    APcbGeneralInfo,
                                    Adict,
                                    strDir,  //export folder
                                    AbyLaneNo,
                                    "Default"
                                    );
                                break;
                            }

                        default:
                            break;
                    }
                }
                if (String.IsNullOrEmpty(strMsg))
                    strMsg = RS_DATAEXPORTDispenserMsg + "Success!";

            }
            catch (System.Exception ex)
            {
                //record the error message to ui log file
                strMsg += RS_DATAEXPORTDispenserMsg + ex.ToString();
            }

            return strMsg;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public string SaveMountSystemFile(
            InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting        
            AppMultiLan.AppLan Adict,           
            byte AbyLaneNo, //1,2
            bool bOnlyExportPCBSerialNum
            )
        {
            string strMsg = RS_EMPTY;
            try
            {
                if (AappSettingData.bEnLinkToMountSystem == false)
                {
                    return strMsg;
                }

                string strDir = RS_EMPTY;

                if (AappSettingData.stMountSystemWistron.stAPC.bEnAPC == true)
                {
                               
                    switch (AappSettingData.stCSVMountSystem)
                    {
                        case AppLayerLib.CSVMountSystem.Panasonic:
                            {
                                strMsg += SaveMountSystemFileForNPM(
                                    APads,
                                    ABrdRes,
                                    AappSettingData,
                                    APcbGeneralInfo,
                                    Adict,                                 
                                    AbyLaneNo,
                                    bOnlyExportPCBSerialNum,
                                    "NPM"
                                    );
                                break;
                            }

                        default:
                            break;
                    }
                }
                if (String.IsNullOrEmpty(strMsg))
                    strMsg = RS_DATAEXPORTMountMsg + "Success!";

            }
            catch (System.Exception ex)
            {
                //record the error message to ui log file
                strMsg += RS_DATAEXPORTMountMsg + ex.ToString();
            }

            return strMsg;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public string SaveMonitorSystemFile(
            InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting        
            AppMultiLan.AppLan Adict,
            byte AbyLaneNo //1,2         
            )
        {
            string strMsg = RS_EMPTY;
            try
            {
                if (AappSettingData.stMonitorSystemParams.bEnLinkToMonitor == false)
                {
                    return strMsg;
                }
                byte byCurLane = (byte)(AbyLaneNo - 1);
                string strDir = RS_EMPTY;

                if (AappSettingData.stMonitorSystemParams.stMonitorLaneParams[byCurLane].bEnExportPCBResult == true)
                {

                    switch (AappSettingData.stMonitorSystemParams.csvFormat)
                    {
                        case ImgCSCoreIM.CSVMonitorSystem.WuHanFoxconn:
                            {
                                strMsg += ExportToMonitorSystemForWUHanFoxConn(APads,
                                 ABrdRes,
                                 APcbGeneralInfo,
                                 AappSettingData,
                                 Adict,
                                 byCurLane,
                                 "WuHanFoxconn");
                                break;
                            }

                        default:
                            break;
                    }
                }
                if (String.IsNullOrEmpty(strMsg))
                    strMsg = RS_DATAEXPORTMonitorMsg + "Success!";

            }
            catch (System.Exception ex)
            {
                //record the error message to ui log file
                strMsg += RS_DATAEXPORTMonitorMsg + ex.ToString();
            }

            return strMsg;
        }
        //Q.F.2017.05.30      
        [MethodImpl(MethodImplOptions.Synchronized)]
        public string SavePrinterFile(
            InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting   
            InspectConfig.ConfigData AConfigData,
            AppMultiLan.AppLan Adict,
            string AstrDir                  
            )
        {
            string strMsg = RS_EMPTY;
            try
            {
                if (AappSettingData.bUsingPrinterSystem == false)
                {
                    return strMsg;
                }
               
                string strDir = RS_EMPTY;
                switch (AappSettingData.stCSVPrinter)
                {
                    case AppLayerLib.CSVPrinter.EKRA:
                        {
                            _deTony.SaveFileToPrinterEkra(ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                AstrDir,
                                AappSettingData.stCSVPrinter.ToString());
                            break;
                        }
                    case AppLayerLib.CSVPrinter.ProDEK:
                        {
                            _deJoch.MESSaveXMLFileForSPI2Print(
                                APads,
                                ABrdRes,
                                APcbGeneralInfo,
                                AappSettingData,
                                Adict,
                                AConfigData,
                                ABrdRes.stPrinter2SPIData,
                                _strTmpFileDir,
                                AstrDir,
                                AappSettingData.stCSVPrinter.ToString());
                            break;
                        }
                    default:
                            break;
                }
                if (String.IsNullOrEmpty(strMsg))
                    strMsg = RS_DATAEXPORTPrinterMsg + "Success!";
            }          
            catch (System.Exception ex)
            {
                //record the error message to ui log file
                strMsg += RS_DATAEXPORTPrinterMsg + ex.ToString();
            }

            return strMsg;
        }
        /// <summary>
        /// AbyMode 0:NXT2SPI
        /// AbyMode 1:SPI2NXT
        /// </summary>
        /// <param name="AstrName"></param>
        /// <param name="AbyLaneNo"></param>
        /// <param name="AbyMode"></param>
        /// <returns></returns>
        public string GetFileName(String AstrName, byte AbyLaneNo, ImgCSCoreIM.WebServiceCmd Acmd)
        {
            if (AstrName.Equals("NXT"))
            {
                if (Acmd == ImgCSCoreIM.WebServiceCmd.CheckConnection)
                {
                    return _strTmpFileDir + "\\" + String.Format(_strSPI2NXT, AbyLaneNo);
                }
                else
                {
                    return _strTmpFileDir + "\\" + String.Format(_strNXT2SPI, AbyLaneNo);
                }
            }
               

            return String.Empty;

        }
        public String GenPostScanFileNameForDataExport(byte AbyLaneNo,int AiPCBID,
            string AstrTmpFile, string AstrDataeExportFile, string AstrClntName)
        {
            String strMsg = RS_EMPTY;
             StreamWriter sw = null;
            try
            {
                string strDir = _strTmpFileDir + "\\" + RS_POSTSCAN_DIR + RS_UnderLine + AbyLaneNo;
                if (_wsBaseF.CheckAndDeleteDir(ref strDir, RS_POSTSCAN_EXT) == -1)
                {
                    strMsg = AstrClntName + " Can Not Creat " + strDir;
                    return strMsg;
                }
                if (_wsBaseF.CheckAndDeleteDir(ref strDir, RS_POSTSCANFILE_EXT) == -1)
                {
                    strMsg = AstrClntName + " Can Not Creat " + strDir;
                    return strMsg;
                }
                string strFileName = strDir + AiPCBID + RS_POSTSCAN_EXT;
                if (File.Exists(AstrTmpFile))
                {
                    File.Copy(AstrTmpFile, strFileName, true);
                }
                strFileName = strDir + AiPCBID + RS_POSTSCANFILE_EXT;
                sw = File.AppendText(strFileName);
                sw.WriteLine(AstrDataeExportFile);
                //Q.F.2017.07.10
                if (File.Exists(AstrTmpFile))
                {
                    Thread.Sleep(100);
                    File.Delete(AstrTmpFile);
                }
                
            }
            catch (System.Exception ex)
            {
                strMsg = AstrClntName + " "+ ex.ToString();
            }
            finally
            {
                if (sw != null)
                    sw.Close();
                if (string.IsNullOrEmpty(strMsg) == true)
                {
                    strMsg = AstrClntName + "_GenPostScanFileNameForDataExport:" + "Success!" + ":Lane/PCBID: " + AbyLaneNo
                        + "/" + AiPCBID;
                }
            }
            return strMsg;
        }
        public string GenDataExportAfterPostScan(
            int AiPCBID,
            String AstrBarcode,
            AppSettingData AappSettingData,
            byte AbyLaneNo,
            ImgCSCoreIM.CSVGenFileAfterPostScanType AGenType
            )
        {
            string strMsg = RS_EMPTY;
            try
            {

                if (AGenType == ImgCSCoreIM.CSVGenFileAfterPostScanType.DataExport)
                {
                    if (AappSettingData.bEnDataExp == false)
                        return strMsg;
                    switch (AappSettingData.csvFormat)
                    {
                        case CSVFormat.Default:
                            {
                                
                                strMsg = GenDataExportAfterPostScanDefault(AiPCBID,
                                   AstrBarcode,
                                   AappSettingData,
                                   AbyLaneNo);
                                break;
                            }

                        default:
                            {

                                break;
                            }

                    }
                }
                if (AGenType == ImgCSCoreIM.CSVGenFileAfterPostScanType.BadMark)
                {
                    switch (AappSettingData.bmFormat)
                    {
                        case BMFormat.NXT:
                            {
                                strMsg = GenDataExportAfterPostScanDefault(AiPCBID,
                                   AstrBarcode,
                                   AappSettingData,
                                   AbyLaneNo);
                                break;
                            }

                        default:
                            {

                                break;
                            }

                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg = ex.ToString();
            
            }

            return strMsg;  
        }
       
        public String GetPostscanBoardBarcode
        {
            get { return RS_POSTSCAN_BARCODE; }
        }

        public void ClearPostScanDir(byte AbyLaneNo)
        {
            try
            {
                string strDir = Path.Combine(_strTmpFileDir ,RS_POSTSCAN_DIR + RS_UnderLine + AbyLaneNo);
                _wsBaseF.CheckAndDeleteDir(ref strDir,RS_POSTSCAN_EXT);
                _wsBaseF.CheckAndDeleteDir(ref strDir, RS_POSTSCANFILE_EXT);
            }
            catch (System.Exception ex)
            {
            	
            }
        }
        //Q.F.2017.07.31
        public void ClearDataExportDir(AppSettingData AappSettingData,byte AbyLaneNo,bool AbBeforeRelease)
        {
           
            try
            {
                String strDir = "";
                if (AappSettingData.bUsingBadMarkSystem == true
                    && AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bENClearExportFolder == true)
                {

                    if (AappSettingData.bmFormat == BMFormat.Panasonic
                        && AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bEnClearBeforeNextPCBInspect == true)
                    {

                        strDir = AappSettingData.strBadMarkSystemExpPath;
                        if (_wsBaseF.DirCheck(ref strDir) == -1)
                        {
                            strDir = _strBadMarkSystemDir;
                        }
                        _wsBaseF.CheckAndDeleteDir(ref strDir, RS_FileExt);//
                    }
                    //Q.F.2017.12.19
                   if (AappSettingData.bUsingBadMarkSystem == true
                       && AbBeforeRelease == true
                       && AappSettingData.stMountSystemWistron.stSystemBadMarkParams.bENClearExportFolder == true
                       )
                   {
                       strDir = AappSettingData.strBadMarkSystemExpPath;
                       if (_wsBaseF.DirCheck(ref strDir) == -1)
                       {
                           strDir = _strBadMarkSystemDir;
                       }
                       _wsBaseF.CheckAndDeleteDir(ref strDir, RS_FileExt);//
                   }
                }
            }
            catch (System.Exception ex)
            {
            	
            }
           
        }

        public void BarcodeErrorLog(       
            ImgCSCoreIM.StBarcodeErrorLog AStBarcodeErrorLogParams,           
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting   
            InspectConfig.ConfigData AConfigData,
            AppMultiLan.AppLan Adict)
        {
            string strMsg = RS_EMPTY;
            try
            {
                switch (AappSettingData.stUIOperations.EMBarcodeLogFormat)
                {
                    case ImgCSCoreIM.EM_BarcodeLogFormat.VT:
                        {
                            strMsg += GenBarcodeErrorLogVT(
                                AStBarcodeErrorLogParams,
                            
                                APcbGeneralInfo, // record pcb info: array , bad mark.
                                AappSettingData, // ui setting   
                                AConfigData,
                                Adict);
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            catch (System.Exception ex)
            {
            	
            }
            finally
            {
            }
            if (String.IsNullOrEmpty(strMsg) == false)
            {
                _imgCSBaseF.LogRecord(strMsg, false);
            }
            else
            {
                _imgCSBaseF.LogRecord(RS_DATAEXPORTBARCODELOGMsg + "Success", false);
            }
           // return strMsg;
        }

        public void SystemLogRecord( SPCBoardRes ABrdRes,
            AppSettingData AappSettingData, // ui setting   
            ImgCSCoreIM.EM_SystemLog AEmSystemLog)
        {
            string strMsg = RS_EMPTY;
            try
            {
                switch (AEmSystemLog)
                {
                    case ImgCSCoreIM.EM_SystemLog.Printer:
                        {
                            strMsg += GenSystemLogForPrinter(
                                ABrdRes, AappSettingData,AEmSystemLog.ToString());
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }
            catch (System.Exception ex)
            {
            	
            }
            finally
            {
            }
            if (String.IsNullOrEmpty(strMsg) == false)
            {
                _imgCSBaseF.LogRecord(strMsg, false);
            }
            else
            {
                _imgCSBaseF.LogRecord(AEmSystemLog.ToString() + "\t" +RS_DATAEXPORTSystemLOGMsg + "Success", false);
            }
        }

         public void GetDataExportSavePadImagePath(AppSettingData AappSettingData, string AstrDir, ref SPCBoardRes ABrdRes)
        {
             try
             {
                 _deJoch.GetDataExportSavePadImagePath(AappSettingData, AstrDir,ref ABrdRes);
             }
             catch (System.Exception ex)
             {
             	
             }
        }
         public String  GenPcbBarcodeStr(InspectMainLib.Pad[] APads,
              SPCBoardRes ABrdRes,
              ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
              AppSettingData AappSettingData,
              out String AoutStrBarcode)
         {
             String strMsg = String.Empty;
             AoutStrBarcode = String.Empty;
             if (AappSettingData.stUIOperations.BENGenBarcode == false)
                 return strMsg;
             try
             {
              //   strMsg = _deDP.getPcbBarcodeStr3(APads, ABrdRes, APcbGeneralInfo, AappSettingData, out AoutStrBarcode);
                // strMsg = _deDP.getPcbBarcodeStr4(APads, ABrdRes, APcbGeneralInfo, AappSettingData, out AoutStrBarcode);
                 strMsg = _deDP.getPcbBarcodeStr(APads, ABrdRes, APcbGeneralInfo, AappSettingData, out AoutStrBarcode);
             }
             catch (System.Exception ex)
             {
                 strMsg = "Error:" + ex.ToString();
             }
             finally
             { 

             }
             return strMsg;
             //String strPre = "GenPcbBarcodeStr";
             //if (String.IsNullOrEmpty(strMsg) == true)
             //    _imgCSBaseF.LogRecord(strPre + "Success",false);
             //else
             //{
             //    _imgCSBaseF.LogRecord(strPre + strMsg, false);
             //}
             //return strMsg;
         }

        
    }
     
}
