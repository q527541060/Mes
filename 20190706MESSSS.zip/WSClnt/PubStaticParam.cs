﻿namespace WSClnt
{
    public static class PubStaticParam
    {
        public static readonly string RS_LineEnd = "\r\n";
        public static readonly string RS_EMPTY = "";

        public static readonly string RS_SemicolonSplit = ";";
        public static readonly string RS_ColonSplit = ":";
        public static readonly string RS_CommaSplit = ",";
        public static readonly string RS_AtSplit = "@";
        public static readonly string RS_MedianLineSplit = "-";
        public static readonly string RS_UnderLineSplit = "_";
        public static readonly string RS_VerticalLineSplit = "|";

        public static readonly string RS_strTmpFileDir = "D:\\EYSPI\\DataExport\\TmpDir";
        public static readonly string RS_DataExportTempFile = "DataExp.Tmp";
        public static readonly string RS_NOREAD = "NOREAD";
        public static readonly string RS_NOREADNA = "N/A";

        public static readonly string RS_CSV_EXT = ".csv";
        public static readonly string RS_TXT_EXT = ".txt";
        public static readonly string RS_XML_EXT = ".xml";
        public static readonly string RS_JSon_EXT = ".json";

        public static readonly string RS_DATAEXPORTMsg = "WSClnt_DataExport:  ";


        /// <summary>
        /// dd/MM/yyyy HH:mm:ss
        /// </summary>
        public static readonly string RS_FORMAT_DATETIME_EU = "dd/MM/yyyy HH:mm:ss";
        /// <summary>
        /// yyyy-MM-dd HH:mm:ss
        /// </summary>
        public static readonly string RS_FORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss";
        /// <summary>
        /// yyyy-MM-ddTHH:mm:sszzzz
        /// </summary>
        public static readonly string RS_FORMAT_DATETIME_ISO8601 = "yyyy-MM-ddTHH:mm:sszzzz";
        /// <summary>
        /// yyyyMMdd
        /// </summary>
        public static readonly string RS_FORMAT_DATE = "yyyyMMdd";
        /// <summary>
        /// HHmmss
        /// </summary>
        public static readonly string RS_FORMAT_TIME = "HHmmss";
        /// <summary>
        /// yyyyMMddHHmmss
        /// </summary>
        public static readonly string RS_Format_DateTimeFileName = "yyyyMMddHHmmss";
        /// <summary>
        /// yyyyMMdd
        /// </summary>
        public static readonly string RS_Format_DateFileName = "yyyyMMdd";

        public static readonly float RS_fUM2MM = 0.001f;
        public static readonly float RS_fMM2UM = 1000f;
        public static readonly float RS_fUM2Mil = 0.03937f;
        public static readonly string RS_ZERO = "0";
        public static readonly string RS_FLOATFORMAT_2Bit = "0.00";
        public static readonly string RS_FLOATFORMAT_3Bit = "0.000";
        public static readonly string RS_FLOATFORMAT_4Bit = "0.0000";
        public static readonly string RS_FLOATFORMAT_6Bit = "0.000000";

        public static JNLog.JNLog _log = new JNLog.JNLog("WSClnt_Log");

        public static int _intCommandTimeout = 600;
        public static int _iStringBuilderCapacity = 50000000;
        public static int _iStringBuilderMaxCapacity = 500000000;
        //public static string _strSPIdbConnectionString = "server=127.0.0.1;user id=root;database=spidb;Password=;Charset=utf8 ";
        public static string _strSPIdbConnectionString = DAL_SPC.PubParams.GetConnString();
    }
}
