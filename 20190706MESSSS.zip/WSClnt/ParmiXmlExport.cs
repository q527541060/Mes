﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using WSClnt;
using InspectMainLib;
using AppLayerLib;

namespace WSClnt
{
    class ParimXmlScheme
    {

        #region Element<Panel> struct

        public struct StPanel
        {
            public string nodeName() { return "Panel"; }
            public string _index;
            public string _openindex;
            public string _lane;
            public string _code;
            public string _barcode;
            public int _boardcount;
            public string _side;
            public int _dftpadcount;
            public float _insptime;
            public int _spantime;
            public string _inspresult;
            public string _represult;
            public string _warnresult;
            public string _inspmethod;
            public string _resultcode;
            public string _MachineName;
            public double _SizeX;
            public double _SizeY;
            public string _pon;
            public string _product;
            public string _operator;
            public string _drawing;
            public string _line;
            public StValue Value;
            public List<StLayer> Layers;
            public List<StBoard> Boards;
        }

        #endregion

        #region Element <Layer> struct

        public struct StLayer
        {
            public string nodeName() { return "Layer"; }
            public string _id;
            public string _boardid;
            public string _side;
            public StValue Value;
        }

        #endregion

        #region Element <Board> struct
        public struct StBoard
        {
            public string nodeName() { return "Board"; }
            public string _id;
            public string _orderid;
            public int _compcount;
            public int _padcount;
            public string _inspresult;
            public string _represult;
            public string _warnresult;
            public string _barcode;
            public string _fc;
            public StValue Value;
            public List<StComponent> Components;
        }

        #endregion

        #region Element <Component> struct

        public struct StComponent
        {
            public string nodeName() { return "Component"; }
            public string _id;
            public string _name;
            public string _code;
            public int _padcount;
            public string _inspresult;
            public string _represult;
            public string _warnresult;
            public StValue Value;
            public List<StPad> Pads;
        }

        #endregion

        #region Element <Pad> struct
        public struct StPad
        {
            public string nodeName() { return "Pad"; }
            public string _id;
            public string _name;
            public string _inspresult;
            public string _represult;
            public string _warnresult;
            public string _fc;
            public string _deftype;
            public string _defcause;
            public double _base;
            public double _PosX;
            public double _PosY;
            public StValue Value;
        }

        #endregion

        #region Element <Value> struct

        public struct StValue
        {
            public string nodeName() { return "Value"; }
            public StHeight Height;
            public StArea Area;
            public StVolume Volume;
            public StOffset Offset;
            public StWarpage Warpage;
            public StRotation Rotation;
            public StBridge Bridge;
            public StShape Shape;
            public StBalance Balance;
            public StValue(StHeight height, StArea area,
                StVolume volume, StOffset offset, StWarpage warpage,
                StRotation rotation, StBridge bridge, StShape shape, StBalance balance)
            {
                Height = height; Area = area; Volume = volume; Offset = offset;
                Warpage = warpage; Rotation = rotation; Bridge = bridge; Shape = shape; Balance = balance;
            }
        }
        public struct StHeight
        {
            public string nodeName() { return "Height"; }
            public double _data;
            public double _per;
            public double _tol_l;
            public double _tol_u;
            public int _l_count;
            public int _u_count;
        }

        public struct StArea
        {
            public string nodeName() { return "Area"; }
            public double _data;
            public double _per;
            public double _tol_l;
            public double _tol_u;
            public double _l_count;
            public double _u_count;
        }
        public struct StVolume
        {
            public string nodeName() { return "Volume"; }
            public double _data;
            public double _per;
            public double _tol_l;
            public double _tol_u;
            public double _l_count;
            public double _u_count;
        }

        public struct StOffset
        {
            public string nodeName() { return "Offset"; }
            public double _data_x;
            public double _data_y;
            public double _tol_x;
            public double _tol_y;
            public int _count_xp;
            public int _count_xm;
            public int _count_yp;
            public int _count_ym;
        }

        public struct StWarpage
        {
            public string nodeName() { return "Warpage"; }
            public double _data;
        }
        public struct StRotation
        {
            public string nodeName() { return "Rotation"; }
            public double _data;
        }

        public struct StBridge
        {
            public string nodeName() { return "Bridge"; }
            public double _height;
            public double _width;
            public int _count;
        }
        public struct StShape
        {
            public string nodeName() { return "Shape"; }
            public string _code;
            public double _value;
            public int _count;
        }
        public struct StBalance
        {
            public string nodeName() { return "Balance"; }
            public int _h_count;
            public int _v_count;
            public int _a_count;
        }

        #endregion

        #region Element <Create> struct

        public struct StCreate
        {
            public string toolName;
            public string toolVersion;
            public string fileName;
            public DateTime exportDate;
            public string Operator;
        }

        #endregion

    }

    //ParimXmlScheme Class End
    
    class ParmiXmlExport
    {
        private readonly string RS_EMPTY = "";

        private const string RS_XML_ROOT_ELEMENT = "SinicTek";

        private const string RS_DATETIME_FORMAT = "yyyyMMddHHmmss";

        private const string RS_XML_EXT = ".xml";

        private const string _strTmpFileDir = "D:\\EYSPI\\DataExport\\TmpDir";

        private const string RS_DATAEXPORTTEMPFILE = "DataExp.Tmp";

        private readonly string RS_NOREAD = "NOREAD";

        private readonly string RS_DATAEXPORTMsg = "WSClnt_XmlDataExport:  ";

        private const string RS_DEFAULT_SPI_OPERATOR = "manager";

        private const string RS_DOUBLE_FORMATE = "#0.000000";

        private const string RS_FLOAT_FORMATE = "#0.00";

        private Basefunction _baseFun;


        public ParmiXmlExport()
        {
            _baseFun = new Basefunction();
            if (!System.IO.Directory.Exists(_strTmpFileDir))
            {
                System.IO.Directory.CreateDirectory(_strTmpFileDir);
            }
        }

        ~ParmiXmlExport() { }

        /// <summary>
        /// saveXmlToFileForHanShine according to Prami
        /// </summary>
        public string SaveDataExport(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                //get board barcode
                String strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                //if (String.Equals(strboardBarcode, RS_NOREAD))
                //    strboardBarcode = "Barcode0";

                DateTime dtNowDate = System.DateTime.Now; 
                string strFileName = AstrDir + strboardBarcode + RS_XML_EXT;
                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.AppendChild(XmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null));
                //create doc root
                XmlElement XmlRootEle = InsertRootEle(RS_XML_ROOT_ELEMENT, ref XmlDoc);
                //create header element
                ParimXmlScheme.StCreate StCreate = new ParimXmlScheme.StCreate();
                StCreate.exportDate = dtNowDate;
                StCreate.fileName = strFileName;
                StCreate.Operator = string.IsNullOrEmpty(ABrdRes.operatorName) ? RS_DEFAULT_SPI_OPERATOR : ABrdRes.operatorName;
                StCreate.toolName = "SpiUI";
                StCreate.toolVersion = "1.0";
                XmlElement XmlHeaderEle = InsertHeaderEle(ref XmlDoc,ref XmlRootEle, ref StCreate);
                //create panel element
                ParimXmlScheme.StPanel StPanel = new ParimXmlScheme.StPanel();
                StPanel._index = ABrdRes.pcbID.ToString();
                StPanel._openindex = ABrdRes.pcbID.ToString();
                StPanel._lane = GetLaneNoStr(ABrdRes.LaneNo);
                StPanel._code = "";
                StPanel._barcode = strboardBarcode;
                StPanel._boardcount = 1;
                StPanel._side = "1";
                StPanel._dftpadcount = 0;
                StPanel._insptime = (ABrdRes.endTime - ABrdRes.startTime).Milliseconds / 1000;
                StPanel._spantime = 0;
                if (ABrdRes.jugResult == JudgeRes.Good)
                {
                    StPanel._inspresult = "0";
                    StPanel._represult = "0";
                    StPanel._warnresult = "0";
                }
                else if (ABrdRes.jugResult == JudgeRes.NG)
                {
                    StPanel._inspresult = "2";
                    StPanel._represult = "2";
                    StPanel._warnresult = "0";
                }
                else if (ABrdRes.jugResult == JudgeRes.Pass)
                {
                    StPanel._inspresult = "2";
                    StPanel._represult = "1";
                    StPanel._warnresult = "0";
                }
                else
                {
                    StPanel._inspresult = "0";
                    StPanel._represult = "0";
                    StPanel._warnresult = "0";
                }
                StPanel._inspmethod = "1";
                StPanel._resultcode = JudgeRes.Pass.ToString();
                StPanel._MachineName = string.IsNullOrEmpty(AappSettingData.stDataExpVT.strTesterName) ? "SPI001" : AappSettingData.stDataExpVT.strTesterName;
                StPanel._SizeX = 0.0d;//confirm it later
                StPanel._SizeY = 0.0d;//confirm it later
                StPanel._pon = "";
                StPanel._product = ABrdRes.jobName;
                StPanel._operator = "";
                StPanel._drawing = "";
                StPanel._line = AappSettingData.LineName; //-1 value is sample

                //panel value
                ParimXmlScheme.StHeight StHeight = new ParimXmlScheme.StHeight();
                ParimXmlScheme.StArea StArea = new ParimXmlScheme.StArea();
                ParimXmlScheme.StVolume StVolume = new ParimXmlScheme.StVolume();
                ParimXmlScheme.StOffset StOffset = new ParimXmlScheme.StOffset();
                ParimXmlScheme.StWarpage StWarpage = new ParimXmlScheme.StWarpage();
                ParimXmlScheme.StRotation StRotation = new ParimXmlScheme.StRotation();
                ParimXmlScheme.StBridge StBridge = new ParimXmlScheme.StBridge();
                ParimXmlScheme.StShape StShape = new ParimXmlScheme.StShape();
                ParimXmlScheme.StBalance StBalance = new ParimXmlScheme.StBalance();
                ParimXmlScheme.StValue StValue = new ParimXmlScheme.StValue(StHeight, StArea, StVolume, StOffset, StWarpage, StRotation, StBridge, StShape, StBalance);
                StPanel.Value = StValue;

                //Fiducials ignore export

                //Layers
                ParimXmlScheme.StLayer StLayer = new ParimXmlScheme.StLayer();
                StLayer._id = "1";
                StLayer._side = "1";//confirm later 
                StLayer._boardid = ""; //array is defualt 1 
                StLayer.Value = StValue;
                StPanel.Layers = new List<ParimXmlScheme.StLayer>();

                StPanel.Layers.Add(StLayer);



                //Boards same as array
                StPanel.Boards = new List<ParimXmlScheme.StBoard>();


                if (APads != null && APads.Length > 0)
                {
                    SortPadsByPinNumAndComponentId(ref APads);
                    
                    string sPinNumber = null;
                    string sComponentId = null;

                    ParimXmlScheme.StComponent StComponent = new ParimXmlScheme.StComponent();
                    ParimXmlScheme.StBoard StBoard = new ParimXmlScheme.StBoard();
                    //string iComponentInspResult = "0";
                    //string iComponentReResult = "0";
                    //string iComponentWarnResult = "0";
                    ////
                    //string iBoardInspResult = "0";
                    //string iBoardReResult = "0";
                    //string iBoardWarnResult = "0";

                    for (int i = 0; i < APads.Length; i++)
                    {
                        bool bNewPinNumber = false;//board element
                        bool bNewComponent = false;
                        //
                        InspectMainLib.Pad pad = APads[i];
                        if (_baseFun.bPadIsSkip(pad))
                            continue;

                        if (sPinNumber == null && sComponentId == null)
                        {
                            bNewPinNumber = true;

                            bNewComponent = true;

                        }
                        else if (!sPinNumber.Equals(pad.pinNumber))
                        {

                            bNewPinNumber = true;

                            bNewComponent = true;

                        }
                        else if (!sComponentId.Equals(pad.componentID))
                        {
                            bNewPinNumber = false;

                            bNewComponent = true;
                        }
                        else
                        {
                            bNewPinNumber = false;

                            bNewComponent = false;
                        }

                        if (bNewPinNumber)
                        {


                            StBoard = new ParimXmlScheme.StBoard();

                            StBoard.Components = new List<ParimXmlScheme.StComponent>();
                            StBoard._id = pad.pinNumber;
                            StBoard._orderid = pad.pinNumber;
                            StBoard._barcode = "";
                            StBoard._fc = "";
                            StBoard._inspresult = "0";
                            StBoard._represult = "0";
                            StBoard._warnresult = "0";
                            StLayer._boardid += string.IsNullOrEmpty(StLayer._boardid) ? StBoard._orderid : "," + StBoard._orderid;
                            if (StPanel.Layers != null && StPanel.Layers.Count > 0)
                            {
                                StPanel.Layers.RemoveAt(StPanel.Layers.Count - 1);
                                StPanel.Layers.Add(StLayer);
                            }
                            if (StPanel.Boards != null) StPanel.Boards.Add(StBoard);

                        }

                        if (bNewComponent)
                        {
                            if (StPanel.Boards != null && StPanel.Boards.Count > 0)
                            {
                                ParimXmlScheme.StBoard stBoardTemp = StPanel.Boards[StPanel.Boards.Count - 1];
                                if (stBoardTemp.Components != null)
                                {
                                    stBoardTemp._compcount = stBoardTemp.Components.Count;
                                    foreach (ParimXmlScheme.StComponent component in stBoardTemp.Components)
                                    {
                                        if (component.Pads != null)
                                        {
                                            stBoardTemp._padcount += component._padcount;
                                        }
                                    }
                                    //if (StPanel.Boards != null && StPanel.Boards.Count > 0)
                                    //{
                                    //    StPanel.Boards.RemoveAt(StPanel.Boards.Count - 1);
                                    //    StPanel.Boards.Add(stBoardTemp);
                                    //}
                                }
                            }


                            if (StComponent.Pads != null)
                            {
                                StComponent._padcount = StComponent.Pads.Count;
                                if (StBoard.Components != null && StBoard.Components.Count > 0)
                                {
                                    StBoard.Components.RemoveAt(StBoard.Components.Count - 1);
                                    StBoard.Components.Add(StComponent);
                                }
                            }
                            StComponent = new ParimXmlScheme.StComponent();
                            StComponent._inspresult = StComponent._represult = StComponent._warnresult = "0";
                            StComponent._id = StComponent._name = StComponent._code = pad.componentID;
                            StComponent.Pads = new List<ParimXmlScheme.StPad>();
                            if (StBoard.Components != null) StBoard.Components.Add(StComponent);
                        }

                        sPinNumber = pad.pinNumber;
                        sComponentId = pad.componentID;

                        //generate pad element

                        ParimXmlScheme.StPad StPad = new ParimXmlScheme.StPad();
                        StPad._id = pad.padID.ToString();
                        StPad._name = pad.padID.ToString();
                        StPad._inspresult = StPad._represult = StPad._warnresult = pad.res.jugRes.ToString();
                        StPad._fc = "0";
                        StPad._deftype = StPad._defcause = "";
                        StPad._base = 0.0d;//unknow base means
                        StPad._PosX = pad.posXmm;
                        StPad._PosY = pad.posYmm;
                        ParimXmlScheme.StHeight padHeight = new ParimXmlScheme.StHeight();
                        ParimXmlScheme.StArea padArea = new ParimXmlScheme.StArea();
                        ParimXmlScheme.StVolume padVolume = new ParimXmlScheme.StVolume();
                        ParimXmlScheme.StOffset padOffset = new ParimXmlScheme.StOffset();
                        ParimXmlScheme.StBridge padBridge = new ParimXmlScheme.StBridge();
                        ParimXmlScheme.StShape padShape = new ParimXmlScheme.StShape();
                        padHeight._data = pad.res.measuredValue.height;
                        padHeight._per = pad.res.measuredValue.perHeight;
                        padHeight._tol_l = pad.spec.heightL;
                        padHeight._tol_u = pad.spec.heightH;
                        padArea._data = pad.res.measuredValue.area;
                        padArea._per = pad.res.measuredValue.perArea;
                        padArea._tol_l = pad.spec.areaPerL;
                        padArea._tol_u = pad.spec.areaPerH;
                        padVolume._data = pad.res.measuredValue.vol;
                        padVolume._per = pad.res.measuredValue.perVol;
                        padVolume._tol_l = pad.spec.volPerL;
                        padVolume._tol_u = pad.spec.volPerH;
                        padOffset._data_x = pad.res.measuredValue.offsetX;
                        padOffset._data_y = pad.res.measuredValue.offsetY;
                        padOffset._tol_x = pad.spec.shiftXH;
                        padOffset._tol_y = pad.spec.shiftYH;
                        padBridge._height = 0.0d;
                        padBridge._width = 0.0d;
                        padShape._code = "0";
                        padShape._value = 0.0d;
                        //
                        if (!string.IsNullOrEmpty(StPad._inspresult) && !StPad._inspresult.Equals("0"))
                        {
                            StComponent._inspresult = StPad._inspresult;
                            StBoard._inspresult = StPad._inspresult;
                        }

                        if (!string.IsNullOrEmpty(StPad._represult) && !StPad._represult.Equals("0"))
                        {
                            StComponent._represult = StPad._represult;
                            StBoard._represult = StPad._represult;
                        }

                        if (!string.IsNullOrEmpty(StPad._warnresult) && !StPad._warnresult.Equals("0"))
                        {
                            StComponent._warnresult = StPad._warnresult;
                            StBoard._warnresult = StPad._warnresult;
                        }


                        ParimXmlScheme.StValue padValue = new ParimXmlScheme.StValue(padHeight, padArea, padVolume, padOffset, new ParimXmlScheme.StWarpage(), new ParimXmlScheme.StRotation(), padBridge, padShape, new ParimXmlScheme.StBalance());
                        StPad.Value = padValue;
                        //judge new component/pinNumber





                        if (StComponent.Pads != null) StComponent.Pads.Add(StPad);

                    }
                    if (StComponent.Pads != null)
                    {
                        StComponent._padcount = StComponent.Pads.Count;
                        if (StBoard.Components != null && StBoard.Components.Count > 0)
                        {
                            StBoard.Components.RemoveAt(StBoard.Components.Count - 1);
                            StBoard.Components.Add(StComponent);
                        }
                    }
                    if (StBoard.Components != null)
                    {
                        foreach (ParimXmlScheme.StComponent component in StBoard.Components)
                        {
                            if (component.Pads != null)
                            {
                                StBoard._padcount += component._padcount;
                            }
                        }
                        StBoard._compcount = StBoard.Components.Count;
                        if (StPanel.Boards != null && StPanel.Boards.Count > 0)
                        {
                            StPanel.Boards.RemoveAt(StPanel.Boards.Count - 1);
                            StPanel.Boards.Add(StBoard);
                        }
                    }


                }

                XmlElement XmlPanelEle = InsertElementPanel(ref XmlDoc, ref XmlRootEle, StPanel);

                //XmlDoc.Save(Console.Out);
                //
                XmlDoc.Save(strFileName);

            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }


            return strMsg;
        }


        private XmlElement InsertRootEle(string AsRootEleName, ref XmlDocument AXmlDoc)
        {
            XmlElement xmlElement = AXmlDoc.CreateElement(AsRootEleName);
            AXmlDoc.AppendChild(xmlElement);
            return xmlElement;
        }

        private XmlElement InsertHeaderEle(ref XmlDocument AXmlDoc,ref XmlElement AXmlParentElement,ref ParimXmlScheme.StCreate AstCreate)
        {
            XmlElement XmlEleHeader = AXmlDoc.CreateElement("Header");
            AXmlParentElement.AppendChild(XmlEleHeader);
            XmlElement xmlEleCreate = AXmlDoc.CreateElement("Create");
            XmlEleHeader.AppendChild(xmlEleCreate);
            XmlElement XmlEleTool = AXmlDoc.CreateElement("Tool");
            xmlEleCreate.AppendChild(XmlEleTool);
            XmlEleTool.SetAttribute("name", AstCreate.toolName);
            XmlEleTool.SetAttribute("version", AstCreate.toolVersion);
            XmlElement XmlEleExport = AXmlDoc.CreateElement("Export");
            xmlEleCreate.AppendChild(XmlEleExport);
            XmlEleExport.SetAttribute("file", AstCreate.fileName);
            XmlEleExport.SetAttribute("date", AstCreate.exportDate.ToString("yyyyMMddHHmmss"));
            XmlEleExport.SetAttribute("operator", AstCreate.Operator);
            return XmlEleHeader;


        }




        private XmlElement InsertElementPanel(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StPanel AStPanel)
        {
            XmlElement XmlElePanel = AXmlDoc.CreateElement(AStPanel.nodeName());
            AXmlParentElement.AppendChild(XmlElePanel);
            XmlElePanel.SetAttribute("index", AStPanel._index);
            XmlElePanel.SetAttribute("openindex", AStPanel._openindex);
            XmlElePanel.SetAttribute("lane", AStPanel._lane);
            XmlElePanel.SetAttribute("code", AStPanel._code);
            XmlElePanel.SetAttribute("barcode", AStPanel._barcode);
            XmlElePanel.SetAttribute("boardcount", AStPanel._boardcount.ToString());
            XmlElePanel.SetAttribute("side", AStPanel._side);
            XmlElePanel.SetAttribute("dftpadcount", AStPanel._dftpadcount.ToString());
            XmlElePanel.SetAttribute("insptime", AStPanel._insptime.ToString(RS_FLOAT_FORMATE));
            XmlElePanel.SetAttribute("spantime", AStPanel._spantime.ToString());
            XmlElePanel.SetAttribute("inspresult", AStPanel._inspresult);
            XmlElePanel.SetAttribute("represult", AStPanel._represult);
            XmlElePanel.SetAttribute("warnresult", AStPanel._warnresult);
            XmlElePanel.SetAttribute("inspmethod", AStPanel._inspmethod);
            XmlElePanel.SetAttribute("resultcode", AStPanel._resultcode);
            XmlElePanel.SetAttribute("MachineName", AStPanel._MachineName);
            XmlElePanel.SetAttribute("SizeX", AStPanel._SizeX.ToString(RS_DOUBLE_FORMATE));
            XmlElePanel.SetAttribute("SizeY", AStPanel._SizeY.ToString(RS_DOUBLE_FORMATE));
            XmlElePanel.SetAttribute("pon", AStPanel._pon);
            XmlElePanel.SetAttribute("product", AStPanel._product);
            XmlElePanel.SetAttribute("operator", AStPanel._operator);
            XmlElePanel.SetAttribute("drawing", AStPanel._drawing);
            XmlElePanel.SetAttribute("line", AStPanel._line);

            XmlElement XmlElePanelValue = AXmlDoc.CreateElement(AStPanel.Value.nodeName());
            XmlElePanel.AppendChild(XmlElePanelValue);
            //insert value element
            InsertHeightEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Height);
            InsertAreaEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Area);
            InsertVolumeEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Volume);
            InsertOffsetEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Offset);
            InsertWarpageEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Warpage);
            InsertRotationEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Rotation);
            InsertBridgeEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Bridge);
            InsertShapeEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Shape);
            InsertBalanceEle(ref AXmlDoc, ref XmlElePanelValue, AStPanel.Value.Balance);

            //layers
            XmlElement XmlElePanelLayers = AXmlDoc.CreateElement("Layers");
            XmlElePanel.AppendChild(XmlElePanelLayers);
            //
            foreach (ParimXmlScheme.StLayer StLayer in AStPanel.Layers)
            {
                XmlElement XmlElePanelLayer = AXmlDoc.CreateElement(StLayer.nodeName());
                XmlElePanelLayers.AppendChild(XmlElePanelLayer);
                XmlElePanelLayer.SetAttribute("id", StLayer._id.ToString());
                XmlElePanelLayer.SetAttribute("boardid", StLayer._boardid.ToString());
                XmlElePanelLayer.SetAttribute("side", StLayer._side.ToString());
                //
                XmlElement XmlEleLayerValue = AXmlDoc.CreateElement(StLayer.Value.nodeName());
                XmlElePanelLayer.AppendChild(XmlEleLayerValue);
                InsertHeightEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Height);
                InsertAreaEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Area);
                InsertVolumeEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Volume);
                InsertOffsetEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Offset);
                InsertWarpageEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Warpage);
                InsertRotationEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Rotation);
                InsertBridgeEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Bridge);
                InsertShapeEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Shape);
                InsertBalanceEle(ref AXmlDoc, ref XmlEleLayerValue, StLayer.Value.Balance);
            }

            //borders
            XmlElement XmlElePanelBoards = AXmlDoc.CreateElement("Boards");
            XmlElePanel.AppendChild(XmlElePanelBoards);
            //
            foreach (ParimXmlScheme.StBoard StBoard in AStPanel.Boards)
            {
                //board
                XmlElement XmlEleBoard = InsertBoradEle(ref AXmlDoc, ref XmlElePanelBoards, StBoard);
                // board->components
                XmlElement XmlEleBoardComponents = AXmlDoc.CreateElement("Components");
                XmlEleBoard.AppendChild(XmlEleBoardComponents);
                foreach (ParimXmlScheme.StComponent StComponect in StBoard.Components)
                {
                    //component
                    XmlElement XmlEleComponent = InsertComponentEle(ref AXmlDoc, ref XmlEleBoardComponents, StComponect);
                    //component->pads
                    XmlElement XmlEleComponentPads = AXmlDoc.CreateElement("Pads");
                    XmlEleComponent.AppendChild(XmlEleComponentPads);
                    foreach (ParimXmlScheme.StPad StPad in StComponect.Pads)
                    {
                        //pad
                        InsertPadEle(ref AXmlDoc, ref XmlEleComponentPads, StPad);
                    }
                }

            }

            return XmlElePanel;
        }

        private XmlElement InsertPadEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StPad AStPad)
        {
            XmlElement XmlElePad = AXmlDoc.CreateElement(AStPad.nodeName());
            AXmlParentElement.AppendChild(XmlElePad);

            XmlElePad.SetAttribute("id", AStPad._id.ToString());
            XmlElePad.SetAttribute("name", AStPad._name.ToString());
            XmlElePad.SetAttribute("inspresult", AStPad._inspresult.ToString());
            XmlElePad.SetAttribute("represult", AStPad._represult.ToString());
            XmlElePad.SetAttribute("fc", AStPad._fc.ToString());
            XmlElePad.SetAttribute("deftype", AStPad._deftype.ToString());
            XmlElePad.SetAttribute("defcause", AStPad._defcause.ToString());
            XmlElePad.SetAttribute("base", AStPad._base.ToString(RS_DOUBLE_FORMATE));
            XmlElePad.SetAttribute("PosX", AStPad._PosX.ToString(RS_DOUBLE_FORMATE));
            XmlElePad.SetAttribute("PosY", AStPad._PosY.ToString(RS_DOUBLE_FORMATE));
            //value
            XmlElement XmlElePadValue = AXmlDoc.CreateElement(AStPad.Value.nodeName());
            XmlElePad.AppendChild(XmlElePadValue);
            InsertHeightEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Height);
            InsertAreaEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Area);
            InsertVolumeEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Volume);
            InsertOffsetEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Offset);
            InsertBridgeEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Bridge);
            InsertShapeEle(ref AXmlDoc, ref XmlElePadValue, AStPad.Value.Shape);
            return XmlElePad;
        }

        private XmlElement InsertComponentEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StComponent AStComponent)
        {
            XmlElement XmlEleComponent = AXmlDoc.CreateElement(AStComponent.nodeName());
            AXmlParentElement.AppendChild(XmlEleComponent);
            XmlEleComponent.SetAttribute("id", AStComponent._id.ToString());
            XmlEleComponent.SetAttribute("name", AStComponent._name.ToString());
            XmlEleComponent.SetAttribute("code", AStComponent._code.ToString());
            XmlEleComponent.SetAttribute("padcount", AStComponent._padcount.ToString());
            XmlEleComponent.SetAttribute("inspresult", AStComponent._inspresult.ToString());
            XmlEleComponent.SetAttribute("represult", AStComponent._represult.ToString());
            XmlEleComponent.SetAttribute("warnresult", AStComponent._warnresult.ToString());
            //value
            XmlElement XmlEleComponentValue = AXmlDoc.CreateElement(AStComponent.Value.nodeName());
            XmlEleComponent.AppendChild(XmlEleComponentValue);

            InsertHeightEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Height);
            InsertAreaEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Area);
            InsertVolumeEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Volume);
            InsertOffsetEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Offset);
            InsertWarpageEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Warpage);
            InsertRotationEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Rotation);
            InsertBridgeEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Bridge);
            InsertShapeEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Shape);
            InsertBalanceEle(ref AXmlDoc, ref XmlEleComponentValue, AStComponent.Value.Balance);
            return XmlEleComponent;
        }


        private XmlElement InsertBoradEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StBoard AStBorad)
        {
            XmlElement XmlEleBoard = AXmlDoc.CreateElement(AStBorad.nodeName());
            AXmlParentElement.AppendChild(XmlEleBoard);
            XmlEleBoard.SetAttribute("id", AStBorad._id.ToString());
            XmlEleBoard.SetAttribute("orderid", AStBorad._orderid.ToString());
            XmlEleBoard.SetAttribute("compcount", AStBorad._compcount.ToString());
            XmlEleBoard.SetAttribute("padcount", AStBorad._padcount.ToString());
            XmlEleBoard.SetAttribute("inspresult", AStBorad._inspresult.ToString());
            XmlEleBoard.SetAttribute("represult", AStBorad._represult.ToString());
            XmlEleBoard.SetAttribute("warnresult", AStBorad._warnresult.ToString());
            XmlEleBoard.SetAttribute("barcode", AStBorad._barcode.ToString());
            XmlEleBoard.SetAttribute("fc", AStBorad._fc.ToString());
            //value
            XmlElement XmlEleBoardValue = AXmlDoc.CreateElement(AStBorad.Value.nodeName());
            XmlEleBoard.AppendChild(XmlEleBoardValue);

            InsertHeightEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Height);
            InsertAreaEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Area);
            InsertVolumeEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Volume);
            InsertOffsetEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Offset);
            InsertWarpageEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Warpage);
            InsertRotationEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Rotation);
            InsertBridgeEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Bridge);
            InsertShapeEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Shape);
            InsertBalanceEle(ref AXmlDoc, ref XmlEleBoardValue, AStBorad.Value.Balance);
            return XmlEleBoard;
        }


        private XmlElement InsertHeightEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StHeight AStHeight)
        {
            XmlElement XmlHeightElement = AXmlDoc.CreateElement(AStHeight.nodeName());
            AXmlParentElement.AppendChild(XmlHeightElement);
            XmlHeightElement.SetAttribute("data", AStHeight._data.ToString(RS_DOUBLE_FORMATE));
            XmlHeightElement.SetAttribute("per", AStHeight._per.ToString(RS_DOUBLE_FORMATE));
            XmlHeightElement.SetAttribute("l_count", AStHeight._l_count.ToString());
            XmlHeightElement.SetAttribute("u_count", AStHeight._u_count.ToString());
            return XmlHeightElement;
        }

        private XmlElement InsertAreaEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StArea AStArea)
        {
            XmlElement XmlAreaElement = AXmlDoc.CreateElement(AStArea.nodeName());
            AXmlParentElement.AppendChild(XmlAreaElement);
            XmlAreaElement.SetAttribute("data", AStArea._data.ToString(RS_DOUBLE_FORMATE));
            XmlAreaElement.SetAttribute("per", AStArea._per.ToString(RS_DOUBLE_FORMATE));
            XmlAreaElement.SetAttribute("l_count", AStArea._l_count.ToString());
            XmlAreaElement.SetAttribute("u_count", AStArea._u_count.ToString());
            return XmlAreaElement;
        }

        private XmlElement InsertVolumeEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StVolume AStVolume)
        {
            XmlElement XmlVolumeElement = AXmlDoc.CreateElement(AStVolume.nodeName());
            AXmlParentElement.AppendChild(XmlVolumeElement);
            XmlVolumeElement.SetAttribute("data", AStVolume._data.ToString(RS_DOUBLE_FORMATE));
            XmlVolumeElement.SetAttribute("per", AStVolume._per.ToString(RS_DOUBLE_FORMATE));
            XmlVolumeElement.SetAttribute("l_count", AStVolume._l_count.ToString());
            XmlVolumeElement.SetAttribute("u_count", AStVolume._u_count.ToString());
            return XmlVolumeElement;
        }

        private XmlElement InsertOffsetEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StOffset AStOffset)
        {
            XmlElement XmlOffsetElement = AXmlDoc.CreateElement(AStOffset.nodeName());
            AXmlParentElement.AppendChild(XmlOffsetElement);
            XmlOffsetElement.SetAttribute("data_x", AStOffset._data_x.ToString(RS_DOUBLE_FORMATE));
            XmlOffsetElement.SetAttribute("data_y", AStOffset._data_y.ToString(RS_DOUBLE_FORMATE));
            XmlOffsetElement.SetAttribute("count_xp", AStOffset._count_xp.ToString());
            XmlOffsetElement.SetAttribute("count_xm", AStOffset._count_xm.ToString());
            XmlOffsetElement.SetAttribute("count_yp", AStOffset._count_yp.ToString());
            XmlOffsetElement.SetAttribute("count_ym", AStOffset._count_ym.ToString());
            return XmlOffsetElement;
        }

        private XmlElement InsertWarpageEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StWarpage AStWarpage)
        {
            XmlElement XmlWarpageElement = AXmlDoc.CreateElement(AStWarpage.nodeName());
            AXmlParentElement.AppendChild(XmlWarpageElement);
            XmlWarpageElement.SetAttribute("data", AStWarpage._data.ToString(RS_DOUBLE_FORMATE));
            return XmlWarpageElement;
        }

        private XmlElement InsertRotationEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StRotation AStRotation)
        {
            XmlElement XmlRotationElement = AXmlDoc.CreateElement(AStRotation.nodeName());
            AXmlParentElement.AppendChild(XmlRotationElement);
            XmlRotationElement.SetAttribute("data", AStRotation._data.ToString(RS_DOUBLE_FORMATE));
            return XmlRotationElement;
        }

        private XmlElement InsertBridgeEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StBridge AStBridge)
        {
            XmlElement XmlBridgeElement = AXmlDoc.CreateElement(AStBridge.nodeName());
            AXmlParentElement.AppendChild(XmlBridgeElement);
            XmlBridgeElement.SetAttribute("data", AStBridge._count.ToString());
            return XmlBridgeElement;
        }

        private XmlElement InsertShapeEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StShape AStShape)
        {
            XmlElement XmlShapeElement = AXmlDoc.CreateElement(AStShape.nodeName());
            AXmlParentElement.AppendChild(XmlShapeElement);
            XmlShapeElement.SetAttribute("data", AStShape._count.ToString());
            return XmlShapeElement;
        }

        private XmlElement InsertBalanceEle(ref XmlDocument AXmlDoc, ref XmlElement AXmlParentElement, ParimXmlScheme.StBalance AStBalance)
        {
            XmlElement XmlBalanceElement = AXmlDoc.CreateElement(AStBalance.nodeName());
            AXmlParentElement.AppendChild(XmlBalanceElement);
            XmlBalanceElement.SetAttribute("h_count", AStBalance._h_count.ToString());
            XmlBalanceElement.SetAttribute("v_count", AStBalance._v_count.ToString());
            XmlBalanceElement.SetAttribute("a_count", AStBalance._a_count.ToString());
            return XmlBalanceElement;
        }



        private string GetLaneNoStr(int AiLaneNo)
        {
            string strRet = "";
            switch (AiLaneNo)
            {
                case 1:
                    strRet = "F";
                    break;
                case 2:
                    strRet = "B";
                    break;
                default:
                    strRet = "F";
                    break;
            }
            return strRet;
        }


        private string GetInspResultStr(int AiResult)
        {
            string strRet = "";
            switch (AiResult)
            {
                case 0:
                    strRet = "Good";
                    break;
                case 1:
                    strRet = "NG";
                    break;
                case 2:
                    strRet = "Pass";
                    break;
                case 3:
                    strRet = "Unmeasured";
                    break;
                case 4:
                    strRet = "Skipped";
                    break;
                default:
                    strRet = "Good";
                    break;
            }
            return strRet;
        }




       


        private void SwapPad(ref InspectMainLib.Pad APadA,ref InspectMainLib.Pad APadB )  
        {  
            InspectMainLib.Pad padTemp = new InspectMainLib.Pad();
            padTemp = APadA;
            APadA = APadB;
            APadB = padTemp;
        }

        int PartitionPad(ref InspectMainLib.Pad[] APads, int low, int high, int AiSortType)  
        {  
            InspectMainLib.Pad privotKey = APads[low];
            while(low < high){
                if (AiSortType == 1)
                {
                    while (low < high && string.Compare(APads[high].pinNumber, privotKey.pinNumber, true) >= 0) --high;
                }
                else if(AiSortType == 2 )
                {
                    while (low < high && string.Compare(APads[high].componentID, privotKey.componentID, true) >= 0) --high;
                }
                
                SwapPad(ref APads[low], ref APads[high]);
                if (AiSortType == 1)
                {
                    while (low < high && string.Compare(APads[low].pinNumber, privotKey.pinNumber, true) <= 0) ++low;
                }
                else if (AiSortType == 2)
                {
                    while (low < high && string.Compare(APads[low].componentID, privotKey.componentID, true) <= 0) ++low;
                }
                SwapPad(ref APads[low], ref APads[high]); 
            }  
            return low;  
        }


        void QuickSortPad(ref InspectMainLib.Pad[] APads, int low, int high,int AiSortType)
        {  
            if(low < high){
                int privotLoc = PartitionPad(ref APads, low, high,AiSortType);
                QuickSortPad(ref APads, low, privotLoc - 1, AiSortType);
                QuickSortPad(ref APads, privotLoc + 1, high, AiSortType);  
            }  
        }

        void SortPadsByPinNumAndComponentId(ref InspectMainLib.Pad[] APads) 
        {
            QuickSortPad(ref APads, 0, APads.Length - 1, 1);
            int iStart = 0, iEnd = 0;
            string sPinNumberTemp = null;
            for (int i = 0; i < APads.Length; i++)
            {
                iEnd = i;
                if (string.IsNullOrEmpty(sPinNumberTemp))
                {
                    sPinNumberTemp = APads[i].pinNumber;
                }
                else if (!sPinNumberTemp.Equals(APads[i].pinNumber))
                {
                    QuickSortPad(ref APads, iStart, iEnd - 1, 2);
                    iStart = i;
                    sPinNumberTemp = APads[i].pinNumber;
                }
            }
            if (iStart != iEnd) QuickSortPad(ref APads, iStart, iEnd, 2);
        }
    }

    // ParmiXmlExport Class End
}
