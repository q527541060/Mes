﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using WSClnt;
using InspectMainLib;
using AppLayerLib;
using WSClnt.Chint;//add by tony 17.04.21
using System.Xml;
using System.Threading;
using ImgCSCoreIM;
using System.Windows.Forms;
using System.Reflection.Emit;
using System.Threading.Tasks;

///20181012 修改武汉富士康Tmp文件写入空字符，并加读入时的判断
///
/// 
namespace WSClnt
{

    public class HefeiBOE
    {
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "HefeiBOEEquipStatusBuffer";
        public static readonly string RS_EQUIPSTATUS_FILE_NAME = "eventdata";
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";

    }

    public class ZhenDingQHDBD
    {
        public static readonly string RS_DATE_FORMAT = "yyyy/MM/dd";
        public static readonly string RS_TIME_FORMAT = "HH:mm:ss";
        public static readonly string RS_DATE_FORMAT_SHOT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT_SHOT = "HHmmss";
        //public static readonly string RS_PNL_PARAM = "Line number|Compname Type|Area(%)|Area|standard Area|Height(%)|Height|standard Height|Volume(%)|Volume|standard Volume|XOffset|YOffset|PadSize(X)|PadSize(Y)|Result|Errcode|PinNum|Barcode|Date|Time|Board|key";
        //public static readonly string RS_BOARD_PARAM_NAME = "Line number|Compname|Compname Type|Area(%)|Area standard|Area|Area upper|Area lower|Height(%)|Height standard|Height|Height upper|Height lower|Volume(%)|Volume standard|Volume|Volume upper|Volume lower|XOffset|XOffset upper|XOffset lower|YOffset|YOffset upper|YOffset lower|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time|Board|Key";
        //public static readonly string RS_BOARD_PARAM_NAME = "Line number|Compname|Compname Type|Area(%)|Area standard|Area|Area USL|Area LSL|Height(%)|Height standard|Height|Height USL|Height LSL|Volume(%)|Volume standard|Volume|Volume USL|Volume LSL|XOffset|XOffset USL|XOffset LSL|YOffset|YOffset USL|YOffset LSL|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time|Board|Key";
        public static readonly string RS_BOARD_PARAM_NAME = "Model Name|Line number|Compname|Type|Area(%)|Area standard|Area USL|Area|Area LSL|Height(%)|Height standard|Height USL|Height|Height LSL|Volume(%)|Volume standard|Volume USL|Volume|Volume LSL|Xoffset USL|XOffset|Xoffset LSL|Yoffset USL|YOffset|Yoffset LSL|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time start|Time stop|Board|key|Group";
        public static readonly string RS_BOARD_BACKUP_NAME = "Model Name,Line number,Compname,Type,Area(%),Area standard,Area USL,Area,Area LSL,Height(%),Height standard,Height USL,Height,Height LSL,Volume(%),Volume standard,Volume USL,Volume,Volume LSL,Xoffset USL,XOffset,Xoffset LSL,Yoffset USL,YOffset,Yoffset LSL,PadSize(X),PadSize(Y),Average Height USL,Average Height,Average Height LSL,Result,Errcode,PinNum,Barcode,Date,Time start,Time stop,Board,key,Group";
        //public static readonly string RS_BARCODE_TEMPLATE = "Barcode";
        //public static readonly string RS_DATE_TEMPLATE = "Date";
        //public static readonly string RS_TIME_TEMPLATE = "Time";
        //public static readonly string RS_RESULT_TEMPLATE = "Resule";
        //public static readonly string RS_KEY_TEMPLATE = "Key";
        public static readonly string RS_PNL_BUFFER_FILE_NAME = "ZhenDingWSPnlBuffer";
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "ZhenDingWSEquipStatusBuffer";
        public static readonly string RS_HEARTBEAT = "State|Runtime";

        public static readonly string RS_EQUIP_STATUS = "State|Runtime|AlarmCode";
        //public static readonly string RS_DLL_NAMESPACE = "WebServiceQHDfox";
        public static readonly string RS_DLL_NAMESPACE = "webServiceSZ";
        public static readonly string RS_DLL_CLASSNAME = "ws";
        public static readonly string RS_DLL_FUNCTION = "wsFun";
        public static readonly int RI_HEARTBEAT_INTERVAL = 5000;
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        //public static readonly string RS_DLL_NAME = "WebServiceQHDfox.dll";
        public static readonly string RS_DLL_NAME = "webServiceSZ.dll";
        public static readonly string[] RS_ARRAY_RESULT = { "PASS", "FAIL", "RPASS", "UNMEASURED", "SKIP" };
        public static readonly string RS_LOGFILE_BASE_PATH = @"D:\EYSPI\Bin\SPILogs";
        public static readonly string[] FilePathYMD = { "yyyy", "MM", "dd" };
        public static readonly int I_MAX_PARALLEL_COUNT = 5;
    }


    public class ChenduFoxonn
    {
        public static readonly string RS_DLL_NAME = "FoxconnDataCollectionAPI.dll";
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        public static readonly string RS_VENDOR_NAME = "HOLLY";
        public static readonly string RS_DLL_NAMESPACE = "FoxconnDataCollectionAPI";
        public static readonly string RS_DLL_CLASSNAME = "LKShare";
        public static readonly string RS_DLL_TYPE_MachineEvent = "MachineEvent";
        public static readonly string RS_DLL_TYPE_StationInfo = "StationInfo";
        public static readonly string RS_DLL_FUNCTION_STATION_INFO = "WriteStationInfoTxt";
        public static readonly string RS_DLL_FUNCTION_MACHINE_EVENT = "WriteMachineEvent";
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "ChenduFoxconnWSEquipStatusBuffer";
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";

    }
    public class ZzFoxconnBD
    {
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "ZzFoxconnEquipStatusBuffer";
        //public static readonly string RS_LOG_FILE_HEAD = "Date,Time,EventCode,EventSubCode,EventMainMessage,EventSubMessage";
        public static readonly string RS_LOG_FILE_HEAD = "Date,Time,EventCode,EventMessage,MachineStatus,ErrorQty";
        public static readonly string RS_EQUIP_TYPE_AOI = "AOI";
        public static readonly string RS_EQUIP_TYPE_SPI = "SPI";
        public static readonly string RS_MANUFACTURE_NAME = "HOLLY";
    }

    //add by Tony 18.08.01
    public class WuhanFoxconnBD
    {
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "WuhanFoxconnEquipStatusBuffer";
        public static readonly string RS_LOG_FILE_HEAD = "Date,Time,EventCode,EventMessage,MachineStatus,ErrorQty";
        public static readonly string RS_EQUIP_TYPE_AOI = "AOI";
        public static readonly string RS_EQUIP_TYPE_SPI = "SPI";
        public static readonly string RS_MANUFACTURE_NAME = "HOLLY";
        public static readonly string RS_LOGFILE_BASE_PATH = @"D:\EYSPI\Bin\SPILogs";
    }

    public class ZhenDingBD
    {
        public static readonly string RS_DATE_FORMAT = "yyyy/MM/dd";
        public static readonly string RS_TIME_FORMAT = "HH:mm:ss";
        public static readonly string RS_DATE_FORMAT_SHOT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT_SHOT = "HHmmss";
        //public static readonly string RS_PNL_PARAM = "Line number|Compname Type|Area(%)|Area|standard Area|Height(%)|Height|standard Height|Volume(%)|Volume|standard Volume|XOffset|YOffset|PadSize(X)|PadSize(Y)|Result|Errcode|PinNum|Barcode|Date|Time|Board|key";
        //public static readonly string RS_BOARD_PARAM_NAME = "Line number|Compname|Compname Type|Area(%)|Area standard|Area|Area upper|Area lower|Height(%)|Height standard|Height|Height upper|Height lower|Volume(%)|Volume standard|Volume|Volume upper|Volume lower|XOffset|XOffset upper|XOffset lower|YOffset|YOffset upper|YOffset lower|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time|Board|Key";
        //public static readonly string RS_BOARD_PARAM_NAME = "Line number|Compname|Compname Type|Area(%)|Area standard|Area|Area USL|Area LSL|Height(%)|Height standard|Height|Height USL|Height LSL|Volume(%)|Volume standard|Volume|Volume USL|Volume LSL|XOffset|XOffset USL|XOffset LSL|YOffset|YOffset USL|YOffset LSL|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time|Board|Key";
        public static readonly string RS_BOARD_PARAM_NAME = "Model Name|Line number|Compname|Type|Area(%)|Area standard|Area USL|Area|Area LSL|Height(%)|Height standard|Height USL|Height|Height LSL|Volume(%)|Volume standard|Volume USL|Volume|Volume LSL|Xoffset USL|XOffset|Xoffset LSL|Yoffset USL|YOffset|Yoffset LSL|PadSize(X)|PadSize(Y)|Average Height USL|Average Height|Average Height LSL|Result|Errcode|PinNum|Barcode|Date|Time start|Time stop|Board|key|Group";
        public static readonly string RS_BOARD_BACKUP_NAME = "Model Name,Line number,Compname,Type,Area(%),Area standard,Area USL,Area,Area LSL,Height(%),Height standard,Height USL,Height,Height LSL,Volume(%),Volume standard,Volume USL,Volume,Volume LSL,Xoffset USL,XOffset,Xoffset LSL,Yoffset USL,YOffset,Yoffset LSL,PadSize(X),PadSize(Y),Average Height USL,Average Height,Average Height LSL,Result,Errcode,PinNum,Barcode,Date,Time start,Time stop,Board,key,Group";
        //public static readonly string RS_BARCODE_TEMPLATE = "Barcode";
        //public static readonly string RS_DATE_TEMPLATE = "Date";
        //public static readonly string RS_TIME_TEMPLATE = "Time";
        //public static readonly string RS_RESULT_TEMPLATE = "Resule";
        //public static readonly string RS_KEY_TEMPLATE = "Key";
        public static readonly string RS_PNL_BUFFER_FILE_NAME = "ZhenDingWSPnlBuffer";
        public static readonly string RS_EQUIPSTATUS_BUFFER_FILE_NAME = "ZhenDingWSEquipStatusBuffer";
        public static readonly string RS_HEARTBEAT = "State|Runtime";
        public static readonly string RS_EQUIP_STATUS = "State|Runtime|AlarmCode";
        public static readonly string RS_DLL_NAMESPACE = "webserviceSZ108";//modify by tony 180320
        public static readonly string RS_DLL_CLASSNAME = "webserviceSZ";//modify by tony 180320
        public static readonly string RS_DLL_FUNCTION = "wsFun";
        public static readonly int RI_HEARTBEAT_INTERVAL = 5000;
        public static readonly int RI_EQUIP_STATUS_INTERVAL = 5000;
        public static readonly string RS_DLL_NAME = "webserviceSZ108.dll";
        public static readonly string[] RS_ARRAY_RESULT = { "PASS", "FAIL", "RPASS", "UNMEASURED", "SKIP" };
        public static readonly string RS_LOGFILE_BASE_PATH = @"D:\EYSPI\Bin\SPILogs";
        public static readonly string[] FilePathYMD = { "yyyy", "MM", "dd" };
        public static readonly int I_MAX_PARALLEL_COUNT = 5;
    }

    public class SWTrulysEmi
    {
        public static readonly string RS_EXPORT_FILE_NAME_TEMPLATE = "SMT_<GROUPNAME>_<LINENAME>_<INSPECTDATE><INSPECTTIME>.txt";
        //modify by tony 17.8.29
        //public static readonly string RS_EXPORT_FILE_NAME_NOBARCODE_TEMPLATE = "<INSPECTDATE><INSPECTTIME>.txt";
        public static readonly string RS_GROUPNAME_TEMPLATE = "<GROUPNAME>";
        public static readonly string RS_LINENAME_TEMPLATE = "<LINENAME>";
        public static readonly string RS_INSPECTDATE_TEMPLATE = "<INSPECTDATE>";
        public static readonly string RS_INSPECTTIME_TEMPLATE = "<INSPECTTIME>";
        public static readonly string RS_SHIP = "SHIP";
        public static readonly string RS_SKIP = "SKIP";
        public static readonly string RS_NONE = "NONE";
        public static readonly string RS_MODEL_SPI = "SPI";
        public static readonly string[] RS_INSPECT_RESULT_TEMPLATE = { "0;0;1;0;", "0;0;0;1;", "0;1;0;0;" };//good/pass ; NG; SKIP
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string RS_NG_PAD_DETAIL_TEMPLATE = "<COMPONENTID>_<ARRAYID>;<PINNUMBER>;<PACKAGETYPE>;<DEFECTION>;0;0;0";
        public static readonly string RS_COMPONENTID_TEMPLATE = "<COMPONENTID>";
        public static readonly string RS_ARRAYID_TEMPLATE = "<ARRAYID>";
        public static readonly string RS_PINNUMBER_TEMPLATE = "<PINNUMBER>";
        public static readonly string RS_PACKAGETYPE_TEMPLATE = "<PACKAGETYPE>";
        public static readonly string RS_DEFECTION_TEMPLATE = "<DEFECTION>";
        public static readonly string RS_TOP_PANEL = "top";
        public static readonly string RS_BOTTOM_PANEL = "bottom";
        //public static readonly string RS_END_LINE = ";\r\n";


    }
    public class KCHoliTech  //葵冲合力泰
    {
        public static readonly string RS_EXPORT_FILE_NAME_TEMPLATE = "<BOARDBARCODE>_<BOARDRESULT>_<INSPECTDATETIME>_<LINENAME>.txt";
        public static readonly string RS_BOARD_BARCODE_TEMPLATE = "<BOARDBARCODE>";
        public static readonly string RS_BOARD_RESULT_TEMPLATE = "<BOARDRESULT>";
        public static readonly string RS_INSPECT_DATETIME_TEMPLATE = "<INSPECTDATETIME>";
        public static readonly string RS_LINE_NAME_TEMPLATE = "<LINENAME>";
        public static readonly string RS_LOCAT_DEFECT_TEMPLATE = "<COMPONENT>_<ARRAYID>_<PINNUMBER>;<USERDEFECTCODE>";
        public static readonly string RS_COMPONENT_TEMPLATE = "<COMPONENT>";
        public static readonly string RS_ARRAY_ID_TEMPLATE = "<ARRAYID>";
        public static readonly string RS_PIN_NUMBER_TEMPLATE = "<PINNUMBER>";
        public static readonly string RS_USER_DEFECT_CODE_TEMPLATE = "<USERDEFECTCODE>";
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string[] RS_BOARD_RESULT = { "PASS", "FAIL", "PASS", "UNMEASURED", "SKIPPED" };//modify Tony 17.6.12
    }

    public class EkraXml
    {
        public static readonly string Node_FeedbackInspResult = "FeedbackInspResult";
        public static readonly string Node_Message = "Message";
        public static readonly string Node_DateAndTime = "DateAndTime";
        public static readonly string Node_Machine = "Machine";
        public static readonly string Node_Name = "Name";
        public static readonly string Node_Reference = "Reference";
        public static readonly string Node_Process = "Process";
        public static readonly string Node_ProductId = "ProductId";
        public static readonly string Node_PanelId = "PanelId";
        public static readonly string Node_PanelStatus = "PanelStatus";

        public static readonly string Node_Units = "Units";
        public static readonly string Node_Distance = "Distance";
        public static readonly string Node_Angle = "Angle";
        public static readonly string Node_Time = "Time";
        public static readonly string Node_Stretch = "Stretch";

        public static readonly string Node_CorrectionFeedback = "CorrectionFeedback";
        public static readonly string Node_Fiducials = "Fiducials";
        public static readonly string Prop_Count = "Count";

        public static readonly string Node_Fiducial = "Fiducial";
        public static readonly string Prop_Name = "Name";
        public static readonly string Node_X = "X";
        public static readonly string Node_Y = "Y";
        public static readonly string Prop_Origin = "Origin";
        public static readonly string Prop_Offset = "Offset";

        public static readonly string Node_PrinterSqueegeeDir = "PrinterSqueegeeDir";
        public static readonly string Node_SpiSqueegeeDir = "SpiSqueegeeDir";

        public static readonly string Node_Defect = "Defect";
        public static readonly string Prop_TotalNum = "TotalNum";
        public static readonly string Prop_DefectNum = "DefectNum";

        public static readonly string Node_Volume = "Volume";
        public static readonly string Prop_Num = "Num";

        public static readonly string Node_High = "High";
        public static readonly string Node_Low = "Low";

        public static readonly string Node_Height = "Height";
        public static readonly string Node_Area = "Area";
        public static readonly string Node_Bridge = "Bridge";

        public static readonly string Node_Command = "Command";
        public static readonly string Node_PcbResult = "PcbResult";

        public static readonly string RS_DATE_AND_TIME = "yyyy-MM-ddTHH:mm:ss.fff";
        public static readonly string RS_DATE_AND_TIME_FILE_NAME = "yyyy-MM-dd-HH-mm-ss";
        public static readonly string RS_XML_EXT = ".xml";
        public static readonly string RS_NAME_SPI = "SPI";
        public static readonly string RS_NULL = "NULL";
        public static readonly string RS_Inspected = "Inspected";
        public static readonly string RS_EMPTY = "";
        public static readonly string RS_MM = "mm";
        public static readonly string RS_DEG = "deg";
        public static readonly string RS_SECONDS = "seconds";
        public static readonly string RS_PERC = "%";
        public static readonly string RS_FID_NAME_PERFIX = "Fid_";
        public static readonly string RS_FLOAT_PRECISION = "0.0000";
        public static readonly string RS_ZERO = "0";
        public static readonly string RS_CLEAN = "X";
        public static readonly string RS_NOCLEAN = "NoUse";
        public static readonly string RS_GOOD = "GOOD";


    }

    public class FEIGE
    {
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string RS_MACHINE_TYPE = "SPI";
        public static readonly string[] RS_RESULT = { "OK", "NG", "PASS", "", "" };
        public static readonly string RS_BUFFER_FILE_NAME = "FeiGeSaveBuffer";
        public static readonly string RS_COLUMN_TITLE = "barcode,date,time,result";

    }
    public class JXHiPAD //江西海派
    {
        public static readonly string RS_COLUMN_TITLE_MAIN = "JOB PATH,BARCODE,INDEX,DATE,S.TIME,E.TIME,CYCLE,JOB,RESULT,USER,LOTINFO,MACHINE";
        public static readonly string RS_COLUMN_TITLE_DETAIL = "Barcode,BoardID,Component,PadID,Pin Number,Height,Area,Area(%),Volume,Volume(%),OffsetX,OffsetY,Result";
        public static readonly string[] RS_PAD_RESULT = { "E.Area", "E.Volume", "E.Volume", "E.Height", "E.Height", "E.Area", "E.Area", "E.Offset", "E.Offset", "E.Bridge", "E.Height", "E.Bridge", "E.Height", "E.Bridge", "E.Area" };
        public static readonly string[] RS_RESULT = { "GOOD", "NG", "PASS", "UNMEASURED", "SKIPPED" };
        public static readonly string RS_DATE_FORMAT = "MM/dd/yyyy";
        public static readonly string RS_TIME_FORMAT = "HH:mm:ss";
        public static readonly string RS_EXPORT_FILE_NAME_TEMPLATE = "<INDEX>_<BARCODE>.csv";
        public static readonly string[] RS_FILE_NAME_REPLACE = { "<INDEX>", "<BARCODE>" };
        public static readonly string RS_OPER = "op";

    }

    public class CQXiSheng //重庆西胜
    {
        //public string ProgramName = "";
        //public string Barcode = "";
        //public string LineName = "";
        //public string Ship = "SHIP";
        //public string EquipModel = "";
        //public string ProductOrder = "NONE";
        //public string InspectDate = "";//format yyyymmdd
        //public string InspectTime = "";//format hhmmss
        //public string InspectResult = "";       
        //public string Side = "";
        //public string AllPadCount = "";
        //public string NGPadCount = "";
        //public string[] NGPadDetdail;
        public static readonly string[] RS_INSPECT_RESULT_TEMPLATE = { "0;0;1;0", "0;0;0;1" };
        public static readonly string RS_NG_PAD_DETAIL_TEMPLATE = "<COMPONENTID>_<ARRAYID>;<PACKAGETYPE>";
        public static readonly string RS_EXPORT_FILE_NAME_TEMPLATE = "<LINENAME>_<INSPECTDATETIME>_<ARRAYID>.txt";
        public static readonly string RS_COMPONENTID = "<COMPONENTID>";
        public static readonly string RS_ARRAYID = "<ARRAYID>";
        public static readonly string RS_PACKAGETYPE = "<PACKAGETYPE>";
        public static readonly string RS_LINENAME = "<LINENAME>";
        public static readonly string RS_INSPECTDATETIME = "<INSPECTDATETIME>";//format yyyymmddhhmmss
        public static readonly string RS_DATE_FORMAT = "yyyyMMdd";
        public static readonly string RS_TIME_FORMAT = "HHmmss";
        public static readonly string RS_END_LINE = ";\r\n";
    }

    public class WZChint //温州正泰
    {
        public static readonly string FileFullNameTemplate = "<BARCODE>_<INSPECTTIME>.csv";
        public static readonly string INSPECTTIME = "<INSPECTTIME>";
        public static readonly string BARCODE = "<BARCODE>";
        public static readonly string FileNameTimeFormat = "yyyyMMddHHmmss";
        public static readonly string RS_COLUMN_TITLE = "生产作业单ID,条形码,检测项目（唯一标识）,位置,检测结果,检测结论,元器件名称,图片地址";
        public static readonly string RS_GOOD = "GOOD";
        public static readonly string RS_PASS = "PASS";
        public static readonly string RS_FAIL = "FAIL";

    }

    public class ZhengZhouFoxconn //郑州富士康
    {
        public static readonly string[] FilePathCheck = { "yyyy", "MM", "dd" };

        public static readonly string FileFullNameTemplate = "<BARCODE>_<INSPECTTIME>.csv";//"<INSPECTTIME>_<BARCODE>.csv";
        public static readonly string INSPECTTIME = "<INSPECTTIME>";
        public static readonly string BARCODE = "<BARCODE>";
        public static readonly string FileFullPath = @"\{0}\{1}\{2}";
        public static readonly string FileNameTimeFormat = "yyyyMMddHHmmss";
        public static readonly string RS_COLUMN_TITLE = "元件名,焊盘编号,料号,条码,面积百分比,体积百分比,高度百分比,高度实际值,面积实际值,体积实际值,焊盘X方向的大小,焊盘Y方向的大小,X偏移,Y偏移,判断结果,引脚编号,测试日期,测试时间,拼板编号";//Q.F.2017.08.10
        // add by Tony 17.9.19
        public static readonly string FileExtension = "csv";
    }


    public class WuHanFoxconnDB //foxconn VI
    {
        public static readonly string RS_DATETIME_FORMAT_CHAR14 = "yyyyMMddHHmmss";
        public static readonly string RS_DATETIME_FORMAT_CHAR19_SLASH = "yyyy/M/d HH:mm:ss";
        public enum EM_InspectResult
        {
            PASS = 0,
            NG = 1,
            RPASS = 2
        }
    }
    public class SzZechinFormat //深圳则成电子
    {
        public static readonly string RS_COLUMN_TITLE = "PN（测试程序文件）,SN（PCB条码）,Testdate（测试时间）,Result（测试结果）,Result2（人工测试结果）,不良位置,不良点位,不良类型,不良信息,图片名称";
        public static readonly string RS_CSV_EXT = ".csv";
        public static readonly string RS_DATETIME_FORMAT_FILENAME = "yyyyMMddHHmmss";
        public static readonly string RS_DATETIME_FORMAT_CONTENT = "yyyy/M/d HH:mm";
        public static readonly string RS_FIAL = "Fail";
        public static readonly string RS_PASS = "Pass";
    }

    public class AegisTextFileFormat
    {
        public static readonly string RS_PanelBarcode = "PanelBarcode:";
        public static readonly string RS_ImageBarcode = "ImageBarcode:";
        public static readonly string RS_TestProgram = "TestProgram:";
        public static readonly string RS_TestProgramVer = "TestProgramVer:";
        public static readonly string RS_Operator = "Operator:";
        public static readonly string RS_TestName = "TestName:";
        public static readonly string RS_TestType = "TestType:";
        public static readonly string RS_TestDesc = "TestDesc:";
        public static readonly string RS_Date = "Date:";
        public static readonly string RS_Time = "Time:";
        public static readonly string RS_Result = "Result:";
        public static readonly string RS_Value = "Value:";
        public static readonly string RS_FailDesc = "FailDesc:";
        public static readonly string RS_Units = "Units:";
        public static readonly string RS_Nominal = "Nominal:";
        public static readonly string RS_LowerLimit = "LowerLimit:";
        public static readonly string RS_UpperLimit = "UpperLimit:";
        public static readonly string RS_DATE_FORMAT = "MM/dd/yyyy";
        public static readonly string RS_TIME_FORMAT = "HH:mm:ss";
        public static readonly string RS_AEGIS_SEPARATE = "~#~";
        public static readonly string RS_DETECT_FAIL = "FAIL";
    }
    public class LonghuaFoxconnFormat //龙华富士康
    {
        public string sInspectStartTime = "";
        public string sInspectEndTime = "";
        // public string sInspectEndTimeFirst = "";
        public string sBarcode = "";
        public string sLineName = "";
        public string sUserName = "Holly";
        public string sRecipeName = "";
        public enum EM_InspectResult
        {
            PASS = 0,
            FAIL = 1
        }
        public EM_InspectResult emInspectRes = new EM_InspectResult();
        public int iAlarmPadCounts = 0;
        public int iNgPadCounts = 0;

        public const string sPadInfoHeaderLine = "Error flag,Recipe name,Paste ID,CAD link Gerber,Error code,Multi Number";
        public struct ST_PadInfo
        {
            public string sPadErrorFlag;//Pass,NG..    
            public string sRecipeName;
            public string sPasteId;
            public string sPadComponentName;
            public string sPadErrorCode;
            public string sPadArrayIndex;
        }
        public ST_PadInfo[] padInfo;

        //
        public static string RS_DATETIME_FORMAT_FIRST = "yyyy-M-d-HH:mm:ss";
        public static string RS_DATETIME_FORMAT_NORMAL = "MMddyyHHmmss";
        public static string RS_COLON = ";";
        public static string RS_3DX_EXT = ".3dx";
    }
    public class WuhanFoxconnFormat //武汉富士康
    {
        public string sInspectStartTime = "";
        public string sInspectEndTime = "";
        public string sInspectEndTimeFirst = "";
        public string sBarcode = "";
        public string sLineName = "";
        public string sUserName = "sinictek";
        public string sRecipeName = "";
        public enum EM_InspectResult
        {
            PASS = 0,
            FAIL = 1
        }
        public enum EM_PadInspectResult
        {
            Pass = 0,
            BAD = 1
        }
        public EM_InspectResult emInspectRes = new EM_InspectResult();
        public int iAlarmPadCounts = 0;
        public int iNgPadCounts = 0;

        public const string sPadInfoHeaderLine = "Error flag,Recipe name,Paste ID,CAD link Gerber,Error code,Multi Number";
        public struct ST_PadInfo
        {
            public string sPadErrorFlag;//Pass,NG..    
            public string sRecipeName;
            public string sPasteId;
            public string sPadComponentName;
            public string sPadErrorCode;
            public string sPadArrayIndex;
        }
        public ST_PadInfo[] padInfo;

        //
        public static string RS_DATETIME_FORMAT_FIRST = "yyyy-M-d-HH:mm:ss";
        public static string RS_DATETIME_FORMAT_NORMAL = "MMddyyHHmmss";
        public static string RS_COLON = ";";
        public static string RS_3DX_EXT = ".3dx";
    }

    public class TransDataEventArgs : EventArgs
    {
        public string Message;
        public string FromModule;

        public TransDataEventArgs(string AMessage, string AFromModule)
        {
            this.Message = AMessage;
            this.FromModule = AFromModule;
        }
    }

    public class DataExportTony
    {
        private readonly string RS_SPLIT = ",";

        private readonly string RS_LineEnd = "\r\n";

        private readonly string RS_EMPTY = "";

        private readonly string RS_UNDERLINE = "_";

        private readonly string RS_SLASH = "\\";

        private const string RS_DATE_MMDDYYYY_FORMAT = "MMddyyyy";

        private const string RS_TIME_HHMMSS_FORMAT = "HHmmss";


        private const string RS_DATETIME_YYYYMMDDHHMMSS_FORMAT = "yyyyMMddHHmmss";

        private const string RS_XML_EXT = ".xml";

        private const string RS_TXT_EXT = ".txt";

        private const string _strTmpFileDir = "D:\\EYSPI\\DataExport\\TmpDir";

        private const string RS_DATAEXPORTTEMPFILE = "DataExp.Tmp";

        private readonly string RS_NOREAD = "NOREAD";

        private readonly string RS_DATAEXPORTMsg = "WSClnt_DataExport:  ";

        private const string RS_DEFAULT_SPI_OPERATOR = "manager";
        private readonly string RS_PERC = "%";//Q.F.2017.04.21
        private readonly string RS_FLOATFORMAT_1Bit = "0.0";//Q.F.2017.04.21
        private readonly string RS_FLOATFORMAT_3Bit = "#0.000";

        private readonly string RS_FLOATFORMAT_4Bit = "#0.0000";

        private readonly string RS_FLOATFORMAT_6Bit = "#0.000000";

        private readonly string RS_TEST_PROGRAM = "SPI test";

        private readonly string RS_TEST_PROGRAM_VERSION = "1.0";

        private readonly string RS_TEST_TYPE_HEIGHT = "Height";

        private readonly string RS_TEST_TYPE_AREA = "Area";

        private readonly string RS_TEST_TYPE_VOLUME = "Volume";

        private readonly string RS_TEST_TYPE_OFFSET_X = "OffsetX";

        private readonly string RS_TEST_TYPE_OFFSET_Y = "OffsetY";

        private readonly string RS_TEST_TYPE_BRIDGE = "Bridge";

        private readonly string RS_TEST_TYPE_SHAPE = "Shape";

        private readonly string RS_NA = "NA";

        private Basefunction _baseFun;

        public event EventHandler<TransDataEventArgs> UploadDataEvent;


        public DataExportTony()
        {
            _baseFun = new Basefunction();
            if (!System.IO.Directory.Exists(_strTmpFileDir))
            {
                System.IO.Directory.CreateDirectory(_strTmpFileDir);
            }
        }

        ~DataExportTony() { }

        //臻鼎 秦皇岛 大数据-------------------start


        //心跳连接

        Thread _zhenDingQHDBDHbThread = null;

        //UI run method to start thread
        public void ZhenDingQHDBDHeartbeatStart(AppSettingData AappSettingData)
        {

            if (_zhenDingQHDBDHbThread != null)
            {
                ThreadState state = _zhenDingQHDBDHbThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
            }
            string sCompanyID = AappSettingData.stMonitorSystemParams.strLogCompany;
            string sDeviceTypeID = AappSettingData.stMonitorSystemParams.strLogDeviceType;
            string sEquipID = AappSettingData.stMonitorSystemParams.strLogEquipID;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogHeartBeatInterval;

            if (iInterval == 0) return;

            object[] objParameters = new object[5];
            objParameters[0] = sCompanyID;
            objParameters[1] = sDeviceTypeID;
            objParameters[2] = sEquipID;
            objParameters[3] = iInterval <= 0 ? ZhenDingQHDBD.RI_HEARTBEAT_INTERVAL : iInterval;
            objParameters[4] = sDllPath;
            _zhenDingQHDBDHbThread = new Thread(new ParameterizedThreadStart(StartRunZhenDingQHDBDHeartbeat));
            _zhenDingQHDBDHbThread.IsBackground = true;
            _zhenDingQHDBDHbThread.Start(objParameters);
        }


        public void ZhenDingQHDBDHeartbeatStop()
        {
            try
            {
                if (_zhenDingQHDBDHbThread != null && (_zhenDingQHDBDHbThread.ThreadState == ThreadState.Running || _zhenDingQHDBDHbThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingQHDBDHbThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingQHDBDHeartbeatStop error" + ex.Message);
            }
        }

        private void StartRunZhenDingQHDBDHeartbeat(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 5) return;

            string sCompanyID = (string)objParameters[0];
            string sDeviceTypeID = (string)objParameters[1];
            string sEquipID = (string)objParameters[2];
            int iHeartBeatInter = (int)objParameters[3];
            string sDllPath = (string)objParameters[4];

            if (string.IsNullOrEmpty(sCompanyID) || string.IsNullOrEmpty(sDeviceTypeID)
                || string.IsNullOrEmpty(sEquipID) || string.IsNullOrEmpty(sDllPath))
            {
                return;
            }
            int iSleep = iHeartBeatInter;
            string sDllPathName = Path.Combine(sDllPath, ZhenDingQHDBD.RS_DLL_NAME);

            DllInvoke dllInvoke = new DllInvoke();

            object[] paramObject = new object[6];
            paramObject[0] = sCompanyID;
            paramObject[1] = sDeviceTypeID;
            paramObject[2] = sEquipID;


            while (true)
            {
                string sNowTime = DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT + " " + ZhenDingQHDBD.RS_TIME_FORMAT);
                paramObject[3] = ZhenDingQHDBD.RS_HEARTBEAT;
                paramObject[4] = ("R|" + sNowTime);
                paramObject[5] = sNowTime;
                try
                {
                    string sErrorReturn = "";
                    object callReturn = dllInvoke.InvokeCLRDll(sDllPathName, ZhenDingQHDBD.RS_DLL_NAMESPACE, ZhenDingQHDBD.RS_DLL_CLASSNAME, ZhenDingQHDBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);

                    if (string.Equals(callReturn.ToString(), "Dll Call Error!"))
                    {
                        Console.WriteLine("Error dll or method not find:" + sErrorReturn);
                    }
                    else
                    {
                        if (callReturn.ToString().IndexOf("OK") >= 0)
                        {
                            Console.WriteLine("Upload success :" + callReturn);
                        }
                        else if (callReturn.ToString().IndexOf("NG") >= 0)
                        {
                            Console.WriteLine("DLL call return error: " + callReturn);
                        }
                        else
                        {
                            Console.WriteLine("Unknow error from dll return");
                        }

                    }
                }
                //add by tony 180320
                catch (Exception ex)
                {
                    Console.WriteLine("Unknow error from dll calling" + ex.InnerException);
                }
                Thread.Sleep(iSleep);
            }
        }


        //设备状态
        Thread _zhenDingQHDBDEsThread = null;

        //UI run method to start thread
        public void ZhenDingQHDBDEquipStatusStart(string AstrDir, byte AbyLaneNo, AppSettingData AappSettingData)
        {

            if (_zhenDingQHDBDEsThread != null)
            {
                ThreadState state = _zhenDingQHDBDEsThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
            }


            //Q.F.2018.03.20
            string sCompanyID = AappSettingData.stMonitorSystemParams.strLogCompany;
            string sDeviceTypeID = AappSettingData.stMonitorSystemParams.strLogDeviceType;
            string sEquipID = AappSettingData.stMonitorSystemParams.strLogEquipID;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogHeartBeatInterval;


            object[] objParameters = new object[7];
            objParameters[0] = AstrDir;
            objParameters[1] = AbyLaneNo;
            objParameters[2] = sCompanyID;
            objParameters[3] = sDeviceTypeID;
            objParameters[4] = sEquipID;
            objParameters[5] = iInterval <= 0 ? ZhenDingQHDBD.RI_EQUIP_STATUS_INTERVAL : iInterval;
            objParameters[6] = sDllPath;
            _zhenDingQHDBDEsThread = new Thread(new ParameterizedThreadStart(StartRunZhenDingQHDBDEquipStatus));
            _zhenDingQHDBDEsThread.IsBackground = true;
            _zhenDingQHDBDEsThread.Start(objParameters);
        }

        public void ZhenDingQHDBDEquipStatusStop()
        {
            try
            {
                if (_zhenDingQHDBDEsThread != null && (_zhenDingQHDBDEsThread.ThreadState == ThreadState.Running || _zhenDingQHDBDEsThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingQHDBDEsThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingQHDBDHeartbeatStop error" + ex.Message);
            }
        }

        //臻鼎秦皇岛 设备状态
        private void StartRunZhenDingQHDBDEquipStatus(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 7) return;

            string AstrDir = (string)objParameters[0];
            byte AbyLaneNo = (byte)objParameters[1];
            string sCompanyID = (string)objParameters[2];
            string sDeviceTypeID = (string)objParameters[3];
            string sEquipID = (string)objParameters[4];
            int iEquipStatusInter = (int)objParameters[5];
            string sDllPath = (string)objParameters[6];

            int iSleep = iEquipStatusInter;
            string sDllPathName = Path.Combine(sDllPath, ZhenDingQHDBD.RS_DLL_NAME);

            DllInvoke dllInvoke = new DllInvoke();

            object[] paramObject = new object[6];
            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();

            string bufferFile = Path.Combine(_strTmpFileDir, ZhenDingQHDBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".temp");
            FileStream fs = null;
            System.IO.StreamWriter streamWrt = null;
            string sLastUploadTime = "";
            if (!File.Exists(bufferFile))//tony 2018.03.20
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(ZhenDingQHDBD.RS_DATE_FORMAT_SHOT + ZhenDingQHDBD.RS_TIME_FORMAT_SHOT);
                }
            }
            //add tony 20180911
            FileStream fsLogFile = null;
            if (!Directory.Exists(Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
            {
                Directory.CreateDirectory(Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
            }
            FileStream fsUserViewLogFile = null;


            string logFilePath = "";
            string userViewLogFilePath = "";
            Hashtable uploadHashTable = new Hashtable();
            while (true)
            {
                if (uploadHashTable.Count > 100)
                {
                    uploadHashTable.Clear();
                }
                try
                {
                    string sql = "select " +
                                " CAST(t.Start AS CHAR)," +
                                " CAST(t.Run AS CHAR)," +
                                " CAST(t.Stop AS CHAR)," +
                                " CAST(t.Idle AS CHAR)," +
                                " CAST(t.Init AS CHAR)," +
                                " CAST(t.ReqSig AS CHAR)," +
                                " CAST(t.InBoard AS CHAR)," +
                                " CAST(t.InspectBoard AS CHAR)," +
                                " CAST(t.InspectFinish AS CHAR)," +
                                " CAST(t.ReadyOut AS CHAR)," +
                                " CAST(t.BVSig AS CHAR)," +
                                " CAST(t.Error AS CHAR)," +
                                " ifnull(t.ErrContent,'')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y/%m/%d')," +
                                " DATE_FORMAT(t.UpdateTime,'%T')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S') " +
                                " from TBEquipStatus t where t.UpdateTime > STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime desc ";


                    //add tony to log zhending equip upload 20180911


                    string logFileName = "ZhendingEquipStatus_" + DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT_SHOT) + ".log";
                    logFilePath = Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", logFileName);

                    string userViewLogFileName = "ZhendingEquipStatus_simple_" + DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT_SHOT) + ".log";
                    userViewLogFilePath = Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", userViewLogFileName);

                    if (!File.Exists(logFilePath))
                    {
                        fsLogFile = File.Create(logFilePath);
                        fsLogFile.Flush();
                        fsLogFile.Close();
                        fsLogFile.Dispose();
                    }

                    if (!File.Exists(userViewLogFilePath))
                    {
                        fsUserViewLogFile = File.Create(userViewLogFilePath);
                        fsUserViewLogFile.Flush();
                        fsUserViewLogFile.Close();
                        fsUserViewLogFile.Dispose();
                    }

                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sql);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：TBEquipStatus return data count：" + dt.Rows.Count);
                            streamWrtLog.Flush();
                            streamWrtLog.Close();
                        }
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;
                            string sUpdateTime;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);
                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + string.Format(" 臻鼎QHD 数据库返回：sMainCode={0}, sSubCode={1},sMainMessage={2}, sSubMessage={3},sUpdateTime={4}", sMainCode, sSubCode, sMainMessage, sSubMessage, sUpdateTime));
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }
                            //modify tony 20180827
                            string[] RStatusSubCodes = new string[] { "002", "003", "004", "005", "006" };
                            string state = "";
                            string runtime = (string)dt.Rows[i][15];
                            string alarmCode = "NULL";
                            if (string.Equals(sMainCode, "002") && RStatusSubCodes.Contains(sSubCode))
                            {
                                state = "R";
                            }
                            else if (string.Equals(sMainCode, "003"))
                            {
                                state = "A";
                                alarmCode = (string)dt.Rows[i][12];
                            }
                            else
                            {
                                state = "H";
                            }


                            if (uploadHashTable.Contains(runtime))
                            {
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD此状态已上传：(" + state + "|" + runtime + "|" + alarmCode + ") Skip");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }

                                fs = new FileStream(bufferFile, FileMode.Create);
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();
                                Thread.Sleep(iSleep);
                                continue;
                            }

                            fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD得到状态：(" + state + "|" + runtime + "|" + alarmCode + ")");
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }

                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：ready to upload data (sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode,sDllPathName)" + sCompanyID + "|" + sDeviceTypeID + "|" + sEquipID + "|" + state + "|" + runtime + "|" + alarmCode + "|" + sDllPathName);
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }
                            string dllCallReturnString = "";
                            if (ZhenDingQHDWSUploadEquipStatus(sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode, sDllPathName, out dllCallReturnString))
                            {

                                fs = new FileStream(bufferFile, FileMode.Create);
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();

                                fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);

                                uploadHashTable.Add(runtime, state);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD上传数据结果：成功");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }


                                fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：finish  upload data Success" + dllCallReturnString);
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }
                            }
                            else
                            {
                                if (UploadDataEvent != null)
                                {
                                    UploadDataEvent.Invoke(this, new TransDataEventArgs("sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode,sDllPathName \n" + sCompanyID + "," + sDeviceTypeID + "," + sEquipID + "," + state + "," + runtime + "," + alarmCode + "," + sDllPathName + "\n" + dllCallReturnString, "臻鼎秦皇島DLL上傳設備狀態數據錯誤"));
                                }
                                fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD上传数据结果：出错");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }
                                fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：finish  upload data Fail:" + dllCallReturnString);
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：TBEquipStatus return data count (" + sLastUploadTime + ")：0");
                            streamWrtLog.Flush();
                            streamWrtLog.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("DataExport StartRunZhenDingQHDBDEquipStatus error:" + ex.Message);
                    fsLogFile = new FileStream(logFilePath, FileMode.Append);
                    using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                    {
                        streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD DLL上传设备状态数据：Catch Exception ：" + ex.Message);
                        streamWrtLog.Flush();
                        streamWrtLog.Close();
                    }
                }
                finally
                {
                    //Q.F.2018.03.20
                    if (streamWrt != null)
                        streamWrt.Close();
                    if (fs != null)
                    {
                        fs.Close();
                        fs.Dispose();
                    }

                    if (fsLogFile != null)
                    {
                        fsLogFile.Close();
                        fsLogFile.Dispose();
                    }
                }

                Thread.Sleep(iSleep);
            }
        }


        private bool ZhenDingQHDWSUploadEquipStatus(string sCompanyID, string sDeviceTypeID, string sEquipID, string sState, string sRunTime, string sAlarmCode, string sDllPathName, out string sDllReturnString)
        {
            //string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + ZhenDingBD.RS_TIME_FORMAT);
            //modify by tony 180323
            string sNowTime = DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT + " " + ZhenDingQHDBD.RS_TIME_FORMAT);
            DllInvoke dllInvoke = new DllInvoke();
            sDllReturnString = "";
            object[] paramObject = new object[6];
            paramObject[0] = (string)sCompanyID;
            paramObject[1] = (string)sDeviceTypeID;
            paramObject[2] = (string)sEquipID;
            paramObject[3] = (string)ZhenDingQHDBD.RS_EQUIP_STATUS;
            paramObject[4] = sState + "|" + sRunTime + "|" + sAlarmCode;
            paramObject[5] = (string)sNowTime;
            string sErrorReturn = "";
            string strCallReturn = (string)dllInvoke.InvokeCLRDll(sDllPathName, ZhenDingQHDBD.RS_DLL_NAMESPACE, ZhenDingQHDBD.RS_DLL_CLASSNAME, ZhenDingQHDBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);
            sDllReturnString = strCallReturn + sErrorReturn;
            if (string.IsNullOrEmpty(strCallReturn) || !string.Equals(strCallReturn, "OK"))
            {
                return false;
            }
            return true;
        }

        //板数据

        Thread _zhenDingQHDBDBoardThread = null;
        //start uploadDoard Thread
        public void StartZhenDingQHDBDBoard(string sCompanyID, string sDeviceTypeID, string sEquipID, string dllPath, string bufferFlag, int iMaxParallelCount)
        {
            if (_zhenDingQHDBDBoardThread != null)
            {
                ThreadState state = _zhenDingQHDBDBoardThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;

            }

            object[] objParameters = new object[6];
            objParameters[0] = sCompanyID;
            objParameters[1] = sDeviceTypeID;
            objParameters[2] = sEquipID;
            objParameters[3] = Path.Combine(dllPath, ZhenDingQHDBD.RS_DLL_NAME);
            objParameters[4] = bufferFlag;
            objParameters[5] = (iMaxParallelCount <= 0 || iMaxParallelCount >= 10) ? ZhenDingQHDBD.I_MAX_PARALLEL_COUNT : iMaxParallelCount;
            _zhenDingQHDBDBoardThread = new Thread(new ParameterizedThreadStart(StartZhenDingQHDBDBoardThread));
            _zhenDingQHDBDBoardThread.IsBackground = true;
            _zhenDingQHDBDBoardThread.Start(objParameters);

        }
        //end uploadDoard Thread
        public void ZhenDingQHDBDUploadBoardStop()
        {
            try
            {
                if (_zhenDingQHDBDBoardThread != null && (_zhenDingQHDBDBoardThread.ThreadState == ThreadState.Running || _zhenDingQHDBDBoardThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingQHDBDBoardThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingQHDBDUploadBoardStop error" + ex.Message);
            }
        }

        // upload board thread function
        private void StartZhenDingQHDBDBoardThread(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            string sCompanyID = (string)objParameters[0];
            string sDeviceTypeID = (string)objParameters[1];
            string sEquipID = (string)objParameters[2];
            string dllPathName = (string)objParameters[3];
            string bufferUpload = (string)objParameters[4];
            int iMaxParallelCount = (int)objParameters[5];
            //object[] paramObject = new object[6];
            //paramObject[0] = (string)sCompanyID;
            //paramObject[1] = (string)sDeviceTypeID;
            //paramObject[2] = (string)sEquipID;
            //paramObject[3] = (string)ZhenDingQHDBD.RS_BOARD_PARAM_NAME;
            DllInvoke dllInvoke = new DllInvoke();
            FileStream fsLogFile = null;
            if (!Directory.Exists(Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
            {
                Directory.CreateDirectory(Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
            }
            string logFilePath = Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", "ZhendingUploadBoard.log");
            if (!File.Exists(logFilePath))
            {
                fsLogFile = File.Create(logFilePath);
            }
            //add by tony 180808
            ParallelOptions parallelOpt = new ParallelOptions();
            parallelOpt.MaxDegreeOfParallelism = iMaxParallelCount;
            while (true)
            {
                TimeSpan nowDateTs = new TimeSpan(DateTime.Now.Ticks);
                string sNowTime = DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT + " " + ZhenDingQHDBD.RS_TIME_FORMAT);

                try
                {
                    if (Directory.Exists(_strTmpFileDir))
                    {
                        DirectoryInfo tmpDirInfo = new DirectoryInfo(_strTmpFileDir);
                        FileInfo[] arrFileInfo = tmpDirInfo.GetFiles(ZhenDingQHDBD.RS_PNL_BUFFER_FILE_NAME + "_*.tmp", SearchOption.TopDirectoryOnly);

                        if (arrFileInfo != null && arrFileInfo.Length > 0)
                        {
                            for (int i = 0; i < arrFileInfo.Length; i++)
                            {
                                FileInfo fInfo = arrFileInfo[i];
                                TimeSpan fileLastModifyTs = new TimeSpan(fInfo.LastWriteTime.Ticks);
                                int lastModifySec = (int)nowDateTs.Subtract(fileLastModifyTs).Duration().TotalSeconds;



                                if (lastModifySec > 60)
                                {
                                    //string upUploadLines = "";
                                    bool bUploadFail = false;
                                    string lineStr;
                                    List<String> arrlineStr = null;
                                    List<String> arrUnUploadLine = null;

                                    using (System.IO.StreamReader sr = new System.IO.StreamReader(fInfo.FullName))
                                    {
                                        arrlineStr = new List<string>();
                                        arrUnUploadLine = new List<string>();

                                        while ((lineStr = sr.ReadLine()) != null)
                                        {
                                            arrlineStr.Add(lineStr);
                                        }

                                        if (arrlineStr.Count > 0)
                                        {
                                            Parallel.For(0, arrlineStr.Count, parallelOpt, index =>
                                            {
                                                object[] paramObject = new object[6];
                                                paramObject[0] = (string)sCompanyID;
                                                paramObject[1] = (string)sDeviceTypeID;
                                                paramObject[2] = (string)sEquipID;
                                                paramObject[3] = (string)ZhenDingQHDBD.RS_BOARD_PARAM_NAME;
                                                paramObject[4] = arrlineStr[index];
                                                paramObject[5] = (string)sNowTime;

                                                if (bUploadFail)
                                                {
                                                    Monitor.Enter(_arrToken);
                                                    arrUnUploadLine.Add(arrlineStr[index]);
                                                    Monitor.Exit(_arrToken);
                                                }
                                                else
                                                {
                                                    string sErrorReturn = "";
                                                    object objCallReturn = dllInvoke.InvokeCLRDll(dllPathName, ZhenDingQHDBD.RS_DLL_NAMESPACE, ZhenDingQHDBD.RS_DLL_CLASSNAME, ZhenDingQHDBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);
                                                    string strCallReturn = objCallReturn.ToString();

                                                    if (string.Equals(strCallReturn, "Dll Call Error!"))
                                                    {
                                                        Monitor.Enter(_arrToken);
                                                        if (UploadDataEvent != null)
                                                        {
                                                            UploadDataEvent.Invoke(this, new TransDataEventArgs(paramObject[3].ToString() + "\n" + paramObject[4].ToString() + "\n" + strCallReturn, "臻鼎秦皇島DLL上傳板數據錯誤"));
                                                        }
                                                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                                        using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                                        {
                                                            streamWrt.WriteLine(DateTime.Now.ToString());
                                                            streamWrt.WriteLine("臻鼎QHDDLL上传板数据：DLL 调用错误" + sErrorReturn);
                                                            streamWrt.WriteLine(ZhenDingQHDBD.RS_BOARD_PARAM_NAME);
                                                            streamWrt.WriteLine(arrlineStr[index]);

                                                            streamWrt.Flush();
                                                            streamWrt.Close();
                                                        }


                                                        arrUnUploadLine.Add(arrlineStr[index]);
                                                        bUploadFail = true;
                                                        Monitor.Exit(_arrToken);
                                                    }

                                                    else if (!string.Equals(strCallReturn, "OK"))
                                                    {
                                                        Monitor.Enter(_arrToken);

                                                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                                        using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                                        {
                                                            if (strCallReturn.IndexOf("parameter number mismatch") >= 0)
                                                            {

                                                                streamWrt.WriteLine(DateTime.Now.ToString());
                                                                streamWrt.WriteLine("臻鼎QHDDLL上传板数据：DLL 返回参数个数不匹配（" + strCallReturn + "）:" + ZhenDingQHDBD.RS_BOARD_PARAM_NAME.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length + "," + lineStr.Split("|".ToCharArray()).Length);
                                                                streamWrt.WriteLine(ZhenDingQHDBD.RS_BOARD_PARAM_NAME);
                                                                streamWrt.WriteLine(arrlineStr[index]);
                                                                streamWrt.Flush();
                                                                streamWrt.Close();

                                                            }
                                                            else
                                                            {
                                                                if (UploadDataEvent != null)
                                                                {
                                                                    UploadDataEvent.Invoke(this, new TransDataEventArgs(paramObject[3].ToString() + "\n" + paramObject[4].ToString() + "\n" + strCallReturn, "臻鼎秦皇島DLL上傳板數據錯誤"));
                                                                }
                                                                streamWrt.WriteLine(DateTime.Now.ToString());
                                                                streamWrt.WriteLine("臻鼎QHD DLL上传板数据：DLL 返回错误（" + strCallReturn + "）");
                                                                streamWrt.WriteLine(ZhenDingQHDBD.RS_BOARD_PARAM_NAME);
                                                                streamWrt.WriteLine(arrlineStr[index]);
                                                                streamWrt.Flush();
                                                                streamWrt.Close();
                                                            }
                                                        }

                                                        arrUnUploadLine.Add(arrlineStr[index]);

                                                        bUploadFail = true;
                                                        Monitor.Exit(_arrToken);
                                                    }
                                                }
                                            });
                                        }

                                    }

                                    if (arrUnUploadLine != null && arrUnUploadLine.Count > 0)
                                    {
                                        FileStream fsReWrite = new FileStream(fInfo.FullName, FileMode.Create);
                                        using (StreamWriter streamWrt = new StreamWriter(fsReWrite, Encoding.Default))
                                        {
                                            foreach (string unUploadline in arrUnUploadLine)
                                            {
                                                streamWrt.WriteLine(unUploadline);
                                            }
                                            streamWrt.Flush();
                                            streamWrt.Close();
                                        }
                                        break;
                                    }
                                    else
                                    {
                                        File.Delete(fInfo.FullName);
                                    }
                                    //if (!string.IsNullOrEmpty(upUploadLines))
                                    //{
                                    //    if (string.Equals(bufferUpload, "True"))
                                    //    {
                                    //        FileStream fsReWrite = new FileStream(fInfo.FullName, FileMode.Create);
                                    //        using (StreamWriter streamWrt = new StreamWriter(fsReWrite, Encoding.Default))
                                    //        {
                                    //            streamWrt.Write(upUploadLines);
                                    //            streamWrt.Flush();
                                    //            streamWrt.Close();
                                    //        }
                                    //    }
                                    //    else
                                    //    {
                                    //        fInfo.Delete();
                                    //        //File.Delete(fInfo.FullName);
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    fInfo.Delete();
                                    //}

                                }

                            }

                        }

                    }
                }
                catch (Exception ex)
                {
                    fsLogFile = new FileStream(logFilePath, FileMode.Append);
                    using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                    {
                        streamWrt.WriteLine("臻鼎QHD DLL上传板数据异常：");
                        streamWrt.WriteLine(ex.Message);
                        streamWrt.Flush();
                        streamWrt.Close();
                    }
                }
                Thread.Sleep(5000);
            }
        }


        public string SendDataZhenDingQHDBDBoard(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            string sCompanyID = AappSettingData.stDataExpVT.strCustomer;
            string sDeviceTypeID = AappSettingData.stDataExpVT.strTestType;
            string sEquipID = AappSettingData.stDataExpVT.strMachine;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            //Add tony 180601
            string sBufferFlag = "False";
            //add Tony 180808
            int iMaxParallelCount = 2;//
            //if (AappSettingData.stDataExpVT.MaxThreadNumUsingExternDLL > 0)
            //{
            //    iMaxParallelCount = AappSettingData.stDataExpVT.MaxThreadNumUsingExternDLL;
            //}
            string strMsg = RS_EMPTY;
            if (!Directory.Exists(_strTmpFileDir))
            {
                Directory.CreateDirectory(_strTmpFileDir);
            }
            
            try
            {
                //string sErrorStr = "";

                string uploadLines = ZhenDingQHDGetBoardLines(ref APads, ref ABrdRes, ref  APcbGeneralInfo, ref  AappSettingData, AstrDir, byLaneNo);

                if (!string.IsNullOrEmpty(uploadLines))
                {
                    // write backUp file
                    bool bSaveTempFile = true;
                    bool bSaveBackupFile = !string.IsNullOrEmpty(AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                    //    && !AappSettingData.stDataExpVT.bEnExportUsingExternDLL;
                    bool bSaveUploadTempFile = AappSettingData.stDataExpVT.bEnExportUsingExternDLL;
                    if (bSaveBackupFile || (bSaveTempFile && !string.IsNullOrEmpty(AstrDir)))
                    {
                        string csvLines = uploadLines.Replace(PubStaticParam.RS_VerticalLineSplit, PubStaticParam.RS_CommaSplit);
                        
                        if (!string.IsNullOrEmpty(AstrDir))
                        {
                            //using (FileStream fs = new FileStream(AstrDir, FileMode.Create))
                            //{
                            //    StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                            //    streamWrt.Write(ZhenDingQHDBD.RS_BOARD_BACKUP_NAME + PubStaticParam.RS_LineEnd + csvLines);
                            //    streamWrt.Flush();
                            //    streamWrt.Close();
                            //}
                        }

                        if (bSaveBackupFile)
                        {
                            if (!Directory.Exists(AappSettingData.stDataExpVT.strBackUpExportedFilePath))
                            {
                                Directory.CreateDirectory(AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                            }

                            string sYear = ABrdRes.startTime.ToString(ZhenDingQHDBD.FilePathYMD[0]);
                            string sMonth = ABrdRes.startTime.ToString(ZhenDingQHDBD.FilePathYMD[1]);
                            string sDay = ABrdRes.startTime.ToString(ZhenDingQHDBD.FilePathYMD[2]);


                            //modify tony 18.11.08 change save file path YYYY/MM/DD
                            ///check or create directory
                            ///

                            //string sBackUpFilePath = AappSettingData.stDataExpVT.strBackUpExportedFilePath;
                            //if yyyy/mm/dd folder path use this line
                            string sBackUpFilePath = Path.Combine(AappSettingData.stDataExpVT.strBackUpExportedFilePath, sYear, sMonth, sDay);
                            if (!Directory.Exists(sBackUpFilePath))
                            {
                                Directory.CreateDirectory(sBackUpFilePath);
                            }

                            string strDate = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                            string strTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                            string strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode,
                                                                AappSettingData, (byte)ABrdRes.LaneNo);

                            string sBackUpFile = Path.Combine(sBackUpFilePath, strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strTime + PubStaticParam.RS_CSV_EXT);

                            if (!File.Exists(sBackUpFile))
                            {
                                using (FileStream fs = new FileStream(sBackUpFile, FileMode.Append))
                                {
                                    StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                                    streamWrt.Write(ZhenDingQHDBD.RS_BOARD_BACKUP_NAME + PubStaticParam.RS_LineEnd + csvLines);
                                    streamWrt.Flush();
                                    streamWrt.Close();

                                }
                            }
                        }
                    }

                    if (bSaveUploadTempFile) 
                    {
                        // write temp file for upload
                        string boardTempFile = Path.Combine(_strTmpFileDir, ZhenDingQHDBD.RS_PNL_BUFFER_FILE_NAME + "_" + byLaneNo + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".tmp");
                        using (FileStream fs = new FileStream(boardTempFile, FileMode.Create))
                        {
                            StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                            streamWrt.Write(uploadLines);
                            streamWrt.Flush();
                            streamWrt.Close();
                        }
                        this.StartZhenDingQHDBDBoard(sCompanyID, sDeviceTypeID, sEquipID, sDllPath, sBufferFlag, iMaxParallelCount);
                    }
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
                ;
            }
            return strMsg;
        }

        private void GetMeanValue(ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            InspectMainLib.Pad APad,//Q.F.2018.11.19
            int AiPadIndex,
            out float AoutMeanHeight, out float AoutMeanArea, out float AoutMeanVolume)
        {
            AoutMeanHeight = 0;//APad....
            AoutMeanArea = 0;
            AoutMeanVolume = 0;
            bool bHasFound = false;
            float fZero = 0.001f;//Q.F.2018.11.27
            if (APcbGeneralInfo.stCoplanarityData == null || APcbGeneralInfo.stCoplanarityData.Length == 0)
            {
                return;
            }
            for (int i = 0; i < APcbGeneralInfo.stCoplanarityData.Length; i++)
            {
                STGroupCondition stGroupCond = APcbGeneralInfo.stCoplanarityData[i];
                if (stGroupCond.aIPadIndices == null || stGroupCond.aIPadIndices.Length == 0) continue;
                for (int j = 0; j < stGroupCond.aIPadIndices.Length; j++)
                {
                    int padIndex = stGroupCond.aIPadIndices[j];
                    if (padIndex == AiPadIndex)
                    {
                        //Q.F.2018.11.19
                        if (stGroupCond.bCheckMeanHeight == true)
                        {
                            AoutMeanHeight = stGroupCond.fMeanHeightUm;
                            ////Q.F.2018.01.22
                            //if (stGroupCond.byMeanHeightValueType == 1
                            //    && APcbGeneralInfo.MedianRealValue == true)
                            //{
                            //    AoutMeanHeight = AoutMeanHeight / APad.stencilHeight * 0.1f;
                            //}
                            //if (stGroupCond.byMeanHeightValueType == 1
                            //    && AoutMeanHeight < fZero)
                            //{

                            //    AoutMeanHeight = 100;
                            //}
                        }
                        else
                        {
                            //AoutMeanHeight = 
                        }
                        if (stGroupCond.bCheckMeanArea == true)
                        {
                            AoutMeanArea = stGroupCond.fMeanArea;
                            //if (APcbGeneralInfo.MedianRealValue == true
                            //    && APad.res.measuredValue.fCadArea > fZero)
                            //{
                            //    AoutMeanArea = AoutMeanArea / APad.res.measuredValue.fCadArea;
                            //}
                            //if (AoutMeanArea < fZero)
                            //{

                            //    AoutMeanArea = 1.0f;
                            //}
                        }
                        else
                        {
                            //AoutMeanHeight = 
                        }
                        if (stGroupCond.bCheckMeanVolume == true)
                        {
                            AoutMeanVolume = stGroupCond.fMeanVolume;
                            //if (APcbGeneralInfo.MedianRealValue == true
                            //    && APad.res.measuredValue.fCadArea > fZero)
                            //{
                            //    AoutMeanVolume = AoutMeanVolume / (APad.res.measuredValue.fCadArea * APad.stencilHeight * 1000);
                            //}
                            //if (AoutMeanVolume < fZero)
                            //{

                            //    AoutMeanVolume = 1.0f;
                            //}
                        }
                        else
                        {
                            //AoutMeanHeight = 
                        }
                        bHasFound = true;
                        break;//Q.F.2018.11.22
                    }
                }
                if (bHasFound)//Q.F.2018.11.22
                    break;
            }
        }

        //private void GetMeanValue(ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, int AiPadIndex, out float AoutMeanHeight, out float AoutMeanArea, out float AoutMeanVolume) 
        //{
        //    AoutMeanHeight = 0;
        //    AoutMeanArea = 0;
        //    AoutMeanVolume = 0;
        //    if (APcbGeneralInfo.stCoplanarityData == null || APcbGeneralInfo.stCoplanarityData.Length==0 ) 
        //    {
        //        return;
        //    }
        //    for (int i = 0; i < APcbGeneralInfo.stCoplanarityData.Length; i++) 
        //    {
        //        STGroupCondition stGroupCond = APcbGeneralInfo.stCoplanarityData[i];
        //        if (stGroupCond.aIPadIndices == null || stGroupCond.aIPadIndices.Length == 0) continue;
        //        for (int j = 0; j < stGroupCond.aIPadIndices.Length; j++) 
        //        {
        //            int padIndex = stGroupCond.aIPadIndices[j];
        //            if (padIndex == AiPadIndex) 
        //            {
        //                AoutMeanHeight  = stGroupCond.fMeanHeightUm;
        //                AoutMeanArea  = stGroupCond.fMeanArea;
        //                AoutMeanVolume  = stGroupCond.fMeanVolume;                        
        //            }
        //        }
        //    }
        //}



        private string ZhenDingQHDGetBoardLines(ref InspectMainLib.Pad[] APads, ref SPCBoardRes ABrdRes,
         ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, ref AppSettingData AappSettingData,
         string AstrDir, byte AbyLaneNo)
        {
            string strLine = string.Empty;
            string strArrayBarcode = string.Empty;
            string strArrayId = string.Empty;
            string result = string.Empty;
            string strArrayStatus = string.Empty;
            string strArrayStatusCustom = string.Empty;
            int iArrayCount = 0;
            try
            {
                string lineName = AappSettingData.LineName;
                string strDate = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                string strStartTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                string strEndTime = ABrdRes.endTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                string modelName = Path.GetFileNameWithoutExtension(ABrdRes.jobName) + "";
                float fValue2Perc = 100.0f;//Q.F.2018.03.27

                string strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                StringBuilder strBld = new StringBuilder();
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                float fShiftSpecX = 0, fShiftSpecY = 0;
                //if (bISArrayPCB && iArrayCount > 0)
                if (iArrayCount > 0)
                {
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            strArrayStatusCustom = ZhenDingQHDBD.RS_ARRAY_RESULT[APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes];
                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            strArrayId = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (string.IsNullOrEmpty(strArrayBarcode)
                                || string.Equals(strArrayBarcode, RS_NOREAD, StringComparison.InvariantCultureIgnoreCase))
                            {
                                strArrayBarcode = strboardBarcode + PubStaticParam.RS_UnderLineSplit + strArrayId;
                            }
                            #region "  skip "
                            if (strArrayStatus == "Skipped")
                            {
                                //Q.F.2019.06.23
                                if (AappSettingData.stDataExpVT.BEnExportSkip == false)
                                    continue;
                                int[] iarrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;
                                foreach (int iPadIndex in iarrPadIndex)
                                {
                                    Pad skipBoardPad = APads[iPadIndex];
                                    string errorSkip = string.Empty;
                                    string padGroup = string.IsNullOrEmpty(skipBoardPad.padGroup) ? "ungrouped" : skipBoardPad.padGroup;
                                    if (skipBoardPad.check)
                                    {
                                        if (skipBoardPad.res.jugRes == JudgeRes.NG)
                                        {
                                            // errorSkip = _baseFun.GetPadErrorCodeStr(skipBoardPad, AappSettingData);
                                        }
                                        float meanHeight = 0f;
                                        float meanArea = 0f;
                                        float meanVolume = 0f;
                                        GetMeanValue(APcbGeneralInfo, skipBoardPad, iPadIndex, out meanHeight, out meanArea, out meanVolume);
                                        strBld.Append(
                                                    modelName + PubStaticParam.RS_VerticalLineSplit +//Model name
                                                   lineName + PubStaticParam.RS_VerticalLineSplit +//Line number
                                                   skipBoardPad.componentID + PubStaticParam.RS_VerticalLineSplit +//comp name
                                                   skipBoardPad.packageType + PubStaticParam.RS_VerticalLineSplit +//type
                                                   (skipBoardPad.res.measuredValue.perArea * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area(%)

                                        //modify tony 2018.11.08
                                        if (meanArea == 0)
                                        {
                                            strBld.Append((skipBoardPad.res.measuredValue.fCadArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        //(skipBoardPad.spec.areaPerH * skipBoardPad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl
                                        strBld.Append(
                                            (skipBoardPad.spec.areaPerH * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl(%)


                                           (skipBoardPad.res.measuredValue.area * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area    
                                            //(skipBoardPad.spec.areaPerL * skipBoardPad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL
                                           (skipBoardPad.spec.areaPerL * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL (%)

                                           (skipBoardPad.res.measuredValue.perHeight * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); //height(%)

                                        //modify tony 2018.11.08
                                        if (meanHeight == 0)
                                        {
                                            strBld.Append(skipBoardPad.stencilHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//height standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanHeight * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }
                                        strBld.Append(

                                    //skipBoardPad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL
                                        (skipBoardPad.spec.heightH / (skipBoardPad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL (%)

                                        (skipBoardPad.res.measuredValue.height * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Height
                                        //skipBoardPad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL                                                   
                                        (skipBoardPad.spec.heightL / (skipBoardPad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL (%)                                                 

                                        (skipBoardPad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//vol %

                                        //modify tony 2018.11.08
                                        if (meanVolume == 0)
                                        {
                                            strBld.Append((skipBoardPad.res.measuredValue.fCadArea * (skipBoardPad.stencilHeight * PubStaticParam.RS_fMM2UM) * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); // vol statndard
                                        }
                                        else
                                        {
                                            strBld.Append((meanVolume * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }
                                        fShiftSpecX = Math.Abs(skipBoardPad.spec.shiftXHPer);
                                        fShiftSpecY = Math.Abs(skipBoardPad.spec.shiftYHPer);
                                        //(skipBoardPad.spec.volPerH * skipBoardPad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL
                                        strBld.Append((skipBoardPad.spec.volPerH * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL (%)

                                         (skipBoardPad.res.measuredValue.vol * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit + //vol                                                   
                                            //(skipBoardPad.spec.volPerL * skipBoardPad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL
                                         (skipBoardPad.spec.volPerL * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL (%)

                                         //skipBoardPad.spec.shiftXH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL
                                         //(skipBoardPad.spec.shiftXH / skipBoardPad.sizeXmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)

                                         (fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)
                                         
                                         (skipBoardPad.res.measuredValue.offsetX).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset                                                    
                                         (-fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                         //"0" + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL
                                            //skipBoardPad.spec.shiftYH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL
                                         //(skipBoardPad.spec.shiftYH / skipBoardPad.sizeYmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                         //(-1f * Math.Abs(skipBoardPad.spec.shiftXHPer) * 100).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                         (fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +
                                         skipBoardPad.res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset                                                   
                                         (-fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset LSL
                                         skipBoardPad.sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//skipBoardPadSizex
                                         skipBoardPad.sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padsizey
                                            //

                                  // modify by tony 180326 Component info spi is null
                                            //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                            //pad.res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average :LSL
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average :LSL


                                         strArrayStatusCustom + PubStaticParam.RS_VerticalLineSplit +//Result(array result)
                                         "" + PubStaticParam.RS_VerticalLineSplit +
                                         skipBoardPad.pinNumber + PubStaticParam.RS_VerticalLineSplit +//pin num
                                         strboardBarcode + PubStaticParam.RS_VerticalLineSplit +//barcode
                                         strDate + PubStaticParam.RS_VerticalLineSplit +//date
                                         strStartTime + PubStaticParam.RS_VerticalLineSplit +//start time
                                         strEndTime + PubStaticParam.RS_VerticalLineSplit +//end time
                                         strArrayId + PubStaticParam.RS_VerticalLineSplit +//array id
                                         strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strStartTime + PubStaticParam.RS_VerticalLineSplit +//key
                                         padGroup

                                         );
                                        strBld.Append(RS_LineEnd);
                                        break;
                                    }
                                }
                            }
                            #endregion
                            else
                            {
                                int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;
                                //

                                foreach (int padIndex in arrPadIndex)
                                {
                                    Pad pad = APads[padIndex];
                                    string errorPadcode = string.Empty;
                                    string padGroup = string.IsNullOrEmpty(pad.padGroup) ? "ungrouped" : pad.padGroup;
                                    if (_baseFun.bPadIsSkip(pad))
                                    {
                                        continue;
                                    }
                                    if (pad.check)
                                    {
                                        if (pad.res.jugRes == JudgeRes.NG)
                                        {
                                            errorPadcode = _baseFun.GetPadErrorCodeStr(pad, AappSettingData);
                                        }
                                        float meanHeight = 0f;
                                        float meanArea = 0f;
                                        float meanVolume = 0f;
                                        GetMeanValue(APcbGeneralInfo, pad, padIndex, out meanHeight, out meanArea, out meanVolume);
                                        strBld.Append(
                                                   modelName + PubStaticParam.RS_VerticalLineSplit +//Model name
                                                   lineName + PubStaticParam.RS_VerticalLineSplit +//Line number
                                                   pad.componentID + PubStaticParam.RS_VerticalLineSplit +//comp name
                                                   pad.packageType + PubStaticParam.RS_VerticalLineSplit +//type
                                                   (pad.res.measuredValue.perArea * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area(%)

                                        //modify tony 2018.11.08
                                        if (meanArea == 0)
                                        {
                                            strBld.Append((pad.res.measuredValue.fCadArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }


                                        //(pad.spec.areaPerH * pad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl
                                        strBld.Append((pad.spec.areaPerH * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl(%)


                                         (pad.res.measuredValue.area * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area    
                                            //(pad.spec.areaPerL * pad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL
                                         (pad.spec.areaPerL * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL (%)

                                         (pad.res.measuredValue.perHeight * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); //height(%)

                                        //modify tony 2018.11.08
                                        if (meanHeight == 0)
                                        {
                                            strBld.Append(pad.stencilHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//height standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanHeight * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL
                                        strBld.Append((pad.spec.heightH / (pad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL (%)

                                        (pad.res.measuredValue.height * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL                                                   
                                        (pad.spec.heightL / (pad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL (%)                                                 

                                        (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//vol %

                                        //modify tony 2018.11.08
                                        if (meanVolume == 0)
                                        {
                                            strBld.Append((pad.res.measuredValue.fCadArea * (pad.stencilHeight * PubStaticParam.RS_fMM2UM) * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);// vol statndard
                                        }
                                        else
                                        {
                                            strBld.Append((meanVolume * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }
                                        fShiftSpecX = Math.Abs(pad.spec.shiftXHPer);
                                        fShiftSpecY = Math.Abs(pad.spec.shiftYHPer);
                                        //(pad.spec.volPerH * pad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL
                                        strBld.Append((pad.spec.volPerH * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL (%)

                                          (pad.res.measuredValue.vol * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit + //vol                                                   
                                            //(pad.spec.volPerL * pad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL
                                          (pad.spec.volPerL * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL (%)

                                          //pad.spec.shiftXH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL
                                          //(pad.spec.shiftXH / pad.sizeXmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)
                                          (fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)

                                          (pad.res.measuredValue.offsetX).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset 
                                            //"0" + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL
                                            //modify by tony 20180412
                                          (-fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL (%)
                                          //(-1f * Math.Abs((pad.spec.shiftXH / pad.sizeXmmNew * 100))).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL (%)
                                            //pad.spec.shiftYH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL
                                          //(pad.spec.shiftYH / pad.sizeYmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          (fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)

                                          pad.res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset                                                   
                                            //"0" + pad.spec.shiftYH + PubStaticParam.RS_VerticalLineSplit +//yoffset LSL
                                            //modify by tony 20180412
                                          //(-1f * Math.Abs((pad.spec.shiftYH / pad.sizeYmmNew * 100))).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          (-fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          pad.sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padSizex
                                          pad.sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padsizey
                                            //
                                   // modify by tony 180326 Component info spi is null
                                            //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                            //pad.res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average :LSL
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average :LSL


                                          strArrayStatusCustom + PubStaticParam.RS_VerticalLineSplit +//Result(array result)
                                          errorPadcode + PubStaticParam.RS_VerticalLineSplit + //errcode
                                          pad.pinNumber + PubStaticParam.RS_VerticalLineSplit +//pin num
                                          strboardBarcode + PubStaticParam.RS_VerticalLineSplit +//barcode
                                          strDate + PubStaticParam.RS_VerticalLineSplit +//date
                                          strStartTime + PubStaticParam.RS_VerticalLineSplit +//start time
                                          strEndTime + PubStaticParam.RS_VerticalLineSplit +//end time

                                          strArrayId + PubStaticParam.RS_VerticalLineSplit +//array id
                                          strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strStartTime + PubStaticParam.RS_VerticalLineSplit +//key

                                          padGroup

                                   );
                                        strBld.Append(RS_LineEnd);
                                    }

                                }
                            }
                        }
                    }
                }
                strLine = strBld.ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strLine;
        }

        //臻鼎 秦皇岛 大数据-------------------end

        //合肥 京东方 设备状态导出---------------start

        Thread _hefeiBOEEQstatusThread = null;

        public void HefeiBOEEquipStatusStart(string AstrDir, byte AbyLaneNo, AppSettingData AappSettingData)
        {
            if (_hefeiBOEEQstatusThread != null)
            {
                ThreadState state = _hefeiBOEEQstatusThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
            }
            //string sMachineInfo = AappSettingData.stMonitorSystemParams.strLogEquipID; //"HCD-DSBG-09000";//will be chagned according to UI setting
            //string sVendor = ChenduFoxonn.RS_VENDOR_NAME;
            //string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogEquipStatusInterval;

            object[] objParameters = new object[3];
            objParameters[0] = AbyLaneNo;
            objParameters[1] = AappSettingData.stMonitorSystemParams.strExportLogPath;//stDataExpVT.strBackUpExportedFilePath; //Q.F.2018.05.09
            objParameters[2] = iInterval <= 0 ? HefeiBOE.RI_EQUIP_STATUS_INTERVAL : iInterval;

            _hefeiBOEEQstatusThread = new Thread(new ParameterizedThreadStart(StartRunHefeiBOEEquipStatus));
            _hefeiBOEEQstatusThread.IsBackground = true;
            _hefeiBOEEQstatusThread.Start(objParameters);
        }

        public void HefeiBOEEquipStatusStop()
        {
            try
            {
                if (_hefeiBOEEQstatusThread != null && (_hefeiBOEEQstatusThread.ThreadState == ThreadState.Running || _hefeiBOEEQstatusThread.ThreadState == ThreadState.Background))
                {
                    _hefeiBOEEQstatusThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("hefeiBOEEQstatusThread Stop error" + ex.Message);
            }
        }

        private void StartRunHefeiBOEEquipStatus(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 2) return;

            byte AbyLaneNo = (byte)objParameters[0];
            string backUpPath = (string)objParameters[1];
            int iEquipStatusInter = (int)objParameters[2];

            int iSleep = iEquipStatusInter;

            //save equip status

            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();

            string bufferFile = Path.Combine(_strTmpFileDir, HefeiBOE.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".temp");



            FileStream fs = null;
            System.IO.StreamWriter streamWrt = null;

            string sLastUploadTime = "";
            if (!File.Exists(bufferFile))
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(HefeiBOE.RS_DATE_FORMAT + HefeiBOE.RS_TIME_FORMAT);
                }
            }

            while (true)
            {
                try
                {
                    string sExportEqFile = Path.Combine(backUpPath, HefeiBOE.RS_EQUIPSTATUS_FILE_NAME + PubStaticParam.RS_UnderLineSplit + DateTime.Now.ToString(HefeiBOE.RS_DATE_FORMAT) + PubStaticParam.RS_TXT_EXT);

                    if (!File.Exists(sExportEqFile))
                    {
                        using (FileStream eqfs = new FileStream(sExportEqFile, FileMode.Append))
                        {
                            streamWrt = new StreamWriter(eqfs, Encoding.Default);
                            streamWrt.WriteLine("时间\t\t设备状态\t\t异常信息");
                            streamWrt.Flush();
                            streamWrt.Close();
                            eqfs.Close();
                        }
                    }

                    string sql = "select " +
                                " CAST(t.Start AS CHAR)," +
                                " CAST(t.Run AS CHAR)," +
                                " CAST(t.Stop AS CHAR)," +
                                " CAST(t.Idle AS CHAR)," +
                                " CAST(t.Init AS CHAR)," +
                                " CAST(t.ReqSig AS CHAR)," +
                                " CAST(t.InBoard AS CHAR)," +
                                " CAST(t.InspectBoard AS CHAR)," +
                                " CAST(t.InspectFinish AS CHAR)," +
                                " CAST(t.ReadyOut AS CHAR)," +
                                " CAST(t.BVSig AS CHAR)," +
                                " CAST(t.Error AS CHAR)," +
                                " ifnull(t.ErrContent,'')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y/%m/%d')," +
                                " DATE_FORMAT(t.UpdateTime,'%T')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S'), " +
                                " (CASE WHEN t.TowerG = '1' THEN	'G' WHEN t.TowerY = '1' THEN 'Y' WHEN t.TowerR = '1' THEN	'R' ELSE '' END ) towerType" +
                                " from TBEquipStatus t where t.UpdateTime > STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime ";

                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sql);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;
                            string sUpdateTime;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);


                            using (FileStream eqfs = new FileStream(sExportEqFile, FileMode.Append))
                            {
                                string towerLight = (string)dt.Rows[i][16];
                                string equipStatus = "";
                                if (string.Equals(towerLight, "R"))
                                {
                                    equipStatus = "Error";
                                }
                                else if (string.Equals(towerLight, "Y"))
                                {
                                    equipStatus = "Wait";
                                }
                                else
                                {
                                    equipStatus = "Run";
                                }

                                string line = sUpdateTime + "\t" + equipStatus + "\t\t" + sSubMessage;
                                streamWrt = new StreamWriter(eqfs, Encoding.Default);
                                streamWrt.WriteLine(line);
                                streamWrt.Flush();
                                streamWrt.Close();
                                eqfs.Close();
                            }

                            using (fs = new FileStream(bufferFile, FileMode.Create))
                            {
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("DataExport HefeiBOEEquipStatus error:" + ex.Message);
                }
                finally
                {
                    if (streamWrt != null)
                        streamWrt.Close();
                    if (fs != null)
                        fs.Close();
                }
                Thread.Sleep(iSleep);
            }
        }


        //合肥 京东方 设备状态导出---------------end



        //成都富士康 webservice 第三方dll调用 设备状态上传-----------------start

        Thread _chenduFoxconnEQstatusThread = null;

        //UI run method to start thread
        public void ChenduFoxconnEquipStatusStart(string AstrDir, byte AbyLaneNo, AppSettingData AappSettingData)
        {
            if (_chenduFoxconnEQstatusThread != null)
            {
                ThreadState state = _chenduFoxconnEQstatusThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
            }
            string sMachineInfo = AappSettingData.stMonitorSystemParams.strLogEquipID; //"HCD-DSBG-09000";//will be chagned according to UI setting
            string sVendor = ChenduFoxonn.RS_VENDOR_NAME;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogEquipStatusInterval;

            object[] objParameters = new object[6];
            objParameters[0] = AstrDir;
            objParameters[1] = AbyLaneNo;
            objParameters[2] = sMachineInfo;
            objParameters[3] = sVendor;
            objParameters[4] = iInterval <= 0 ? ChenduFoxonn.RI_EQUIP_STATUS_INTERVAL : iInterval;
            objParameters[5] = sDllPath;

            _chenduFoxconnEQstatusThread = new Thread(new ParameterizedThreadStart(StartRunChenduFoxconnEquipStatus));
            _chenduFoxconnEQstatusThread.IsBackground = true;
            _chenduFoxconnEQstatusThread.Start(objParameters);
        }

        public void ChenduFoxconnEquipStatusStop()
        {
            try
            {
                if (_chenduFoxconnEQstatusThread != null && (_chenduFoxconnEQstatusThread.ThreadState == ThreadState.Running || _chenduFoxconnEQstatusThread.ThreadState == ThreadState.Background))
                {
                    _chenduFoxconnEQstatusThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ChenduFoxconnEQstatusThread Stop error" + ex.Message);
            }
        }


        private void StartRunChenduFoxconnEquipStatus(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 4) return;

            string AstrDir = (string)objParameters[0];
            byte AbyLaneNo = (byte)objParameters[1];
            string sMachineInfo = (string)objParameters[2];
            string sVendor = (string)objParameters[3];
            int iEquipStatusInter = (int)objParameters[4];
            string sDllPath = (string)objParameters[5];

            int iSleep = iEquipStatusInter;
            string sDllPathName = Path.Combine(sDllPath, ChenduFoxonn.RS_DLL_NAME);

            DllInvoke dllInvoke = new DllInvoke();


            //create sturct object

            object StationInfoObj = null;

            Hashtable htParam = new Hashtable();
            htParam.Add("machine_info", sMachineInfo);
            htParam.Add("vendor", sVendor);

            while (StationInfoObj == null)
            {
                StationInfoObj = dllInvoke.CreateType(sDllPathName, ChenduFoxonn.RS_DLL_NAMESPACE, ChenduFoxonn.RS_DLL_TYPE_StationInfo, htParam);

                Thread.Sleep(iEquipStatusInter);
            }

            object[] paramObject = new object[0];

            //register machine

            while (true)
            {

                paramObject = new object[2];
                paramObject[0] = sMachineInfo;
                paramObject[1] = sVendor;
                string sErrorReturn = "";
                string strCallReturn = (string)dllInvoke.InvokeCLRDll(sDllPathName, ChenduFoxonn.RS_DLL_NAMESPACE, ChenduFoxonn.RS_DLL_CLASSNAME, ChenduFoxonn.RS_DLL_FUNCTION_STATION_INFO, paramObject, ref sErrorReturn);
                bool bCallSuccess = false;
                if (string.IsNullOrEmpty(strCallReturn))
                {
                    bCallSuccess = true;
                }
                if (bCallSuccess == true)
                    break;
                Thread.Sleep(iSleep);
            }

            //upload equip status

            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();

            string bufferFile = Path.Combine(_strTmpFileDir, ChenduFoxonn.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".temp");
            FileStream fs = null;
            System.IO.StreamWriter streamWrt = null;
            string sLastUploadTime = "";
            if (!File.Exists(bufferFile))
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(ChenduFoxonn.RS_DATE_FORMAT + ChenduFoxonn.RS_TIME_FORMAT);
                }
            }

            while (true)
            {
                try
                {
                    string sql = "select " +
                                " CAST(t.Start AS CHAR)," +
                                " CAST(t.Run AS CHAR)," +
                                " CAST(t.Stop AS CHAR)," +
                                " CAST(t.Idle AS CHAR)," +
                                " CAST(t.Init AS CHAR)," +
                                " CAST(t.ReqSig AS CHAR)," +
                                " CAST(t.InBoard AS CHAR)," +
                                " CAST(t.InspectBoard AS CHAR)," +
                                " CAST(t.InspectFinish AS CHAR)," +
                                " CAST(t.ReadyOut AS CHAR)," +
                                " CAST(t.BVSig AS CHAR)," +
                                " CAST(t.Error AS CHAR)," +
                                " ifnull(t.ErrContent,'')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y/%m/%d')," +
                                " DATE_FORMAT(t.UpdateTime,'%T')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S'), " +
                                " (CASE WHEN t.TowerG = '1' THEN	'G' WHEN t.TowerY = '1' THEN 'Y' WHEN t.TowerR = '1' THEN	'R' ELSE '' END ) towerType" +
                                " from TBEquipStatus t where t.UpdateTime > STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime ";

                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sql);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;
                            string sUpdateTime;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);
                            bool bReturnVal = ChenduFoxconnWSUploadEquipStatus(dt.Rows[i], sUpdateTime, StationInfoObj, sMainCode + sSubCode, sMainMessage + sSubMessage, sDllPathName);
                            if (bReturnVal == true)
                            {
                                fs = new FileStream(bufferFile, FileMode.Create);
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("DataExport ChenduFoxconnEquipStatus error:" + ex.Message);
                }
                finally
                {
                    if (streamWrt != null)
                        streamWrt.Close();
                    if (fs != null)
                        fs.Close();
                }
                Thread.Sleep(iSleep);
            }
        }

        private bool ChenduFoxconnWSUploadEquipStatus(System.Data.DataRow dataRow, string sUpdateTime, object StationInfoObj, string sEquipStatusCode, string sEquipStatusMessage, string sDllPathName)
        {
            try
            {
                Hashtable htKeyValueParam = new Hashtable();
                int year = int.Parse(sUpdateTime.Substring(0, 4));
                int month = int.Parse(sUpdateTime.Substring(4, 2));
                int day = int.Parse(sUpdateTime.Substring(6, 2));
                int hour = int.Parse(sUpdateTime.Substring(8, 2));
                int min = int.Parse(sUpdateTime.Substring(10, 2));
                int sec = int.Parse(sUpdateTime.Substring(12, 2));
                DateTime statusDateTime = new DateTime(year, month, day, hour, min, sec);
                htKeyValueParam.Add("date_time", statusDateTime);
                htKeyValueParam.Add("machine_status", (string)dataRow[16]);
                htKeyValueParam.Add("event_code", sEquipStatusCode);
                htKeyValueParam.Add("event_msg", sEquipStatusMessage);

                object MachineEventObj = null;
                DllInvoke dllInvoke = new DllInvoke();
                MachineEventObj = dllInvoke.CreateType(sDllPathName, ChenduFoxonn.RS_DLL_NAMESPACE, ChenduFoxonn.RS_DLL_TYPE_MachineEvent, htKeyValueParam);
                if (MachineEventObj != null)
                {
                    object[] paramObject = new object[2];
                    paramObject[0] = StationInfoObj;
                    paramObject[1] = MachineEventObj;
                    string sErrorReturn = "";
                    object returnVal = dllInvoke.InvokeCLRDll(sDllPathName, ChenduFoxonn.RS_DLL_NAMESPACE, ChenduFoxonn.RS_DLL_CLASSNAME, ChenduFoxonn.RS_DLL_FUNCTION_MACHINE_EVENT, paramObject, ref sErrorReturn);
                    if (returnVal == null) return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }

        //成都富士康 webservice 第三方dll调用 设备状态上传-----------------end



        //臻鼎大数据-------------------start


        //心跳连接

        Thread _zhenDingBDHbThread = null;

        //UI run method to start thread
        public void ZhenDingBDHeartbeatStart(AppSettingData AappSettingData)
        {
            //Q.F.2018.03.20
            //if (_zhenDingBDHbThread != null)
            //{
            //    ThreadState state = _zhenDingBDHbThread.ThreadState;
            //    if (state == ThreadState.Running
            //        || state == ThreadState.Background
            //        || state == ThreadState.WaitSleepJoin
            //        )
            //        return;
            //    MessageBox.Show("ZhenDingBDHeartbeatStart:" + state.ToString());
            //}

            if (_zhenDingBDHbThread != null)
            {
                ThreadState state = _zhenDingBDHbThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
                // MessageBox.Show("ZhenDingBDHeartbeatStart:" + state.ToString());
            }


            //Q.F.2018.03.20
            string sCompanyID = AappSettingData.stMonitorSystemParams.strLogCompany;
            string sDeviceTypeID = AappSettingData.stMonitorSystemParams.strLogDeviceType;
            string sEquipID = AappSettingData.stMonitorSystemParams.strLogEquipID;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogHeartBeatInterval;

            if (iInterval == 0) return;

            object[] objParameters = new object[5];
            objParameters[0] = sCompanyID;
            objParameters[1] = sDeviceTypeID;
            objParameters[2] = sEquipID;
            objParameters[3] = iInterval <= 0 ? ZhenDingBD.RI_HEARTBEAT_INTERVAL : iInterval;
            objParameters[4] = sDllPath;
            _zhenDingBDHbThread = new Thread(new ParameterizedThreadStart(StartRunZhenDingBDHeartbeat));
            _zhenDingBDHbThread.IsBackground = true;
            _zhenDingBDHbThread.Start(objParameters);
        }


        public void ZhenDingBDHeartbeatStop()
        {
            try
            {
                if (_zhenDingBDHbThread != null && (_zhenDingBDHbThread.ThreadState == ThreadState.Running || _zhenDingBDHbThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingBDHbThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingBDHeartbeatStop error" + ex.Message);
            }
        }

        private void StartRunZhenDingBDHeartbeat(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 5) return;

            string sCompanyID = (string)objParameters[0];
            string sDeviceTypeID = (string)objParameters[1];
            string sEquipID = (string)objParameters[2];
            int iHeartBeatInter = (int)objParameters[3];
            string sDllPath = (string)objParameters[4];

            if (string.IsNullOrEmpty(sCompanyID) || string.IsNullOrEmpty(sDeviceTypeID)
                || string.IsNullOrEmpty(sEquipID) || string.IsNullOrEmpty(sDllPath))
            {
                return;
            }
            int iSleep = iHeartBeatInter;
            string sDllPathName = Path.Combine(sDllPath, ZhenDingBD.RS_DLL_NAME);

            DllInvoke dllInvoke = new DllInvoke();

            object[] paramObject = new object[6];
            paramObject[0] = sCompanyID;
            paramObject[1] = sDeviceTypeID;
            paramObject[2] = sEquipID;


            while (true)
            {
                string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + " " + ZhenDingBD.RS_TIME_FORMAT);
                paramObject[3] = ZhenDingBD.RS_HEARTBEAT;
                paramObject[4] = ("R|" + sNowTime);
                paramObject[5] = sNowTime;
                try
                {
                    string sErrorReturn = "";
                    object callReturn = dllInvoke.InvokeCLRDll(sDllPathName, ZhenDingBD.RS_DLL_NAMESPACE, ZhenDingBD.RS_DLL_CLASSNAME, ZhenDingBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);

                    if (string.Equals(callReturn.ToString(), "Dll Call Error!"))
                    {
                        Console.WriteLine("Error dll or method not find" + sErrorReturn);
                    }
                    else
                    {
                        if (callReturn.ToString().IndexOf("OK") >= 0)
                        {
                            Console.WriteLine("Upload success :" + callReturn);
                        }
                        else if (callReturn.ToString().IndexOf("NG") >= 0)
                        {
                            Console.WriteLine("DLL call return error: " + callReturn);
                        }
                        else
                        {
                            Console.WriteLine("Unknow error from dll return");
                        }

                    }
                }
                //add by tony 180320
                catch (Exception ex)
                {
                    Console.WriteLine("Unknow error from dll calling" + ex.InnerException);
                }
                Thread.Sleep(iSleep);
            }
        }


        //臻鼎松岗 设备状态
        Thread _zhenDingBDEsThread = null;

        //UI run method to start thread
        public void ZhenDingBDEquipStatusStart(string AstrDir, byte AbyLaneNo, AppSettingData AappSettingData)
        {
            //Q.F.2018.03.20
            //if (_zhenDingBDEsThread != null && 
            //    ( _zhenDingBDEsThread.ThreadState == ThreadState.Running 
            //    || _zhenDingBDEsThread.ThreadState == ThreadState.Background
            //    || _zhenDingBDEsThread.ThreadState == ThreadState.WaitSleepJoin)
            //    )
            //    return;
            //if (_zhenDingBDEsThread != null)
            //{
            //    ThreadState state = _zhenDingBDEsThread.ThreadState;
            //    if (state == ThreadState.Running
            //        || state == ThreadState.Background
            //        || state == ThreadState.WaitSleepJoin
            //        )
            //        return;
            //    MessageBox.Show("ZhenDingBDEquipStatusStart:" + state.ToString());
            //}
            if (_zhenDingBDEsThread != null)
            {
                ThreadState state = _zhenDingBDEsThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;
                //MessageBox.Show("ZhenDingBDEquipStatusStart:" + state.ToString());
            }


            //Q.F.2018.03.20
            string sCompanyID = AappSettingData.stMonitorSystemParams.strLogCompany;
            string sDeviceTypeID = AappSettingData.stMonitorSystemParams.strLogDeviceType;
            string sEquipID = AappSettingData.stMonitorSystemParams.strLogEquipID;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iInterval = AappSettingData.stMonitorSystemParams.iLogHeartBeatInterval;


            object[] objParameters = new object[7];
            objParameters[0] = AstrDir;
            objParameters[1] = AbyLaneNo;
            objParameters[2] = sCompanyID;
            objParameters[3] = sDeviceTypeID;
            objParameters[4] = sEquipID;
            objParameters[5] = iInterval <= 0 ? ZhenDingBD.RI_EQUIP_STATUS_INTERVAL : iInterval;
            objParameters[6] = sDllPath;
            _zhenDingBDEsThread = new Thread(new ParameterizedThreadStart(StartRunZhenDingBDEquipStatus));
            _zhenDingBDEsThread.IsBackground = true;
            _zhenDingBDEsThread.Start(objParameters);
        }

        public void ZhenDingBDEquipStatusStop()
        {
            try
            {
                if (_zhenDingBDEsThread != null && (_zhenDingBDEsThread.ThreadState == ThreadState.Running || _zhenDingBDEsThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingBDEsThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingBDHeartbeatStop error" + ex.Message);
            }
        }

        //臻鼎松岗 设备状态
        private void StartRunZhenDingBDEquipStatus(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            if (objParameters == null || objParameters.Length < 7) return;

            string AstrDir = (string)objParameters[0];
            byte AbyLaneNo = (byte)objParameters[1];
            string sCompanyID = (string)objParameters[2];
            string sDeviceTypeID = (string)objParameters[3];
            string sEquipID = (string)objParameters[4];
            int iEquipStatusInter = (int)objParameters[5];
            string sDllPath = (string)objParameters[6];

            int iSleep = iEquipStatusInter;
            string sDllPathName = Path.Combine(sDllPath, ZhenDingBD.RS_DLL_NAME);

            DllInvoke dllInvoke = new DllInvoke();

            object[] paramObject = new object[6];
            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();

            string bufferFile = Path.Combine(_strTmpFileDir, ZhenDingBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".temp");
            FileStream fs = null;
            System.IO.StreamWriter streamWrt = null;
            string sLastUploadTime = "";
            if (!File.Exists(bufferFile))//tony 2018.03.20
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(ZhenDingBD.RS_DATE_FORMAT_SHOT + ZhenDingBD.RS_TIME_FORMAT_SHOT);
                }
            }

            //add tony to log zhending equip upload 
            FileStream fsLogFile = null;
            if (!Directory.Exists(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
            {
                Directory.CreateDirectory(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
            }
            string logFilePath = "";

            FileStream fsUserViewLogFile = null;
            string userViewLogFilePath = "";
            Hashtable uploadHashTable = new Hashtable();
            while (true)
            {
                if (uploadHashTable.Count > 100)
                {
                    uploadHashTable.Clear();
                }
                try
                {
                    string sql = "select " +
                                " CAST(t.Start AS CHAR)," +
                                " CAST(t.Run AS CHAR)," +
                                " CAST(t.Stop AS CHAR)," +
                                " CAST(t.Idle AS CHAR)," +
                                " CAST(t.Init AS CHAR)," +
                                " CAST(t.ReqSig AS CHAR)," +
                                " CAST(t.InBoard AS CHAR)," +
                                " CAST(t.InspectBoard AS CHAR)," +
                                " CAST(t.InspectFinish AS CHAR)," +
                                " CAST(t.ReadyOut AS CHAR)," +
                                " CAST(t.BVSig AS CHAR)," +
                                " CAST(t.Error AS CHAR)," +
                                " ifnull(t.ErrContent,'')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y/%m/%d')," +
                                " DATE_FORMAT(t.UpdateTime,'%T')," +
                                " DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S') " +
                                " from TBEquipStatus t where t.UpdateTime > STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime desc ";

                    // add by tony 20180911
                    string logFileName = "ZhendingEquipStatus_" + DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT_SHOT) + ".log";
                    logFilePath = Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", logFileName);

                    string userViewLogFileName = "ZhendingEquipStatus_simple_" + DateTime.Now.ToString(ZhenDingQHDBD.RS_DATE_FORMAT_SHOT) + ".log";
                    userViewLogFilePath = Path.Combine(ZhenDingQHDBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", userViewLogFileName);

                    if (!File.Exists(logFilePath))
                    {
                        fsLogFile = File.Create(logFilePath);
                        fsLogFile.Flush();
                        fsLogFile.Close();
                        fsLogFile.Dispose();
                    }

                    if (!File.Exists(userViewLogFilePath))
                    {
                        fsUserViewLogFile = File.Create(userViewLogFilePath);
                        fsUserViewLogFile.Flush();
                        fsUserViewLogFile.Close();
                        fsUserViewLogFile.Dispose();
                    }


                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sql);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：TBEquipStatus return data count：" + dt.Rows.Count);
                            streamWrtLog.Flush();
                            streamWrtLog.Close();
                        }
                        for (int i = 0; i < dt.Rows.Count; i++)
                        //for (int i = 0; i < 1; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;
                            string sUpdateTime;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);
                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + string.Format(" 臻鼎松岗 数据库返回：sMainCode={0}, sSubCode={1},sMainMessage={2}, sSubMessage={3},sUpdateTime={4}", sMainCode, sSubCode, sMainMessage, sSubMessage, sUpdateTime));
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }
                            //modify tony 20180827
                            string[] RStatusSubCodes = new string[] { "002", "003", "004", "005", "006" };
                            string state = "";
                            string runtime = (string)dt.Rows[i][15];
                            string alarmCode = "NULL";
                            if (string.Equals(sMainCode, "002") && RStatusSubCodes.Contains(sSubCode))
                            {
                                state = "R";
                            }
                            else if (string.Equals(sMainCode, "003"))
                            {
                                state = "A";
                                alarmCode = (string)dt.Rows[i][12];
                            }
                            else
                            {
                                state = "H";
                            }

                            if (uploadHashTable.Contains(runtime))
                            {
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗此状态已上传：(" + state + "|" + runtime + "|" + alarmCode + ") Skip");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }

                                fs = new FileStream(bufferFile, FileMode.Create);
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();
                                Thread.Sleep(iSleep);
                                continue;
                            }

                            fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗得到状态：(" + state + "|" + runtime + "|" + alarmCode + ")");
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }


                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：ready to upload data (sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode,sDllPathName)" + sCompanyID + "|" + sDeviceTypeID + "|" + sEquipID + "|" + state + "|" + runtime + "|" + alarmCode + "|" + sDllPathName);
                                streamWrtLog.Flush();
                                streamWrtLog.Close();
                            }
                            string dllCallReturnString = "";
                            if (ZhenDingWSUploadEquipStatus(sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode, sDllPathName, out dllCallReturnString))
                            {
                                fs = new FileStream(bufferFile, FileMode.Create);
                                sLastUploadTime = sUpdateTime;
                                streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();

                                fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD上传数据结果：成功");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }

                                fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：finish  upload data Success" + dllCallReturnString);
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }
                            }
                            else
                            {
                                if (UploadDataEvent != null)
                                {
                                    UploadDataEvent.Invoke(this, new TransDataEventArgs("sCompanyID, sDeviceTypeID, sEquipID, state, runtime, alarmCode,sDllPathName \n" + sCompanyID + "," + sDeviceTypeID + "," + sEquipID + "," + state + "," + runtime + "," + alarmCode + "," + sDllPathName + "\n" + dllCallReturnString, "臻鼎松崗DLL上傳設備狀態數據錯誤"));
                                }

                                fsUserViewLogFile = new FileStream(userViewLogFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsUserViewLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎QHD上传数据结果：出错");
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }

                                fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                                {
                                    streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：finish  upload data Fail:" + dllCallReturnString);
                                    streamWrtLog.Flush();
                                    streamWrtLog.Close();
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：TBEquipStatus return data count (" + sLastUploadTime + ")：0");
                            streamWrtLog.Flush();
                            streamWrtLog.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("DataExport StartRunZhenDingBDEquipStatus error:" + ex.Message);
                    fsLogFile = new FileStream(logFilePath, FileMode.Append);
                    using (StreamWriter streamWrtLog = new StreamWriter(fsLogFile, Encoding.Default))
                    {
                        streamWrtLog.WriteLine(DateTime.Now.ToString() + " 臻鼎松岗 DLL上传设备状态数据：Catch Exception ：" + ex.Message);
                        streamWrtLog.Flush();
                        streamWrtLog.Close();
                    }
                }
                finally
                {
                    //Q.F.2018.03.20
                    if (streamWrt != null)
                        streamWrt.Close();
                    if (fs != null)
                    {
                        //fs.Flush();
                        fs.Close();
                        fs.Dispose();
                    }

                    if (fsLogFile != null)
                    {
                        //fsLogFile.Flush();
                        fsLogFile.Close();
                        fsLogFile.Dispose();
                    }
                }

                Thread.Sleep(iSleep);
            }
        }

        private static void GetEquipStatusFromDB(System.Data.DataRow Adr, out string AsMainCode, out string AsSubCode, out string AsMainCodeMessage, out string AsSubCodeMessage, out string AsUpdateTime)
        {
            string Start = (string)Adr[0];
            string Run = (string)Adr[1];
            string Stop = (string)Adr[2];
            string Idle = (string)Adr[3];
            string Init = (string)Adr[4];
            string ReqSig = (string)Adr[5];
            string InBoard = (string)Adr[6];
            string InspectBoard = (string)Adr[7];
            string InspectFinish = (string)Adr[8];
            string ReadyOut = (string)Adr[9];
            string BVSig = (string)Adr[10];
            string Error = (string)Adr[11];
            string ErrorContent = (string)Adr[12];
            AsUpdateTime = (string)Adr[15];
            AsMainCode = "";
            AsSubCode = "";
            AsMainCodeMessage = "";
            AsSubCodeMessage = "";
            //string sStatusCode = "";
            if (string.Equals(Error, "1"))
            {
                AsMainCode = "003";
                AsMainCodeMessage = "EquipError";
                AsSubCode = ErrorContent;
                AsSubCodeMessage = ErrorContent;
            }
            else if (string.Equals(ReqSig, "1") || string.Equals(InBoard, "1") || string.Equals(InspectBoard, "1") || string.Equals(InspectFinish, "1") || string.Equals(ReadyOut, "1") || string.Equals(BVSig, "1"))
            {
                AsMainCode = "002";
                AsMainCodeMessage = "EquipMotionChange";
                if (string.Equals(ReqSig, "1"))
                {
                    AsSubCode = "001";
                    AsSubCodeMessage = "RequestSignal";
                }
                else if (string.Equals(InBoard, "1"))
                {
                    AsSubCode = "002";
                    AsSubCodeMessage = "InBoard";
                }
                else if (string.Equals(InspectBoard, "1"))
                {
                    AsSubCode = "003";
                    AsSubCodeMessage = "InspectBoard";
                }
                else if (string.Equals(InspectFinish, "1"))
                {
                    AsSubCode = "004";
                    AsSubCodeMessage = "InspectBoardFinish";
                }
                else if (string.Equals(ReadyOut, "1"))
                {
                    AsSubCode = "005";
                    AsSubCodeMessage = "BoardReadyOut";
                }
                else if (string.Equals(BVSig, "1"))
                {
                    AsSubCode = "006";
                    AsSubCodeMessage = "SendBVSignal";
                }
            }
            else if (string.Equals(Init, "1") || string.Equals(Start, "1") || string.Equals(Run, "1") || string.Equals(Stop, "1") || string.Equals(Idle, "1"))
            {
                AsMainCode = "001";
                AsMainCodeMessage = "EquipStatusChange";
                if (string.Equals(Init, "1"))
                {
                    AsSubCode = "001";
                    AsSubCodeMessage = "EquipInit";
                }
                else if (string.Equals(Start, "1"))
                {
                    AsSubCode = "002";
                    AsSubCodeMessage = "EquipStart";
                }
                else if (string.Equals(Run, "1"))
                {
                    AsSubCode = "003";
                    AsSubCodeMessage = "EquipRun";
                }
                else if (string.Equals(Stop, "1"))
                {
                    AsSubCode = "004";
                    AsSubCodeMessage = "EquipStop";
                }
                else if (string.Equals(Idle, "1"))
                {
                    AsSubCode = "005";
                    AsSubCodeMessage = "EquipIdle";
                }
            }

        }

        private bool ZhenDingWSUploadEquipStatus(string sCompanyID, string sDeviceTypeID, string sEquipID, string sState, string sRunTime, string sAlarmCode, string sDllPathName, out string sDllReturnString)
        {
            //string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + ZhenDingBD.RS_TIME_FORMAT);
            //modify by tony 180323
            string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + " " + ZhenDingBD.RS_TIME_FORMAT);
            DllInvoke dllInvoke = new DllInvoke();
            sDllReturnString = "";
            object[] paramObject = new object[6];
            paramObject[0] = (string)sCompanyID;
            paramObject[1] = (string)sDeviceTypeID;
            paramObject[2] = (string)sEquipID;
            paramObject[3] = (string)ZhenDingBD.RS_EQUIP_STATUS;
            paramObject[4] = sState + "|" + sRunTime + "|" + sAlarmCode;
            paramObject[5] = (string)sNowTime;
            string sErrorReturn = "";
            string strCallReturn = (string)dllInvoke.InvokeCLRDll(sDllPathName, ZhenDingBD.RS_DLL_NAMESPACE, ZhenDingBD.RS_DLL_CLASSNAME, ZhenDingBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);
            sDllReturnString = strCallReturn + sErrorReturn;
            if (string.IsNullOrEmpty(strCallReturn) || !string.Equals(strCallReturn, "OK"))
            {
                return false;
            }
            return true;
        }

        //板数据

        Thread _zhenDingBDBoardThread = null;
        //start uploadDoard Thread
        public void StartZhenDingBDBoard(string sCompanyID, string sDeviceTypeID, string sEquipID, string dllPath, int iMaxParallelCount)
        {
            if (_zhenDingBDBoardThread != null)
            {
                ThreadState state = _zhenDingBDBoardThread.ThreadState;
                if ((state
                    & (System.Threading.ThreadState.WaitSleepJoin
                    | System.Threading.ThreadState.Background
                    | System.Threading.ThreadState.Running))
                    == state)
                    return;

            }

            object[] objParameters = new object[5];
            objParameters[0] = sCompanyID;
            objParameters[1] = sDeviceTypeID;
            objParameters[2] = sEquipID;
            objParameters[3] = Path.Combine(dllPath, ZhenDingBD.RS_DLL_NAME);
            objParameters[4] = (iMaxParallelCount <= 0 || iMaxParallelCount >= 10) ? ZhenDingBD.I_MAX_PARALLEL_COUNT : iMaxParallelCount;
            _zhenDingBDBoardThread = new Thread(new ParameterizedThreadStart(StartZhenDingBDBoardThread));
            _zhenDingBDBoardThread.IsBackground = true;
            _zhenDingBDBoardThread.Start(objParameters);

        }
        //end uploadDoard Thread
        public void ZhenDingBDUploadBoardStop()
        {
            try
            {
                if (_zhenDingBDBoardThread != null && (_zhenDingBDBoardThread.ThreadState == ThreadState.Running || _zhenDingBDBoardThread.ThreadState == ThreadState.Background))
                {
                    _zhenDingBDBoardThread.Abort();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ZhenDingBDUploadBoardStop error" + ex.Message);
            }
        }

        protected ushort[] _arrToken = new ushort[2];

        // upload board thread function
        private void StartZhenDingBDBoardThread(object AobjParameters)
        {
            object[] objParameters = (object[])AobjParameters;
            string sCompanyID = (string)objParameters[0];
            string sDeviceTypeID = (string)objParameters[1];
            string sEquipID = (string)objParameters[2];
            string dllPathName = (string)objParameters[3];
            int iMaxParallelCount = (int)objParameters[4];

            DllInvoke dllInvoke = new DllInvoke();
            FileStream fsLogFile = null;
            if (!Directory.Exists(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
            {
                Directory.CreateDirectory(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
            }
            string logFilePath = Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", "ZhendingUploadBoard.log");
            if (!File.Exists(logFilePath))
            {
                fsLogFile = File.Create(logFilePath);
            }
            //else
            //{
            //    fsLogFile = new FileStream(logFilePath, FileMode.Append);
            //}
            //add by tony 180806
            ParallelOptions parallelOpt = new ParallelOptions();
            parallelOpt.MaxDegreeOfParallelism = iMaxParallelCount;
            while (true)
            {
                TimeSpan nowDateTs = new TimeSpan(DateTime.Now.Ticks);
                string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + " " + ZhenDingBD.RS_TIME_FORMAT);

                try
                {
                    if (Directory.Exists(_strTmpFileDir))
                    {
                        DirectoryInfo tmpDirInfo = new DirectoryInfo(_strTmpFileDir);
                        FileInfo[] arrFileInfo = tmpDirInfo.GetFiles(ZhenDingBD.RS_PNL_BUFFER_FILE_NAME + "_*.tmp", SearchOption.TopDirectoryOnly);

                        if (arrFileInfo != null && arrFileInfo.Length > 0)
                        {
                            for (int i = 0; i < arrFileInfo.Length; i++)
                            {
                                FileInfo fInfo = arrFileInfo[i];
                                TimeSpan fileLastModifyTs = new TimeSpan(fInfo.LastWriteTime.Ticks);
                                int lastModifySec = (int)nowDateTs.Subtract(fileLastModifyTs).Duration().TotalSeconds;

                                if (lastModifySec > 60)
                                {
                                    //Console.WriteLine("fInfo.FullName=" + fInfo.FullName);
                                    //string upUploadLines = "";
                                    bool bUploadFail = false;
                                    string lineStr;
                                    List<String> arrlineStr = null;
                                    List<String> arrUnUploadLine = null;

                                    using (System.IO.StreamReader sr = new System.IO.StreamReader(fInfo.FullName))
                                    {
                                        arrlineStr = new List<string>();
                                        arrUnUploadLine = new List<string>();

                                        while ((lineStr = sr.ReadLine()) != null)
                                        {
                                            arrlineStr.Add(lineStr);
                                        }
                                        if (arrlineStr.Count > 0)
                                        {

                                            Parallel.For(0, arrlineStr.Count, parallelOpt, index =>
                                            {
                                                //Console.WriteLine("index==" + index);
                                                object[] paramObject = new object[6];
                                                paramObject[0] = (string)sCompanyID;
                                                paramObject[1] = (string)sDeviceTypeID;
                                                paramObject[2] = (string)sEquipID;
                                                paramObject[3] = (string)ZhenDingBD.RS_BOARD_PARAM_NAME;
                                                paramObject[4] = arrlineStr[index];
                                                paramObject[5] = (string)sNowTime;

                                                if (bUploadFail)
                                                {
                                                    Monitor.Enter(_arrToken);
                                                    arrUnUploadLine.Add(arrlineStr[index]);
                                                    Monitor.Exit(_arrToken);
                                                }
                                                else
                                                {
                                                    string sErrorReturn = "";
                                                    object objCallReturn = dllInvoke.InvokeCLRDll(dllPathName, ZhenDingBD.RS_DLL_NAMESPACE, ZhenDingBD.RS_DLL_CLASSNAME, ZhenDingBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);
                                                    string strCallReturn = objCallReturn.ToString();

                                                    if (string.Equals(strCallReturn, "Dll Call Error!"))
                                                    {
                                                        Monitor.Enter(_arrToken);
                                                        if (UploadDataEvent != null)
                                                        {
                                                            UploadDataEvent.Invoke(this, new TransDataEventArgs(paramObject[3].ToString() + "\n" + paramObject[4].ToString() + "\n" + strCallReturn, "臻鼎松崗DLL上傳板數據錯誤"));
                                                        }
                                                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                                        using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                                        {
                                                            streamWrt.WriteLine(DateTime.Now.ToString());
                                                            streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 调用错误:" + sErrorReturn);
                                                            streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                                            streamWrt.WriteLine(arrlineStr[index]);

                                                            streamWrt.Flush();
                                                            streamWrt.Close();
                                                        }


                                                        arrUnUploadLine.Add(arrlineStr[index]);

                                                        bUploadFail = true;
                                                        Monitor.Exit(_arrToken);
                                                    }
                                                    else if (!string.Equals(strCallReturn, "OK"))
                                                    {
                                                        Monitor.Enter(_arrToken);
                                                        if (strCallReturn.IndexOf("NG") > 0)
                                                        {
                                                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                                            using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                                            {
                                                                if (strCallReturn.IndexOf("parameter number mismatch") >= 0)
                                                                {
                                                                    streamWrt.WriteLine(DateTime.Now.ToString());
                                                                    streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 返回参数个数不匹配（" + strCallReturn + "）:" + ZhenDingBD.RS_BOARD_PARAM_NAME.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length + "," + lineStr.Split("|".ToCharArray()).Length);
                                                                    streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                                                    streamWrt.WriteLine(arrlineStr[index]);
                                                                    streamWrt.Flush();
                                                                    streamWrt.Close();
                                                                }
                                                                else
                                                                {
                                                                    if (UploadDataEvent != null)
                                                                    {
                                                                        UploadDataEvent.Invoke(this, new TransDataEventArgs(paramObject[3].ToString() + "\n" + paramObject[4].ToString() + "\n" + strCallReturn, "臻鼎松崗DLL上傳板數據錯誤"));
                                                                    }
                                                                    streamWrt.WriteLine(DateTime.Now.ToString());
                                                                    streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 返回错误（" + strCallReturn + "）");
                                                                    streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                                                    streamWrt.WriteLine(arrlineStr[index]);
                                                                    streamWrt.Flush();
                                                                    streamWrt.Close();
                                                                }
                                                            }
                                                        }

                                                        arrUnUploadLine.Add(arrlineStr[index]);

                                                        bUploadFail = true;
                                                        Monitor.Exit(_arrToken);
                                                    }
                                                }
                                                ;
                                            });
                                        }

                                        //while ((lineStr = sr.ReadLine()) != null)
                                        //{
                                        //    paramObject[4] = lineStr;
                                        //    paramObject[5] = (string)sNowTime;
                                        //    if (bUploadFail)
                                        //    {
                                        //        upUploadLines += lineStr + RS_LineEnd;
                                        //    }
                                        //    else
                                        //    {
                                        //        string sErrorReturn = "";
                                        //        object objCallReturn = dllInvoke.InvokeCLRDll(dllPathName, ZhenDingBD.RS_DLL_NAMESPACE, ZhenDingBD.RS_DLL_CLASSNAME, ZhenDingBD.RS_DLL_FUNCTION, paramObject, ref sErrorReturn);
                                        //        string strCallReturn = objCallReturn.ToString();

                                        //        if (string.Equals(strCallReturn, "Dll Call Error!"))
                                        //        {
                                        //            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                        //            using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                        //            {
                                        //                streamWrt.WriteLine(DateTime.Now.ToString());
                                        //                streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 调用错误:" + sErrorReturn);
                                        //                streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                        //                streamWrt.WriteLine(lineStr);
                                        //            }

                                        //            upUploadLines += lineStr + RS_LineEnd;
                                        //            bUploadFail = true;
                                        //        }

                                        //        else if (!string.Equals(strCallReturn, "OK"))
                                        //        {
                                        //            if (strCallReturn.IndexOf("NG") > 0)
                                        //            {
                                        //                fsLogFile = new FileStream(logFilePath, FileMode.Append);
                                        //                using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                        //                {
                                        //                    if (strCallReturn.IndexOf("parameter number mismatch") >= 0)
                                        //                    {

                                        //                        streamWrt.WriteLine(DateTime.Now.ToString());
                                        //                        streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 返回参数个数不匹配（" + strCallReturn + "）:" + ZhenDingBD.RS_BOARD_PARAM_NAME.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length + "," + lineStr.Split("|".ToCharArray()).Length);
                                        //                        streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                        //                        streamWrt.WriteLine(lineStr);

                                        //                    }
                                        //                    else
                                        //                    {
                                        //                        streamWrt.WriteLine(DateTime.Now.ToString());
                                        //                        streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 返回错误（" + strCallReturn + "）");
                                        //                        streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                        //                        streamWrt.WriteLine(lineStr);
                                        //                    }
                                        //                }
                                        //            }
                                        //            upUploadLines += lineStr + RS_LineEnd;
                                        //            bUploadFail = true;
                                        //        }

                                        //    }

                                        //}
                                    }

                                    if (arrUnUploadLine != null && arrUnUploadLine.Count > 0)
                                    {
                                        FileStream fsReWrite = new FileStream(fInfo.FullName, FileMode.Create);
                                        using (StreamWriter streamWrt = new StreamWriter(fsReWrite, Encoding.Default))
                                        {
                                            foreach (string unUploadline in arrUnUploadLine)
                                            {
                                                streamWrt.WriteLine(unUploadline);
                                            }
                                            streamWrt.Flush();
                                            streamWrt.Close();
                                        }
                                        break;
                                    }
                                    else
                                    {
                                        File.Delete(fInfo.FullName);
                                    }


                                    //if (!string.IsNullOrEmpty(upUploadLines))
                                    //{
                                    //    FileStream fsReWrite = new FileStream(fInfo.FullName, FileMode.Create);
                                    //    using (StreamWriter streamWrt = new StreamWriter(fsReWrite, Encoding.Default))
                                    //    {
                                    //        streamWrt.Write(upUploadLines);
                                    //        streamWrt.Flush();
                                    //        streamWrt.Close();
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    File.Delete(fInfo.FullName);
                                    //}
                                }

                            }

                        }

                    }
                }
                catch (Exception ex)
                {
                    fsLogFile = new FileStream(logFilePath, FileMode.Append);
                    using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                    {
                        streamWrt.WriteLine("臻鼎DLL上传板数据异常：");
                        streamWrt.WriteLine(ex.Message);
                        streamWrt.Flush();
                        streamWrt.Close();
                    }
                }
                Thread.Sleep(5000);
            }
        }


        public string SendDataZhenDingBDBoard(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            string sCompanyID = AappSettingData.stDataExpVT.strCustomer;
            string sDeviceTypeID = AappSettingData.stDataExpVT.strTestType;
            string sEquipID = AappSettingData.stDataExpVT.strMachine;
            string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
            int iMaxParallelCount = 2;//
            //if (AappSettingData.stDataExpVT.MaxThreadNumUsingExternDLL > 0) 
            //{
            //    iMaxParallelCount = AappSettingData.stDataExpVT.MaxThreadNumUsingExternDLL;
            //}
            string strMsg = RS_EMPTY;
            if (!Directory.Exists(_strTmpFileDir))
            {
                Directory.CreateDirectory(_strTmpFileDir);
            }
            
            try
            {
                //string sErrorStr = "";

                string uploadLines = ZhenDingGetBoardLines(ref APads, ref ABrdRes, ref  APcbGeneralInfo, ref  AappSettingData, AstrDir, byLaneNo);

                if (!string.IsNullOrEmpty(uploadLines))
                {
                    // write backUp file
                    bool bSaveTempFile = true;

                    bool bSaveBackupFile = !string.IsNullOrEmpty(AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                       // && !AappSettingData.stDataExpVT.bEnExportUsingExternDLL;
                    bool bSaveUploadTempFile = AappSettingData.stDataExpVT.bEnExportUsingExternDLL;
                    if (bSaveBackupFile || (bSaveTempFile && !string.IsNullOrEmpty(AstrDir)))
                    {

                        string csvLines = uploadLines.Replace(PubStaticParam.RS_VerticalLineSplit, PubStaticParam.RS_CommaSplit);
                        if (!string.IsNullOrEmpty(AstrDir))
                        {
                            //using (FileStream fs = new FileStream(AstrDir, FileMode.Create))
                            //{
                            //    StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                            //    streamWrt.Write(ZhenDingQHDBD.RS_BOARD_BACKUP_NAME + PubStaticParam.RS_LineEnd + csvLines);
                            //    streamWrt.Flush();
                            //    streamWrt.Close();
                            //}
                        }
                        if (bSaveBackupFile)
                        {
                            if (!Directory.Exists(AappSettingData.stDataExpVT.strBackUpExportedFilePath))
                            {
                                Directory.CreateDirectory(AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                            }
                            string strDate = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                            string strTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                            string strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode,
                                                                AappSettingData, (byte)ABrdRes.LaneNo);

                            //modify tony 18.07.12 change save file path YYYY/MM/DD
                            ///check or create directory
                            ///

                            string sYear = ABrdRes.startTime.ToString(ZhenDingBD.FilePathYMD[0]);
                            string sMonth = ABrdRes.startTime.ToString(ZhenDingBD.FilePathYMD[1]);
                            string sDay = ABrdRes.startTime.ToString(ZhenDingBD.FilePathYMD[2]);
                            string sBackUpFilePath = Path.Combine(AappSettingData.stDataExpVT.strBackUpExportedFilePath, sYear, sMonth, sDay);
                            if (!Directory.Exists(sBackUpFilePath))
                            {
                                Directory.CreateDirectory(sBackUpFilePath);
                            }

                            string sBackUpFile = Path.Combine(sBackUpFilePath, strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strTime + PubStaticParam.RS_CSV_EXT);

                            if (!File.Exists(sBackUpFile))
                            {
                                using (FileStream fs = new FileStream(sBackUpFile, FileMode.Append))
                                {

                                    StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                                    streamWrt.Write(ZhenDingBD.RS_BOARD_BACKUP_NAME + PubStaticParam.RS_LineEnd + csvLines);
                                    streamWrt.Flush();
                                    streamWrt.Close();
                                }
                            }
                        }

                    }
                    if (bSaveUploadTempFile)
                    {
                        // write temp file for upload    
                        string boardTempFile = Path.Combine(_strTmpFileDir, ZhenDingBD.RS_PNL_BUFFER_FILE_NAME + "_" + byLaneNo + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".tmp");
                        using (FileStream fs = new FileStream(boardTempFile, FileMode.Create))
                        {
                            StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                            streamWrt.Write(uploadLines);
                            streamWrt.Flush();
                            streamWrt.Close();

                        }
                        this.StartZhenDingBDBoard(sCompanyID, sDeviceTypeID, sEquipID, sDllPath, iMaxParallelCount);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
                ;
            }
            return strMsg;
        }


        /*
                public string SendDataZhenDingBDBoard(InspectMainLib.Pad[] APads,
                 SPCBoardRes ABrdRes,
                 ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                 AppSettingData AappSettingData,
                 string AstrDir, string AstrClntName)
                {
                    //Q.F.2018.03.19
                    //-> byte byLaneNo string sCompanyID, string sDeviceTypeID, string sEquipID,string sDllPath
                    byte byLaneNo = (byte)ABrdRes.LaneNo;
                    string sCompanyID = AappSettingData.stDataExpVT.strCustomer;
                    string sDeviceTypeID = AappSettingData.stDataExpVT.strTestType;
                    string sEquipID = AappSettingData.stDataExpVT.strMachine;

                    //string sCompanyID = AappSettingData.stMonitorSystemParams.strLogCompany;
                    //string sDeviceTypeID = AappSettingData.stMonitorSystemParams.strLogDeviceType;
                    //string sEquipID = AappSettingData.stMonitorSystemParams.strLogEquipID;


                    string sDllPath = AappSettingData.strConfigThirdPartyDLLPath;
                    //<-

                    string strMsg = RS_EMPTY;
                    int iUnUploadPadsCount = 0;
                    string bufferFile = Path.Combine(_strTmpFileDir, ZhenDingBD.RS_PNL_BUFFER_FILE_NAME + "_" + byLaneNo + ".tmp");
                    FileStream fs = null;
                    FileStream fsLogFile = null;
                    System.IO.StreamWriter streamWrt = null;
                    string dllPathName = Path.Combine(sDllPath, ZhenDingBD.RS_DLL_NAME);


                    try
                    {
                        bool bDllCallErrorFlag = false;
                        string sErrorStr = "";
                        //add by Tony 2018.04.23
                        if (!Directory.Exists(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
                        {
                            Directory.CreateDirectory(Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
                        }
                        string logFilePath = Path.Combine(ZhenDingBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", "ZhendingUploda.log");
                
                        if (!File.Exists(logFilePath))
                        {
                            fsLogFile = File.Create(logFilePath);
                        }
                        else 
                        {
                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        }
                        string sUnUploadLines = ZhenDingWSUploadBoard(ref APads, ref  ABrdRes, ref  APcbGeneralInfo, ref AappSettingData,
                                            AstrDir, byLaneNo, sCompanyID, sDeviceTypeID, sEquipID, "", dllPathName, ref bDllCallErrorFlag, ref sErrorStr, ref fsLogFile);
                        fs = new FileStream(bufferFile, FileMode.Append);
                        if (!string.IsNullOrEmpty(sUnUploadLines))
                        {
                            streamWrt = new StreamWriter(fs, Encoding.Default);
                            streamWrt.Write(sUnUploadLines);
                            streamWrt.Close();
                            strMsg += "Upload Current board Error: " + sErrorStr;

                        }
                        fs.Close();
                        sErrorStr = "";
                        StringBuilder sbRemainLines = new StringBuilder();
                        using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
                        {
                            string lineStr;
                            while ((lineStr = sr.ReadLine()) != null)
                            {
                                sUnUploadLines = ZhenDingWSUploadBoard(ref APads, ref  ABrdRes, ref  APcbGeneralInfo, ref AappSettingData,
                                            AstrDir, byLaneNo, sCompanyID, sDeviceTypeID, sEquipID, lineStr, dllPathName, ref bDllCallErrorFlag, ref sErrorStr,ref fsLogFile);
                                if (!string.IsNullOrEmpty(sUnUploadLines))
                                {
                                    iUnUploadPadsCount++;
                                    sbRemainLines.Append(lineStr + RS_LineEnd);
                                }
                            }
                        }

                        fs = new FileStream(bufferFile, FileMode.Create);
                        streamWrt = new StreamWriter(fs, Encoding.Default);
                        if (!string.IsNullOrEmpty(sbRemainLines.ToString()))
                        {
                            strMsg += "Upload History board Error: " + sErrorStr;
                            streamWrt.Write(sbRemainLines);
                            streamWrt.Close();
                            fs.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                        strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
                    }
                    finally
                    {
                        if (streamWrt != null)
                            streamWrt.Close();
                        if (fs != null)
                            fs.Close();
                        if (fsLogFile != null)
                            fsLogFile.Close();
                    }
                    return strMsg;
                }

        */
        /*
                private string ZhenDingWSUploadBoard(ref InspectMainLib.Pad[] APads, ref SPCBoardRes ABrdRes,
                 ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, ref AppSettingData AappSettingData,
                 string AstrDir, byte AbyLaneNo,
                 string sCompanyID, string sDeviceTypeID, string sEquipID, string strBoardUploadLines, string sDllPathName, ref bool bDllCallErrorFlag, ref string sErrorString,ref FileStream fsLogFile )
                {
                    string UnUploadLines = "";
                    try
                    {
                        //string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + ZhenDingBD.RS_TIME_FORMAT);
                        //modify by tony 180323
                        string sNowTime = DateTime.Now.ToString(ZhenDingBD.RS_DATE_FORMAT + " " + ZhenDingBD.RS_TIME_FORMAT);
                        DllInvoke dllInvoke = new DllInvoke();


                        object[] paramObject = new object[6];
                        paramObject[0] = (string)sCompanyID;
                        paramObject[1] = (string)sDeviceTypeID;
                        paramObject[2] = (string)sEquipID;
                        paramObject[3] = (string)ZhenDingBD.RS_BOARD_PARAM_NAME;
                        int iParamNameCount = ZhenDingBD.RS_BOARD_PARAM_NAME.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length;
                        string uploadLines = strBoardUploadLines;

                        if (string.IsNullOrEmpty(uploadLines))
                        {

                            uploadLines = ZhenDingGetBoardLines(ref APads, ref ABrdRes, ref  APcbGeneralInfo, ref  AappSettingData, AstrDir, AbyLaneNo);
                            //add by tony 180326
                            //可能要加是否要输出backup file
                            if (!string.IsNullOrEmpty(AappSettingData.stDataExpVT.strBackUpExportedFilePath)) 
                            {
                                try
                                {
                                    if (!Directory.Exists(AappSettingData.stDataExpVT.strBackUpExportedFilePath))
                                    {
                                        Directory.CreateDirectory(AappSettingData.stDataExpVT.strBackUpExportedFilePath);
                                    }
                                    string strDate = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                                    string strTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                                    string strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode,
                                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                                    //string sBackUpFile = Path.Combine(_strTmpFileDir, strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strTime + PubStaticParam.RS_CSV_EXT);
                                    string sBackUpFile = Path.Combine(AappSettingData.stDataExpVT.strBackUpExportedFilePath, strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strTime + PubStaticParam.RS_CSV_EXT);
                                                       
                                    if (!File.Exists(sBackUpFile))
                                    {
                                        using (FileStream fs = new FileStream(sBackUpFile, FileMode.Append))
                                        {
                                            if (!string.IsNullOrEmpty(uploadLines))
                                            {
                                                string csvLines = uploadLines.Replace(PubStaticParam.RS_VerticalLineSplit, PubStaticParam.RS_CommaSplit);
                                                StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                                                streamWrt.Write(ZhenDingBD.RS_BOARD_BACKUP_NAME + PubStaticParam.RS_LineEnd + csvLines);
                                                streamWrt.Flush();
                                                streamWrt.Close();
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex) 
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }                    
                        }


                        string[] arrSlines = uploadLines.Split(RS_LineEnd.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                        using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrt.WriteLine(DateTime.Now.ToString());
                            streamWrt.WriteLine("臻鼎DLL上传板数据-Data------>>");
                            streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                            streamWrt.Write(uploadLines);                    
                            streamWrt.Flush();
                            streamWrt.Close();
                        }
                        // bool bDllCallErrorFlag = false;
                        foreach (string line in arrSlines)
                        {
                            //
                            paramObject[4] = line;
                            paramObject[5] = (string)sNowTime;
                            int iValueCount = line.Split("|".ToCharArray()).Length;
                    
                            if (iParamNameCount != iValueCount) 
                            {
                                Console.WriteLine("ZhenDingWSUploadBoard Dll Call Error! parameter name value mismatch" + iParamNameCount+","+iValueCount);
                        
                                using(StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                {
                                    streamWrt.WriteLine(DateTime.Now.ToString());
                                    streamWrt.WriteLine("臻鼎DLL上传板数据：参数个数不匹配:"+ iParamNameCount+","+iValueCount);                            
                                    streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                    streamWrt.WriteLine(line);
                                    streamWrt.Flush();
                                    streamWrt.Close();
                                }
                                bDllCallErrorFlag = true;
                       
                            }
                            if (bDllCallErrorFlag == false)
                            {
                                object objCallReturn = dllInvoke.InvokeCLRDll(sDllPathName, ZhenDingBD.RS_DLL_NAMESPACE, ZhenDingBD.RS_DLL_CLASSNAME, ZhenDingBD.RS_DLL_FUNCTION, paramObject);
                                string strCallReturn = objCallReturn.ToString();
                                if (string.Equals(strCallReturn, "Dll Call Error!"))
                                {
                                    Console.WriteLine("ZhenDingWSUploadBoard Dll Call Error!");
                                    bDllCallErrorFlag = true;


                                }
                                if (bDllCallErrorFlag == true || !string.Equals(strCallReturn, "OK"))
                                {
                                    if (bDllCallErrorFlag == true)
                                    {
                                        sErrorString = "ZhenDingWSUploadBoard Dll Call Catch Exception! ";
                                    }
                                    else
                                    {
                                        if (strCallReturn.IndexOf("NG") > 0) 
                                        {
                                            bDllCallErrorFlag = true;
                                            if (strCallReturn.IndexOf("parameter number mismatch")>=0) 
                                            {
                                                using (StreamWriter streamWrt = new StreamWriter(fsLogFile, Encoding.Default))
                                                {
                                                    streamWrt.WriteLine(DateTime.Now.ToString());
                                                    streamWrt.WriteLine("臻鼎DLL上传板数据：DLL 返回参数个数不匹配（" + strCallReturn + "）:" + iParamNameCount + "," + iValueCount);
                                                    streamWrt.WriteLine(ZhenDingBD.RS_BOARD_PARAM_NAME);
                                                    streamWrt.WriteLine(line);
                                                    streamWrt.Flush();
                                                    streamWrt.Close();
                                                }
                      
                                            }
                                        }
                                        sErrorString = "ZhenDingWSUploadBoard Dll Call return : " + strCallReturn.ToString();
                                    }

                                    UnUploadLines += line + RS_LineEnd;
                                }

                            }
                            else
                            {
                                UnUploadLines += line + RS_LineEnd;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return UnUploadLines;

                }

        */

        private string ZhenDingGetBoardLines(ref InspectMainLib.Pad[] APads, ref SPCBoardRes ABrdRes,
         ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, ref AppSettingData AappSettingData,
         string AstrDir, byte AbyLaneNo)
        {
            string strLine = string.Empty;
            string strArrayBarcode = string.Empty;
            string strArrayId = string.Empty;
            string result = string.Empty;
            string strArrayStatus = string.Empty;
            string strArrayStatusCustom = string.Empty;
            int iArrayCount = 0;
            try
            {
                string lineName = AappSettingData.LineName;
                string strDate = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE);
                string strStartTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                string strEndTime = ABrdRes.endTime.ToString(PubStaticParam.RS_FORMAT_TIME);
                string modelName = Path.GetFileNameWithoutExtension(ABrdRes.jobName) + "";
                float fValue2Perc = 100.0f;//Q.F.2018.03.27

                string strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode,
                                                      AappSettingData, (byte)ABrdRes.LaneNo);
                StringBuilder strBld = new StringBuilder();
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                float fShiftSpecX = 0, fShiftSpecY = 0;
                //if (bISArrayPCB && iArrayCount > 0)
                if (iArrayCount > 0)
                {
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            strArrayStatusCustom = ZhenDingQHDBD.RS_ARRAY_RESULT[APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes];
                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            strArrayId = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (string.IsNullOrEmpty(strArrayBarcode)
                                || string.Equals(strArrayBarcode, RS_NOREAD, StringComparison.InvariantCultureIgnoreCase))
                            {
                                strArrayBarcode = strboardBarcode + PubStaticParam.RS_UnderLineSplit + strArrayId;
                            }
                            #region "  skip "
                            if (strArrayStatus == "Skipped")
                            {
                                //Q.F.2019.06.23
                                if (AappSettingData.stDataExpVT.BEnExportSkip == false)
                                    continue;
                                int[] iarrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;
                                foreach (int iPadIndex in iarrPadIndex)
                                {
                                    Pad skipBoardPad = APads[iPadIndex];
                                    string errorSkip = string.Empty;
                                    string padGroup = string.IsNullOrEmpty(skipBoardPad.padGroup) ? "ungrouped" : skipBoardPad.padGroup;
                                    if (skipBoardPad.check)
                                    {
                                        if (skipBoardPad.res.jugRes == JudgeRes.NG)
                                        {
                                            // errorSkip = _baseFun.GetPadErrorCodeStr(skipBoardPad, AappSettingData);
                                        }
                                        float meanHeight = 0f;
                                        float meanArea = 0f;
                                        float meanVolume = 0f;
                                        GetMeanValue(APcbGeneralInfo, skipBoardPad, iPadIndex, out meanHeight, out meanArea, out meanVolume);
                                        strBld.Append(
                                                    modelName + PubStaticParam.RS_VerticalLineSplit +//Model name
                                                   lineName + PubStaticParam.RS_VerticalLineSplit +//Line number
                                                   skipBoardPad.componentID + PubStaticParam.RS_VerticalLineSplit +//comp name
                                                   skipBoardPad.packageType + PubStaticParam.RS_VerticalLineSplit +//type
                                                   (skipBoardPad.res.measuredValue.perArea * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area(%)

                                        //modify tony 2018.11.08
                                        if (meanArea == 0)
                                        {
                                            strBld.Append((skipBoardPad.res.measuredValue.fCadArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        //(skipBoardPad.spec.areaPerH * skipBoardPad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl
                                        strBld.Append(
                                            (skipBoardPad.spec.areaPerH * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl(%)


                                           (skipBoardPad.res.measuredValue.area * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area    
                                            //(skipBoardPad.spec.areaPerL * skipBoardPad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL
                                           (skipBoardPad.spec.areaPerL * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL (%)

                                           (skipBoardPad.res.measuredValue.perHeight * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); //height(%)

                                        //modify tony 2018.11.08
                                        if (meanHeight == 0)
                                        {
                                            strBld.Append(skipBoardPad.stencilHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//height standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanHeight * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        fShiftSpecX = Math.Abs(skipBoardPad.spec.shiftXHPer);
                                        fShiftSpecY = Math.Abs(skipBoardPad.spec.shiftYHPer);

                                        strBld.Append(

                                    //skipBoardPad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL
                                           (skipBoardPad.spec.heightH / (skipBoardPad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL (%)

                                           (skipBoardPad.res.measuredValue.height * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Height
                                            //skipBoardPad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL                                                   
                                           (skipBoardPad.spec.heightL / (skipBoardPad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL (%)                                                 

                                           (skipBoardPad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//vol %

                                        //modify tony 2018.11.08
                                        if (meanVolume == 0)
                                        {
                                            strBld.Append((skipBoardPad.res.measuredValue.fCadArea * (skipBoardPad.stencilHeight * PubStaticParam.RS_fMM2UM) * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); // vol statndard
                                        }
                                        else
                                        {
                                            strBld.Append((meanVolume * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        //(skipBoardPad.spec.volPerH * skipBoardPad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL
                                        strBld.Append((skipBoardPad.spec.volPerH * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL (%)

                                         (skipBoardPad.res.measuredValue.vol * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit + //vol                                                   
                                            //(skipBoardPad.spec.volPerL * skipBoardPad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL
                                         (skipBoardPad.spec.volPerL * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL (%)

                                         //skipBoardPad.spec.shiftXH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL
                                         (fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)

                                         (skipBoardPad.res.measuredValue.offsetX).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset                                                    
                                         (-fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                            //"0" + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL
                                            //skipBoardPad.spec.shiftYH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL
                                            //(skipBoardPad.spec.shiftYH / skipBoardPad.sizeYmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                            //(-1f * Math.Abs(skipBoardPad.spec.shiftXHPer) * 100).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                         (fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +
                                         skipBoardPad.res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset                                                   
                                         (-fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset LSL
                                         skipBoardPad.sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//skipBoardPadSizex
                                         skipBoardPad.sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padsizey
                                            //

                                  // modify by tony 180326 Component info spi is null
                                            //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                            //pad.res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average :LSL
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                         "" + PubStaticParam.RS_VerticalLineSplit +//Average :LSL


                                         strArrayStatusCustom + PubStaticParam.RS_VerticalLineSplit +//Result(array result)
                                         "" + PubStaticParam.RS_VerticalLineSplit +
                                         skipBoardPad.pinNumber + PubStaticParam.RS_VerticalLineSplit +//pin num
                                         strboardBarcode + PubStaticParam.RS_VerticalLineSplit +//barcode
                                         strDate + PubStaticParam.RS_VerticalLineSplit +//date
                                         strStartTime + PubStaticParam.RS_VerticalLineSplit +//start time
                                         strEndTime + PubStaticParam.RS_VerticalLineSplit +//end time
                                         strArrayId + PubStaticParam.RS_VerticalLineSplit +//array id
                                         strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strStartTime + PubStaticParam.RS_VerticalLineSplit +//key
                                         padGroup

                                         );
                                        strBld.Append(RS_LineEnd);
                                        break;
                                    }
                                }
                            }
                            #endregion
                            else
                            {
                                int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;
                                //

                                foreach (int padIndex in arrPadIndex)
                                {
                                    Pad pad = APads[padIndex];
                                    string errorPadcode = string.Empty;
                                    string padGroup = string.IsNullOrEmpty(pad.padGroup) ? "ungrouped" : pad.padGroup;
                                    if (_baseFun.bPadIsSkip(pad))
                                    {
                                        continue;
                                    }
                                    if (pad.check)
                                    {
                                        if (pad.res.jugRes == JudgeRes.NG)
                                        {
                                            errorPadcode = _baseFun.GetPadErrorCodeStr(pad, AappSettingData);
                                        }
                                        float meanHeight = 0f;
                                        float meanArea = 0f;
                                        float meanVolume = 0f;
                                        GetMeanValue(APcbGeneralInfo, pad, padIndex, out meanHeight, out meanArea, out meanVolume);
                                        strBld.Append(
                                                   modelName + PubStaticParam.RS_VerticalLineSplit +//Model name
                                                   lineName + PubStaticParam.RS_VerticalLineSplit +//Line number
                                                   pad.componentID + PubStaticParam.RS_VerticalLineSplit +//comp name
                                                   pad.packageType + PubStaticParam.RS_VerticalLineSplit +//type
                                                   (pad.res.measuredValue.perArea * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area(%)

                                        //modify tony 2018.11.08
                                        if (meanArea == 0)
                                        {
                                            strBld.Append((pad.res.measuredValue.fCadArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//Area standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanArea * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }


                                        //(pad.spec.areaPerH * pad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl
                                        strBld.Append((pad.spec.areaPerH * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area usl(%)


                                         (pad.res.measuredValue.area * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area    
                                            //(pad.spec.areaPerL * pad.res.measuredValue.fCadArea).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL
                                         (pad.spec.areaPerL * fValue2Perc).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Area LSL (%)

                                         (pad.res.measuredValue.perHeight * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit); //height(%)

                                        //modify tony 2018.11.08
                                        if (meanHeight == 0)
                                        {
                                            strBld.Append(pad.stencilHeight.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//height standard
                                        }
                                        else
                                        {
                                            strBld.Append((meanHeight * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }

                                        //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL
                                        strBld.Append((pad.spec.heightH / (pad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height USL (%)

                                        (pad.res.measuredValue.height * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL                                                   
                                        (pad.spec.heightL / (pad.stencilHeight * 10)).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//height LSL (%)                                                 

                                        (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);//vol %

                                        //modify tony 2018.11.08
                                        if (meanVolume == 0)
                                        {
                                            strBld.Append((pad.res.measuredValue.fCadArea * (pad.stencilHeight * PubStaticParam.RS_fMM2UM) * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);// vol statndard
                                        }
                                        else
                                        {
                                            strBld.Append((meanVolume * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit);
                                        }
                                        fShiftSpecX = Math.Abs(pad.spec.shiftXHPer);
                                        fShiftSpecY = Math.Abs(pad.spec.shiftYHPer);
                                        //(pad.spec.volPerH * pad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL
                                        strBld.Append((pad.spec.volPerH * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol USL (%)

                                          (pad.res.measuredValue.vol * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM * PubStaticParam.RS_fUM2MM).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit + //vol                                                   
                                            //(pad.spec.volPerL * pad.res.measuredValue.vol).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL
                                          (pad.spec.volPerL * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//vol LSL (%)

                                          //pad.spec.shiftXH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL
                                          (fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset USL (%)

                                          (pad.res.measuredValue.offsetX).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset 
                                            //"0" + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL
                                            //modify by tony 20180412
                                           (-fShiftSpecX).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL (%)
                                            //(-1f * Math.Abs((pad.spec.shiftXH / pad.sizeXmmNew * 100))).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//xoffset LSL (%)
                                            //pad.spec.shiftYH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL
                                            //(pad.spec.shiftYH / pad.sizeYmmNew * 100).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          (fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)

                                          pad.res.measuredValue.offsetY.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset                                                   
                                            //"0" + pad.spec.shiftYH + PubStaticParam.RS_VerticalLineSplit +//yoffset LSL
                                            //modify by tony 20180412
                                            //(-1f * Math.Abs((pad.spec.shiftYH / pad.sizeYmmNew * 100))).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          (-fShiftSpecY).ToString(PubStaticParam.RS_ZERO) + PubStaticParam.RS_VerticalLineSplit +//yoffset USL (%)
                                          pad.sizeXmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padSizex
                                          pad.sizeYmmNew.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//padsizey
                                            //

                                   // modify by tony 180326 Component info spi is null
                                            //pad.spec.heightH.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                            //pad.res.measuredValue.height.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                            //pad.spec.heightL.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit) + PubStaticParam.RS_VerticalLineSplit +//Average :LSL
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average Height USL
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average Height
                                          "" + PubStaticParam.RS_VerticalLineSplit +//Average :LSL


                                          strArrayStatusCustom + PubStaticParam.RS_VerticalLineSplit +//Result(array result)
                                          errorPadcode + PubStaticParam.RS_VerticalLineSplit + //errcode
                                          pad.pinNumber + PubStaticParam.RS_VerticalLineSplit +//pin num
                                          strboardBarcode + PubStaticParam.RS_VerticalLineSplit +//barcode
                                          strDate + PubStaticParam.RS_VerticalLineSplit +//date
                                          strStartTime + PubStaticParam.RS_VerticalLineSplit +//start time
                                          strEndTime + PubStaticParam.RS_VerticalLineSplit +//end time

                                          strArrayId + PubStaticParam.RS_VerticalLineSplit +//array id
                                          strboardBarcode + PubStaticParam.RS_UnderLineSplit + strDate + strStartTime + PubStaticParam.RS_VerticalLineSplit +//key

                                          padGroup

                                   );
                                        strBld.Append(RS_LineEnd);
                                    }

                                }
                            }
                        }
                    }
                }
                strLine = strBld.ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strLine;
        }

        //臻鼎大数据-------------------end


        //郑州富士康Log输出---------------start

        public static void StartRunZZFoxconnEquipStatus(object AobjParameter)
        {
            object[] para = (object[])AobjParameter;
            string AstrDir = (string)para[0];
            byte AbyLaneNo = (byte)para[1];
            int iEquipStatusInter = (int)para[2];
            int iSleep = iEquipStatusInter == 0 ? ZzFoxconnBD.RI_EQUIP_STATUS_INTERVAL : iEquipStatusInter;
            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();
            //string bufferFile = AstrDir + "\\" + ZzFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".txt";
            //Q.F.2018.03.08
            //string bufferFile = Path.Combine(AstrDir, ZzFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".tmp");
            string bufferFile = Path.Combine(_strTmpFileDir, ZzFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".tmp");

            if (!File.Exists(bufferFile))
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            FileStream fs;
            string sLastUploadTime = "";
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(ZzFoxconnBD.RS_DATE_FORMAT + ZzFoxconnBD.RS_TIME_FORMAT);
                }

            }
            string sCustomer = "";
            string sFactory = "";
            string sFloor = "";
            string sEquipName = "";
            string sEquipId = "";
            string sLine = "";
            while (true)
            {
                try
                {
                    System.Data.DataTable dtFileName = mysqlBean.GetDataTableFrSQL("select t.Customer,t.Factory,t.Floor,t.EquipName,t.EquipID,t.Line from TBEquipStatus t order by t.UpdateTime desc LIMIT 1");
                    if (dtFileName != null && dtFileName.Rows != null && dtFileName.Rows.Count > 0 && dtFileName.Rows[0][0] != null)
                    {
                        sCustomer = dtFileName.Rows[0][0] == null ? "" : (string)dtFileName.Rows[0][0];
                        sFactory = dtFileName.Rows[0][1] == null ? "" : (string)dtFileName.Rows[0][1];
                        sFloor = dtFileName.Rows[0][2] == null ? "" : (string)dtFileName.Rows[0][2];
                        sEquipName = dtFileName.Rows[0][3] == null ? "" : (string)dtFileName.Rows[0][3];
                        sEquipId = dtFileName.Rows[0][4] == null ? "" : (string)dtFileName.Rows[0][4];
                        sLine = dtFileName.Rows[0][5] == null ? "" : (string)dtFileName.Rows[0][5];
                    }
                    if (!string.IsNullOrEmpty(sCustomer) && !string.IsNullOrEmpty(sFactory) && !string.IsNullOrEmpty(sFloor) && !string.IsNullOrEmpty(sEquipName) && !string.IsNullOrEmpty(sEquipId))
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Thread.Sleep(iSleep);
            }

            while (true)
            {
                FileStream fsLog = null;
                System.IO.StreamWriter streamWrtLog = null;
                try
                {
                    string sNowDate = DateTime.Now.ToString(ZzFoxconnBD.RS_DATE_FORMAT);
                    //string sNowTime = DateTime.Now.ToString(ZzFoxconnBD.RS_TIME_FORMAT);
                    //string sLogFilePathName = AstrDir + "\\" + sNowDateTime + "_"+AbyLaneNo+".log";
                    //Q.F.2018.03.08
                    //AAA_BBBBBBBB_CCC_YYYYMMDD(全部為英文或數字，不同內容間使用下劃綫進行分隔)
                    string sFileName = ZzFoxconnBD.RS_EQUIP_TYPE_SPI + "_" + sFactory + sFloor + sLine + "_" + sEquipName + "_" + sNowDate;
                    string sLogFilePathName = Path.Combine(AstrDir, sFileName + PubStaticParam.RS_CSV_EXT);
                    if (!File.Exists(sLogFilePathName))
                    {
                        using (FileStream fsNewLog = File.Create(sLogFilePathName))
                        {
                            System.IO.StreamWriter streamWrtNewLog = new StreamWriter(fsNewLog, Encoding.Default);
                            streamWrtNewLog.WriteLine(sFactory + sFloor);//A1為樓層(5位英文或數字，如K052F)；
                            streamWrtNewLog.WriteLine(sLine);//A2為纖體名(英文或數字，同一纖體的所有設備此欄位均需相同)；
                            streamWrtNewLog.WriteLine(ZzFoxconnBD.RS_EQUIP_TYPE_SPI);//A3為設備類型(3位英文或數字)，如 SMT、AOI等;
                            streamWrtNewLog.WriteLine(ZzFoxconnBD.RS_MANUFACTURE_NAME);//A4為廠商名稱(英文或數字，且同一廠商的所有設備在該欄位相同，即字母大小寫也需一致);
                            streamWrtNewLog.WriteLine(sEquipId);//A5為設備ID號(即廠商為設備設定的唯一可識別的編號，一般為英文或數字);
                            streamWrtNewLog.WriteLine(sEquipName);//A6為設備編號(與文件名中的CCC相同)
                            streamWrtNewLog.WriteLine(sNowDate);//A7為文件上傳時間(與文件名中的YYYYMMDD相同)
                            streamWrtNewLog.WriteLine("");
                            streamWrtNewLog.WriteLine(ZzFoxconnBD.RS_LOG_FILE_HEAD);
                            streamWrtNewLog.Close();
                            fsNewLog.Close();
                        }
                    }


                    fsLog = new FileStream(sLogFilePathName, FileMode.Append);
                    streamWrtLog = new StreamWriter(fsLog, Encoding.Default);
                    string sStatusSql = "select CAST(t.Start AS CHAR)," +
                        "CAST(t.Run AS CHAR)," +
                        "CAST(t.Stop AS CHAR)," +
                        "CAST(t.Idle AS CHAR)," +
                        "CAST(t.Init AS CHAR)," +
                        "CAST(t.ReqSig AS CHAR)," +
                        "CAST(t.InBoard AS CHAR)," +
                        "CAST(t.InspectBoard AS CHAR)," +
                        "CAST(t.InspectFinish AS CHAR)," +
                        "CAST(t.ReadyOut AS CHAR)," +
                        "CAST(t.BVSig AS CHAR)," +
                        "CAST(t.Error AS CHAR)," +
                        "ifnull(t.ErrContent,'')," +
                        "DATE_FORMAT(t.UpdateTime,'%Y%m%d')," +
                        "DATE_FORMAT(t.UpdateTime,'%H%i%S')," +
                        "DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S'), " +
                        "(CASE WHEN t.TowerG = '1' THEN	'G' WHEN t.TowerY = '1' THEN 'Y' WHEN t.TowerR = '1' THEN	'R' ELSE '' END ) towerType " +
                        " from TBEquipStatus t where t.UpdateTime is not null && t.UpdateTime> STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime";

                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sStatusSql);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;
                            string sUpdateTime;
                            string towerLight = "";
                            int towerLightCount = 0;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);
                            towerLight = (string)dt.Rows[i][16];
                            if (!string.Equals(towerLight, ""))
                            {
                                string sTowerSql = "SELECT CAST(count(*) AS CHAR) FROM TBEquipStatus  WHERE UpdateTime > STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S'	)" +
                                     " and  UpdateTime <= STR_TO_DATE('" + sUpdateTime + "','%Y%m%d%H%i%S'	) " + " and Tower" + towerLight + " = 1 ";
                                System.Data.DataTable dtTowerCount = mysqlBean.GetDataTableFrSQL(sTowerSql);
                                if (dtTowerCount != null && dtTowerCount.Rows.Count > 0)
                                {
                                    towerLightCount = int.Parse(dtTowerCount.Rows[0][0].ToString());
                                }
                            }

                            string sNewLine = dt.Rows[i][13] + PubStaticParam.RS_CommaSplit +
                                dt.Rows[i][14] + PubStaticParam.RS_CommaSplit +
                                sMainCode + sSubCode + PubStaticParam.RS_CommaSplit +
                                sMainMessage + " " + sSubMessage + PubStaticParam.RS_CommaSplit +
                                towerLight + PubStaticParam.RS_CommaSplit + towerLightCount;

                            streamWrtLog.WriteLine(sNewLine);

                            if (!string.IsNullOrEmpty(sUpdateTime) && !sUpdateTime.Trim().Equals(""))
                            {
                                sLastUploadTime = sUpdateTime;
                                fs = new FileStream(bufferFile, FileMode.Create);
                                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                                fs.Close();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    streamWrtLog.Close();
                    fsLog.Close();
                }
                Thread.Sleep(iSleep);
            }
        }


        //郑州富士康Log输出---------------end


        //武汉富士康Log输出---------------start
        //add by tony 18.08.01
        public static void StartRunWuhanFoxconnEquipStatus(object AobjParameter)
        {
            object[] para = (object[])AobjParameter;
            string AstrDir = (string)para[0];
            byte AbyLaneNo = (byte)para[1];
            int iEquipStatusInter = (int)para[2];
            int iSleep = iEquipStatusInter == 0 ? WuhanFoxconnBD.RI_EQUIP_STATUS_INTERVAL : iEquipStatusInter;
            DataBeanEx.MySQLBean mysqlBean = new DataBeanEx.MySQLBean();
            //string bufferFile = AstrDir + "\\" + ZzFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".txt";
            //Q.F.2018.03.08
            //string bufferFile = Path.Combine(AstrDir, ZzFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".tmp");
            string bufferFile = Path.Combine(_strTmpFileDir, WuhanFoxconnBD.RS_EQUIPSTATUS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".tmp");

            if (!File.Exists(bufferFile))
            {
                using (FileStream sfTemp = File.Create(bufferFile)) { }
            }
            FileStream fs;

            string sLastUploadTime = "";
            using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
            {
                sLastUploadTime = sr.ReadLine();
                if (string.IsNullOrEmpty(sLastUploadTime) || sLastUploadTime.Trim().Equals("") || sLastUploadTime.IndexOfAny("\0".ToArray()) >= 0)
                {
                    sLastUploadTime = DateTime.Now.AddDays(-1).ToString(WuhanFoxconnBD.RS_DATE_FORMAT + WuhanFoxconnBD.RS_TIME_FORMAT);
                }

            }
            string sCustomer = "";
            string sFactory = "";
            string sFloor = "";
            string sEquipName = "";
            string sEquipId = "";
            string sLine = "";
            int whileInt = 10;
            while (whileInt-- > 0)
            {
                try
                {
                    System.Data.DataTable dtFileName = mysqlBean.GetDataTableFrSQL("select t.Customer,t.Factory,t.Floor,t.EquipName,t.EquipID,t.Line from TBEquipStatus t order by t.UpdateTime desc LIMIT 1");
                    if (dtFileName != null && dtFileName.Rows != null && dtFileName.Rows.Count > 0 && dtFileName.Rows[0][0] != null)
                    {
                        sCustomer = dtFileName.Rows[0][0] == null ? "" : (string)dtFileName.Rows[0][0];
                        sFactory = dtFileName.Rows[0][1] == null ? "" : (string)dtFileName.Rows[0][1];
                        sFloor = dtFileName.Rows[0][2] == null ? "" : (string)dtFileName.Rows[0][2];
                        sEquipName = dtFileName.Rows[0][3] == null ? "" : (string)dtFileName.Rows[0][3];
                        sEquipId = dtFileName.Rows[0][4] == null ? "" : (string)dtFileName.Rows[0][4];
                        sLine = dtFileName.Rows[0][5] == null ? "" : (string)dtFileName.Rows[0][5];
                    }
                    if (!string.IsNullOrEmpty(sCustomer) && !string.IsNullOrEmpty(sFactory) && !string.IsNullOrEmpty(sFloor) && !string.IsNullOrEmpty(sEquipName) && !string.IsNullOrEmpty(sEquipId))
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Thread.Sleep(iSleep);
            }

            FileStream fsLogFile = null;
            if (!Directory.Exists(Path.Combine(WuhanFoxconnBD.RS_LOGFILE_BASE_PATH, "Tony", "MES")))
            {
                Directory.CreateDirectory(Path.Combine(WuhanFoxconnBD.RS_LOGFILE_BASE_PATH, "Tony", "MES"));
            }

            string logFilePath = "";
            string logFileName = "";
            while (true)
            {
                FileStream fsLog = null;
                System.IO.StreamWriter streamWrtLog = null;

                //add by tony 20180911
                logFileName = "WuhanFoxconnEquipStatus_" + DateTime.Now.ToString(WuhanFoxconnBD.RS_DATE_FORMAT) + ".log";
                logFilePath = Path.Combine(WuhanFoxconnBD.RS_LOGFILE_BASE_PATH, "Tony", "MES", logFileName);
                if (!File.Exists(logFilePath))
                {
                    fsLogFile = File.Create(logFilePath);
                    fsLogFile.Flush();
                    fsLogFile.Close();
                    fsLogFile.Dispose();
                }

                try
                {
                    string sNowDate = DateTime.Now.ToString(WuhanFoxconnBD.RS_DATE_FORMAT);
                    string sNowTime = DateTime.Now.ToString(WuhanFoxconnBD.RS_TIME_FORMAT);
                    //string sLogFilePathName = AstrDir + "\\" + sNowDateTime + "_"+AbyLaneNo+".log";
                    //Q.F.2018.03.08
                    //AAA_BBBBBBBB_CCC_YYYYMMDD(全部為英文或數字，不同內容間使用下劃綫進行分隔)
                    string sFileName = WuhanFoxconnBD.RS_EQUIP_TYPE_SPI + "_" + sFactory + sFloor + sLine + "_" + sEquipName + "_" + sNowDate + sNowTime;
                    string sLogFilePathName = Path.Combine(AstrDir, sFileName + PubStaticParam.RS_CSV_EXT);
                    if (!File.Exists(sLogFilePathName))
                    {
                        using (FileStream fsNewLog = File.Create(sLogFilePathName))
                        {
                            System.IO.StreamWriter streamWrtNewLog = new StreamWriter(fsNewLog, Encoding.Default);
                            streamWrtNewLog.WriteLine(sFactory + sFloor);//A1為樓層(5位英文或數字，如K052F)；
                            streamWrtNewLog.WriteLine(sLine);//A2為纖體名(英文或數字，同一纖體的所有設備此欄位均需相同)；
                            streamWrtNewLog.WriteLine(WuhanFoxconnBD.RS_EQUIP_TYPE_SPI);//A3為設備類型(3位英文或數字)，如 SMT、AOI等;
                            streamWrtNewLog.WriteLine(WuhanFoxconnBD.RS_MANUFACTURE_NAME);//A4為廠商名稱(英文或數字，且同一廠商的所有設備在該欄位相同，即字母大小寫也需一致);
                            streamWrtNewLog.WriteLine(sEquipId);//A5為設備ID號(即廠商為設備設定的唯一可識別的編號，一般為英文或數字);
                            streamWrtNewLog.WriteLine(sEquipName);//A6為設備編號(與文件名中的CCC相同)
                            streamWrtNewLog.WriteLine(sNowDate);//A7為文件上傳時間(與文件名中的YYYYMMDD相同)
                            streamWrtNewLog.WriteLine("");
                            streamWrtNewLog.WriteLine(WuhanFoxconnBD.RS_LOG_FILE_HEAD);
                            streamWrtNewLog.Close();
                            fsNewLog.Close();
                        }
                    }


                    fsLog = new FileStream(sLogFilePathName, FileMode.Append);
                    streamWrtLog = new StreamWriter(fsLog, Encoding.Default);
                    string sStatusSql = "select CAST(t.Start AS CHAR)," +
                        "CAST(t.Run AS CHAR)," +
                        "CAST(t.Stop AS CHAR)," +
                        "CAST(t.Idle AS CHAR)," +
                        "CAST(t.Init AS CHAR)," +
                        "CAST(t.ReqSig AS CHAR)," +
                        "CAST(t.InBoard AS CHAR)," +
                        "CAST(t.InspectBoard AS CHAR)," +
                        "CAST(t.InspectFinish AS CHAR)," +
                        "CAST(t.ReadyOut AS CHAR)," +
                        "CAST(t.BVSig AS CHAR)," +
                        "CAST(t.Error AS CHAR)," +
                        "ifnull(t.ErrContent,'')," +
                        "DATE_FORMAT(t.UpdateTime,'%Y%m%d')," +
                        "DATE_FORMAT(t.UpdateTime,'%H%i%S')," +
                        "DATE_FORMAT(t.UpdateTime,'%Y%m%d%H%i%S'), " +
                        "(CASE WHEN t.TowerG = '1' THEN	'G' WHEN t.TowerY = '1' THEN 'Y' WHEN t.TowerR = '1' THEN	'R' ELSE '' END ) towerType " +
                        " from TBEquipStatus t where t.UpdateTime is not null && t.UpdateTime> STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S') order by t.UpdateTime";

                    System.Data.DataTable dt = mysqlBean.GetDataTableFrSQL(sStatusSql);

                    string sUpdateTime = "";
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLogFile = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLogFile.WriteLine(DateTime.Now.ToString() + " 武汉富士康设备状态：TBEquipStatus return data count：" + dt.Rows.Count);
                            streamWrtLogFile.Flush();
                            streamWrtLogFile.Close();
                        }

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string sMainCode;
                            string sSubCode;
                            string sMainMessage;
                            string sSubMessage;

                            string towerLight = "";
                            int towerLightCount = 0;
                            GetEquipStatusFromDB(dt.Rows[i], out sMainCode, out sSubCode, out sMainMessage, out sSubMessage, out sUpdateTime);
                            towerLight = (string)dt.Rows[i][16];



                            if (!string.Equals(towerLight, ""))
                            {
                                string sTowerSql = "SELECT CAST(count(*) AS CHAR) FROM TBEquipStatus  WHERE UpdateTime >= STR_TO_DATE('" + sLastUploadTime + "','%Y%m%d%H%i%S'	)" +
                                     " and  UpdateTime <= STR_TO_DATE('" + sUpdateTime + "','%Y%m%d%H%i%S'	) " + " and Tower" + towerLight + " = 1 ";
                                System.Data.DataTable dtTowerCount = mysqlBean.GetDataTableFrSQL(sTowerSql);
                                if (dtTowerCount != null && dtTowerCount.Rows.Count > 0)
                                {
                                    towerLightCount = int.Parse(dtTowerCount.Rows[0][0].ToString());
                                }
                            }

                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLogFile = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLogFile.WriteLine(DateTime.Now.ToString() + " 武汉富士康设备状态：write log file before");
                                streamWrtLogFile.Flush();
                                streamWrtLogFile.Close();
                            }

                            string sNewLine = dt.Rows[i][13] + PubStaticParam.RS_CommaSplit +
                                dt.Rows[i][14] + PubStaticParam.RS_CommaSplit +
                                sMainCode + sSubCode + PubStaticParam.RS_CommaSplit +
                                sMainMessage + " " + sSubMessage + PubStaticParam.RS_CommaSplit +
                                towerLight + PubStaticParam.RS_CommaSplit + towerLightCount;

                            streamWrtLog.WriteLine(sNewLine);

                            fsLogFile = new FileStream(logFilePath, FileMode.Append);
                            using (StreamWriter streamWrtLogFile = new StreamWriter(fsLogFile, Encoding.Default))
                            {
                                streamWrtLogFile.WriteLine(DateTime.Now.ToString() + " 武汉富士康设备状态：write log file end Line data:" + sNewLine);
                                streamWrtLogFile.Flush();
                                streamWrtLogFile.Close();
                            }

                        }
                        if (!string.IsNullOrEmpty(sUpdateTime) && !sUpdateTime.Trim().Equals("") && sUpdateTime.IndexOfAny("\0".ToArray()) < 0)
                        {
                            sLastUploadTime = sUpdateTime;
                            using (fs = new FileStream(bufferFile, FileMode.Create))
                            {
                                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                                streamWrt.Write(sLastUploadTime);
                                streamWrt.Flush();
                                streamWrt.Close();
                            }
                        }
                    }
                    else
                    {
                        fsLogFile = new FileStream(logFilePath, FileMode.Append);
                        using (StreamWriter streamWrtLogFile = new StreamWriter(fsLogFile, Encoding.Default))
                        {
                            streamWrtLogFile.WriteLine(DateTime.Now.ToString() + " 武汉富士康设备状态：TBEquipStatus return data count：0 (" + sLastUploadTime + ")");
                            streamWrtLogFile.Flush();
                            streamWrtLogFile.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    fsLogFile = new FileStream(logFilePath, FileMode.Append);
                    using (StreamWriter streamWrtLogFile = new StreamWriter(fsLogFile, Encoding.Default))
                    {
                        streamWrtLogFile.WriteLine(DateTime.Now.ToString() + " 武汉富士康设备状态：Exception:" + ex.Message);
                        streamWrtLogFile.Flush();
                        streamWrtLogFile.Close();
                    }
                }
                finally
                {
                    if (streamWrtLog != null)
                        streamWrtLog.Close();
                    if (fsLog != null)
                        fsLog.Close();
                    if (fsLogFile != null)
                    {
                        fsLogFile.Close();
                    }
                }
                Thread.Sleep(iSleep);
            }
        }


        //武汉富士康Log输出---------------end

        //信利半导体---------------------start

        private void generateFileSWTrulysEmi(string AsProgramName, string AsBarcode, string AsGroupName, string AsLineName,
                                    string AsShip, string AsEquipModel, string AsProductOrder, string AsInspectDate,
                                    string AsInspectTime, string AsArrayId, InspectMainLib.Pad[] APads, bool AbIsSkip, ref StringBuilder AstrBuder)
        {
            AstrBuder.Append(AsProgramName + RS_LineEnd);
            //modify by tony 17.8.29
            //if (!AbIsSkip)
            //{
            //    AstrBuder.Append(AsBarcode + RS_LineEnd);
            //}
            //else 
            //{
            //    //modify by tony 07.24
            //    AstrBuder.Append(AsInspectDate + AsInspectTime + RS_LineEnd);
            //   // AstrBuder.Append(SWTrulysEmi.RS_SKIP + RS_LineEnd);
            //}
            if (string.Equals(AsBarcode, RS_NOREAD) || (AbIsSkip && string.Equals(AsBarcode, RS_NOREAD)))
            {
                AstrBuder.Append(AsInspectDate + AsInspectTime + RS_LineEnd);
            }
            else
            {
                AstrBuder.Append(AsBarcode + RS_LineEnd);
            }

            AstrBuder.Append("SMT_" + AsGroupName + "_" + AsLineName + RS_LineEnd);
            AstrBuder.Append(AsShip + RS_LineEnd);
            AstrBuder.Append(AsEquipModel + RS_LineEnd);
            AstrBuder.Append(AsProductOrder + RS_LineEnd);
            AstrBuder.Append(AsInspectDate + RS_LineEnd);
            AstrBuder.Append(AsInspectTime + RS_LineEnd);
            int totalPadCount = 0;
            int NGPadCount = 0;
            StringBuilder padContent = new StringBuilder();
            if (AbIsSkip)
            {
                AstrBuder.Append(SWTrulysEmi.RS_INSPECT_RESULT_TEMPLATE[2] + RS_LineEnd);
            }
            else
            {
                for (int i = 0; i < APads.Length; i++)
                {
                    if (_baseFun.bPadIsSkip(APads[i]))
                        continue;
                    totalPadCount++;
                    if (APads[i].res.jugRes == JudgeRes.NG)
                    {
                        NGPadCount++;
                        padContent.Append(SWTrulysEmi.RS_NG_PAD_DETAIL_TEMPLATE.
                            Replace(SWTrulysEmi.RS_COMPONENTID_TEMPLATE, APads[i].componentID).
                            Replace(SWTrulysEmi.RS_ARRAYID_TEMPLATE, AsArrayId).
                            Replace(SWTrulysEmi.RS_PINNUMBER_TEMPLATE, APads[i].pinNumber).
                            Replace(SWTrulysEmi.RS_PACKAGETYPE_TEMPLATE, APads[i].packageType).
                            Replace(SWTrulysEmi.RS_DEFECTION_TEMPLATE, APads[i].res.jugDefectType.ToString()));
                        padContent.Append(RS_LineEnd);
                    }
                }
                if (NGPadCount == 0)
                {
                    AstrBuder.Append(SWTrulysEmi.RS_INSPECT_RESULT_TEMPLATE[0] + RS_LineEnd);
                }
                else
                {
                    AstrBuder.Append(SWTrulysEmi.RS_INSPECT_RESULT_TEMPLATE[1] + RS_LineEnd);
                }
            }
            string sPanel = "T";
            if (AsProgramName.ToLower().IndexOf(SWTrulysEmi.RS_BOTTOM_PANEL) > 0)
            {
                sPanel = "B";
            }
            AstrBuder.Append(sPanel + RS_LineEnd);

            //modify by tony 07.24
            if (!AbIsSkip)
            {
                AstrBuder.Append(totalPadCount.ToString() + RS_LineEnd);
                AstrBuder.Append(NGPadCount.ToString() + RS_LineEnd);
                if (padContent.Length > 0)
                {
                    AstrBuder.Append(padContent);
                }
            }
            else
            {
                AstrBuder.Append("0" + RS_LineEnd);
                AstrBuder.Append("0" + RS_LineEnd);
            }
        }


        public string SaveDataExpFileSWTrulysEmi(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                string programName = "";
                string strBoardBarcode = "";
                string strGroupName = "";
                string lineName = "";
                string ship = SWTrulysEmi.RS_SHIP;
                string equipModel = SWTrulysEmi.RS_MODEL_SPI;
                string strLotNumber = "";
                string inspectDate = "";
                string inspectTime = "";


                programName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);

                strGroupName = string.IsNullOrEmpty(AappSettingData.stDataExpVT.strGroupName) ? SWTrulysEmi.RS_NONE : AappSettingData.stDataExpVT.strGroupName;

                lineName = AappSettingData.LineName;
                strLotNumber = AappSettingData.strLotNumber;
                if (string.IsNullOrEmpty(strLotNumber)) strLotNumber = SWTrulysEmi.RS_NONE;
                inspectDate = ABrdRes.startTime.ToString(SWTrulysEmi.RS_DATE_FORMAT);
                inspectTime = ABrdRes.startTime.ToString(SWTrulysEmi.RS_TIME_FORMAT);
                StringBuilder SbFileContent = new StringBuilder();
                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array
                        if (APads != null && APads.Length > 0)
                        {
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;
                            generateFileSWTrulysEmi(programName, strBoardBarcode, strGroupName, lineName,
                                ship, equipModel, strLotNumber, inspectDate, inspectTime, strArrayID, APads, false, ref SbFileContent);
                        }
                    }
                    else
                    {
                        int iBarcodeCount = _baseFun.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                        string strArrayBarcode = "";
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false)
                            //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)//Q.F.2017.07.04
                            {
                                continue;
                            }
                            //Q.F.2017.05.18
                            if (iBarcodeCount > 1)
                            {
                                //Q.F.2017.07.04
                                //strArrayBarcode = _baseFun.BarcodeDicision(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode.Trim(),
                                //                                 AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                                //modify by tony 07.24
                                strArrayBarcode = _baseFun.BarcodeDicision((string.IsNullOrEmpty(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode) ? "" : APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode.Trim()),
                                                                 AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                            }
                            else
                            {
                                strArrayBarcode = strBoardBarcode;
                            }
                            //copy PadsRes to tempPads 
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (iPartPadsLength >= 0)//Q.F.2017.07.04 because skip array iPartPadsLength is zero 
                            {
                                //Q.F.2017.07.04
                                //modify by tony 07.24
                                //modify Q.F.2017.07.24
                                bool bSkip = (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                   || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0);
                                generateFileSWTrulysEmi(programName, strArrayBarcode, AappSettingData.stDataExpVT.strGroupName, lineName,
                                ship, equipModel, strLotNumber, inspectDate, inspectTime, strArrayID, arrPartPads, bSkip, ref SbFileContent);
                            }
                            SbFileContent.Append(RS_LineEnd);
                        }
                    }

                    //modify by tony 07.24                   
                    string sFileNameTemplate = "";
                    //modify by tony 17.8.29           
                    //if (string.IsNullOrEmpty(strBoardBarcode) || strBoardBarcode.Equals("NOREAD")) 
                    //{
                    //    sFileNameTemplate = SWTrulysEmi.RS_EXPORT_FILE_NAME_NOBARCODE_TEMPLATE;
                    //}
                    //else
                    //{
                    //    sFileNameTemplate = SWTrulysEmi.RS_EXPORT_FILE_NAME_TEMPLATE;
                    //}
                    sFileNameTemplate = SWTrulysEmi.RS_EXPORT_FILE_NAME_TEMPLATE;

                    string strExportFileName = AstrDir + "\\" + sFileNameTemplate.
                         Replace(SWTrulysEmi.RS_GROUPNAME_TEMPLATE, strGroupName).
                         Replace(SWTrulysEmi.RS_LINENAME_TEMPLATE, lineName).
                         Replace(SWTrulysEmi.RS_INSPECTDATE_TEMPLATE, inspectDate).
                         Replace(SWTrulysEmi.RS_INSPECTTIME_TEMPLATE, inspectTime);

                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(SbFileContent);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strExportFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        //信利半导体---------------------end


        //KCHoliTeck---------------start

        private void generateFileContentKCHoliTech(ref StringBuilder AfileContent, string AsArrayID, InspectMainLib.Pad[] APads, ref AppSettingData AappSettingData)
        {
            for (int i = 0; i < APads.Length; i++)
            {
                if (_baseFun.bPadIsSkip(APads[i]) || APads[i].res.jugRes == JudgeRes.Good)
                    continue;
                string padLine = KCHoliTech.RS_LOCAT_DEFECT_TEMPLATE.
                    Replace(KCHoliTech.RS_COMPONENT_TEMPLATE, APads[i].componentID).
                    Replace(KCHoliTech.RS_ARRAY_ID_TEMPLATE, AsArrayID).
                    Replace(KCHoliTech.RS_PIN_NUMBER_TEMPLATE, APads[i].pinNumber).
                    Replace(KCHoliTech.RS_USER_DEFECT_CODE_TEMPLATE, _baseFun.GetPadErrorCodeStr(APads[i], AappSettingData));
                AfileContent.Append(padLine + RS_LineEnd);

            }
        }


        public string SaveDataExpFileKCHoliTech(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                StringBuilder fileContent = new StringBuilder();

                string strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                string lineName = AappSettingData.LineName;
                string inspectDate = ABrdRes.startTime.ToString(KCHoliTech.RS_DATE_FORMAT);
                string inspectStartTime = ABrdRes.startTime.ToString(KCHoliTech.RS_TIME_FORMAT);
                string boardResult = KCHoliTech.RS_BOARD_RESULT[(int)ABrdRes.jugResult];
                //modify Tony 17.6.12
                int iLaneNo = (byte)ABrdRes.LaneNo;
                string sLaneNo = iLaneNo == 0 ? "L1" : "L2";

                string strFileName = AstrDir + KCHoliTech.RS_EXPORT_FILE_NAME_TEMPLATE;
                //modify Tony 17.6.12
                strFileName = strFileName.Replace(KCHoliTech.RS_BOARD_BARCODE_TEMPLATE, strBoardBarcode).
                    Replace(KCHoliTech.RS_BOARD_RESULT_TEMPLATE, boardResult).
                    Replace(KCHoliTech.RS_INSPECT_DATETIME_TEMPLATE, inspectDate + inspectStartTime).
                    Replace(KCHoliTech.RS_LINE_NAME_TEMPLATE, sLaneNo);

                //modify Tony 17.6.12
                if (ABrdRes.jugResult != JudgeRes.Skipped && ABrdRes.jugResult != JudgeRes.Good && ABrdRes.jugResult != JudgeRes.Pass)
                {

                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array
                        if (APads != null && APads.Length > 0)
                        {
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;
                            generateFileContentKCHoliTech(ref fileContent, strArrayID, APads, ref AappSettingData);
                        }
                    }
                    else
                    {
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (iPartPadsLength > 0)
                            {
                                generateFileContentKCHoliTech(ref fileContent, strArrayID, arrPartPads, ref AappSettingData);
                            }

                        }
                    }




                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(fileContent);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                }
                else
                {
                    //Q.F.2017.06.12
                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(fileContent);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                }

            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }


        //KCHoliTeck---------------end


        //EKRA XML-----------------start
        public string SaveFileToPrinterEkra(
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.AppendChild(XmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null));
                //create doc root
                XmlElement RootEle = XmlDoc.CreateElement(EkraXml.Node_FeedbackInspResult);
                XmlDoc.AppendChild(RootEle);
                XmlElement MessageEle = XmlDoc.CreateElement(EkraXml.Node_Message);
                XmlElement DateAndTimeEle = XmlDoc.CreateElement(EkraXml.Node_DateAndTime);
                DateAndTimeEle.InnerText = ABrdRes.startTime.ToString(EkraXml.RS_DATE_AND_TIME);
                MessageEle.AppendChild(DateAndTimeEle);
                RootEle.AppendChild(MessageEle);
                XmlElement MachineEle = XmlDoc.CreateElement(EkraXml.Node_Machine);
                XmlElement NameEle = XmlDoc.CreateElement(EkraXml.Node_Name);
                XmlElement ReferenceEle = XmlDoc.CreateElement(EkraXml.Node_Reference);
                NameEle.InnerText = EkraXml.RS_NAME_SPI;
                ReferenceEle.InnerText = ABrdRes.stPrinterSystemRes.strReference;//EkraXml.RS_NULL;//Q.F.2017.06.02
                MachineEle.AppendChild(NameEle);
                MachineEle.AppendChild(ReferenceEle);
                RootEle.AppendChild(MachineEle);
                XmlElement ProcessEle = XmlDoc.CreateElement(EkraXml.Node_Process);
                XmlElement ProductIdEle = XmlDoc.CreateElement(EkraXml.Node_ProductId);
                ProductIdEle.InnerText = AappSettingData.stPrintSystemGKG.strProductID;
                ProcessEle.AppendChild(ProductIdEle);
                XmlElement PanelIdEle = XmlDoc.CreateElement(EkraXml.Node_PanelId);
                PanelIdEle.InnerText = EkraXml.RS_ZERO;//Q.F.2017.06.01
                ProcessEle.AppendChild(PanelIdEle);
                XmlElement PanelStatusEle = XmlDoc.CreateElement(EkraXml.Node_PanelStatus);
                PanelStatusEle.InnerText = EkraXml.RS_Inspected;
                ProcessEle.AppendChild(PanelStatusEle);
                XmlElement UnitsEle = XmlDoc.CreateElement(EkraXml.Node_Units);
                XmlElement DistanceEle = XmlDoc.CreateElement(EkraXml.Node_Distance);
                DistanceEle.InnerText = EkraXml.RS_MM;
                UnitsEle.AppendChild(DistanceEle);

                XmlElement AngleEle = XmlDoc.CreateElement(EkraXml.Node_Angle);
                AngleEle.InnerText = EkraXml.RS_DEG;
                UnitsEle.AppendChild(AngleEle);

                XmlElement TimeEle = XmlDoc.CreateElement(EkraXml.Node_Time);
                TimeEle.InnerText = EkraXml.RS_SECONDS;
                UnitsEle.AppendChild(TimeEle);
                //Q.F.2017.06.01
                XmlElement PercEle = XmlDoc.CreateElement(EkraXml.Node_Stretch);
                PercEle.InnerText = EkraXml.RS_PERC;
                UnitsEle.AppendChild(PercEle);
                ProcessEle.AppendChild(UnitsEle);

                XmlElement CorrectionFeedbackEle = XmlDoc.CreateElement(EkraXml.Node_CorrectionFeedback);
                XmlElement FiducialsEle = XmlDoc.CreateElement(EkraXml.Node_Fiducials);
                int iFidCount = ABrdRes.stPrinterSystemRes.aFLstMarkXOrg.Count;
                FiducialsEle.SetAttribute(EkraXml.Prop_Count, iFidCount.ToString());
                iFidCount++;
                float fValue = 0f;
                float fOffSetX = 0f;
                float fOffSetY = 0f;
                for (int i = 1; i != iFidCount; ++i)
                {
                    if (i == 3) break;
                    fOffSetX = 0f;
                    fOffSetY = 0f;

                    XmlElement FiducialEle = XmlDoc.CreateElement(EkraXml.Node_Fiducial);
                    FiducialEle.SetAttribute(EkraXml.Prop_Name, EkraXml.RS_FID_NAME_PERFIX + i.ToString());
                    XmlElement XEle = XmlDoc.CreateElement(EkraXml.Node_X);
                    //XEle.SetAttribute(EkraXml.Prop_Origin, ABrdRes.stPrinterSystemRes.aFLstMarkXOrg[i - 1].ToString(EkraXml.RS_FLOAT_PRECISION));
                    //Q.F.2017.06.02
                    _baseFun.CalPrinterOffsetEkra(ABrdRes.stPrinterSystemRes, AappSettingData, i - 1, ref fOffSetX, ref fOffSetY, (byte)ABrdRes.LaneNo);//Q.F.2017.11.16
                    //Q.F.2017.06.01
                    XEle.SetAttribute(EkraXml.Prop_Origin, ABrdRes.stPrinterSystemRes.aFPrinterMarkOrgX[i - 1].ToString(EkraXml.RS_FLOAT_PRECISION));
                    fValue = fOffSetX;
                    // fValue = ABrdRes.stPrinterSystemRes.aFLstMarkXReal[i - 1] - ABrdRes.stPrinterSystemRes.aFLstMarkXOrg[i - 1];
                    XEle.SetAttribute(EkraXml.Prop_Offset, fValue.ToString(EkraXml.RS_FLOAT_PRECISION));
                    XmlElement YEle = XmlDoc.CreateElement(EkraXml.Node_Y);
                    // YEle.SetAttribute(EkraXml.Prop_Origin, ABrdRes.stPrinterSystemRes.aFLstMarkYOrg[i - 1].ToString(EkraXml.RS_FLOAT_PRECISION));
                    //Q.F.2017.06.02
                    YEle.SetAttribute(EkraXml.Prop_Origin, ABrdRes.stPrinterSystemRes.aFPrinterMarkOrgY[i - 1].ToString(EkraXml.RS_FLOAT_PRECISION));
                    //Q.F.2017.07.01
                    fValue = fOffSetY;
                    // fValue = ABrdRes.stPrinterSystemRes.aFLstMarkYReal[i - 1] - ABrdRes.stPrinterSystemRes.aFLstMarkYOrg[i - 1];
                    YEle.SetAttribute(EkraXml.Prop_Offset, fValue.ToString(EkraXml.RS_FLOAT_PRECISION));
                    FiducialEle.AppendChild(XEle);
                    FiducialEle.AppendChild(YEle);
                    FiducialsEle.AppendChild(FiducialEle);
                }
                CorrectionFeedbackEle.AppendChild(FiducialsEle);

                float fRealDial = 0.0f;
                float fOrgDial = 0.0f;
                float fValueX = 0.0f;
                float fValueY = 0.0f;
                fValueX = (ABrdRes.stPrinterSystemRes.aFLstMarkXReal[1] - ABrdRes.stPrinterSystemRes.aFLstMarkXReal[0]);
                fValueY = (ABrdRes.stPrinterSystemRes.aFLstMarkYReal[1] - ABrdRes.stPrinterSystemRes.aFLstMarkYReal[0]);
                fRealDial = (float)Math.Sqrt(fValueX * fValueX + fValueY * fValueY);
                fValueX = (ABrdRes.stPrinterSystemRes.aFLstMarkXOrg[1] - ABrdRes.stPrinterSystemRes.aFLstMarkXOrg[0]);
                fValueY = (ABrdRes.stPrinterSystemRes.aFLstMarkYOrg[1] - ABrdRes.stPrinterSystemRes.aFLstMarkYOrg[0]);
                fOrgDial = (float)Math.Sqrt(fValueX * fValueX + fValueY * fValueY);
                float fStrech = (fRealDial - fOrgDial) / fOrgDial;
                XmlElement StretchEle = XmlDoc.CreateElement(EkraXml.Node_Stretch);
                StretchEle.InnerText = fStrech.ToString(EkraXml.RS_FLOAT_PRECISION);
                CorrectionFeedbackEle.AppendChild(StretchEle);

                XmlElement PrinterSqueegeeDirEle = XmlDoc.CreateElement(EkraXml.Node_PrinterSqueegeeDir);
                PrinterSqueegeeDirEle.InnerText = ABrdRes.stPrinterSystemRes.strSqueege;
                CorrectionFeedbackEle.AppendChild(PrinterSqueegeeDirEle);

                XmlElement SpiSqueegeeDirEle = XmlDoc.CreateElement(EkraXml.Node_SpiSqueegeeDir);
                SpiSqueegeeDirEle.InnerText = ABrdRes.stPrinterSystemRes.strSqueege;
                CorrectionFeedbackEle.AppendChild(SpiSqueegeeDirEle);
                ProcessEle.AppendChild(CorrectionFeedbackEle);

                XmlElement DefectEle = XmlDoc.CreateElement(EkraXml.Node_Defect);
                DefectEle.SetAttribute(EkraXml.Prop_TotalNum, EkraXml.RS_ZERO);
                DefectEle.SetAttribute(EkraXml.Prop_DefectNum, EkraXml.RS_ZERO);

                XmlElement HighEle = XmlDoc.CreateElement(EkraXml.Node_High);
                HighEle.InnerText = EkraXml.RS_ZERO;
                XmlElement LowEle = XmlDoc.CreateElement(EkraXml.Node_Low);
                LowEle.InnerText = EkraXml.RS_ZERO;

                XmlElement VolumeEle = XmlDoc.CreateElement(EkraXml.Node_Volume);
                VolumeEle.SetAttribute(EkraXml.Prop_Num, EkraXml.RS_ZERO);
                VolumeEle.AppendChild(HighEle.Clone());
                VolumeEle.AppendChild(LowEle.Clone());
                DefectEle.AppendChild(VolumeEle);

                XmlElement HeightEle = XmlDoc.CreateElement(EkraXml.Node_Height);
                HeightEle.SetAttribute(EkraXml.Prop_Num, EkraXml.RS_ZERO);
                HeightEle.AppendChild(HighEle.Clone());
                HeightEle.AppendChild(LowEle.Clone());
                DefectEle.AppendChild(HeightEle);

                XmlElement AreaEle = XmlDoc.CreateElement(EkraXml.Node_Area);
                AreaEle.SetAttribute(EkraXml.Prop_Num, EkraXml.RS_ZERO);
                AreaEle.AppendChild(HighEle.Clone());
                AreaEle.AppendChild(LowEle.Clone());
                DefectEle.AppendChild(AreaEle);

                XmlElement BridgeEle = XmlDoc.CreateElement(EkraXml.Node_Bridge);
                BridgeEle.InnerText = EkraXml.RS_ZERO;
                DefectEle.AppendChild(BridgeEle);

                ProcessEle.AppendChild(DefectEle);

                String strCommand = EkraXml.RS_NULL;
                if (ABrdRes.stPrinterSystemRes.bClean == true)
                    strCommand = EkraXml.RS_CLEAN;
                else
                {
                    strCommand = EkraXml.RS_NOCLEAN;//Q.F.2017.06.01
                }
                XmlElement CommandEle = XmlDoc.CreateElement(EkraXml.Node_Command);
                CommandEle.InnerText = strCommand;//"NoUse";
                ProcessEle.AppendChild(CommandEle);

                XmlElement PcbResultEle = XmlDoc.CreateElement(EkraXml.Node_PcbResult);
                PcbResultEle.InnerText = ABrdRes.jugResult.ToString().ToUpper();
                ProcessEle.AppendChild(PcbResultEle);

                RootEle.AppendChild(ProcessEle);

                XmlDoc.Save(tmpFile);
                //Q.F.2017.06.02
                //string strFileName = AstrDir + "\\" +ABrdRes.startTime.ToString(EkraXml.RS_DATE_AND_TIME_FILE_NAME) + EkraXml.RS_XML_EXT;
                string strFileName = AstrDir + "\\" + ABrdRes.stPrinterSystemRes.strPrinterToSpiFileName + EkraXml.RS_XML_EXT;
                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }
            }
            catch (Exception ex)
            {
                strMsg += RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();

            }
            return strMsg;
        }



        //EKRA XML-----------------end

        //飞歌----------------------start 

        public string SaveDataExpFileFeiGe(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, byte AbyLaneNo, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                StringBuilder fileContent = new StringBuilder();
                string ABarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
                string AResult = FEIGE.RS_RESULT[(int)ABrdRes.jugResult];
                string ADate = ABrdRes.startTime.ToString(FEIGE.RS_DATE_FORMAT);
                string ATime = ABrdRes.startTime.ToString(FEIGE.RS_TIME_FORMAT);
                fileContent.Append(FEIGE.RS_COLUMN_TITLE + RS_LineEnd);
                fileContent.Append(ABarcode + RS_SPLIT + ADate + RS_SPLIT + ATime + RS_SPLIT + AResult + RS_LineEnd);

                string strFileName = AstrDir + "\\" + ADate + ATime + "_" + ABarcode + ".csv";

                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(fileContent);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }

            }
            catch (Exception ex)
            {
                strMsg += RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            return strMsg;
        }

        public string SaveDataFeiGe(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, byte AbyLaneNo, string AstrClntName)
        {
            string strMsg = RS_EMPTY;


            if (ABrdRes.jugResult != JudgeRes.Skipped)
            {
                try
                {
                    string ABarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
                    string AResult = FEIGE.RS_RESULT[(int)ABrdRes.jugResult];
                    string ALine = AappSettingData.LineName;
                    string ADate = ABrdRes.startTime.ToString(FEIGE.RS_DATE_FORMAT);
                    string ATime = ABrdRes.startTime.ToString(FEIGE.RS_TIME_FORMAT);
                    string ASPI = FEIGE.RS_MACHINE_TYPE;
                    string SaveLineStr = "";
                    SaveLineStr += (string.IsNullOrEmpty(ABarcode) ? "" : ABarcode) + RS_SPLIT;
                    SaveLineStr += (string.IsNullOrEmpty(AResult) ? "" : AResult) + RS_SPLIT;
                    SaveLineStr += (string.IsNullOrEmpty(ALine) ? "" : ALine) + RS_SPLIT;
                    SaveLineStr += (string.IsNullOrEmpty(ADate) ? "" : ADate) + RS_SPLIT;
                    SaveLineStr += (string.IsNullOrEmpty(ATime) ? "" : ATime) + RS_SPLIT;
                    SaveLineStr += (string.IsNullOrEmpty(ASPI) ? "" : ASPI) + RS_LineEnd;

                    string bufferFile = AstrDir + "\\" + FEIGE.RS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".txt";
                    FileStream fs = new FileStream(bufferFile, FileMode.Append);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(SaveLineStr);
                    streamWrt.Close();
                }
                catch (Exception ex)
                {
                    strMsg += RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
                }
            }

            //strMsg += UploadDataToDBFeiGe(AstrDir, AstrClntName, 
            //    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseAddress,
            //    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseName,
            //    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseUserID,
            //    AappSettingData.stMonitorSystemParams.stMonitorLaneParams[AbyLaneNo].strDataBaseUserPassword);
            strMsg += UploadDataToDBFeiGe(AstrDir, AstrClntName,
                AappSettingData.stDataExpVT.strWebAddress,
                AappSettingData.stDataExpVT.strDataBaseName,
                 AappSettingData.strDataExpOperator,
                AappSettingData.stDataExpVT.strOperatorPassword,
                AbyLaneNo);
            return strMsg;
        }
        //Q.F.2017.06.26
        public string CheckFeiGeConnection(string AServerIpAddress, string AsDbName, string AsDbUserName, string AsDbUserPw)
        {
            string strMsg = "";
            try
            {
                if (string.IsNullOrEmpty(AServerIpAddress) || string.IsNullOrEmpty(AsDbName)
              || string.IsNullOrEmpty(AsDbUserName) || string.IsNullOrEmpty(AsDbUserPw))
                {
                    strMsg = "error:parameter error";//Q.F.2017.04.07
                    return strMsg;
                }
                strMsg = _baseFun.PingCheck(AServerIpAddress);
                if (!String.IsNullOrEmpty(strMsg))
                {
                    return strMsg;
                }
                //Q.F.2017.08.21
                SQLServerDAO sqlServerDao = new SQLServerDAO(AServerIpAddress, AsDbName, AsDbUserName, AsDbUserPw, 2005);
            }
            catch (System.Exception ex)
            {
                strMsg = ex.ToString();
            }

            return strMsg;
        }
        //Q.F.2017.06.26
        private string UploadDataToDBFeiGe(string AstrDir,
            string AstrClntName, string AServerIpAddress, string AsDbName, string AsDbUserName, string AsDbUserPw,
            byte AbyLaneNo
            )
        {
            string strMsg = "";
            string bufferFile = AstrDir + "\\" + FEIGE.RS_BUFFER_FILE_NAME + "_" + AbyLaneNo + ".txt";
            strMsg = _baseFun.PingCheck(AServerIpAddress);
            SQLServerDAO sqlServerDao = null;
            if (!String.IsNullOrEmpty(strMsg))
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + strMsg;
                return strMsg;
            }
            try
            {
                //FileStream fs = new FileStream(bufferFile, FileMode.Open);
                StringBuilder RemainLines = new StringBuilder();
                //Q.F.2017.08.21
                sqlServerDao = new SQLServerDAO(AServerIpAddress, AsDbName, AsDbUserName, AsDbUserPw, 2005);
                using (System.IO.StreamReader sr = new System.IO.StreamReader(bufferFile))
                {
                    string lineStr;
                    while ((lineStr = sr.ReadLine()) != null)
                    {
                        string[] arrData = lineStr.Split(new char[1] { ',' }, StringSplitOptions.None);
                        if (arrData.Length == 6)
                        {

                            string result = sqlServerDao.InsertTableFeiGeSMTMA(AsDbName, arrData[0], arrData[1], arrData[2], arrData[3], arrData[4], arrData[5]);
                            if (!string.IsNullOrEmpty(result))
                            {
                                RemainLines.Append(lineStr + RS_LineEnd);
                                //strMsg += result;
                            }
                        }
                    }
                }
                //Q.F.2017.6.27
                if (File.Exists(bufferFile))
                {
                    File.Delete(bufferFile);
                }
                if (!string.IsNullOrEmpty(RemainLines.ToString()))
                {

                    FileStream fs = new FileStream(bufferFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(RemainLines);
                    streamWrt.Close();
                }
            }
            catch (Exception ex)
            {
                strMsg += RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }

            return strMsg;
        }


        //飞歌----------------------end


        //海派---------------------start

        private void generateFileContentJXHiPAD(ref StringBuilder fileContent, string AsBarcode, string AsArrayId, string AsCarrierBarcode, InspectMainLib.Pad[] APads)
        {
            for (int i = 0; i < APads.Length; i++)
            {
                if (_baseFun.bPadIsSkip(APads[i]))
                    continue;
                fileContent.Append(AsBarcode + RS_SPLIT);
                fileContent.Append(AsArrayId + RS_SPLIT);
                fileContent.Append(APads[i].componentID + RS_SPLIT);
                fileContent.Append(APads[i].padID + RS_SPLIT);
                fileContent.Append(APads[i].pinNumber + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.height) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.area) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.perArea) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.vol) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.perVol) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.offsetX) + RS_SPLIT);
                fileContent.Append(string.Format("{0:F3}", APads[i].res.measuredValue.offsetY) + RS_SPLIT);
                if (APads[i].res.jugRes == JudgeRes.Good)
                {
                    //   fileContent.Append(JXHiPAD.RS_RESULT[0] + RS_SPLIT + RS_LineEnd);
                    fileContent.Append(JXHiPAD.RS_RESULT[0] + RS_SPLIT);
                }
                else
                {
                    // fileContent.Append(JXHiPAD.RS_PAD_RESULT[(int)APads[i].res.jugDefectType] + RS_SPLIT + RS_LineEnd);
                    fileContent.Append(JXHiPAD.RS_PAD_RESULT[(int)APads[i].res.jugDefectType] + RS_SPLIT);
                }
                //add by joch 20170907
                fileContent.Append(AsCarrierBarcode + RS_SPLIT + RS_LineEnd);

            }
        }



        public string SaveDataExpFileJXHiPAD(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                StringBuilder fileContent = new StringBuilder();

                string jobPathName = ABrdRes.jobName;
                string jobName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                string strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                //add by joch 20170907
                string strCarrierBarcode = string.Empty;
                foreach (ImgCSCoreIM.StExtenBarcode extBarcode in ABrdRes.lstExtenBarcode)
                {
                    if (extBarcode.type == ImgCSCoreIM.ExtenBarcodeType.CarrierBarcode)
                    {
                        strCarrierBarcode = extBarcode.strBarcode;
                        break;
                    }
                }
                strCarrierBarcode = _baseFun.BarcodeDicision(strCarrierBarcode, AappSettingData, (byte)ABrdRes.LaneNo);

                string PcbId = ABrdRes.pcbID.ToString();
                string lineName = AappSettingData.LineName;
                string inspectDate = ABrdRes.startTime.ToString(JXHiPAD.RS_DATE_FORMAT);
                string inspectStartTime = ABrdRes.startTime.ToString(JXHiPAD.RS_TIME_FORMAT);
                string inspectEndTime = ABrdRes.endTime.ToString(JXHiPAD.RS_TIME_FORMAT);
                System.TimeSpan tick = ABrdRes.endTime.Subtract(ABrdRes.startTime);
                string cycleTime = string.Format("0:F2", Math.Abs(tick.TotalSeconds));
                string machineNo = AappSettingData.LineName;


                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    fileContent.Append(JXHiPAD.RS_COLUMN_TITLE_MAIN + RS_LineEnd);
                    fileContent.Append(jobPathName + RS_SPLIT);
                    fileContent.Append(strBoardBarcode + RS_SPLIT);
                    fileContent.Append(PcbId + RS_SPLIT);
                    fileContent.Append(inspectDate + RS_SPLIT);
                    fileContent.Append(inspectStartTime + RS_SPLIT);
                    fileContent.Append(inspectEndTime + RS_SPLIT);
                    fileContent.Append(cycleTime + RS_SPLIT);
                    fileContent.Append(jobName + RS_SPLIT);
                    fileContent.Append(JXHiPAD.RS_RESULT[(int)ABrdRes.jugResult] + RS_SPLIT);
                    fileContent.Append(JXHiPAD.RS_OPER + RS_SPLIT);
                    fileContent.Append(RS_SPLIT);
                    fileContent.Append(machineNo + RS_LineEnd);
                    fileContent.Append(JXHiPAD.RS_COLUMN_TITLE_DETAIL + RS_LineEnd);


                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array
                        if (APads != null && APads.Length > 0)
                        {
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;
                            generateFileContentJXHiPAD(ref fileContent, strBoardBarcode, strArrayID, strCarrierBarcode, APads);
                        }
                    }
                    else
                    {
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }
                            string sArrayBarcode = APcbGeneralInfo.PanelResults[0].arrStrBrcd[i];
                            if (string.IsNullOrEmpty(sArrayBarcode)) sArrayBarcode = strBoardBarcode;
                            //copy PadsRes to tompPads                         
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (iPartPadsLength > 0)
                            {
                                generateFileContentJXHiPAD(ref fileContent, strBoardBarcode, strArrayID, strCarrierBarcode, arrPartPads);
                            }

                        }
                    }
                    string strFileName = AstrDir + JXHiPAD.RS_EXPORT_FILE_NAME_TEMPLATE.Replace(JXHiPAD.RS_FILE_NAME_REPLACE[0], PcbId).Replace(JXHiPAD.RS_FILE_NAME_REPLACE[1], strBoardBarcode);

                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(fileContent);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                }


            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        //海派---------------------end


        //西胜---------------------start

        private void generateFileCQXiSheng(string AstrDir, string AsProgramName, string AsBarcode, string AsLineName,
                                    string AsShip, string AsEquipModel, string AsProductOrder, string AsInspectDate,
                                    string AsInspectTime, string AsArrayId, InspectMainLib.Pad[] APads)
        {
            //delete old tmp file
            string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
            if (File.Exists(tmpFile))
            {
                File.Delete(tmpFile);
            }
            string strFileName = AstrDir + CQXiSheng.RS_EXPORT_FILE_NAME_TEMPLATE.Replace(CQXiSheng.RS_LINENAME, AsLineName).Replace(CQXiSheng.RS_INSPECTDATETIME, (AsInspectDate + AsInspectTime)).Replace(CQXiSheng.RS_ARRAYID, AsArrayId);
            StringBuilder fileContent = new StringBuilder();
            fileContent.Append(AsProgramName + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsBarcode + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsLineName + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsShip + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsEquipModel + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsProductOrder + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsInspectDate + CQXiSheng.RS_END_LINE);
            fileContent.Append(AsInspectTime + CQXiSheng.RS_END_LINE);

            int totalPadCount = 0;
            int NGPadCount = 0;
            StringBuilder padContent = new StringBuilder();
            for (int i = 0; i < APads.Length; i++)
            {
                if (_baseFun.bPadIsSkip(APads[i]))
                    continue;
                totalPadCount++;
                if (APads[i].res.jugRes == JudgeRes.NG)
                {
                    NGPadCount++;
                    padContent.Append(CQXiSheng.RS_NG_PAD_DETAIL_TEMPLATE.Replace(CQXiSheng.RS_COMPONENTID, APads[i].componentID).Replace(CQXiSheng.RS_ARRAYID, AsArrayId).Replace(CQXiSheng.RS_PACKAGETYPE, (APads[i].packageType)));
                    padContent.Append(CQXiSheng.RS_END_LINE);
                }
            }

            if (NGPadCount == 0)
            {
                fileContent.Append(CQXiSheng.RS_INSPECT_RESULT_TEMPLATE[0] + CQXiSheng.RS_END_LINE);
            }
            else
            {
                fileContent.Append(CQXiSheng.RS_INSPECT_RESULT_TEMPLATE[1] + CQXiSheng.RS_END_LINE);
            }

            fileContent.Append("T" + CQXiSheng.RS_END_LINE);
            fileContent.Append(totalPadCount.ToString() + CQXiSheng.RS_END_LINE);
            fileContent.Append(NGPadCount.ToString() + CQXiSheng.RS_END_LINE);

            if (padContent.Length > 0)
            {
                fileContent.Append(padContent);
            }
            FileStream fs = new FileStream(tmpFile, FileMode.Create);
            System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
            streamWrt.Write(fileContent);
            streamWrt.Close();

            if (File.Exists(tmpFile))
            {
                File.Copy(tmpFile, strFileName, true);
                Thread.Sleep(100);
                File.Delete(tmpFile);
            }
        }


        public string SaveDataExpFileCQXiSheng(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                string programName = "";
                string strBoardBarcode = "";
                string lineName = "";
                string ship = "SHIP";
                string equipModel = "SPI";
                //string productOrder = "";
                string strLotNumber = "";//Q.F.2017.05.18 工单号
                string inspectDate = "";
                string inspectTime = "";

                programName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                lineName = AappSettingData.LineName;
                strLotNumber = AappSettingData.strLotNumber;
                if (string.IsNullOrEmpty(strLotNumber)) strLotNumber = "NONE";
                inspectDate = ABrdRes.startTime.ToString(CQXiSheng.RS_DATE_FORMAT);
                inspectTime = ABrdRes.startTime.ToString(CQXiSheng.RS_TIME_FORMAT);

                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array
                        if (APads != null && APads.Length > 0)
                        {
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;
                            generateFileCQXiSheng(AstrDir, programName, strBoardBarcode, lineName, ship, equipModel, strLotNumber, inspectDate, inspectTime, strArrayID, APads);
                        }
                    }
                    else
                    {
                        int iBarcodeCount = _baseFun.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                        string strArrayBarcode = "";
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }
                            //Q.F.2017.05.18
                            if (iBarcodeCount > 1)
                            {
                                strArrayBarcode = _baseFun.BarcodeDicision(APcbGeneralInfo.PanelResults[0].arrStrBrcd[i].Trim(),
                                                                 AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                            }
                            else
                            {
                                strArrayBarcode = strBoardBarcode;
                            }
                            //copy PadsRes to tompPads 
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                            string strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (iPartPadsLength > 0)
                            {
                                generateFileCQXiSheng(AstrDir, programName, strArrayBarcode, lineName, ship, equipModel, strLotNumber, inspectDate, inspectTime, strArrayID, arrPartPads);
                            }

                        }
                    }

                }

            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        //西胜---------------------end

        //add by tony 17.04.21
        //正泰WebService-----------start
        public string ChintWSUserLogin(string AwsAddress, string AsLoginName, String AsPassword,
            out string userId, out string userAuth, out string userName)
        {
            string returnStr = "";
            ChintWebservice chintWS = new ChintWebservice(AwsAddress);
            Result result;
            ResultDetail resultDetail;
            returnStr = chintWS.DoLogin(AsLoginName, AsPassword, out result, out resultDetail);
            if (!string.IsNullOrEmpty(returnStr) && returnStr.IndexOf("TRUE") >= 0)
            {
                userId = resultDetail.YGID;
                userAuth = resultDetail.CZQX;
                userName = resultDetail.YGXM;
            }
            else
            {
                userId = "";
                userAuth = "";
                userName = "";
            }

            return returnStr;
        }


        public string ChintWSValidateBarcode(string AwsAddress, string AsUserId, string AsBarcode,
            out string productOrderId, out string customerId, out string productId)
        {
            string returnStr = "";
            ChintWebservice chintWS = new ChintWebservice(AwsAddress);
            Result result;
            ResultDetail resultDetail;
            returnStr = chintWS.DoValidateBarcode(AsUserId, AsBarcode, out result, out resultDetail);
            if (!string.IsNullOrEmpty(returnStr) && returnStr.IndexOf("TRUE") >= 0)
            {
                productOrderId = resultDetail.SCZYDID;
                customerId = resultDetail.KHID;
                productId = resultDetail.CPID;
            }
            else
            {
                productOrderId = "";
                customerId = "";
                productId = "";
            }

            return returnStr;
        }

        //modify by QF 2017.04.22 
        public string ChintWSWSUploadData(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting   
            string AstrDir, //add by tony 17.5.2
            string AstrClntName
            )
        {

            string strMsg = String.Empty;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
                return strMsg;

            byte byLaneNo = (byte)ABrdRes.LaneNo;


            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
               || string.IsNullOrEmpty(ABrdRes.pcbBarcode)
               || string.IsNullOrEmpty(AappSettingData.LineName))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }

            String strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
            try
            {
                InspectMainLib.DefectType defectType = DefectType.Missing;
                foreach (InspectMainLib.Pad pad in APads)
                {
                    if (_baseFun.bPadIsSkip(pad))
                        continue;
                    if (pad.res.jugRes == JudgeRes.NG)
                    {
                        defectType = pad.res.jugDefectType;
                        break;
                    }
                }

                //modify by tony 17.5.2

                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                StringBuilder strFileContent = new StringBuilder();
                strFileContent.Append(WZChint.RS_COLUMN_TITLE + RS_LineEnd);

                string padImagePath = ABrdRes.strDataExportSavePadImagePath;

                int totalArrayIndex = 0;
                string barcodeArrayIndex = "";
                string inspectTime = ABrdRes.startTime.ToString(WZChint.FileNameTimeFormat);
                string strFileName = AstrDir + WZChint.FileFullNameTemplate.Replace(WZChint.INSPECTTIME, inspectTime).Replace(WZChint.BARCODE, strBoardBarcode);

                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null && APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length > 0)
                {
                    totalArrayIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                else
                {
                    totalArrayIndex = 1;
                }
                generateFileContentWZChint(ref strFileContent, strBoardBarcode, ABrdRes.stMESPrams.productOrderId, padImagePath, APads);

                //barcodeArrayIndex
                //if (APcbGeneralInfo.camBarcodes.BarcodeList != null && APcbGeneralInfo.camBarcodes.BarcodeList.Count > 0) 
                //{
                //    for (int i = 0; i < APcbGeneralInfo.camBarcodes.BarcodeList.Count; i++) 
                //    {
                //        ImageProcessingCPP.Barcode barcode = APcbGeneralInfo.camBarcodes.BarcodeList[i];
                //        if(strBoardBarcode.Equals(barcode.BarcodeRes.strDecodingStr))
                //        {
                //            barcodeArrayIndex = barcode.strArrayID;
                //            break;
                //        }
                //    }
                //}
                //Q.F.2017.06.07
                //barcodeArrayIndex = _baseFun.GetArrayIDForArrayBarcode(strBoardBarcode, APcbGeneralInfo, AappSettingData, (byte)ABrdRes.LaneNo);
                //for (int i = 0; i < APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length; i++)
                //{
                //    barcodeArrayIndex += "Barcode: " + APcbGeneralInfo.PanelResults[0].arrStrBrcd[i] + "  ArrayID: ";
                //    barcodeArrayIndex += _baseFun.GetArrayIDForArrayBarcode(APcbGeneralInfo.PanelResults[0].arrStrBrcd[i], APcbGeneralInfo, AappSettingData, (byte)ABrdRes.LaneNo);
                //    barcodeArrayIndex += "\n";
                //}
                //MessageBox.Show(barcodeArrayIndex);
                //Q.F.2017.07.05
                barcodeArrayIndex = AappSettingData.stDataExpVT.aStrUserDefinedArrayID[byLaneNo];

                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strFileContent);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }


                return ChintWSUploadInspect(AappSettingData.stDataExpVT.strWebAddress,
                    ABrdRes.stMESPrams.userId,
                    ABrdRes.stMESPrams.productOrderId,
                    strBoardBarcode,
                    ABrdRes.jugResult,
                    defectType,
                    ABrdRes.stMESPrams.productId,
                    ABrdRes.stMESPrams.customerId,
                    ABrdRes.stMESPrams.userName,
                    AappSettingData.LineName,
                    totalArrayIndex, barcodeArrayIndex, strFileName); //modify by tony 17.5.2
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
                return strMsg;
            }
        }

        private void generateFileContentWZChint(ref StringBuilder strFileContent, string strBoardBarcode, string productOrderId, string padImagePath, InspectMainLib.Pad[] APads)
        {
            int iPadLength = APads.Length;
            List<string> arrayIdList = new List<string>();
            for (int i = 0; i < iPadLength; i++)
            {
                Pad pad = APads[i];
                if (_baseFun.bPadIsSkip(pad))
                    continue;
                //生产作业单ID,条形码,检测项目（唯一标识）,位置,检测结果,检测结论,元器件名称,图片地址
                strFileContent.Append(productOrderId + RS_SPLIT);
                strFileContent.Append(strBoardBarcode + RS_SPLIT);
                strFileContent.Append(strBoardBarcode + RS_UNDERLINE + pad.arrayIDIndex.ToString() + pad.padID.ToString() + RS_SPLIT);
                strFileContent.Append(pad.padID.ToString() + RS_SPLIT);
                if (!arrayIdList.Contains(pad.arrayIDIndex.ToString()))
                {
                    arrayIdList.Add(pad.arrayIDIndex.ToString());
                }
                switch (pad.res.jugRes)
                {
                    case JudgeRes.Good:
                        strFileContent.Append(WZChint.RS_GOOD + RS_SPLIT);
                        strFileContent.Append(WZChint.RS_GOOD + RS_SPLIT);
                        break;
                    case JudgeRes.NG:
                        strFileContent.Append(pad.res.jugDefectType.ToString() + RS_SPLIT);
                        strFileContent.Append(WZChint.RS_FAIL + RS_SPLIT);
                        break;
                    case JudgeRes.Pass:
                        strFileContent.Append(pad.res.jugDefectType.ToString() + RS_SPLIT);
                        strFileContent.Append(WZChint.RS_PASS + RS_SPLIT);
                        break;
                    default:
                        strFileContent.Append(RS_SPLIT);
                        strFileContent.Append(RS_SPLIT);
                        break;
                }

                strFileContent.Append(pad.componentID + RS_SPLIT);
                // strFileContent.Append(pad.padID.ToString() + RS_SPLIT);
                strFileContent.Append(padImagePath + pad.padID + ".jpg" + RS_LineEnd);

            }
        }

        //ApadDefect为第一个pad的不良类型，lineName为设备编号或线体号  modify by Tony 17.5.2
        public string ChintWSUploadInspect(string AwsAddress, string AsUserId, string productOrderId, string AsBarcode,
            JudgeRes AboardJudgeRes, DefectType ApadDefect, string productId, string customerId, string userName, string lineName,
            int totalArrayCount, string barcodeArrayIndex, string inspectDetailFile)
        {
            string returnStr = "";
            ChintWebservice chintWS = new ChintWebservice(AwsAddress);
            Result result;
            ResultDetail resultDetail;
            string defectType = ApadDefect == null ? "" : ApadDefect.ToString();
            returnStr = chintWS.DoUploadInspect(AsUserId, productOrderId, AsBarcode, AboardJudgeRes, defectType,
                productId, customerId, userName, lineName, totalArrayCount, barcodeArrayIndex, inspectDetailFile,
                out result, out resultDetail);
            return returnStr;
        }

        //正泰WebService----------end

        //郑州富士康 ----------start

        public string SaveDataExpFileZzFoxconn(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName, ImgCSCoreIM.StDeleteFileParam AstDelFileParam)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //get board barcode
                String strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strBoardBarcode, RS_NOREAD))
                    strBoardBarcode = "NOREAD";
                string strInspectTime = ABrdRes.startTime.ToString(ZhengZhouFoxconn.FileNameTimeFormat);
                string strExportFileName = ZhengZhouFoxconn.FileFullNameTemplate.Replace(ZhengZhouFoxconn.INSPECTTIME, strInspectTime).Replace(ZhengZhouFoxconn.BARCODE, strBoardBarcode);
                string strExportFilePath = AstrDir;

                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                //check or create directory
                string[] strFileDir = new string[3];
                strFileDir[0] = "\\" + ABrdRes.startTime.ToString(ZhengZhouFoxconn.FilePathCheck[0]);
                strFileDir[1] = "\\" + ABrdRes.startTime.ToString(ZhengZhouFoxconn.FilePathCheck[1]);
                strFileDir[2] = "\\" + ABrdRes.startTime.ToString(ZhengZhouFoxconn.FilePathCheck[2]);

                for (int i = 0; i < strFileDir.Length; i++)
                {
                    strExportFilePath += strFileDir[i];
                    if (!Directory.Exists(strExportFilePath))
                    {
                        Directory.CreateDirectory(strExportFilePath);
                    }
                }

                StringBuilder strFileContent = new StringBuilder();

                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    string strFileName = strExportFilePath + "\\" + strExportFileName;


                    strFileContent.Append(ZhengZhouFoxconn.RS_COLUMN_TITLE + RS_LineEnd);
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array                                             
                        if (APads != null && APads.Length > 0)
                        {
                            generateFileContentZzFoxconn(ref strFileContent, strBoardBarcode, ABrdRes.startTime, "", APads, APcbGeneralInfo);
                        }
                    }
                    else
                    {
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }

                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);

                            if (iPartPadsLength > 0)
                            {
                                generateFileContentZzFoxconn(ref strFileContent, strBoardBarcode, ABrdRes.startTime, i.ToString(), arrPartPads, APcbGeneralInfo);
                            }

                        }
                    }
                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(strFileContent);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strFileName, true);
                        Thread.Sleep(100);
                        File.Delete(tmpFile);
                    }
                }
                //add by tony 17.8.14
                // _baseFun.DeleteDataExportFile(  AstDelFileParam);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        private void generateFileContentZzFoxconn(ref StringBuilder strFileContent, string strBoardBarcode, DateTime startTime, string arrayId, InspectMainLib.Pad[] APads, ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo)
        {
            for (int i = 0; i < APads.Length; i++)
            {
                if (_baseFun.bPadIsSkip(APads[i]))
                    continue;

                strFileContent.Append(APads[i].componentID + RS_SPLIT);
                //.F.2017.08.10
                strFileContent.Append(APads[i].padID + RS_SPLIT);
                strFileContent.Append(APads[i].packageType + RS_SPLIT);
                strFileContent.Append(strBoardBarcode + RS_SPLIT);
                //Q.F.2017.04.21
                strFileContent.Append((APads[i].res.measuredValue.perArea * 100).ToString(RS_FLOATFORMAT_1Bit) + RS_PERC + RS_SPLIT);
                strFileContent.Append((APads[i].res.measuredValue.perVol * 100).ToString(RS_FLOATFORMAT_1Bit) + RS_PERC + RS_SPLIT);
                strFileContent.Append((APads[i].res.measuredValue.perHeight * 100).ToString(RS_FLOATFORMAT_1Bit) + RS_PERC + RS_SPLIT);

                strFileContent.Append(APads[i].res.measuredValue.height.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                strFileContent.Append(APads[i].res.measuredValue.area.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                strFileContent.Append(APads[i].res.measuredValue.vol.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                //Q.F.2017.04.17
                strFileContent.Append(APads[i].sizeXmmNew.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                strFileContent.Append(APads[i].sizeYmmNew.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);

                strFileContent.Append(APads[i].res.measuredValue.offsetX.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                strFileContent.Append(APads[i].res.measuredValue.offsetY.ToString(RS_FLOATFORMAT_6Bit) + RS_SPLIT);
                if (APads[i].res.jugRes == JudgeRes.Good)
                {
                    strFileContent.Append(JudgeRes.Good.ToString() + RS_SPLIT);
                }
                else
                {

                    strFileContent.Append(convertDefectTypeToChinese(APads[i].res.jugDefectType) + RS_SPLIT);
                }
                strFileContent.Append(APads[i].pinNumber.ToString() + RS_SPLIT);
                strFileContent.Append(startTime.ToString("yyyy-MM-dd") + RS_SPLIT);
                strFileContent.Append(startTime.ToString("HH:mm:ss") + RS_SPLIT);
                strFileContent.Append(arrayId + RS_SPLIT);

                strFileContent.Append(RS_LineEnd);

            }
        }



        //郑州富士康 ----------end

        //欣旺达 SunWoDa webservice-----start
        #region "  SunWoDa欣旺达"
        /**
         * user login
         **/
        public string SunWoDaWSUserLogin(ref AppSettingData AappSettingData,
            string AsWSAdress, string AsUserNo, string AsPassword, string AsMachineNo)
        {

            //test
            
            switch ((ENM_SunWoDaExportFormat)AappSettingData.stDataExpVT.byExportFormat)
            {
                case ENM_SunWoDaExportFormat.BoLuo:
                    {
                        return SunWoDaWSUserLogin_Boluo(AsWSAdress, AsUserNo, AsPassword, AsMachineNo);
                        break;
                    }
                case ENM_SunWoDaExportFormat.BoLuo10D:
                    {
                        return SunWoDaWSUserLogin_BoluoWith10D(AsWSAdress, AsUserNo, AsPassword, AsMachineNo);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
            

            string strMsg = String.Empty;
            if (string.IsNullOrEmpty(AsWSAdress) || string.IsNullOrEmpty(AsUserNo)
                || string.IsNullOrEmpty(AsPassword) || string.IsNullOrEmpty(AsMachineNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            Hashtable htParams = new Hashtable();
            htParams.Add("M_USERNO", AsUserNo);
            htParams.Add("M_PASSWORD", AsPassword);
            htParams.Add("M_MACHINENO", AsMachineNo);
            string sMethodName = "CheckUserDo";
            try
            {
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUserLogin -> CheckUserDo ", "start...");
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUserLogin -> CheckUserDo ", "end...");
                }
                return strMsg;
            }
            catch (Exception ee)
            {
                //throw new Exception();
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }

        public string SunWoDaWSUserLogin_Boluo(string AsWSAdress, string AsUserNo, string AsPassword, string AsMachineNo)
        {
            string strMsg = String.Empty;
            if (string.IsNullOrEmpty(AsWSAdress) || string.IsNullOrEmpty(AsUserNo)
                || string.IsNullOrEmpty(AsPassword) || string.IsNullOrEmpty(AsMachineNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            Hashtable htParams = new Hashtable();
            htParams.Add("M_USERNO", AsUserNo);
            htParams.Add("M_PASSWORD", AsPassword);
            htParams.Add("M_MACHINENO", AsMachineNo);
            string sMethodName = "CheckUserDo";
            try
            {
                return WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
            }
            catch (Exception ee)
            {
                //throw new Exception();
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }

        public string SunWoDaWSUserLogin_BoluoWith10D(string AsWSAdress, string AsUserNo, string AsPassword, string AsMachineNo)
        {
            string strMsg = String.Empty;
            if (string.IsNullOrEmpty(AsWSAdress) || string.IsNullOrEmpty(AsUserNo)
                || string.IsNullOrEmpty(AsPassword) || string.IsNullOrEmpty(AsMachineNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            Hashtable htParams = new Hashtable();
            htParams.Add("M_USERNO", AsUserNo);
            htParams.Add("M_PASSWORD", AsPassword);
            htParams.Add("M_MACHINENO", AsMachineNo);
            string sMethodName = "CheckUserDo";
            try
            {
                return WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
            }
            catch (Exception ee)
            {
                //throw new Exception();
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }

        /**
         * check barcode invalidate
         **/
        public string SunWoDaWSCheckBarcode(ref AppSettingData AappSettingData,
            string AsWSAdress, string AsBarcode,
            string AsMachineNo, string AsUserNo, 
            InspectMainLib.Marks AMarks, 
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            byte AbyLaneNo)
        {
            
            switch ((ENM_SunWoDaExportFormat)AappSettingData.stDataExpVT.byExportFormat)
            {
                case ENM_SunWoDaExportFormat.BoLuo:
                    {
                        return SunWoDaWSCheckBarcode_Boluo(AsWSAdress, AsBarcode, AsMachineNo, AsUserNo, AMarks, APcbGeneralInfo,AappSettingData,AbyLaneNo);
                        break;
                    }
                case ENM_SunWoDaExportFormat.BoLuo10D:
                    {
                        return SunWoDaWSCheckBarcode_BoluoWith10D(AsWSAdress, AsBarcode, AsMachineNo, AsUserNo, AMarks, APcbGeneralInfo, AappSettingData, AbyLaneNo);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
            string strMsg = String.Empty;
            //MessageBox.Show(AsMachineNo);
            //strMsg = "true";    //modified by peng 20190520      
            //return strMsg;//Q.F.2018.11.26    //modified by peng 20190520    
            if (string.IsNullOrEmpty(AsWSAdress) //|| string.IsNullOrEmpty(AsBarcode)
                || string.IsNullOrEmpty(AsMachineNo) || string.IsNullOrEmpty(AsUserNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            
            int iArrayCount = 0;
            string strMarkGroupID = string.Empty;
            bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            string strMarkBarcode = string.Empty;
            //mmodified by peng 20190520   APcbGeneralInfo.bEnGlbMarkGroup replace bEnExportGlobalMarkGroup
            if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[AbyLaneNo])
            {
                if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                {
                    for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                    {
                        //string strMarkResult = "OK";
                        strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                        {
                            iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        }
                        for (int i = 0; i != iArrayCount; ++i)
                        {
                            if (bPosZeroISUsed == false && i == 0)
                            {
                                continue;
                            }
                            if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                            {
                                string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                {
                                    continue;
                                }
                                strMarkBarcode = strTmpMarkCode;
                            }
                        }
                    }
                }
                
            }
            else
            {
                strMarkBarcode = AsBarcode;
            }
            if (string.IsNullOrEmpty(strMarkBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strMarkBarcode, StringComparison.CurrentCultureIgnoreCase))
            {
                strMsg = "error:parameter error  MarkBarcode_Is_Null or NoRead!";
                return strMsg;
            }

            Hashtable htParams = new Hashtable();
            htParams.Add("M_SN", strMarkBarcode);
            htParams.Add("M_MACHINENO", AsMachineNo);
            htParams.Add("M_EMP", AsUserNo);
            string sMethodName = "GroupTest";
            try
            {
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSCheckBarcode -> GroupTest ", "start...");
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSCheckBarcode -> GroupTest ", "end...");
                }
                return strMsg;
            }
            catch (Exception ee)
            {
                // throw new Exception("error:" + ee.Message);
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }
        private readonly string RS_Log_Tony = @"D:\EYSPI\Bin\SPILogs\tony";

        private void SaveLogsYouJiaInfo(string Akey, string Avalue)
        {
            string str = string.Empty;
            string strFilePath = RS_Log_Tony;
            if (Directory.Exists(RS_Log_Tony) == false)
            {
                Directory.CreateDirectory(RS_Log_Tony);
            }
            string strFile = Path.Combine(strFilePath, "logs" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
            string strDateTime = DateTime.Now.ToString("yyyyMMdd HH:mm:ss");
            string strLog = "";
            try
            {
                if (!Directory.Exists(strFilePath))
                {
                    Directory.CreateDirectory(strFilePath);
                }
                if (!File.Exists(strFile))
                {
                    using (FileStream fs = new FileStream(strFile, FileMode.Create))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        strLog += "[    " + strDateTime + "   ]  " + Akey + " :" + Avalue + "\r\n " + "\r\n";
                        sw.Write(strLog);
                        sw.Close();
                    }
                }
                else
                {
                    using (FileStream fs = new FileStream(strFile, FileMode.Append))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        strLog += "[    " + strDateTime + "   ]  " + Akey + " :" + Avalue + "\r\n " + "\r\n";
                        sw.Write(strLog);
                        sw.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SunWoDaWSCheckBarcode_Boluo(string AsWSAdress,
            string AsBarcode, string AsMachineNo, 
            string AsUserNo, InspectMainLib.Marks AMarks,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppSettingData AappSettingData,
            byte AbyLaneNo)
        {
            string strMsg = String.Empty;
            if (string.IsNullOrEmpty(AsWSAdress) //|| string.IsNullOrEmpty(AsBarcode)
                || string.IsNullOrEmpty(AsMachineNo) || string.IsNullOrEmpty(AsUserNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            //test
            int iArrayCount = 0;
            string strMarkGroupID = string.Empty;
            bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            string strMarkBarcode = string.Empty;
            try
            {
                //mmodified by peng 20190520   APcbGeneralInfo.bEnGlbMarkGroup replace bEnExportGlobalMarkGroup
               // MessageBox.Show("全局mark:"+AbyLaneNo+"_"+AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[AbyLaneNo] +"");
                if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[AbyLaneNo])
                {
                    if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                    {
                        for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                        {
                            //string strMarkResult = "OK";
                            strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                            {
                                iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                            }
                            for (int i = 0; i != iArrayCount; ++i)
                            {
                                if (bPosZeroISUsed == false && i == 0)
                                {
                                    continue;
                                }
                                //MessageBox.Show("MarkGroupID:" + strMarkGroupID + "_arrSingleArrayInfo[i].strGlbMarkGroupID" + APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID);
                                if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                {
                                    string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                    //MessageBox.Show("TmpMarkCode:" + strTmpMarkCode);
                                    if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        continue;
                                    }
                                    strMarkBarcode = strTmpMarkCode;
                                    //MessageBox.Show("MarkBarcode:" + strMarkBarcode + "  MarkGroupID:" + strMarkGroupID);
                                }
                            }
                        }
                    }
                    if (string.IsNullOrEmpty(strMarkBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strMarkBarcode, StringComparison.CurrentCultureIgnoreCase))
                    {
                        strMsg = "error:parameter error  MarkBarcode_Is_Null or NoRead!";
                        return strMsg;
                    }
                }
                else
                {
                        strMarkBarcode = AsBarcode;
                }
                Hashtable htParams = new Hashtable();
                htParams.Add("M_SN", strMarkBarcode);
                string sMethodName = "BakeTest";
                string bakeTestReturn = "";

                bakeTestReturn = WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                if (string.Equals(bakeTestReturn, "TRUE"))
                {
                    //工序校验
                    //单轨
                    //if (AconfigData._conv3StageMode == false)
                    //{
                    //    htParams.Add("M_MACHINCENO", strLineName);
                    //    SaveLogsYouJiaInfo("[单轨]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", strLineName);
                    //}
                    ////双轨
                    //else
                    //{
                    //    htParams.Add("M_MACHINCENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                    //    SaveLogsYouJiaInfo("[双轨:ABrdRes.LaneNo=>" + byLaneNo + "]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                    //}
                    //htParams.Add("M_MACHINCENO", AsMachineNo);
                    //htParams.Add("M_EMP", AsUserNo);
                    //sMethodName = "GroupTest";
                    return strMsg;//WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                }
                else
                {
                    return bakeTestReturn;
                }
            }
            catch (Exception ee)
            {
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }

        public string SunWoDaWSCheckBarcode_BoluoWith10D(string AsWSAdress,
            string AsBarcode, string AsMachineNo,
            string AsUserNo, InspectMainLib.Marks AMarks,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppSettingData AappSettingData,
            byte AbyLaneNo)
        {
            string strMsg = String.Empty;
            if (string.IsNullOrEmpty(AsWSAdress) //|| string.IsNullOrEmpty(AsBarcode)
                || string.IsNullOrEmpty(AsMachineNo) || string.IsNullOrEmpty(AsUserNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            //test
            int iArrayCount = 0;
            string strMarkGroupID = string.Empty;
            bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            string strMarkBarcode = string.Empty;
            try
            {
                //mmodified by peng 20190520   APcbGeneralInfo.bEnGlbMarkGroup replace bEnExportGlobalMarkGroup
                if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[AbyLaneNo])
                {
                    if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                    {
                        for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                        {
                            //string strMarkResult = "OK";
                            strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                            {
                                iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                            }
                            for (int i = 0; i != iArrayCount; ++i)
                            {
                                if (bPosZeroISUsed == false && i == 0)
                                {
                                    continue;
                                }
                                if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                {
                                    string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                    if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        continue;
                                    }
                                    strMarkBarcode = strTmpMarkCode;
                                }
                            }
                        }
                    }
                    if (string.IsNullOrEmpty(strMarkBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strMarkBarcode, StringComparison.CurrentCultureIgnoreCase))
                    {
                        strMsg = "error:parameter error  MarkBarcode_Is_Null or NoRead!";
                        return strMsg;
                    }
                }
                else
                {
                    strMarkBarcode = AsBarcode;
                }
                Hashtable htParams = new Hashtable();
                htParams.Add("M_SN", strMarkBarcode);
                string sMethodName = "BakeTest";
                string bakeTestReturn = "";

                bakeTestReturn = WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                if (string.Equals(bakeTestReturn, "TRUE"))
                {
                    
                    return strMsg;//WSClnt.SoapOperator.DoSoapWebService(AsWSAdress, sMethodName, htParams);
                }
                else
                {
                    return bakeTestReturn;
                }
            }
            catch (Exception ee)
            {
                strMsg = "error:" + ee.Message;//Q.F.2017.04.07
                return strMsg;
            }
        }

        /**
         *  upload inspect data
         *  AsResult:PASS/FAIL
         *  
         **/
        //public string SunWoDaWSUploadData(string AsWSAdress, string AsBarcode, string AsResult, string AsUserNo,
        //    string AsMachineNo,string AsErrorCode,string AsInspData,string AsMakeOder,string AsPCBInfo)
        //modify by QF 2017.07.04
        //modify by joch 20170911  strWSReturn 0/1/2/3;0表示错误,1表示正常，2表示报警但是不停机，3表示停机设备不能继续生产
        public string SunWoDaWSUploadData(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn,InspectMainLib.Marks AMarks
            )
        {
            
            switch ((ENM_SunWoDaExportFormat)AappSettingData.stDataExpVT.byExportFormat)
            {
                case ENM_SunWoDaExportFormat.BoLuo:
                    {
                        return SunWoDaWSUploadData_Boluo(APads,
                            ABrdRes,
                            APcbGeneralInfo,
                            AappSettingData,
                            AconfigData,
                            AstrClntName,
                            out AiWSReturn, AMarks
                            );
                        break;
                    }
                case ENM_SunWoDaExportFormat.BoLuo10D:
                    {
                        return SunWoDaWSUploadData_BoluoWith10D(APads,
                            ABrdRes,
                            APcbGeneralInfo,
                            AappSettingData,
                            AconfigData,
                            AstrClntName,
                            out AiWSReturn, AMarks
                            );
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            string strMsg = String.Empty;
            if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])
            {
                strMsg = SunWoDaWSUploadData_Mark(APads, ABrdRes, APcbGeneralInfo, AappSettingData, AconfigData, AstrClntName, out AiWSReturn, AMarks);
                
                return strMsg;
            }
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }

            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];
            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }
            
            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                || string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            
            String strResult = "FAIL";
            if (ABrdRes.jugResult == JudgeRes.Good
                || ABrdRes.jugResult == JudgeRes.Pass)
                strResult = "PASS";


            Hashtable htParams = new Hashtable();
            htParams.Add("M_SN", ABrdRes.pcbBarcode);
            htParams.Add("M_RESULT", strResult);
            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                
                htParams.Add("M_MACHINENO", strLineName);
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
            }

            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                if (iArrayCount > 0)
                {

                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        iArrayIndex++;
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            if (string.Equals(strArrayStatus, "Skipped"))
                            {
                                continue;
                            }
                            int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                            foreach (int padIndex in arrPadIndex)
                            {
                                Pad pad = APads[padIndex];
                                //modify tony 20181213
                                //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                if (_baseFun.bPadIsSkip(pad))
                                {
                                    continue;
                                }
                                string arrayName = iArrayIndex.ToString();
                                string padName = padIndex.ToString();
                                string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);


                                padInspectItemValue += arrayName + "-" + padName
                                    + ":," + compomentName
                                    + ",V:" + volValuePercent
                                    + ",H," + heightValue
                                    + ",A," + areaValue
                                    + ",X," + xOffsetValue
                                    + ",Y," + yOffsetValue;
                                if (pad.res.jugRes == JudgeRes.NG)
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Pass)
                                {
                                    padInspectItemValue += ",NG,PASS,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Good)
                                {
                                    padInspectItemValue += ",PASS,PASS,";
                                    padInspectItemValue += "Good|";
                                }
                                else
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }

                            }

                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
            //------------
            int arrayGoodCount = 0, arrayNGCount = 0;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
            {
                itemValue = "|1:" + strResult + "1";
            }
            else
            {
                //array
                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int arrayIndex = 1;
                for (int i = 0; i < iArrayQty; i++)
                {
                    if ((i == 0 && bPosZeroISUsed == false)
                            || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                        //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                        )
                    {
                        continue;
                    }
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                   || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                    //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                    {
                        itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                    }
                    else
                    {
                        //string arrayResult = "PASS";
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                            arrayNGCount++;
                            int ngPadDCount = 0;
                            for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                            {
                                int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                {
                                    continue;
                                }
                                string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                ngPadDCount++;
                            }
                        }
                        else
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                            arrayGoodCount++;
                        }


                        InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                        int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                    }
                    arrayIndex++;
                }
                if (arrayIndex > 1)
                {
                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                }
            }
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);

            //-------------------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
            //add by joch 
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            int iArrayQtyNumber = 0, iNGArrayCount = 0;
            if (bISArrayPCB)
            {
                foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                {
                    if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                    {
                        iArrayQtyNumber++;
                        // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                        if (sArrayInfo.shBadMarkMode > 0)
                        {
                            iNGArrayCount++;
                        }
                    }
                }
            }
            htParams.Add("M_Boards_Number", iArrayQtyNumber);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);



            string sMethodName = "SMTWeldInput";
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUploadData -> SMTWeldInput ", "start...");
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUploadData -> SMTWeldInput ", "end...");
                }
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }

        private string SunWoDaWSUploadData_Mark(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn, InspectMainLib.Marks AMarks
            )
        {
            string strMsg = String.Empty;
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }
            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];
            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }

            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                //|| string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            String strMarkResult = "PASS";
            //if (ABrdRes.jugResult == JudgeRes.Good
            //    || ABrdRes.jugResult == JudgeRes.Pass)
            //    strResult = "PASS";

            Hashtable htParams = new Hashtable();
            
            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                htParams.Add("M_MACHINENO", strLineName);
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
            }
            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            string strMarkGroupID = string.Empty, strMarkBarcode=string.Empty;
            int iArrayQtyNumber = 0, iNGArrayCount = 0;
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                //if (iArrayCount > 0)
                //{
                int arrayGoodCount = 0, arrayNGCount = 0;
                if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])//(APcbGeneralInfo.bEnGlbMarkGroup)
                {
                    if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                    {
                        for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                        {
                            //string strMarkResult = "OK";
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                            {
                                iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                            }
                            strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                            for (int i = 0; i < iArrayCount; i++)
                            {
                                if (bPosZeroISUsed == false && i == 0)
                                {
                                    continue;
                                }
                                if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                {
                                    iArrayIndex++;
                                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                                        APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                                    {
                                        string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                                        if (string.Equals(strArrayStatus, "Skipped"))
                                        {
                                            continue;
                                        }
                                        string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                        if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            continue;
                                        }
                                        strMarkBarcode = strTmpMarkCode;

                                        if (strArrayStatus == "NG"
                                           )
                                        {
                                            strMarkResult = "NG";
                                        }
                                        int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                                        foreach (int padIndex in arrPadIndex)
                                        {
                                            Pad pad = APads[padIndex];
                                            //modify tony 20181213
                                            //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                            if (_baseFun.bPadIsSkip(pad))
                                            {
                                                continue;
                                            }
                                            string arrayName = iArrayIndex.ToString();
                                            string padName = padIndex.ToString();
                                            string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                            string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                            string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                            string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                            string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                            string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);


                                            padInspectItemValue += arrayName + "-" + padName
                                                + ":," + compomentName
                                                + ",V:" + volValuePercent
                                                + ",H," + heightValue
                                                + ",A," + areaValue
                                                + ",X," + xOffsetValue
                                                + ",Y," + yOffsetValue;
                                            if (pad.res.jugRes == JudgeRes.NG)
                                            {
                                                padInspectItemValue += ",NG,NG,";
                                                padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                            }
                                            else if (pad.res.jugRes == JudgeRes.Pass)
                                            {
                                                padInspectItemValue += ",NG,PASS,";
                                                padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                            }
                                            else if (pad.res.jugRes == JudgeRes.Good)
                                            {
                                                padInspectItemValue += ",PASS,PASS,";
                                                padInspectItemValue += "Good|";
                                            }
                                            else
                                            {
                                                padInspectItemValue += ",NG,NG,";
                                                padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                            }

                                        }

                                    }
                                }
                            }

                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                            {
                                itemValue = "|1:" + strMarkResult + "1";
                            }
                            else
                            {
                                //array
                                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                                 bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                                int arrayIndex = 1;
                                for (int i = 0; i < iArrayQty; i++)
                                {
                                    if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                    {
                                        string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                        if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            continue;
                                        }
                                        if ((i == 0 && bPosZeroISUsed == false)
                                                || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                            //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                                            )
                                        {
                                            continue;
                                        }
                                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                                       || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                                        //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                                        {
                                            itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                                        }
                                        else
                                        {
                                            //string arrayResult = "PASS";
                                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                                                arrayNGCount++;
                                                int ngPadDCount = 0;
                                                for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                                                {
                                                    int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                                    if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                                    {
                                                        continue;
                                                    }
                                                    string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                                    itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                                    ngPadDCount++;
                                                }
                                            }
                                            else
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                                                arrayGoodCount++;
                                            }


                                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                                        }
                                        arrayIndex++;
                                    }
                                }
                                if (arrayIndex > 1)
                                {
                                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                                }
                            }
                            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                            if (bISArrayPCB)
                            {
                                foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                                {
                                    if (strMarkGroupID == sArrayInfo.strGlbMarkGroupID)
                                    {
                                        string strTmpMarkCode = sArrayInfo.strGlbMarkGroupBarcode;
                                        if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            continue;
                                        }
                                        if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                                        {
                                            iArrayQtyNumber++;
                                            // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                                            if (sArrayInfo.shBadMarkMode > 0)
                                            {
                                                iNGArrayCount++;
                                            }
                                        }
                                    }
                                }
                            }
                            // }
                        }
                    }

                }
            }
            catch (Exception)
            {

            }
            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
            //------------
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);
            //-------------------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);

            htParams.Add("M_SN", strMarkBarcode);
            htParams.Add("M_RESULT", strMarkResult);

            //add by joch 
            
            
            
            htParams.Add("M_Boards_Number", iArrayQtyNumber);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);

            string sMethodName = "SMTWeldInput";
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUploadData_Mark -> SMTWeldInput ", "start...");
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("调用SunWoDaWSUploadData_Mark -> SMTWeldInput ", "end...");
                }
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }

        public string SunWoDaWSUploadData_Boluo(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn,
            InspectMainLib.Marks AMarks 
            )
        {
            string strMsg = String.Empty;
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }

            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];

            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }
            if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])//(APcbGeneralInfo.bEnGlbMarkGroup)
            {
                strMsg = SunWoDaWSUploadData_BoluoForMark(APads, ABrdRes, APcbGeneralInfo, AappSettingData, AconfigData, AstrClntName, out AiWSReturn, AMarks);
                return strMsg;
            }
            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                || string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            String strResult = "FAIL";
            if (ABrdRes.jugResult == JudgeRes.Good
                || ABrdRes.jugResult == JudgeRes.Pass)
                strResult = "PASS";


            Hashtable htParams = new Hashtable();
            htParams.Add("M_SN", ABrdRes.pcbBarcode);
            htParams.Add("M_RESULT", strResult);
            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                htParams.Add("M_MACHINENO", strLineName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[单轨]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", strLineName);
                }
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[双轨:ABrdRes.LaneNo=>" + byLaneNo + "]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                }
            }
            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                if (iArrayCount > 0)
                {

                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        iArrayIndex++;
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            if (string.Equals(strArrayStatus, "Skipped"))
                            {
                                continue;
                            }
                            int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                            foreach (int padIndex in arrPadIndex)
                            {
                                Pad pad = APads[padIndex];
                                //modify tony 20181213
                                //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                if (_baseFun.bPadIsSkip(pad))
                                {
                                    continue;
                                }
                                string arrayName = iArrayIndex.ToString();
                                string padName = padIndex.ToString();
                                string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);

                                padInspectItemValue += arrayName + "-" + padName
                                    + ":," + compomentName
                                    + ",V:" + volValuePercent
                                    + ",H," + heightValue
                                    + ",A," + areaValue
                                    + ",X," + xOffsetValue
                                    + ",Y," + yOffsetValue;
                                if (pad.res.jugRes == JudgeRes.NG)
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Pass)
                                {
                                    padInspectItemValue += ",NG,PASS,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Good)
                                {
                                    padInspectItemValue += ",PASS,PASS,";
                                    padInspectItemValue += "Good|";
                                }
                                else
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }

                            }

                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
            //------------------
            int arrayGoodCount = 0, arrayNGCount = 0;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
            {
                itemValue = "|1:" + strResult + "1";
            }
            else
            {
                //array
                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int arrayIndex = 1;
                for (int i = 0; i < iArrayQty; i++)
                {
                    if ((i == 0 && bPosZeroISUsed == false)
                            || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                        //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                        )
                    {
                        continue;
                    }
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                   || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                    //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                    {
                        itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                    }
                    else
                    {
                        //string arrayResult = "PASS";
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                            arrayNGCount++;
                            int ngPadDCount = 0;
                            for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                            {
                                int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                {
                                    continue;
                                }
                                string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                ngPadDCount++;
                            }
                        }
                        else
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                            arrayGoodCount++;
                        }


                        InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                        int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                    }
                    arrayIndex++;
                }
                if (arrayIndex > 1)
                {
                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                }
            }
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);
            //--------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            ///-----------------------
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
            ////add by joch 
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            int iNGArrayCount = 0, iArrayCountW = 1;
            if (bISArrayPCB)
            {
                foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                {
                    if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                    {
                        iArrayCountW++;
                        // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                        if (sArrayInfo.shBadMarkMode > 0)
                        {
                            iNGArrayCount++;
                        }
                    }
                }
            }
            htParams.Add("M_Boards_Number", iArrayCountW);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);
            ///-----------------
            string sMethodName = "SMTWeldInput";
            //string sMethodName = "WeldInputTest";

            if (AappSettingData.enPadDebug)
            {
                SaveLogsYouJiaInfo("SMTWeldInput M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Solder =>", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Stencil =>", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Boards_Number =>", iArrayCountW + "");
                SaveLogsYouJiaInfo("SMTWeldInput M_Bad_Boards_Number =>", iNGArrayCount + "");
                //SaveLogsYouJiaInfo("M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            }
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }
        private string SunWoDaWSUploadData_BoluoForMark(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn,
            InspectMainLib.Marks AMarks
            )
        {


            string strMsg = String.Empty;
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }


            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];

            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }
            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                //|| string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }

            String strMarkResult = "PASS"; //string strMarkResult = "OK";
            

            Hashtable htParams = new Hashtable();
            
            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                htParams.Add("M_MACHINENO", strLineName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[单轨]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", strLineName);
                }
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[双轨:ABrdRes.LaneNo=>" + byLaneNo + "]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                }
            }
            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            int iNGArrayCount = 0, iArrayCountW = 1;
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                string strMarkGroupID = string.Empty, strMarkBarcode=string.Empty;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }

                if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])//(APcbGeneralInfo.bEnGlbMarkGroup)
                {
                    if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                    {
                        for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                        {
                            //string strMarkResult = "OK";
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                            {
                                iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                            }
                            strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                            for (int i = 0; i != iArrayCount; ++i)
                            {
                                if (bPosZeroISUsed == false && i == 0)
                                {
                                    continue;
                                }
                                
                                if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                {
                                    iArrayIndex++;
                                    string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                    if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        continue;
                                    }
                                    strMarkBarcode = strTmpMarkCode;
                                    
                                    string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                                    if (string.Equals(strArrayStatus, "Skipped"))
                                    {
                                        continue;
                                    }
                                    if (strArrayStatus == "NG"
                                       )
                                    {
                                        strMarkResult = "NG";
                                    }
                                    int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                                    foreach (int padIndex in arrPadIndex)
                                    {
                                        Pad pad = APads[padIndex];
                                        //modify tony 20181213
                                        //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                        if (_baseFun.bPadIsSkip(pad))
                                        {
                                            continue;
                                        }
                                        string arrayName = iArrayIndex.ToString();
                                        string padName = padIndex.ToString();
                                        string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                        string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);


                                        padInspectItemValue += arrayName + "-" + padName
                                            + ":," + compomentName
                                            + ",V:" + volValuePercent
                                            + ",H," + heightValue
                                            + ",A," + areaValue
                                            + ",X," + xOffsetValue
                                            + ",Y," + yOffsetValue;
                                        if (pad.res.jugRes == JudgeRes.NG)
                                        {
                                            padInspectItemValue += ",NG,NG,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }
                                        else if (pad.res.jugRes == JudgeRes.Pass)
                                        {
                                            padInspectItemValue += ",NG,PASS,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }
                                        else if (pad.res.jugRes == JudgeRes.Good)
                                        {
                                            padInspectItemValue += ",PASS,PASS,";
                                            padInspectItemValue += "Good|";
                                        }
                                        else
                                        {
                                            padInspectItemValue += ",NG,NG,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }

                                    }
                                }
                            }
                            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
                            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
                            //------------------
                            int arrayGoodCount = 0, arrayNGCount = 0;
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                            {
                                itemValue = "|1:" + strMarkResult + "1";
                            }
                            else
                            {
                                //array
                                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                                //bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                                int arrayIndex = 1;
                                for (int i = 0; i < iArrayQty; i++)
                                {
                                    if ((i == 0 && bPosZeroISUsed == false)
                                            || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                        //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                                        )
                                    {
                                        continue;
                                    }
                                    if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                    {
                                        string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                        if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            continue;
                                        }
                                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                                       || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                                        //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                                        {
                                            itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                                        }
                                        else
                                        {
                                            //string arrayResult = "PASS";
                                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                                                arrayNGCount++;
                                                int ngPadDCount = 0;
                                                for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                                                {
                                                    int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                                    if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                                    {
                                                        continue;
                                                    }
                                                    string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                                    itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                                    ngPadDCount++;
                                                }
                                            }
                                            else
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                                                arrayGoodCount++;
                                            }
                                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                                        }
                                        arrayIndex++;
                                    }
                                    
                                }
                                if (arrayIndex > 1)
                                {
                                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                                }
                                ////add 
                                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                                
                                if (bISArrayPCB)
                                {
                                    foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                                    {
                                        if (strMarkGroupID == sArrayInfo.strGlbMarkGroupID)
                                        {
                                            string strTmpMarkCode = sArrayInfo.strGlbMarkGroupBarcode;
                                            if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                            {
                                                continue;
                                            }
                                            if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                                            {
                                                iArrayCountW++;
                                                // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                                                if (sArrayInfo.shBadMarkMode > 0)
                                                {
                                                    iNGArrayCount++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                htParams.Add("M_SN", strMarkBarcode);
                htParams.Add("M_RESULT", strMarkResult);
            }
            catch (Exception)
            {
            }
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);
            //--------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            ///-----------------------
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
            
            
            htParams.Add("M_Boards_Number", iArrayCountW);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);
            ///-----------------
            string sMethodName = "SMTWeldInput";
            //string sMethodName = "WeldInputTest";

            if (AappSettingData.enPadDebug)
            {
                SaveLogsYouJiaInfo("SMTWeldInput M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Solder =>", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Stencil =>", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Boards_Number =>", iArrayCountW + "");
                SaveLogsYouJiaInfo("SMTWeldInput M_Bad_Boards_Number =>", iNGArrayCount + "");
                //SaveLogsYouJiaInfo("M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            }
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }

        public string SunWoDaWSUploadData_BoluoWith10D(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn,
            InspectMainLib.Marks AMarks
            )
        {
            string strMsg = String.Empty;
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }

            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];

            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }
            if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])//(APcbGeneralInfo.bEnGlbMarkGroup)
            {
                strMsg = SunWoDaWSUploadData_BoluoForMarkWith10D(APads, ABrdRes, APcbGeneralInfo, AappSettingData, AconfigData, AstrClntName, out AiWSReturn, AMarks);
                return strMsg;
            }
            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                //|| string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            //carrier barcode  add  20181011
            string strCarrierBarcode = string.Empty;
            foreach (ImgCSCoreIM.StExtenBarcode extBarcode in ABrdRes.lstExtenBarcode)
            {
                if (extBarcode.type == ImgCSCoreIM.ExtenBarcodeType.CarrierBarcode)
                {
                    strCarrierBarcode = extBarcode.strBarcode;
                    break;
                }
            }
            strCarrierBarcode = _baseFun.BarcodeDicision(strCarrierBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
            if(string.IsNullOrEmpty(strCarrierBarcode) || string.Equals(PubStaticParam.RS_NOREAD,strCarrierBarcode,StringComparison.CurrentCultureIgnoreCase))
            {
                return "SunWoDaWSUploadData_Boluo10D=>CarrierBarcode_Is_Null or NoRead!";
            }
            String strResult = "FAIL";
            if (ABrdRes.jugResult == JudgeRes.Good
                || ABrdRes.jugResult == JudgeRes.Pass)
                strResult = "PASS";


            Hashtable htParams = new Hashtable();
            htParams.Add("M_SN", ABrdRes.pcbBarcode);
            htParams.Add("M_RESULT", strResult);
            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                htParams.Add("M_MACHINENO", strLineName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[单轨]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", strLineName);
                }
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[双轨:ABrdRes.LaneNo=>" + byLaneNo + "]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                }
            }
            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }
                if (iArrayCount > 0)
                {

                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        iArrayIndex++;
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                            if (string.Equals(strArrayStatus, "Skipped"))
                            {
                                continue;
                            }
                            int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                            foreach (int padIndex in arrPadIndex)
                            {
                                Pad pad = APads[padIndex];
                                //modify tony 20181213
                                //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                if (_baseFun.bPadIsSkip(pad))
                                {
                                    continue;
                                }
                                string arrayName = iArrayIndex.ToString();
                                string padName = padIndex.ToString();
                                string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);

                                padInspectItemValue += arrayName + "-" + padName
                                    + ":," + compomentName
                                    + ",V:" + volValuePercent
                                    + ",H," + heightValue
                                    + ",A," + areaValue
                                    + ",X," + xOffsetValue
                                    + ",Y," + yOffsetValue;
                                if (pad.res.jugRes == JudgeRes.NG)
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Pass)
                                {
                                    padInspectItemValue += ",NG,PASS,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }
                                else if (pad.res.jugRes == JudgeRes.Good)
                                {
                                    padInspectItemValue += ",PASS,PASS,";
                                    padInspectItemValue += "Good|";
                                }
                                else
                                {
                                    padInspectItemValue += ",NG,NG,";
                                    padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                }

                            }

                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
            //------------------
            int arrayGoodCount = 0, arrayNGCount = 0;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
            {
                itemValue = "|1:" + strResult + "1";
            }
            else
            {
                //array
                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int arrayIndex = 1;
                for (int i = 0; i < iArrayQty; i++)
                {
                    if ((i == 0 && bPosZeroISUsed == false)
                            || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                        //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                        )
                    {
                        continue;
                    }
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                   || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                    //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                    {
                        itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                    }
                    else
                    {
                        //string arrayResult = "PASS";
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                            arrayNGCount++;
                            int ngPadDCount = 0;
                            for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                            {
                                int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                {
                                    continue;
                                }
                                string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                ngPadDCount++;
                            }
                        }
                        else
                        {
                            itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                            arrayGoodCount++;
                        }


                        InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                        int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                    }
                    arrayIndex++;
                }
                if (arrayIndex > 1)
                {
                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                }
            }
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);
            //--------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            ///-----------------------
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
            ////add by joch 
            bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
            int iNGArrayCount = 0, iArrayCountW = 1;
            if (bISArrayPCB)
            {
                foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                {
                    if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                    {
                        iArrayCountW++;
                        // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                        if (sArrayInfo.shBadMarkMode > 0)
                        {
                            iNGArrayCount++;
                        }
                    }
                }
            }
            htParams.Add("M_Boards_Number", iArrayCountW);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);
            htParams.Add("M_FIXTURESN",strCarrierBarcode);
            htParams.Add("M_SN_B", string.Empty);
            ///-----------------
            string sMethodName = "SMTWeldInput_V4";
            //string sMethodName = "WeldInputTest";

            if (AappSettingData.enPadDebug)
            {
                SaveLogsYouJiaInfo("SMTWeldInput M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Solder =>", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Stencil =>", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Boards_Number =>", iArrayCountW + "");
                SaveLogsYouJiaInfo("SMTWeldInput M_Bad_Boards_Number =>", iNGArrayCount + "");
                //SaveLogsYouJiaInfo("M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            }
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }
        private string SunWoDaWSUploadData_BoluoForMarkWith10D(InspectMainLib.Pad[] APads,// record all pads info
            SPCBoardRes ABrdRes, // record the result of board pcb
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, // record pcb info: array , bad mark.
            AppSettingData AappSettingData, // ui setting 
             InspectConfig.ConfigData AconfigData,
            string AstrClntName, out int AiWSReturn,
            InspectMainLib.Marks AMarks
            )
        {
            string strMsg = String.Empty;
            AiWSReturn = 3;
            //Q.F.2017.04.19
            if (ABrdRes.jugResult == JudgeRes.NG
                  && AappSettingData.stDataExpVT.bEnSKIPNGPCB == true)
            {
                AiWSReturn = 1;//Q.F.2017.10.16
                return strMsg;
            }
            //if (ABrdRes.byCurrentLaneIndex == 0)
            //    return strMsg;
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strOrderNo = AappSettingData.stDataExpVT.aStrOrderNo[byLaneNo];

            //Q.F.2019.03.13
            String strLineName = AappSettingData.LineName;
            if (byLaneNo != 0 && AappSettingData.stDataExpVT.stDELaneParams != null)
            {
                strLineName = AappSettingData.stDataExpVT.stDELaneParams[1].LineName;
            }
            if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strWebAddress)
                //|| string.IsNullOrEmpty(ABrdRes.pcbBarcode)
                || string.IsNullOrEmpty(AappSettingData.strDataExpOperator)
                || string.IsNullOrEmpty(strLineName)
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo])
                || string.IsNullOrEmpty(AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo])
                || string.IsNullOrEmpty(strOrderNo))
            {
                //throw new Exception("error:parameter error");
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + "error:parameter error";//Q.F.2017.04.07
                return strMsg;
            }
            //carrier barcode  add  20181011
            string strCarrierBarcode = string.Empty;
            foreach (ImgCSCoreIM.StExtenBarcode extBarcode in ABrdRes.lstExtenBarcode)
            {
                if (extBarcode.type == ImgCSCoreIM.ExtenBarcodeType.CarrierBarcode)
                {
                    strCarrierBarcode = extBarcode.strBarcode;
                    break;
                }
            }
            strCarrierBarcode = _baseFun.BarcodeDicision(strCarrierBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
            if (string.IsNullOrEmpty(strCarrierBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strCarrierBarcode, StringComparison.CurrentCultureIgnoreCase))
            {
                return "SunWoDaWSUploadData_Boluo10D=>CarrierBarcode_Is_Null or NoRead!";
            }
            String strMarkResult = "PASS"; //string strMarkResult = "OK";


            Hashtable htParams = new Hashtable();

            htParams.Add("M_USERNO", AappSettingData.strDataExpOperator);
            //单轨
            if (AconfigData._conv3StageMode == false)
            {
                htParams.Add("M_MACHINENO", strLineName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[单轨]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", strLineName);
                }
            }
            //双轨
            else
            {
                htParams.Add("M_MACHINENO", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("[双轨:ABrdRes.LaneNo=>" + byLaneNo + "]SunWoDaWSUploadData_Boluo start    M_MACHINCENO=>", AappSettingData.stDataExpVT.stDELaneParams[byLaneNo].strUserDefinedLaneName);
                }
            }
            htParams.Add("M_ERROR", "");
            //add by tony 20181016 
            string itemValue = "";
            //modify 20181207 tony
            string padInspectItemValue = "|";
            int iNGArrayCount = 0, iArrayCountW = 1;
            try
            {
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayIndex = 0;
                int iArrayCount = 0;
                string strMarkGroupID = string.Empty, strMarkBarcode = string.Empty;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }

                if (AappSettingData.stDataExpVT.aBEnExportGlobalMarkGroup[byLaneNo])//(APcbGeneralInfo.bEnGlbMarkGroup)
                {
                    if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                    {
                        for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                        {
                            //string strMarkResult = "OK";
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                            {
                                iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                            }
                            strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;
                            for (int i = 0; i != iArrayCount; ++i)
                            {
                                if (bPosZeroISUsed == false && i == 0)
                                {
                                    continue;
                                }

                                if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                {
                                    iArrayIndex++;
                                    string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                    if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        continue;
                                    }
                                    strMarkBarcode = strTmpMarkCode;

                                    string strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                                    if (string.Equals(strArrayStatus, "Skipped"))
                                    {
                                        continue;
                                    }
                                    if (strArrayStatus == "NG"
                                       )
                                    {
                                        strMarkResult = "NG";
                                    }
                                    int[] arrPadIndex = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices;

                                    foreach (int padIndex in arrPadIndex)
                                    {
                                        Pad pad = APads[padIndex];
                                        //modify tony 20181213
                                        //if (_baseFun.bPadIsSkip(pad) || pad.res.jugRes == JudgeRes.Good)
                                        if (_baseFun.bPadIsSkip(pad))
                                        {
                                            continue;
                                        }
                                        string arrayName = iArrayIndex.ToString();
                                        string padName = padIndex.ToString();
                                        string compomentName = string.IsNullOrEmpty(pad.componentID) ? "" : pad.componentID;
                                        string volValuePercent = (pad.res.measuredValue.perVol * 100).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string heightValue = (pad.res.measuredValue.height).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string areaValue = (pad.res.measuredValue.perArea * 100f).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string xOffsetValue = (pad.res.measuredValue.offsetX * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);
                                        string yOffsetValue = (pad.res.measuredValue.offsetY * PubStaticParam.RS_fMM2UM).ToString(PubStaticParam.RS_FLOATFORMAT_3Bit);


                                        padInspectItemValue += arrayName + "-" + padName
                                            + ":," + compomentName
                                            + ",V:" + volValuePercent
                                            + ",H," + heightValue
                                            + ",A," + areaValue
                                            + ",X," + xOffsetValue
                                            + ",Y," + yOffsetValue;
                                        if (pad.res.jugRes == JudgeRes.NG)
                                        {
                                            padInspectItemValue += ",NG,NG,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }
                                        else if (pad.res.jugRes == JudgeRes.Pass)
                                        {
                                            padInspectItemValue += ",NG,PASS,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }
                                        else if (pad.res.jugRes == JudgeRes.Good)
                                        {
                                            padInspectItemValue += ",PASS,PASS,";
                                            padInspectItemValue += "Good|";
                                        }
                                        else
                                        {
                                            padInspectItemValue += ",NG,NG,";
                                            padInspectItemValue += _baseFun.GetPadErrorCodeStr(pad, AappSettingData) + "|";
                                        }

                                    }
                                }
                            }
                            if (padInspectItemValue != null && padInspectItemValue.Length <= 1) padInspectItemValue = "";
                            //htParams.Add("M_ITEMVALUE", padInspectItemValue);
                            //------------------
                            int arrayGoodCount = 0, arrayNGCount = 0;
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                            {
                                itemValue = "|1:" + strMarkResult + "1";
                            }
                            else
                            {
                                //array
                                int iArrayQty = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                                //bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                                int arrayIndex = 1;
                                for (int i = 0; i < iArrayQty; i++)
                                {
                                    if ((i == 0 && bPosZeroISUsed == false)
                                            || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                        //|| APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                                        )
                                    {
                                        continue;
                                    }
                                    if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                    {
                                        string strTmpMarkCode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                        if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            continue;
                                        }
                                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus == -1
                                                       || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode > 0)
                                        //if(APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode>0)
                                        {
                                            itemValue += "|" + arrayIndex + ":BADMARK" + arrayIndex;
                                        }
                                        else
                                        {
                                            //string arrayResult = "PASS";
                                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes == 1)
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":FAIL" + arrayIndex;
                                                arrayNGCount++;
                                                int ngPadDCount = 0;
                                                for (int arrayPadIndexIndex = 0; arrayPadIndexIndex < APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length && ngPadDCount < 10; arrayPadIndexIndex++)
                                                {
                                                    int iPadIndex = APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices[arrayPadIndexIndex];
                                                    if (_baseFun.bPadIsSkip(APads[iPadIndex]) == true || APads[iPadIndex].res.jugRes == JudgeRes.Good || APads[iPadIndex].res.jugRes == JudgeRes.Pass)
                                                    {
                                                        continue;
                                                    }
                                                    string componentName = string.IsNullOrEmpty(APads[iPadIndex].componentID) ? "UNKNOW" : APads[iPadIndex].componentID;
                                                    itemValue += " " + componentName + " " + convertDefectTypeToChinese(APads[iPadIndex].res.jugDefectType);
                                                    ngPadDCount++;
                                                }
                                            }
                                            else
                                            {
                                                itemValue += "|" + arrayIndex.ToString() + ":PASS" + arrayIndex;
                                                arrayGoodCount++;
                                            }
                                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                                        }
                                        arrayIndex++;
                                    }

                                }
                                if (arrayIndex > 1)
                                {
                                    itemValue += "|fail_count:" + arrayNGCount + "|pass_count:" + arrayGoodCount + "|";
                                }
                                ////add 
                                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;

                                if (bISArrayPCB)
                                {
                                    foreach (ImgCSCoreIM.SingleArrayInfo sArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                                    {
                                        if (strMarkGroupID == sArrayInfo.strGlbMarkGroupID)
                                        {
                                            string strTmpMarkCode = sArrayInfo.strGlbMarkGroupBarcode;
                                            if (string.IsNullOrEmpty(strTmpMarkCode) || string.Equals(PubStaticParam.RS_NOREAD, strTmpMarkCode, StringComparison.CurrentCultureIgnoreCase))
                                            {
                                                continue;
                                            }
                                            if (sArrayInfo.bChecked && sArrayInfo.bMESNotExported == false)
                                            {
                                                iArrayCountW++;
                                                // if (sArrayInfo.shArrayStatus == (int)JudgeRes.NG)
                                                if (sArrayInfo.shBadMarkMode > 0)
                                                {
                                                    iNGArrayCount++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                htParams.Add("M_SN", strMarkBarcode);
                htParams.Add("M_RESULT", strMarkResult);
            }
            catch (Exception)
            {
            }
            htParams.Add("M_ITEMVALUE", itemValue + padInspectItemValue);
            //--------------------
            htParams.Add("M_MO", strOrderNo);
            //htParams.Add("M_PCB", "");
            //你们看看怎么加，目前线都用轨1数据
            ///-----------------------
            htParams.Add("M_PCB", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            htParams.Add("M_Solder", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
            htParams.Add("M_Stencil", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);


            htParams.Add("M_Boards_Number", iArrayCountW);
            htParams.Add("M_Bad_Boards_Number", iNGArrayCount);
            ///-----------------
            htParams.Add("M_FIXTURESN",strCarrierBarcode);
            htParams.Add("M_SN_B",string.Empty);
            ///-----------------
            string sMethodName = "SMTWeldInput_V4";
            //string sMethodName = "WeldInputTest";

            if (AappSettingData.enPadDebug)
            {
                SaveLogsYouJiaInfo("SMTWeldInput M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Solder =>", AappSettingData.stDataExpVT.aStrSolderSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Stencil =>", AappSettingData.stDataExpVT.aStrStencilSN[byLaneNo]);
                SaveLogsYouJiaInfo("SMTWeldInput M_Boards_Number =>", iArrayCountW + "");
                SaveLogsYouJiaInfo("SMTWeldInput M_Bad_Boards_Number =>", iNGArrayCount + "");
                //SaveLogsYouJiaInfo("M_PCB =>", AappSettingData.stDataExpVT.aStrPCBSN[byLaneNo]);
            }
            bool saveJSON = true;
            try
            {
                //    return WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,                    sMethodName, htParams);
                //数据返回格式“TRUE|1  FALSE|2/3|?”，返回信息包括两部分（1、当前条码的状态TRUE/FALSE:信息异常；2、预警信息）
                if (AappSettingData.enPadDebug || saveJSON)
                {
                    string strJsonFile = "D:\\EYSPI\\DataExport\\SunWoDa\\" + ABrdRes.pcbBarcode + ".json";
                    Directory.CreateDirectory("D:\\EYSPI\\DataExport\\SunWoDa\\");
                    JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                }
                strMsg = WSClnt.SoapOperator.DoSoapWebService(AappSettingData.stDataExpVT.strWebAddress,
                sMethodName, htParams);
                //strMsg = " FALSE PCB:211192170728020006 剩余数量: 0 请使用指令SMT101续料 |>";
                string[] arrWSReturn = strMsg.Split('|');
                if (arrWSReturn.Length > 1)
                {
                    switch (arrWSReturn[1].Trim().ToUpper())
                    {
                        case "1":
                            AiWSReturn = 1;
                            strMsg = string.Empty;
                            break;
                        case "2":
                            AiWSReturn = 2;
                            break;
                        default:
                            AiWSReturn = 3;
                            break;
                    }
                }
                if (AiWSReturn == 1)
                    strMsg = string.Empty;
            }
            catch (Exception ee)
            {
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ee.Message.ToString();//Q.F.2017.04.07               
                //throw new Exception("error:" + ee.Message);                
            }
            return strMsg;
        }
        #endregion


        //欣旺达 SunWoDa webservice-----end


        //武汉富士康 工业4.0------start
        public void UpdateInspectionWuHanFoxconn(string AsLine, string AsEquipId, string AsRecipeId, string AsBarcode, int AiTtime, int AiWaitingTime, SQLServerDAO sqlDao)
        {
            try
            {
                ST_SPI_EQUIP_INFO info = new ST_SPI_EQUIP_INFO();
                info.tTime = AiTtime.ToString();
                info.waitingTime = AiWaitingTime.ToString();
                info.line = AsLine;
                info.equipId = AsEquipId;
                info.recipeId = AsRecipeId;
                info.barcode = AsBarcode;
                sqlDao.UpdateInfoTable(info);
            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.Message);
                throw new Exception("Update Info Table Error");
            }
        }

        public void InsertInspectionWuHanFoxconn(InspectMainLib.Pad[] APads, SPCBoardRes ABrdRes,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo, AppSettingData AappSettingData, SQLServerDAO sqlDao)
        {
            String sBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

            if (ABrdRes.jugResult != JudgeRes.Skipped)
            {
                ST_FOXCONN_TABLE_INFO StTableInfo = new ST_FOXCONN_TABLE_INFO();
                StTableInfo.info = new ST_SPI_EQUIP_INFO();

                //StTableInfo.info.line = APcbGeneralInfo.line;
                //StTableInfo.info.equipId = APcbGeneralInfo.equipId;
                StTableInfo.info.recipeId = APcbGeneralInfo.strJobVersion;//modify
                StTableInfo.info.barcode = sBoardBarcode;
                StTableInfo.info.startTestTime = ABrdRes.startTime.ToString(WuHanFoxconnDB.RS_DATETIME_FORMAT_CHAR19_SLASH);
                StTableInfo.info.endTextTime = ABrdRes.endTime.ToString(WuHanFoxconnDB.RS_DATETIME_FORMAT_CHAR14);
                //StTableInfo.info.realCycleTime = ABrdRes.realCycleTime;
                //StTableInfo.info.historyQuantity = ABrdRes.historyQuantity;
                //StTableInfo.info.recipeDate = ABrdRes.jobDate.ToString(WuHanFoxconnDB.RS_DATETIME_FORMAT_CHAR19_SLASH);
                //StTableInfo.info.processTime = ABrdRes.processTime;
                //StTableInfo.info.tTime = ABrdRes.tTime;
                string boardResult = ABrdRes.jugResult == JudgeRes.Good ? WuHanFoxconnDB.EM_InspectResult.PASS.ToString() : (ABrdRes.jugResult == JudgeRes.Pass ? WuHanFoxconnDB.EM_InspectResult.RPASS.ToString() : WuHanFoxconnDB.EM_InspectResult.NG.ToString());
                StTableInfo.info.result = boardResult;
                StTableInfo.info.uiStart = "";
                StTableInfo.info.uiClose = "";
                sqlDao.InsertTable(E_FOXCONN_TABLE_NAME.SPI_INSPECTION_INFO, StTableInfo);
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                {
                    FillItemsWuHanFoxconn(ref StTableInfo, "0", APads, ABrdRes);
                }
                else
                {
                    //array
                    int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if ((i == 0 && bPosZeroISUsed == false)
                                || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                        {
                            continue;
                        }

                        InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                        int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);

                        if (iPartPadsLength > 0)
                        {
                            FillItemsWuHanFoxconn(ref StTableInfo, (i).ToString(), APads, ABrdRes);
                        }

                    }
                }
                sqlDao.InsertTable(E_FOXCONN_TABLE_NAME.SPI_INSPECTION_ITEMS, StTableInfo);
            }
        }

        private void FillItemsWuHanFoxconn(ref ImgCSCoreIM.ST_FOXCONN_TABLE_INFO StTableInfo, string AsArrayId, InspectMainLib.Pad[] APads, SPCBoardRes ABrdRes)
        {
            if (APads != null && APads.Length > 0)
            {
                StTableInfo.items = new ST_SPI_EQUIP_ITEMS[APads.Length];
                for (int i = 0; i < APads.Length; i++)
                {
                    if (_baseFun.bPadIsSkip(APads[i]))
                        continue;

                    StTableInfo.items[i].line = StTableInfo.info.line;
                    StTableInfo.items[i].equipId = StTableInfo.info.equipId;
                    StTableInfo.items[i].barcode = StTableInfo.info.barcode;
                    StTableInfo.items[i].padId = APads[i].padID.ToString();
                    StTableInfo.items[i].component = APads[i].componentID;
                    StTableInfo.items[i].arrayId = AsArrayId;
                    StTableInfo.items[i].type = "";//modify
                    StTableInfo.items[i].result = APads[i].res.jugRes == JudgeRes.Good ? WuHanFoxconnDB.EM_InspectResult.PASS.ToString() : (APads[i].res.jugRes == JudgeRes.NG ? WuHanFoxconnDB.EM_InspectResult.NG.ToString() : WuHanFoxconnDB.EM_InspectResult.RPASS.ToString());
                    StTableInfo.items[i].error = APads[i].res.jugDefectType.ToString();
                    StTableInfo.items[i].errorCode = convertDefectTypeToChinese(APads[i].res.jugDefectType);
                    StTableInfo.items[i].modifyDate = ABrdRes.endTime.ToString(WuHanFoxconnDB.RS_DATETIME_FORMAT_CHAR14);

                }
            }

        }

        //武汉富士康 工业4.0------------end

        private void generateFileContentSzZechin(ref StringBuilder strFileContent, string jobName, string strBoardBarcode,
            DateTime startTime, string arrayId, string padImagePath, InspectMainLib.Pad[] APads, int[] AaPadIndices)
        {
            int i = 0, iPadIndex = 0;
            int iLength = APads.Length;
            if (AaPadIndices != null)
            {
                iLength = AaPadIndices.Length;
            }
            InspectMainLib.Pad pad = null;
            for (i = 0; i < iLength; i++)
            {
                if (AaPadIndices == null)
                    iPadIndex = i;
                else
                {
                    iPadIndex = AaPadIndices[i];
                }
                pad = APads[iPadIndex];
                if (_baseFun.bPadIsSkip(pad))
                    continue;

                strFileContent.Append(jobName + RS_SPLIT);
                strFileContent.Append(strBoardBarcode + RS_SPLIT);
                strFileContent.Append(startTime.ToString(SzZechinFormat.RS_DATETIME_FORMAT_CONTENT) + RS_SPLIT);
                bool iGood = false;
                switch (pad.res.jugRes)
                {
                    case JudgeRes.Good:
                        strFileContent.Append(SzZechinFormat.RS_PASS + RS_SPLIT);
                        strFileContent.Append(RS_SPLIT + RS_SPLIT + RS_SPLIT + RS_SPLIT + RS_SPLIT + RS_SPLIT + RS_LineEnd);
                        iGood = true;
                        break;
                    case JudgeRes.NG:
                        strFileContent.Append(SzZechinFormat.RS_FIAL + RS_SPLIT);
                        strFileContent.Append(SzZechinFormat.RS_FIAL + RS_SPLIT);
                        break;
                    case JudgeRes.Pass:
                        strFileContent.Append(SzZechinFormat.RS_FIAL + RS_SPLIT);
                        strFileContent.Append(SzZechinFormat.RS_PASS + RS_SPLIT);
                        break;
                    default:
                        break;
                }
                if (!iGood)
                {
                    strFileContent.Append(pad.strArrayID + RS_SPLIT);//Q.F.2017.04.26
                    strFileContent.Append(pad.padID.ToString() + RS_SPLIT);
                    strFileContent.Append(convertDefectTypeToChinese(pad.res.jugDefectType) + RS_SPLIT);
                    strFileContent.Append(pad.componentID + RS_SPLIT);
                    strFileContent.Append(padImagePath + pad.padID + ".jpg" + RS_LineEnd);
                }
            }
        }

        public string SaveDataExpFileSzZechin(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName, InspectMainLib.Marks AMarks)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //get board barcode
                String strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strBoardBarcode, RS_NOREAD))
                    strBoardBarcode = "";
                //else
                //     strBoardBarcode += RS_UNDERLINE;

                string fileNameBarcode = string.IsNullOrEmpty(strBoardBarcode) ? "" : (strBoardBarcode + RS_UNDERLINE);

                string strMarkGroupID = string.Empty;
                
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                int iArrayCount = 0;

                StringBuilder strFileContent = new StringBuilder();
                string padImagePath = ABrdRes.strDataExportSavePadImagePath;//Q.F.2017.04.09
                String strArrayID = String.Empty;//Q.F.2017.04.25
                //string padImagePath = "c:\\padImagePath\\";
                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    //string boardResult = ABrdRes.jugResult == JudgeRes.Good || ABrdRes.jugResult == JudgeRes.Pass ? SzZechinFormat.RS_PASS : SzZechinFormat.RS_FIAL;
                    string boardResult = ABrdRes.jugResult == JudgeRes.Good ? SzZechinFormat.RS_PASS : SzZechinFormat.RS_FIAL; //modify by tony 17.3.2
                    string strFileName = Path.Combine(AstrDir ,fileNameBarcode + ABrdRes.startTime.ToString(SzZechinFormat.RS_DATETIME_FORMAT_FILENAME) + RS_UNDERLINE + boardResult + SzZechinFormat.RS_CSV_EXT);
                        
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                    string strMarkBarcode = string.Empty;
                    string jobName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                    string startTime = ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName);
                    string strArrayStatus = string.Empty;
                    strFileContent.Append(SzZechinFormat.RS_COLUMN_TITLE + RS_LineEnd);
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array                                             
                        if (APads != null && APads.Length > 0)
                        {
                            strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;//Q.F.2017.04.25
                            generateFileContentSzZechin(ref strFileContent, jobName, strBoardBarcode, ABrdRes.startTime, strArrayID, padImagePath, APads, null);//Q.F.2017.04.26
                        }
                    }
                    else
                    {
                        if (APcbGeneralInfo.bEnGlbMarkGroup)
                        {
                            if (AMarks.arrGlbMarkGroup != null && AMarks.arrGlbMarkGroup.Length > 0)
                            {
                                for (int m = 0; m < AMarks.arrGlbMarkGroup.Length; m++)
                                {
                                    strFileContent.Clear() ;
                                    strFileContent.Append(SzZechinFormat.RS_COLUMN_TITLE + RS_LineEnd);
                                    strMarkGroupID = AMarks.arrGlbMarkGroup[m].strGlbMarkGroupID;

                                    string strMarkResult = "OK";

                                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                                    {
                                        iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                                    }

                                    for (int i = 0; i != iArrayCount; ++i)
                                    {
                                        if (bPosZeroISUsed == false && i == 0)
                                        {
                                            continue;
                                        }
                                        if (strMarkGroupID == APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupID)
                                        {
                                            strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[0].strArrayID;
                                            strMarkBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strGlbMarkGroupBarcode;
                                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes);
                                            if (string.IsNullOrEmpty(strMarkBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strMarkBarcode, StringComparison.CurrentCultureIgnoreCase))
                                            {
                                                strMarkBarcode = startTime + PubStaticParam.RS_UnderLineSplit + strMarkGroupID;
                                            }
                                            //strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                                            //if (string.IsNullOrEmpty(strArrayBarcode) || string.Equals(PubStaticParam.RS_NOREAD, strArrayBarcode, StringComparison.CurrentCultureIgnoreCase))
                                            //{
                                            //    strArrayBarcode = strMarkBarcode;
                                            //}
                                            //strArrayId = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                                            if (strArrayStatus == "NG"
                                                || strArrayStatus == "Skipped")
                                            {
                                                strMarkResult = "NG";
                                            }
                                            generateFileContentSzZechin(ref strFileContent, jobName, strMarkBarcode, ABrdRes.startTime, strArrayID, padImagePath, APads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);


                                        }
                                    }
                                    //fileNameBarcode = string.IsNullOrEmpty(strBoardBarcode) ? "" : (strBoardBarcode + RS_UNDERLINE);
                                    boardResult = strArrayStatus == "NG" ?  SzZechinFormat.RS_FIAL:SzZechinFormat.RS_PASS ;
                                    strFileName = Path.Combine(AstrDir , strMarkBarcode + RS_UNDERLINE + ABrdRes.startTime.ToString(SzZechinFormat.RS_DATETIME_FORMAT_FILENAME) + RS_UNDERLINE + boardResult + SzZechinFormat.RS_CSV_EXT);
                                        
                                    FileStream fsMark = new FileStream(tmpFile, FileMode.Create);
                                    System.IO.StreamWriter streamWrtMark = new StreamWriter(fsMark, Encoding.Default);
                                    streamWrtMark.Write(strFileContent);
                                    streamWrtMark.Close();

                                    if (File.Exists(tmpFile))
                                    {
                                        File.Copy(tmpFile, strFileName, true);
                                        Thread.Sleep(100);
                                        File.Delete(tmpFile);
                                    }
                                }
                            }
                        }
                        //array
                        else
                        {
                            for (int i = 0; i < iArrayCount; i++)
                            {
                                if ((i == 0 && bPosZeroISUsed == false)
                                        || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                        || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1
                                        || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == 4)
                                {
                                    continue;
                                }

                                InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                                //  int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);

                                if (APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices != null
                                    && APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length > 0)
                                {
                                    strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;//Q.F.2017.4//Q.F.2017.04.25
                                    generateFileContentSzZechin(ref strFileContent, jobName, strBoardBarcode, ABrdRes.startTime, strArrayID, padImagePath, APads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);//Q.F.2017.04.26
                                }
                            }
                        }
                    }
                    if (APcbGeneralInfo.bEnGlbMarkGroup == false )
                    {
                        FileStream fs = new FileStream(tmpFile, FileMode.Create);
                        System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                        streamWrt.Write(strFileContent);
                        streamWrt.Close();

                        if (File.Exists(tmpFile))
                        {
                            File.Copy(tmpFile, strFileName, true);
                            Thread.Sleep(100);
                            File.Delete(tmpFile);
                        }
                    }
                }

            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        public string SaveDataExpFileLonghuaFoxconn(InspectMainLib.Pad[] APads,
        SPCBoardRes ABrdRes,
        ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
        AppSettingData AappSettingData,
        string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //get board barcode
                String strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strBoardBarcode, RS_NOREAD))
                    strBoardBarcode = "Barcode0";

                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    //modify by Tony 17.4.25
                    //if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    //{

                    //no array
                    //string strFileName = AstrDir + strBoardBarcode + LonghuaFoxconnFormat.RS_3DX_EXT;
                    string inspEndTime = ABrdRes.endTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                    string strFileName = AstrDir + inspEndTime + AappSettingData.LineName + LonghuaFoxconnFormat.RS_3DX_EXT;
                    strMsg += GeneralDataExpFileForLonghuaFoxconn(APads, ABrdRes, strBoardBarcode, AappSettingData.LineName, AappSettingData.strDataExpOperator, AstrClntName, strFileName);
                    //}
                    //modify by Tony 17.4.25                         
                    //else
                    //{
                    //    List<InspectMainLib.Pad> UsefulPadList = new List<Pad>();
                    //    //array
                    //    int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    //    bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                    //    for (int i = 0; i < iArrayCount; i++)
                    //    {
                    //        if ((i == 0 && bPosZeroISUsed == false)
                    //                || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                    //                || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                    //        {
                    //            continue;
                    //        }
                    //        //Q.F.2017.04.25 no array barcode in long hua foxconn
                    //        //string sArrayBarcode = strBoardBarcode;// APcbGeneralInfo.PanelResults[0].arrStrBrcd[i];
                    //        //if (string.IsNullOrEmpty(sArrayBarcode)) sArrayBarcode = strBoardBarcode + RS_UNDERLINE + i.ToString();
                    //        //copy PadsRes to tompPads 
                    //        InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                    //        int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                    //        for (int j = 0; j < iPartPadsLength; j++) 
                    //        {
                    //           UsefulPadList.Add( arrPartPads[j]);
                    //        }

                    //        //if (iPartPadsLength > 0)
                    //        //{
                    //        //    //string strFileName = AstrDir + sArrayBarcode + LonghuaFoxconnFormat.RS_3DX_EXT;
                    //        //    string inspEndTime = ABrdRes.endTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                    //        //    string strFileName = AstrDir + inspEndTime + AappSettingData.LineName + LonghuaFoxconnFormat.RS_3DX_EXT;
                    //        //    strMsg += GeneralDataExpFileForLonghuaFoxconn(arrPartPads, ABrdRes, sArrayBarcode, AappSettingData.LineName, AappSettingData.strDataExpOperator, AstrClntName, strFileName);
                    //        //}

                    //    }
                    //    //InspectMainLib.Pad[] allUsefulPad = new InspectMainLib.Pad[UsefulPadList.Count];
                    //    //if (UsefulPadList.Count > 0) 
                    //    //{                            
                    //    //    for (int i=0;i<allUsefulPad.Length;i++)
                    //    //    {
                    //    //        allUsefulPad[i] = UsefulPadList[i];
                    //    //    }
                    //    //}
                    //    //string inspEndTime = ABrdRes.endTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                    //    //string strFileName = AstrDir + inspEndTime + AappSettingData.LineName + LonghuaFoxconnFormat.RS_3DX_EXT;
                    //    //strMsg += GeneralDataExpFileForLonghuaFoxconn(allUsefulPad, ABrdRes, strBoardBarcode, AappSettingData.LineName, AappSettingData.strDataExpOperator, AstrClntName, strFileName);

                    //}
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        private string GeneralDataExpFileForLonghuaFoxconn(InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            string AsBarcode,
            string AsLineName,
            string AsUserName,//Q.F.2017.04.21
            string AstrClntName,
            string strFileName)
        {
            string sReturn = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                LonghuaFoxconnFormat lhFoxcFormat = new LonghuaFoxconnFormat();
                lhFoxcFormat.sInspectStartTime = ABrdRes.startTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                lhFoxcFormat.sInspectEndTime = ABrdRes.endTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                //lhFoxcFormat.sInspectEndTimeFirst = ABrdRes.endTime.ToString(LonghuaFoxconnFormat.RS_DATETIME_FORMAT_FIRST);
                lhFoxcFormat.sBarcode = AsBarcode;
                lhFoxcFormat.sLineName = AsLineName.Trim();
                lhFoxcFormat.sUserName = AsUserName; //Q.F.2017.04.21
                lhFoxcFormat.sRecipeName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                lhFoxcFormat.emInspectRes = LonghuaFoxconnFormat.EM_InspectResult.PASS;

                int alarmPadCounts = 0;
                int ngPadCounts = 0;

                if (APads != null && APads.Length > 0)
                {
                    lhFoxcFormat.padInfo = new LonghuaFoxconnFormat.ST_PadInfo[APads.Length];
                    for (int i = 0; i < APads.Length; i++)
                    {
                        if (_baseFun.bPadIsSkip(APads[i]))
                            continue;
                        if (APads[i].res.jugRes == JudgeRes.Good)
                            continue;

                        lhFoxcFormat.padInfo[i].sPadErrorFlag = "";
                        if (APads[i].res.jugRes == JudgeRes.Pass)
                        {
                            alarmPadCounts++;
                            lhFoxcFormat.padInfo[i].sPadErrorFlag = "Pass";

                        }
                        else if (APads[i].res.jugRes == JudgeRes.NG)
                        {
                            ngPadCounts++;
                            alarmPadCounts++;
                            lhFoxcFormat.padInfo[i].sPadErrorFlag = "NG";
                            lhFoxcFormat.emInspectRes = LonghuaFoxconnFormat.EM_InspectResult.FAIL;
                        }

                        lhFoxcFormat.padInfo[i].sRecipeName = lhFoxcFormat.sRecipeName;
                        string componentId = string.IsNullOrEmpty(APads[i].componentID) ? APads[i].padID.ToString() : APads[i].componentID;
                        if (string.IsNullOrEmpty(componentId)) componentId = RS_NA;
                        lhFoxcFormat.padInfo[i].sPadComponentName = componentId;
                        lhFoxcFormat.padInfo[i].sPasteId = RS_NA;
                        lhFoxcFormat.padInfo[i].sPadErrorCode = ((int)APads[i].res.jugRes).ToString();
                        lhFoxcFormat.padInfo[i].sPadArrayIndex = APads[i].strArrayID;


                    }
                }
                lhFoxcFormat.iAlarmPadCounts = alarmPadCounts;
                lhFoxcFormat.iNgPadCounts = ngPadCounts;
                //create stringbuffer
                StringBuilder strFileContent = new StringBuilder();
                //strFileContent.Append(lhFoxcFormat.sInspectEndTimeFirst + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sBarcode + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sLineName + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sUserName + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sRecipeName + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.emInspectRes.ToString() + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sInspectStartTime + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.sInspectEndTime + RS_LineEnd);
                strFileContent.Append(RS_NA + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.iAlarmPadCounts + RS_LineEnd);
                strFileContent.Append(lhFoxcFormat.iNgPadCounts + RS_LineEnd);
                strFileContent.Append(LonghuaFoxconnFormat.sPadInfoHeaderLine + RS_LineEnd);
                for (int i = 0; i < lhFoxcFormat.padInfo.Length; i++)
                {
                    LonghuaFoxconnFormat.ST_PadInfo padInfo = lhFoxcFormat.padInfo[i];
                    if (string.IsNullOrEmpty(padInfo.sPadErrorFlag))
                        continue;
                    strFileContent.Append(padInfo.sPadErrorFlag + LonghuaFoxconnFormat.RS_COLON
                        + padInfo.sRecipeName + LonghuaFoxconnFormat.RS_COLON
                        + padInfo.sPasteId + LonghuaFoxconnFormat.RS_COLON
                        + padInfo.sPadComponentName + LonghuaFoxconnFormat.RS_COLON
                        + padInfo.sPadErrorCode + LonghuaFoxconnFormat.RS_COLON
                        + padInfo.sPadArrayIndex + RS_LineEnd);
                }
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strFileContent);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                sReturn = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return sReturn;
        }



        public string SaveDataExpFileWuHanFoxconn(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            try
            {
                //get board barcode
                String strBoardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strBoardBarcode, RS_NOREAD))
                    strBoardBarcode = "Barcode0";

                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //no array
                        string strFileName = AstrDir + strBoardBarcode + WuhanFoxconnFormat.RS_3DX_EXT;
                        strMsg += GeneralDataExpFileForWuhanFoxconn(APads, ABrdRes, strBoardBarcode, AappSettingData.LineName, AstrClntName, strFileName);
                        //strMsg += GeneralDataExpFileForWuhanFoxconnFltPadRes(APads, ABrdRes, ref AappSettingData.stDataExpVT ,strBoardBarcode, AappSettingData.LineName, AstrClntName, strFileName);
                    }
                    else
                    {
                        //array
                        int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }
                            string sArrayBarcode = APcbGeneralInfo.PanelResults[0].arrStrBrcd[i];
                            if (string.IsNullOrEmpty(sArrayBarcode)) sArrayBarcode = strBoardBarcode + RS_UNDERLINE + i.ToString();
                            //copy PadsRes to tompPads 
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);

                            if (iPartPadsLength > 0)
                            {
                                string strFileName = AstrDir + sArrayBarcode + WuhanFoxconnFormat.RS_3DX_EXT;
                                strMsg += GeneralDataExpFileForWuhanFoxconn(arrPartPads, ABrdRes, sArrayBarcode, AappSettingData.LineName, AstrClntName, strFileName);
                                // strMsg += GeneralDataExpFileForWuhanFoxconnFltPadRes(arrPartPads,ref ABrdRes,AappSettingData.stDataExpVT, sArrayBarcode, AappSettingData.LineName, AstrClntName, strFileName);
                            }

                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        private string GeneralDataExpFileForWuhanFoxconn(InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            string AsBarcode,
            string AsLineName,
            string AstrClntName,
            string strFileName)
        {
            string sReturn = RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                WuhanFoxconnFormat whFoxcFormat = new WuhanFoxconnFormat();
                whFoxcFormat.sInspectStartTime = ABrdRes.startTime.ToString(WuhanFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                whFoxcFormat.sInspectEndTime = ABrdRes.endTime.ToString(WuhanFoxconnFormat.RS_DATETIME_FORMAT_NORMAL);
                whFoxcFormat.sInspectEndTimeFirst = ABrdRes.endTime.ToString(WuhanFoxconnFormat.RS_DATETIME_FORMAT_FIRST);
                whFoxcFormat.sBarcode = AsBarcode;
                whFoxcFormat.sLineName = AsLineName.Trim();
                whFoxcFormat.sRecipeName = DataExportTony.GetJobNameWithoutDirAndExt(ABrdRes.jobName);
                whFoxcFormat.emInspectRes = WuhanFoxconnFormat.EM_InspectResult.PASS;

                int alarmPadCounts = 0;
                int ngPadCounts = 0;

                if (APads != null && APads.Length > 0)
                {
                    whFoxcFormat.padInfo = new WuhanFoxconnFormat.ST_PadInfo[APads.Length];
                    for (int i = 0; i < APads.Length; i++)
                    {
                        if (_baseFun.bPadIsSkip(APads[i]))
                            continue;
                        if (APads[i].res.jugRes == JudgeRes.Good)
                            continue;

                        whFoxcFormat.padInfo[i].sPadErrorFlag = "";
                        if (APads[i].res.jugRes == JudgeRes.Pass)
                        {
                            alarmPadCounts++;
                            whFoxcFormat.padInfo[i].sPadErrorFlag = Enum.GetName(typeof(WuhanFoxconnFormat.EM_PadInspectResult), WuhanFoxconnFormat.EM_PadInspectResult.Pass); ;

                        }
                        else if (APads[i].res.jugRes == JudgeRes.NG)
                        {
                            ngPadCounts++;
                            alarmPadCounts++;
                            whFoxcFormat.padInfo[i].sPadErrorFlag = Enum.GetName(typeof(WuhanFoxconnFormat.EM_PadInspectResult), WuhanFoxconnFormat.EM_PadInspectResult.BAD);//"NG";
                            whFoxcFormat.emInspectRes = WuhanFoxconnFormat.EM_InspectResult.FAIL;
                        }

                        whFoxcFormat.padInfo[i].sRecipeName = whFoxcFormat.sRecipeName;
                        string componentId = string.IsNullOrEmpty(APads[i].componentID) ? APads[i].padID.ToString() : APads[i].componentID;
                        if (string.IsNullOrEmpty(componentId)) componentId = RS_NA;
                        whFoxcFormat.padInfo[i].sPadComponentName = componentId;
                        whFoxcFormat.padInfo[i].sPasteId = RS_NA;
                        whFoxcFormat.padInfo[i].sPadErrorCode = ((int)APads[i].res.jugRes).ToString();
                        whFoxcFormat.padInfo[i].sPadArrayIndex = APads[i].strArrayID;


                    }
                }
                whFoxcFormat.iAlarmPadCounts = alarmPadCounts;
                whFoxcFormat.iNgPadCounts = ngPadCounts;
                //create stringbuffer
                StringBuilder strFileContent = new StringBuilder();
                //modify by Tony 2018.03.20  QinZhi
                //strFileContent.Append(whFoxcFormat.sInspectEndTimeFirst + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sBarcode + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sLineName + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sUserName + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sRecipeName + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.emInspectRes.ToString() + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sInspectStartTime + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.sInspectEndTime + RS_LineEnd);
                strFileContent.Append(RS_NA + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.iAlarmPadCounts + RS_LineEnd);
                strFileContent.Append(whFoxcFormat.iNgPadCounts + RS_LineEnd);
                strFileContent.Append(WuhanFoxconnFormat.sPadInfoHeaderLine + RS_LineEnd);
                for (int i = 0; i < whFoxcFormat.padInfo.Length; i++)
                {
                    WuhanFoxconnFormat.ST_PadInfo padInfo = whFoxcFormat.padInfo[i];
                    if (string.IsNullOrEmpty(padInfo.sPadErrorFlag))
                        continue;
                    strFileContent.Append(padInfo.sPadErrorFlag + WuhanFoxconnFormat.RS_COLON
                        + padInfo.sRecipeName + WuhanFoxconnFormat.RS_COLON
                        + padInfo.sPasteId + WuhanFoxconnFormat.RS_COLON
                        + padInfo.sPadComponentName + WuhanFoxconnFormat.RS_COLON
                        + padInfo.sPadErrorCode + WuhanFoxconnFormat.RS_COLON
                        + padInfo.sPadArrayIndex + RS_LineEnd);
                }
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strFileContent);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                sReturn = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return sReturn;
        }


        public string SaveDataExpFileHanShine(InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir, string AstrClntName)
        {
            string strMsg = RS_EMPTY;
            StringBuilder strFileContent = new StringBuilder();

            try
            {
                //delete old tmp file
                string tmpFile = _strTmpFileDir + "\\" + RS_DATAEXPORTTEMPFILE;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }

                //get board barcode
                String strboardBarcode = _baseFun.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                if (String.Equals(strboardBarcode, RS_NOREAD))
                    strboardBarcode = "Barcode0";

                DateTime dtNowDate = System.DateTime.Now;
                string strFileName = AstrDir + dtNowDate.ToString(RS_DATE_MMDDYYYY_FORMAT) +
                               RS_UNDERLINE + dtNowDate.ToString(RS_TIME_HHMMSS_FORMAT) + RS_UNDERLINE + strboardBarcode + RS_TXT_EXT;
                if (ABrdRes.jugResult != JudgeRes.Skipped)
                {
                    strFileContent.Append(AegisTextFileFormat.RS_PanelBarcode + strboardBarcode + RS_LineEnd);
                    strFileContent.Append(AegisTextFileFormat.RS_TestProgram + RS_TEST_PROGRAM + RS_LineEnd);
                    strFileContent.Append(AegisTextFileFormat.RS_TestProgramVer + RS_TEST_PROGRAM_VERSION + RS_LineEnd);
                    string strOperator = string.IsNullOrEmpty(ABrdRes.operatorName) ? RS_DEFAULT_SPI_OPERATOR : ABrdRes.operatorName;
                    strFileContent.Append(AegisTextFileFormat.RS_Operator + strOperator + RS_LineEnd);
                    strFileContent.Append(AegisTextFileFormat.RS_Date + ABrdRes.startTime.ToString(AegisTextFileFormat.RS_DATE_FORMAT) + RS_LineEnd);
                    strFileContent.Append(AegisTextFileFormat.RS_Time + ABrdRes.startTime.ToString(AegisTextFileFormat.RS_TIME_FORMAT) + RS_LineEnd);


                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false)
                    {
                        //NO ARRAY PCB
                        strFileContent.Append(RS_LineEnd);
                        if (APads != null && APads.Length > 0)
                        {
                            for (int i = 0; i < APads.Length; i++)
                            {
                                InspectMainLib.Pad pad = APads[i];
                                if (_baseFun.bPadIsSkip(pad))
                                    continue;
                                AppandPadTestInfoHanShine(pad, ref strFileContent);
                            }
                        }
                    }
                    else
                    {

                        //ARRAY PCB
                        int iBoardCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                        for (int i = 0; i < iBoardCount; i++)
                        {
                            if ((i == 0 && bPosZeroISUsed == false)
                                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked == false
                                    || APcbGeneralInfo.PanelResults[0].arrDataLst[i].shArrayStatus == -1)
                            {
                                continue;
                            }
                            string sImageBarcode = APcbGeneralInfo.PanelResults[0].arrStrBrcd[i];
                            if (string.IsNullOrEmpty(sImageBarcode)) sImageBarcode = "";
                            strFileContent.Append(RS_LineEnd);
                            strFileContent.Append("ImageBarcode:" + sImageBarcode + RS_LineEnd);
                            //copy PadsRes to tompPads 
                            InspectMainLib.Pad[] arrPartPads = new InspectMainLib.Pad[APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices.Length];
                            int iPartPadsLength = CreateArrayPads(APads, ref arrPartPads, APcbGeneralInfo.PanelResults[0].arrDataLst[i].arrIPadIndices);
                            if (iPartPadsLength > 0)
                            {
                                for (int j = 0; j < iPartPadsLength; j++)
                                {
                                    InspectMainLib.Pad pad = arrPartPads[j];
                                    if (_baseFun.bPadIsSkip(pad))
                                        continue;
                                    AppandPadTestInfoHanShine(pad, ref strFileContent);
                                }
                            }

                        }
                    }
                }
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strFileContent);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    Thread.Sleep(100);
                    File.Delete(tmpFile);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                strMsg = RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        private void AppandPadTestInfoHanShine(InspectMainLib.Pad Apad, ref StringBuilder AstrFileContent)
        {
            if (Apad.check)
            {
                //height    
                if (Apad.checkHeight)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_HEIGHT + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 0);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Value + Apad.res.measuredValue.height.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Units + "mm" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Nominal + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_LowerLimit + Apad.spec.heightL.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_UpperLimit + Apad.spec.heightH.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
                if (Apad.checkArea)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_AREA + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 1);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Value + Apad.res.measuredValue.area.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Units + "mm" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Nominal + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_LowerLimit + Apad.spec.areaPerL.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_UpperLimit + Apad.spec.areaPerH.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
                if (Apad.checkVol)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_VOLUME + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 2);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Value + Apad.res.measuredValue.vol.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Units + "mm" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Nominal + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_LowerLimit + Apad.spec.volPerL.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_UpperLimit + Apad.spec.volPerH.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
                if (Apad.checkOffset)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_OFFSET_X + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 3);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Value + Apad.res.measuredValue.offsetX.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Units + "mm" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Nominal + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_LowerLimit + "0.0000" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_UpperLimit + Apad.spec.shiftXH.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);

                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_OFFSET_Y + RS_LineEnd);
                    result = GetdDefectResult(Apad, 4);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Value + Apad.res.measuredValue.offsetY.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Units + "mm" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Nominal + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_LowerLimit + "0.0000" + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_UpperLimit + Apad.spec.shiftYH.ToString(RS_FLOATFORMAT_4Bit) + RS_LineEnd);
                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
                if (Apad.checkShape)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_SHAPE + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 5);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);

                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
                if (Apad.checkBridge)
                {
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestName + Apad.padID + RS_LineEnd);
                    AstrFileContent.Append(AegisTextFileFormat.RS_TestType + RS_TEST_TYPE_BRIDGE + RS_LineEnd);
                    string result = GetdDefectResult(Apad, 6);
                    AstrFileContent.Append(AegisTextFileFormat.RS_Result + result + RS_LineEnd);

                    if (result.Equals(AegisTextFileFormat.RS_DETECT_FAIL))
                    {
                        AstrFileContent.Append(AegisTextFileFormat.RS_FailDesc + Apad.res.jugDefectType.ToString() + RS_LineEnd);
                    }
                    AstrFileContent.Append(AegisTextFileFormat.RS_AEGIS_SEPARATE + RS_LineEnd);
                }
            }

            return;


        }

        private string GetdDefectResult(InspectMainLib.Pad pad, int detectType)
        {
            string strRtn = "PASSED";
            switch (detectType)
            {
                case 0://height
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.LowHeight || pad.res.jugDefectType == InspectMainLib.DefectType.OverHeight)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 1://area
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.LowArea || pad.res.jugDefectType == InspectMainLib.DefectType.OverArea
                        || pad.res.jugDefectType == InspectMainLib.DefectType.PadAreaError)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 2://volume
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.Missing || pad.res.jugDefectType == InspectMainLib.DefectType.Insufficient
                        || pad.res.jugDefectType == InspectMainLib.DefectType.Excess)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 3://Offset x
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.ShiftX)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 4://Offset y
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.ShiftY)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 5://shape
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.ShapeError)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                case 6://Bridge
                    if (pad.res.jugDefectType == InspectMainLib.DefectType.Bridge || pad.res.jugDefectType == InspectMainLib.DefectType.PreBridge)
                    {
                        strRtn = AegisTextFileFormat.RS_DETECT_FAIL;
                    }
                    break;
                default:
                    break;
            }
            return strRtn;
        }

        /// <summary>
        /// copy main pads array  partiton to temporary pads array and return;
        /// </summary>
        /// <param name="AMainPads"></param>
        /// <param name="AarrPartPads"></param>
        /// <param name="AarrPadsIndex"></param>
        /// <returns>partition array length</returns>
        private int CreateArrayPads(InspectMainLib.Pad[] AMainPads, ref InspectMainLib.Pad[] AarrPartPads, int[] AarrPadsIndex)
        {
            int iPadsCount = AarrPadsIndex.Length;
            int iSkipPadsCount = 0;
            for (int i = 0; i < iPadsCount; i++)
            {
                int iPadIndex = AarrPadsIndex[i];
                if (_baseFun.bPadIsSkip(AMainPads[iPadIndex]) == true)
                {
                    iSkipPadsCount++;
                    continue;
                }
                AarrPartPads[i - iSkipPadsCount] = AMainPads[iPadIndex];
            }

            return iPadsCount - iSkipPadsCount;
        }

        public static string GetJobNameWithoutDirAndExt(string AsJobName)
        {
            string jobName = AsJobName;
            if (jobName.IndexOf("\\") >= 0)
            {
                jobName = jobName.Substring(jobName.LastIndexOf("\\") + 1);
            }
            if (jobName.IndexOf(".") >= 0)
            {
                jobName = jobName.Substring(0, jobName.IndexOf("."));
            }
            return jobName;

        }

        public string convertDefectTypeToChinese(DefectType dt)
        {
            switch (dt)
            {
                case DefectType.Missing:
                    return "无锡";
                case DefectType.Insufficient:
                    return "少锡";
                case DefectType.Excess:
                    return "锡多";
                case DefectType.OverHeight:
                    return "高度偏高";
                case DefectType.LowHeight:
                    return "高度偏底";
                case DefectType.OverArea:
                    return "面积偏多";
                case DefectType.LowArea:
                    return "面积偏少";
                case DefectType.ShiftX:
                    return "X偏移";
                case DefectType.ShiftY:
                    return "Y偏移";
                case DefectType.Bridge:
                    return "短路";
                case DefectType.ShapeError:
                    return "锡型不良";
                case DefectType.Smeared:
                    return "污点";
                case DefectType.Coplanarity:
                    return "共面";
                case DefectType.PreBridge:
                    return "短路";
                case DefectType.PadAreaError:
                    return "焊盘面积错误";//Q.F.2017.08.29
                default:
                    return "";
            }
        }
    }
}

