﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using ImgCSCoreIM;
using System.Reflection;

namespace WSClnt
{
    public partial class Basefunction
    {
        public static string GetMachineID()
        {
           
                string sPath, Str;
                sPath = Path.GetTempFileName();
                Str = string.Format("FOR /F \"tokens=3\" %I IN ('CSCRIPT %WINDIR%\\SYSTEM32\\SLMGR.VBS /DTI') DO ECHO %I > {0}", sPath);
                Process p = new Process();
                p.StartInfo.FileName = "CMD.exe";
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                p.StandardInput.WriteLine(Str);
                p.StandardInput.WriteLine("Exit");
                p.StandardInput.AutoFlush = true;
                p.WaitForExit();
                p.Close();
                Str = File.ReadAllText(sPath).TrimEnd().Replace("\r\n", "");
                File.Delete(sPath);
                return Str;

            
        }
        /// <summary>
        /// 判断某项功能是否可用
        /// </summary>
        /// <param name="AstrConfigPath">配置文件路径</param>
        /// <param name="AstrFuncName">功能名</param>
        /// <returns></returns>
        public static bool CheckFunctionEnable(string AstrConfigPath, string AstrFuncName)
        {
            bool result = false;
            if (!File.Exists(AstrConfigPath))
            {
                //Q.F.2018.12.26
                if (String.Equals(AstrFuncName, ImgCSCoreIM.EM_ExtFunctonEnableControl.JobEditorWithoutGerber.ToString())
                    || String.Equals(AstrFuncName, ImgCSCoreIM.EM_ExtFunctonEnableControl.ExtBarcode.ToString()))
                {
                    return true;
                }
                return result;
            }
            StreamReader sr = new StreamReader(AstrConfigPath);
            string strContent = sr.ReadToEnd();
            sr.Close();
            strContent = Security.RijndaelDecrypt(strContent);
            ConfigModel model = XMLSerialize.DESerializer<ConfigModel>(strContent);
            DateTime dtEdit = Convert.ToDateTime(model.LastEditTime);
            if (model.IsAllMachine)
            {
                double iHoursLeft = model.ValidHours_All * 60 - Convert.ToDouble(DateTime.Now.Subtract(dtEdit).Minutes);
                if (iHoursLeft > 0)
                {
                    return true;
                }
            }
            string machineID = Basefunction.GetMachineID();
            if (!model.MachineID.Equals(machineID))
                return false;
            foreach (FuncConfig func in model.FuncConfigs)
            {
                if (func.FuncName.Equals(AstrFuncName, StringComparison.OrdinalIgnoreCase))
                {
                    if (func.Enabled == false)
                    {
                        return false;
                    }

                    if (func.NeverExpire)
                        return true;

                    int iDaysLeft = func.ValidDays - DateTime.Now.Subtract(dtEdit).Days;
                    if (iDaysLeft > 0)
                    {
                        return true;
                    }
                }
            }

            return result;

        }


        public static List<FuncConfig> CheckFunctionEnable(string AstrConfigPath)
        {
           
            List<FuncConfig> lstResult = new List<FuncConfig>();
            if (!File.Exists(AstrConfigPath))
                return lstResult;
            foreach (EM_ExtFunctonEnableControl func in Enum.GetValues(typeof(EM_ExtFunctonEnableControl)))
            {
                FuncConfig fc = new FuncConfig();
                fc.FuncName = func.ToString();
                fc.Enabled = false;
                fc.NeverExpire = false;
                lstResult.Add(fc);

            }

            StreamReader sr = new StreamReader(AstrConfigPath);
            string strContent = sr.ReadToEnd();
            sr.Close();
            strContent = Security.RijndaelDecrypt(strContent);
            ConfigModel model = XMLSerialize.DESerializer<ConfigModel>(strContent);
            DateTime dtEdit = Convert.ToDateTime(model.LastEditTime);
            if (model.IsAllMachine)
            {
                double iHoursLeft = model.ValidHours_All * 60 - Convert.ToDouble(DateTime.Now.Subtract(dtEdit).Minutes);
                if (iHoursLeft > 0)
                {
                    foreach (FuncConfig fc in lstResult)
                    {
                        fc.Enabled = true;
                    }
                    return lstResult;
                }
            }
            string machineID = Basefunction.GetMachineID();
            if (!model.MachineID.Equals(machineID))
                return lstResult;
            foreach (FuncConfig item in lstResult)
            {
                List<FuncConfig> selConfigs = model.FuncConfigs.Where(fc => fc.FuncName.Equals(item.FuncName, StringComparison.OrdinalIgnoreCase)).ToList<FuncConfig>();
                if (selConfigs.Count <= 0)
                    continue;
                if (selConfigs[0].Enabled == false)
                    continue;
                if (selConfigs[0].NeverExpire)
                {
                    item.Enabled = true;
                    continue;
                }

                int iDaysLeft = selConfigs[0].ValidDays - DateTime.Now.Subtract(dtEdit).Days;
                if (iDaysLeft > 0)
                {
                    item.Enabled = true;
                    continue;
                }
            }

            return lstResult;

        }

        /// <summary>
        /// 读取某个命名空间底下的所有枚举
        /// </summary>
        /// <param name="AstrNameSpace"></param>
        /// <returns></returns>
        public List<Type> GetEnumListByNamespace(string AstrNameSpace)
        {
            
            List<Type> lstEnum = new List<Type>();
            try
            {
                var arrClass = Assembly.Load(AstrNameSpace).GetTypes();
                foreach (var cls in arrClass)
                {
                    if (cls.IsEnum)
                    {
                        lstEnum.Add(cls);
                    }
                }

            }
            catch (Exception ex)
            {
                 
            }
            return lstEnum;
 
        }
        /// <summary>
        /// 读取某个命名空间下某个枚举的所有字段名称和值
        /// </summary>
        /// <param name="AstrNameSpace">命名空间</param>
        /// <param name="AstrEnumName">枚举名称</param>
        /// <returns></returns>
        public Dictionary<string, int> GetEnumFieldsByName(string AstrNameSpace, string AstrEnumName)
        {
            Dictionary<string, int> dicFields = new Dictionary<string, int>();
            try
            {

                List<Type> lstEnum = GetEnumListByNamespace(AstrNameSpace);
                if (lstEnum.Count <=0)
                    return dicFields;
                 
                var eum = lstEnum.Find(x => x.Name == AstrEnumName);
                Array arrValues = Enum.GetValues(eum);
                foreach (int value in arrValues)
                {
                    string strName = Enum.GetName(eum, value);
                    dicFields.Add(strName, value);
                }//可以拿到具体某个enum底下的所有字段信息
                
            }
            catch (Exception ex)
            {

            }

            return dicFields;

        }
    }
}
