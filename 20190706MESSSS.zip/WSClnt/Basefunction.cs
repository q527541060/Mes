﻿using AppLayerLib;
using InspectMainLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Text; 
using System.Threading;
using System.Windows.Forms;
using System.Data;
using ImgCSCoreIM;
using System.Drawing;
using System.Drawing.Imaging;
namespace WSClnt
{  
    //do some processing for data export
    // bPadIsSkip must be written by to Q.F
    public partial class Basefunction
    {
        private const string RS_Brcd_NoBarcode = "NOREAD";
        private readonly string RS_PAINTPAD_GROUPNAME = "@PEN";
        private int _iProcessorCount = Environment.ProcessorCount;
        private readonly string RS_LineEnd = "\r\n";
        private readonly string RS_SPLIT = ",";
        private const string RS_AUTOAPP_APPSETTING = @"D:\EYSPI\Bin\AutoAPPConfig";
        private readonly string RS_FLOATFORMAT_1Bit = "0.0";
        private readonly string RS_FLOATFORMAT_3Bit = "0.000";
        private readonly string RS_FLOATFORMAT_4Bit = "0.0000";
        private readonly string RS_FLOATFORMAT_6Bit = "0.000000";
        private readonly string RS_TXT_EXT = ".txt";
        private readonly string RS_CSV_EXT = ".csv";

        private const int C_INT_NPM_BADMARK_NGCODE = 134217728;
       
        ImageProcessingCS.Basefunction _imgBaseFunction = new ImageProcessingCS.Basefunction();

        public int CINT_NPM_BADMARK_NGCODE { get { return C_INT_NPM_BADMARK_NGCODE; }  }



        /// <summary>
        /// 根据参数删除文件
        /// add by Tony 17.8.14 modify 17.9.19
        /// Rewride  by Joch 20171115
        /// </summary>
        /// <param name="AstDelFileParam"></param>
        /// <returns></returns>
        public bool DeleteDataExportFile(ImgCSCoreIM.StDeleteFileParam AstDelFileParam,out string strLog)
        {
            StringBuilder  sbLog = new StringBuilder();
            strLog = string.Empty;
            if (string.IsNullOrEmpty(AstDelFileParam.sBaseDirectory) &&
                !Directory.Exists(AstDelFileParam.sBaseDirectory))
            {
                return false;
            }
            if (AstDelFileParam.iMaxSaveDays < 0)
            {
                return false;
            }
            try
            {
                if (AstDelFileParam.sSkipDirectory.Contains(AstDelFileParam.sBaseDirectory))
                {
                    return true;
                }
                DateTime effectDatePoint = DateTime.Now.AddDays(-AstDelFileParam.iMaxSaveDays);

         foreach( string strDirectoryDataExport in       Directory.GetDirectories(AstDelFileParam.sBaseDirectory))
                {
                    if (!AstDelFileParam.sSkipDirectory.Contains(strDirectoryDataExport))
                    {

                        DirectoryInfo diDataExport = new DirectoryInfo(strDirectoryDataExport);

                int iFileExtCount = AstDelFileParam.sFileExtension.Count;
                sbLog.AppendLine( "FileExtension  Count :"+iFileExtCount +"datetime:"  +DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); 
                //System.Threading.Tasks.Parallel.ForEach(System.Collections.Concurrent.Partitioner.Create(0, iFileExtCount, ((int)(iFileExtCount / _iProcessorCount) + 1)), range =>
                //{
                //  //  StringBuilder strLog = new StringBuilder();
                //    for (int i = range.Item1; i < range.Item2; i++)
                       foreach (string strFileExt in AstDelFileParam.sFileExtension)
                    {
                        DateTime dt1 = DateTime.Now;
                        DateTime dt2 = DateTime.Now;

                     //   string strFileExt = AstDelFileParam.sFileExtension[i];
                        string strFileSearch = "*";
                        if (!string.IsNullOrEmpty(strFileExt))
                        {
                            if (strFileExt.StartsWith("."))
                            {
                                strFileSearch = "*" + strFileExt;
                            }
                            else
                            {
                                strFileSearch = "*." + strFileExt;
                            }
                        }
                        TimeSpan ts1 = DateTime.Now - dt1;
                        sbLog.AppendLine("strFileSearch timespan:" +ts1.TotalSeconds);

                         dt1 = DateTime.Now;
                        FileInfo[] fiDataExports = diDataExport.GetFiles(strFileSearch);
                        int iFileCount = fiDataExports.Length;
                         ts1 = DateTime.Now - dt1;
                        sbLog.AppendLine("GetFiles timespan:" + ts1.TotalSeconds);
                        sbLog.AppendLine("    strFileSearch  :" + strFileSearch  + "      iFileCount: " +iFileCount);

                        if (iFileCount > 0)
                        {
                            System.Threading.Tasks.Parallel.ForEach(System.Collections.Concurrent.Partitioner.Create(0, iFileCount, ((int)(iFileCount / _iProcessorCount) + 1)), range2 =>
                            {
                                for (int j = range2.Item1; j < range2.Item2; j++)
                                //foreach (FileSystemInfo fsiDataExport in diDataExport.GetFileSystemInfos(strFileSearch, SearchOption.AllDirectories))
                                {
                                   
                                    FileInfo fsiDataExport = fiDataExports[j];

                                    sbLog.AppendLine( "子线程: " + j + " statr   FileName  :" + fsiDataExport.Name + "      datetime: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                                    switch (fsiDataExport.Attributes)
                                    {
                                        case FileAttributes.Directory:
                                            if (fsiDataExport.Directory.GetFiles().Length == 0
                                                   && fsiDataExport.DirectoryName != AstDelFileParam.sBaseDirectory)
                                            {
                                                dt1 = DateTime.Now;
                                                (fsiDataExport).Directory.Delete();
                                                ts1 = DateTime.Now - dt1;
                                                sbLog.AppendLine( "子线程: " + j + fsiDataExport.Name + "  Delete timespan:" + ts1.TotalSeconds + "|Attributes:" + fsiDataExport.Attributes);
                                            }
                                            break;
                                        default:
                                            if (fsiDataExport.CreationTime < effectDatePoint &&
                                            !AstDelFileParam.sSkipDirectory.Contains(fsiDataExport.DirectoryName))
                                            {
                                                dt1 = DateTime.Now;
                                                fsiDataExport.Delete();
                                                ts1 = DateTime.Now - dt1;
                                                sbLog.AppendLine("子线程: " + j + fsiDataExport.Name + "  Delete timespan:" + ts1.TotalSeconds + "|Attributes:" + fsiDataExport.Attributes);

                                                dt1 = DateTime.Now;
                                                //if (fsiDataExport.Directory.GetFiles().Length == 0
                                                //    && fsiDataExport.Directory.GetDirectories().Length == 0
                                                //    && fsiDataExport.DirectoryName != AstDelFileParam.sBaseDirectory)
                                                //{
                                                //    (fsiDataExport).Directory.Delete();
                                                //}
                                                ts1 = DateTime.Now - dt1;
                                                sbLog.AppendLine( "子线程: " + j + fsiDataExport.DirectoryName + "Directory  Delete timespan:" + ts1.TotalSeconds + "|Attributes:" + fsiDataExport.Attributes);
                                            }
                                            break;
                                    }

                                    sbLog.AppendLine( "子线程: " + j + "  end   FileName  :" + fsiDataExport.Name + "      datetime: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                                }
                            });
                        }

                      TimeSpan  ts2 = DateTime.Now - dt2;
                       sbLog.AppendLine("ext: "+ strFileSearch + " timespan:" +ts2.TotalSeconds);

                    }
                        //  });

                    }
                }
                sbLog.AppendLine("DeleteDataExportFile  End   datetime:" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                strLog = sbLog.ToString();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }
        //public bool DeleteDataExportFile(ImgCSCoreIM.StDeleteFileParam AstDelFileParam)
        //{
        //    if (string.IsNullOrEmpty(AstDelFileParam.sBaseDirectory)) 
        //    {
        //        return false;
        //    }
        //    if (AstDelFileParam.iMaxSaveDays == 0)
        //    {
        //        return true;
        //    }
        //    try
        //    {
        //        DirectoryInfo directoryInfo = new DirectoryInfo(AstDelFileParam.sBaseDirectory);
        //        DateTime effectDatePoint = DateTime.Now.AddDays(-AstDelFileParam.iMaxSaveDays);
        //        DirectoryInfo skipDirectory = string.IsNullOrEmpty( AstDelFileParam.sSkipDirectory )?null: new DirectoryInfo(AstDelFileParam.sSkipDirectory);


        //        DeleFile(directoryInfo, AstDelFileParam.sFileExtension, effectDatePoint, AstDelFileParam.bDelDirectory, AstDelFileParam.iDelFileRecursiveLayer, skipDirectory);
        //    }
        //    catch (System.IO.IOException) 
        //    {
        //        return false;
        //    }

        //    return true;
        //}

        private void DeleFile(DirectoryInfo AdirInfo, string AstrFileExtension, DateTime ADTeffectDatePoint, bool bIsDelDir, int AiRecursiveLayer, DirectoryInfo ASkipDirectory)
        {
            if (AdirInfo == null
                || AiRecursiveLayer < 0
                || (ASkipDirectory != null && string.Equals(ASkipDirectory.FullName, AdirInfo.FullName)))
                return;


            FileInfo[] arrFileInfo = AdirInfo.GetFiles();
            DirectoryInfo[] arrDirInfo = AdirInfo.GetDirectories();

            //DELETE FILE
            foreach (FileInfo fileInfo in arrFileInfo)
            {
                if (DateTime.Compare(fileInfo.CreationTime, ADTeffectDatePoint) < 0
                    && (string.IsNullOrEmpty(AstrFileExtension) ? true : (!string.IsNullOrEmpty(fileInfo.Extension) && fileInfo.Extension.ToLower() == ("." + AstrFileExtension.ToLower()))))
                {
                    fileInfo.Delete();
                }
            }
            foreach (DirectoryInfo dirInfo in arrDirInfo)
            {
                DeleFile(dirInfo, AstrFileExtension, ADTeffectDatePoint, bIsDelDir, AiRecursiveLayer--, ASkipDirectory);
            }
            AdirInfo.Refresh();
            if (bIsDelDir && AdirInfo.GetFiles().Length == 0 && AdirInfo.GetDirectories().Length == 0)
            {
                AdirInfo.Delete();
                return;
            }
            return;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public string BarcodeDicision(string AStrBarcode,
            AppSettingData AappSettingData, byte AbyLaneNo)
        {
            string str = "";

            //Q.F.2017.4.13
            bool bEnCapBarcode = true;
            //if (AappSettingData.arrBarcodeSetting == null)
            //{
            //    if (AappSettingData.bUseExtBrcd == false
            //        && AappSettingData.bUseCamBrcd == false
            //        && AappSettingData.useManualBarcode == false)
            //    {
            //        bEnCapBarcode = false;
            //    }
            //}
            //else
            {
                if (AappSettingData.arrBarcodeSetting[AbyLaneNo].bUseExtBrcd == false
                   && AappSettingData.arrBarcodeSetting[AbyLaneNo].bUseCamBrcd == false
                   && AappSettingData.arrBarcodeSetting[AbyLaneNo].useManualBarcode == false)
                {
                    bEnCapBarcode = false;
                }
            }


            if (bEnCapBarcode == false
               || string.IsNullOrEmpty(AStrBarcode)
               || string.Equals(AStrBarcode, RS_Brcd_NoBarcode, StringComparison.InvariantCultureIgnoreCase)
                 )
            {
                str = RS_Brcd_NoBarcode;
            }
            else
            {
                str = AStrBarcode.Trim();

            }
            return str;

        }

        //Q.F.2016.09.06
        //update this function please inform Q.F
        public bool bPadIsSkip(InspectMainLib.Pad APad)
        {
            bool bPadIsSkip = false;
            if (APad.check == false
                || APad.fovNo < 0
                || APad.isTmpSkipped == true
                || APad.bLocalGroupPad == true
                || APad.bUseAsPosMark == true
                || APad.bUseAsBadMark == true
                || APad.bPadAsBarcode == true
                || APad.bPadAsReferPad == true//Q.F.2016.01.13
                || APad.bBadMarkIsPassed == false
                || APad.bPadAsCompRefPad == true//Q.F.2016.10.27
                || APad.bCheckedButNotCalInYield == true)//Q.F.2018.05.11
            {
                bPadIsSkip = true;
            }

            //Q.F.2017.09.05
            if (String.Equals(APad.padGroup, RS_PAINTPAD_GROUPNAME,
                       StringComparison.InvariantCultureIgnoreCase))
            {
                bPadIsSkip = true;
            }
            return bPadIsSkip;
        }
        public int[] GenMountSystemInfo(SPCBoardRes ABrdRes,
            InspectMainLib.Pad[] APads,
            AppSettingData AappSettingData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            //ImageProcessingCPP.ArrayBadPadData[] APcbGeneralInfo.PanelResults[0].arrBadPadData,
            bool AbUseNGAsBadMark,
            AppMultiLan.AppLan Adict)
        {
            if (AappSettingData.stBadMarkParams.byBadMarkCalMode == 1)
            {
                return GenMountSystemInfoNewMethod(APcbGeneralInfo, Adict);
            }
            else
            {
                return GenMountSystemInfoOldMethod(ABrdRes, APads,
                    APcbGeneralInfo, AbUseNGAsBadMark, Adict);
            }

        }
        private int[] GenMountSystemInfoNewMethod(ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppMultiLan.AppLan Adict)
        {
            try
            {
                //Q.F.2016.12.28
                //    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.shNumOfCheckedALLBM == 0)
                //        return null;

                int iLength = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                int iArrayNum = iLength;

                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                    && bPosZeroISUsed == false)
                {
                    iArrayNum--;
                }
                if (iArrayNum == 0)
                    return null;

                int[] aIInfo = new int[iArrayNum];
                int i = 0;
                short shArrayIDIndex = 0;
                String strArrayID = "";
                int iArrayID = 0;
                Array.Clear(aIInfo, 0, iArrayNum);

                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false
                    || APcbGeneralInfo.PanelResults[0].stArrayInfo.shNumOfCheckedALLBM == 0)//Q.F.2016.12.28
                    return aIInfo;

                for (i = 0; i != iLength; ++i)
                {
                    if (i == 0 && bPosZeroISUsed == false)
                    {
                        continue;
                    }
                    strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                    if (!System.Int32.TryParse(strArrayID, out iArrayID))
                    {
                        MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                        /* bRun = false;*/
                        break;
                    }
                    if (iArrayID > aIInfo.Length)
                    {
                        MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                        /* bRun = false;*/
                        break;
                    }
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shBadMarkMode < 1)
                    {
                        //strBMInfo += "0";
                        aIInfo[iArrayID - 1] = 0;

                    }
                    else
                    {
                        //strBMInfo += "1";
                        aIInfo[iArrayID - 1] = 1;
                    }
                }
                return aIInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error");
                return null;
            }

        }

        private int[] GenMountSystemInfoOldMethod(SPCBoardRes ABrdRes,
            InspectMainLib.Pad[] APads,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            bool AbUseNGAsBadMark,
            AppMultiLan.AppLan Adict)
        {
            bool bRun = true;
            bool bISArrayPCB = true;
            int iLength = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
            int iArrayNum = iLength;

            bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                && bPosZeroISUsed == false)
            {
                iArrayNum--;
            }
            if (iArrayNum == 0)
                return null;
            int[] aIInfo = new int[iArrayNum];

            Array.Clear(aIInfo, 0, iArrayNum);

            String strArrayID = "";

            int iArrayID = 0;
            short shArrayIDIndex = 0;
            int i = 0;
            int iPadIndex = 0;
            int iArrayCount = 0;
            bool bHasError = false;
            //according to bad mark info
            if (bISArrayPCB == true && APcbGeneralInfo.PanelResults[0].arrBadPadData != null)
            {
                for (i = 0; i < APcbGeneralInfo.PanelResults[0].arrBadPadData.Length; i++)
                {
                    if (APcbGeneralInfo.PanelResults[0].arrBadPadData[i].arrIPadIndices != null)
                    {
                        if (APcbGeneralInfo.PanelResults[0].arrBadPadData[i].arrIPadIndices.Length != 0)
                        {
                            iPadIndex = APcbGeneralInfo.PanelResults[0].arrBadPadData[i].iBadPadIndex;
                            shArrayIDIndex = APads[iPadIndex].arrayIDIndex;
                            strArrayID = APads[iPadIndex].strArrayID;
                            if (!System.Int32.TryParse(strArrayID, out iArrayID))
                            {
                                bHasError = true;
                                MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                                break;
                            }
                            if (iArrayID > aIInfo.Length)
                            {
                                bHasError = true;
                                MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                                break;
                            }
                            if (APads[iPadIndex].isTmpSkipped == true
                                || APcbGeneralInfo.PanelResults[0].arrBadPadData[i].bBadPadIsNG == false)
                            {
                                aIInfo[iArrayID - 1] = 0;
                            }
                            else
                            {
                                aIInfo[iArrayID - 1] = 1;
                            }
                            iArrayCount++;
                        }

                    }
                }
                if (bHasError == true)
                {
                    return null;
                }
            }

            //only open the ng as bad mark 
            //modify in 2015.09.29
            if (AbUseNGAsBadMark)
            {

                if (ABrdRes.jugResult == InspectMainLib.JudgeRes.NG)
                {
                    for (i = 0; i < APads.Length; i++)
                    {
                        if (bPadIsSkip(APads[i]) == true)
                            continue;

                        if (APads[i].res.jugRes == JudgeRes.NG)
                        {
                            strArrayID = APads[i].strArrayID;
                            if (!System.Int32.TryParse(strArrayID, out iArrayID))
                            {
                                bHasError = true;
                                MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                                break;
                            }
                            if (iArrayID > aIInfo.Length)
                            {
                                bHasError = true;
                                MessageBox.Show(Adict.GetTranslate("ArrayID Error") + "!");
                                break;
                            }
                            if (iArrayID == 0)
                                aIInfo[iArrayID] = 1;
                            else
                                aIInfo[iArrayID - 1] = 1;
                        }
                    }
                }
                if (bHasError == true)
                    return null;
            }

            return aIInfo;
        }
        //icount > 1 means has array barcode, but not equls barcode count
        public int IHasBarcode(ref AppSettingData AappSetting,
            ref ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            byte AbyLaneNo)
        {
            //if (AappSetting.bUseExtBrcd == false
            //    &&
            //    AappSetting.bUseCamBrcd == false
            //    &&
            //    AappSetting.useManualBarcode == false)
            //    return 0;

            //Q.F.2017.04.13
            bool bEnCapBarcode = true;
            //if (AappSetting.arrBarcodeSetting == null)
            //{
            //    if (AappSetting.bUseExtBrcd == false
            //        && AappSetting.bUseCamBrcd == false
            //        && AappSetting.useManualBarcode == false)
            //    {
            //        bEnCapBarcode = false;
            //    }
            //}
            //else
            {
                if (AappSetting.arrBarcodeSetting[AbyLaneNo].bUseExtBrcd == false
                   && AappSetting.arrBarcodeSetting[AbyLaneNo].bUseCamBrcd == false
                   && AappSetting.arrBarcodeSetting[AbyLaneNo].useManualBarcode == false)
                {
                    bEnCapBarcode = false;
                }
            }
            if (bEnCapBarcode == false)
                return 0;


            int iCount = 1;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == false
                ||
                APcbGeneralInfo.PanelResults[0].arrStrBrcd == null)
                return iCount;

            iCount = 0;
            for (int i = 0; i < APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length; i++)
            {
                if (!string.IsNullOrEmpty(APcbGeneralInfo.PanelResults[0].arrStrBrcd[i])
                    && !string.Equals(APcbGeneralInfo.PanelResults[0].arrStrBrcd[i], RS_Brcd_NoBarcode, StringComparison.InvariantCultureIgnoreCase))
                {
                    iCount++;
                }
            }

            if (iCount == 0)
                iCount = 1;
            return iCount;
        }
        public string GetPadErrorCodeStr(InspectMainLib.Pad APad, AppSettingData AappSettingData)
        {
            bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true
                   && AappSettingData.strUserDefinedErrorCodes != null;
            string sErrorCode = "";
            try
            {
                if (bEnUserDefinedErrorCode)
                {
                    sErrorCode = AappSettingData.strUserDefinedErrorCodes[(byte)(APad.res.jugDefectType)];
                }
                else
                {
                    sErrorCode = APad.res.jugDefectType.ToString();
                }
            }
            catch (System.Exception ex)
            {
            }
            return sErrorCode;
        }

        public int GetPadErrorCode(InspectMainLib.Pad APad, AppSettingData AappSettingData)
        {
            bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true
                   && AappSettingData.strUserDefinedErrorCodes != null;
            int iErrorCode = 0;
            try
            {
                if (bEnUserDefinedErrorCode)
                {
                    System.Int32.TryParse(AappSettingData.strUserDefinedErrorCodes[(byte)(APad.res.jugDefectType)],
                        out iErrorCode);
                }
                else
                {
                    iErrorCode = (byte)(APad.res.jugDefectType);
                }
            }
            catch (System.Exception ex)
            {
            }
            return iErrorCode;
        }

        public string GetPadResult(InspectMainLib.Pad APad, AppSettingData AappSettingData)
        {
            bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true
                   && AappSettingData.strUserDefinedErrorCodes != null;
            string strResult = "";
            if (bEnUserDefinedErrorCode)
                strResult = AappSettingData.strUserDefinedResCodes[(byte)(APad.res.jugRes)];
            else
            {
                strResult = APad.res.jugRes.ToString("g");
            }

            return strResult;
        }
        public string GetJudgeResult(InspectMainLib.JudgeRes Ares, AppSettingData AappSettingData)
        {
            bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true
                  && AappSettingData.strUserDefinedErrorCodes != null;
            string strResult = "";
            if (bEnUserDefinedErrorCode)
            {
                strResult = AappSettingData.strUserDefinedResCodes[(byte)(Ares)];
                //if (String.IsNullOrEmpty(strResult) && (byte)(Ares) == 4)
                //{
                //    strResult = "SKIPPED";
                //}
            }
            else
            {
                strResult = Ares.ToString("g");
            }

            return strResult;
        }
        public int DirCheck(ref String AstrDir)
        {
            //InspectMainLib.InspectAlgCore.DirChkAndCrt(_logRecordDir);
            try
            {
                if (String.IsNullOrEmpty(AstrDir))
                    return -1;
                if (System.IO.Directory.Exists(AstrDir) == false)
                    System.IO.Directory.CreateDirectory(AstrDir);

                if (!String.Equals(AstrDir.Substring(AstrDir.Length - 1, 1), "\\"))
                    AstrDir += "\\";

                return 0;
            }
            catch (System.Exception ex)
            {
                return -1;
            }


        }
        public int GetNGCodeOfPadInNPMFrPanasonic(ref InspectMainLib.Pad APad, ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo)
        {
            int iNgCode = 0;
            int iArrayIDIndex = APad.arrayIDIndex;
            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[iArrayIDIndex].shBadMarkMode > 0)
            {
                iNgCode = C_INT_NPM_BADMARK_NGCODE;
                return iNgCode;
            }

            if (APad.res.jugRes != JudgeRes.NG
                && APad.res.jugRes != JudgeRes.Pass)//Q.F.2019.01.31
            {
                return iNgCode;
            }

            
            switch (APad.res.jugDefectType)
            {
                case InspectMainLib.DefectType.Missing:
                    {
                        iNgCode = 64;// bit6 1000 000
                        break;
                    }
                case InspectMainLib.DefectType.Insufficient:
                    {
                        iNgCode = 64;// bit6 1000 000
                        break;
                    }
                case InspectMainLib.DefectType.Excess:
                    {
                        iNgCode = 128;// bit7 1000 0000
                        break;
                    }
                case InspectMainLib.DefectType.OverHeight:
                    {
                        iNgCode = 128;// bit7 1000 0000
                        break;
                    }
                case InspectMainLib.DefectType.LowHeight:
                    {
                        iNgCode = 64;// bit6 1000 000
                        break;
                    }
                case InspectMainLib.DefectType.OverArea:
                    {
                        iNgCode = 2;// bit1 10
                        break;
                    }
                case InspectMainLib.DefectType.LowArea:
                    {
                        iNgCode = 1;//bit0  1
                        break;
                    }
                case InspectMainLib.DefectType.ShiftX:
                    {
                        iNgCode = 8;//bit3  1000
                        break;
                    }
                case InspectMainLib.DefectType.ShiftY:
                    {
                        iNgCode = 16;//bit3  1000 0
                        break;
                    }
                case InspectMainLib.DefectType.Bridge:
                    {
                        iNgCode = 4;//bit2  100
                        break;
                    }
                case InspectMainLib.DefectType.ShapeError:
                    {
                        iNgCode = 32;//bit5  1000 00
                        break;
                    }
                default:
                    iNgCode = -1; //unkown code
                    break;
            }

            return iNgCode;


        }
        //Q.F.2017.01.03
        public String[] GetFiles(String AstrDir, String AstrExt)
        {
            return Directory.GetFiles(AstrDir, "*" + AstrExt).Where(t => t.ToLower().EndsWith(AstrExt.ToLower())).ToArray();

        }
        public int CheckAndDeleteDir(ref String AstrDir, String AstrExt)
        {
            try
            {
                if (DirCheck(ref AstrDir) == 0)
                {
                    String[] strFiles = null;
                    if (String.Equals(AstrExt, ".*"))
                    {
                        strFiles = Directory.GetFiles(AstrDir, "*.*");
                    }
                    else
                    {
                        strFiles = GetFiles(AstrDir, AstrExt);
                    }

                    if (strFiles != null && strFiles.Length > 0)
                    {
                        foreach (String str in strFiles)
                        {
                            File.Delete(str);
                        }
                        Thread.Sleep(20);
                    }

                }
                else
                    return -1;
            }
            catch (System.Exception ex)
            {
                return -1;
            }
            return 0;
        }
        public String PingCheck(String AstrIPAddress)
        {
            String strMsg = "Ping  " + AstrIPAddress + "  ";
            try
            {

                Ping ping = new Ping();
                PingReply reply = ping.Send(AstrIPAddress);
                if (reply.Status != IPStatus.Success)
                {
                    strMsg += reply.Status.ToString();
                }
                else
                {
                    strMsg = "";
                }
            }
            catch (System.Exception ex)
            {
                strMsg += ex.Message.ToString();
            }
            return strMsg;
        }
        // * Xr = cos(angle) * X - sin(angle) * Y
        // * Yr = cos(angle) * Y + sin(angle) * X
        public void CalPrinterOffsetEkra(ImageProcessingCPP.PrinterSystemRes ARes,
            AppLayerLib.AppSettingData AaPPsetting,
        int AiMarkIndex, ref float AoutFOffsetX, ref float AoutFOffsetY, byte AbyLaneNo)
      {
            AoutFOffsetX = 0f;
            AoutFOffsetY = 0f;
            try
            {
                if (AaPPsetting.stPrintSystemGKGCS.paramsLane[AbyLaneNo].bEnCalShift == false)
                    return;
                if (AaPPsetting.stPrintSystemGKGCS.paramsLane[AbyLaneNo].bEnCalAngle == false)
                {
                    AoutFOffsetX = ARes.fOffsetX;
                    AoutFOffsetY = ARes.fOffsetY;
                }
                else
                {
                    float X = ARes.aFPrinterMarkOrgX[AiMarkIndex];
                    float Y = ARes.aFPrinterMarkOrgY[AiMarkIndex];
                    double Xr = X * Math.Cos(ARes.fTheta) - Y * Math.Sin(ARes.fTheta) + ARes.fOffsetX;
                    double Yr = Y * Math.Cos(ARes.fTheta) + X * Math.Sin(ARes.fTheta) + ARes.fOffsetY;
                    AoutFOffsetX = (float)(Xr - X);
                    AoutFOffsetY = (float)(Yr - Y);
                }
            }
            catch (System.Exception ex)
            {

            }
        }

        public string GetArrayIDForArrayBarcode(
            String AstrBarcode,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppSettingData AappSettingData,
            byte AbyLaneNo
            )
        {
            string strArrayID = "";
            if (String.IsNullOrEmpty(AstrBarcode)
                || String.Equals(AstrBarcode, RS_Brcd_NoBarcode, StringComparison.InvariantCultureIgnoreCase))
                return strArrayID;

            if (APcbGeneralInfo.PanelResults[0].arrStrBrcd != null
                && APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length > 0)
            {
                int iArrayIDIndex = 0;
                for (int a = 0, iLength = APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length; a < iLength; ++a)
                {
                    strArrayID = "";
                    iArrayIDIndex = a;
                    //if(AappSettingData.bUseCamBrcd == true)
                    if (AappSettingData.arrBarcodeSetting[AbyLaneNo].bUseCamBrcd == true
                         || AappSettingData.arrBarcodeSetting[AbyLaneNo].useManualBarcode == true)
                    {
                        if (a == 0
                            && APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                            && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                            continue;
                    }
                    else
                    {
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                            && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                        {
                            iArrayIDIndex = a + 1;
                        }
                        if (iArrayIDIndex >= APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length)
                            continue;

                    }
                    strArrayID = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[iArrayIDIndex].strArrayID;
                    if (string.IsNullOrEmpty(strArrayID))
                    {
                        strArrayID = "";
                    }

                    if (!string.IsNullOrEmpty(APcbGeneralInfo.PanelResults[0].arrStrBrcd[a])
                        && String.Equals(AstrBarcode, APcbGeneralInfo.PanelResults[0].arrStrBrcd[a]))
                    {
                        break;
                    }
                }
            }


            return strArrayID;
        }

        public bool bNeedAfterPostScanExport(
            AppSettingData AappSettingData,
            byte AbyLaneNo)
        {
            if (AappSettingData.bEnDataExp == false)
                return false;


            if (AappSettingData.arrBarcodeSetting[AbyLaneNo].bUseExtBrcd == true &&
                AappSettingData.bBrcdUsePostScan == true)
                return true;

            return false;
        }
        public bool BLinkToOtherMachineWithExConveyor(AppSettingData AappSetting)
        {
            bool bEnable = false;

            if (AappSetting.stUIHardWareParams.bWithExConveyor == true)
            {
                return true;
            }
            return bEnable;

        }

        public int PadToPad(ref InspectMainLib.Pad APadSrc,
            ref InspectMainLib.Pad APadRes,
            ImageProcessingCPP.ParamsOp AParamsOp,
            bool AbCheckGageMode
            )
        {
            int iRet = 0;
            try
            {
                if (AbCheckGageMode == true)
                    return -1;
                //if (APadRes.res == null)             
                //{
                APadRes.res = new InspectMainLib.PadRes();
                APadRes.res.measuredValue = new InspectMainLib.Value3DSPI();
                APadRes.res.measuredValue.extMatrixData = new float[1, 1];
                APadRes.res.measuredValue.proc3DGrayData = new short[1, 1];
                APadRes.res.measuredValue.bridgePosMtr = new byte[9];

                APadRes.imgInspectData = new InspectMainLib.ImgInspectData();
                APadRes.spec = new InspectMainLib.PadSpec();
                APadRes.vector = new InspectMainLib.ShapeVector();

                APadRes.padID = APadSrc.padID;//1
                APadRes.fovNo = APadSrc.fovNo;//2
                APadRes.shapeType = APadSrc.shapeType;//3

                APadRes.shapeID = APadSrc.shapeID;//4
                APadRes.ShapeIDindex = APadSrc.ShapeIDindex;//5            
                APadRes.extrXum = APadSrc.extrXum;//6

                APadRes.extrYum = APadSrc.extrYum;//7
                APadRes.extrXpixels = APadSrc.extrXpixels;//8
                APadRes.extrYpixels = APadSrc.extrYpixels;//9

                APadRes.posXmm = APadSrc.posXmm;//10
                APadRes.posYmm = APadSrc.posYmm;//11
                APadRes.sizeXmmNew = APadSrc.sizeXmmNew;//12
                APadRes.sizeYmmNew = APadSrc.sizeYmmNew;//13

                APadRes.rotationDegOrg = APadSrc.rotationDegOrg;//14
                APadRes.baseType = APadSrc.baseType;//15
                APadRes.check = APadSrc.check;//16

                APadRes.checkVol = APadSrc.checkVol;//17
                APadRes.checkArea = APadSrc.checkArea;//18	
                APadRes.checkHeight = APadSrc.checkHeight;//19

                APadRes.checkShape = APadSrc.checkShape;//20
                APadRes.checkBridge = APadSrc.checkBridge;//21
                APadRes.checkOffset = APadSrc.checkOffset;//22

                APadRes.checkCoplanarity = APadSrc.checkCoplanarity;//23
                APadRes.offsetMarkID = APadSrc.offsetMarkID;//24
                APadRes.offsetMarkIDindex = APadSrc.offsetMarkIDindex;//25

                APadRes.stencilHeight = APadSrc.stencilHeight;//26
                APadRes.useMask = APadSrc.useMask;//27

                APadRes.bVAHBlobEnbld = APadSrc.bVAHBlobEnbld;//28                

                APadRes.bVAHRatioEnbld = APadSrc.bVAHRatioEnbld;//29
                APadRes.bVAHGPUEnabled = APadSrc.bVAHGPUEnabled;//30           
                //bridge
                APadRes.brdgVectorIndex = APadSrc.brdgVectorIndex;//31

                APadRes.arrayIDIndex = APadSrc.arrayIDIndex;//32
                APadRes.panelIDIndex = APadSrc.panelIDIndex;//33
                APadRes.isTmpSkipped = APadSrc.isTmpSkipped;//34
                APadRes.bBadMarkIsPassed = APadSrc.bBadMarkIsPassed;//35
                APadRes.bUseAsBadMark = APadSrc.bUseAsBadMark;//36

                APadRes.checkPadArea = APadSrc.checkPadArea;

                APadRes.componentID = APadSrc.componentID;
                APadRes.packageType = APadSrc.packageType;
                APadRes.pinNumber = APadSrc.pinNumber;

                APadRes.byBrdgChkType = APadSrc.byBrdgChkType;
                APadRes.byGerberAreaPerc = APadSrc.byGerberAreaPerc;
                APadRes.vector.lCadArea = APadSrc.vector.lCadArea;
                APadRes.checkBridge = APadSrc.checkBridge;

                APadRes.padHeightUM = APadSrc.padHeightUM;
                //APadRes.checkPadArea = true;
                APadRes.byCalShiftMode = APadSrc.byCalShiftMode;

                APadRes.stencilHeight = APadSrc.stencilHeight;
                APadRes.bComponentPlaneCrr = APadSrc.bComponentPlaneCrr;
                APadRes.bHeightResReverse = APadSrc.bHeightResReverse;
                APadRes.bPadAsCompRefPad = APadSrc.bPadAsCompRefPad;
                APadRes.aIComRefPadIndices = APadSrc.aIComRefPadIndices;
                APadRes.arrRectRefLst = APadSrc.arrRectRefLst;
                //PadRes
                APadRes.res.posXmmCorr = APadSrc.res.posXmmCorr;//37
                APadRes.res.posYmmCorr = APadSrc.res.posYmmCorr;//38

                //PadSpec
                APadRes.spec.heightH = APadSrc.spec.heightH; //um
                APadRes.spec.heightL = APadSrc.spec.heightL;
                APadRes.spec.heightWH = APadSrc.spec.heightWH;
                APadRes.spec.heightWL = APadSrc.spec.heightWL;

                APadRes.spec.areaPerH = APadSrc.spec.areaPerH;
                APadRes.spec.areaPerL = APadSrc.spec.areaPerL;
                APadRes.spec.areaPerWH = APadSrc.spec.areaPerWH;
                APadRes.spec.areaPerWL = APadSrc.spec.areaPerWL;

                APadRes.spec.volPerH = APadSrc.spec.volPerH;
                APadRes.spec.volPerL = APadSrc.spec.volPerL;
                APadRes.spec.volPerWH = APadSrc.spec.volPerWH;
                APadRes.spec.volPerWL = APadSrc.spec.volPerWL;




                APadRes.spec.shiftXH = APadSrc.spec.shiftXH;//39
                APadRes.spec.shiftYH = APadSrc.spec.shiftYH;//40

                APadRes.spec.shapeHeightMaxMeanDelta = APadSrc.spec.shapeHeightMaxMeanDelta;//41
                APadRes.spec.brdgHeight = APadSrc.spec.brdgHeight;//42

                APadRes.spec.brdgMinWidth = APadSrc.spec.brdgMinWidth;//43
                APadRes.spec.brdgDistance = APadSrc.spec.brdgDistance;//44

                APadRes.spec.brdgMinWidthPixels = APadSrc.spec.brdgMinWidthPixels;//45
                APadRes.spec.brdgDistancePixels = APadSrc.spec.brdgDistancePixels;//46
                APadRes.spec.byVAHRatioMode = APadSrc.spec.byVAHRatioMode;
                APadRes.spec.fVAHRatioThresh = APadSrc.spec.fVAHRatioThresh;

                //vah
                //added in 2013.09.04 for save result from vah
                APadRes.res.measuredValue.baseHeight = APadSrc.res.measuredValue.baseHeight;
                APadRes.res.measuredValue.height = APadSrc.res.measuredValue.height;	//um
                APadRes.res.measuredValue.area = APadSrc.res.measuredValue.area;		//um2
                APadRes.res.measuredValue.vol = APadSrc.res.measuredValue.vol;		//um3
                APadRes.res.measuredValue.offsetX = APadSrc.res.measuredValue.offsetX;	//mm
                APadRes.res.measuredValue.offsetY = APadSrc.res.measuredValue.offsetY;	//mm
                APadRes.res.measuredValue.offsetXpixel = APadSrc.res.measuredValue.offsetXpixel;
                APadRes.res.measuredValue.offsetYpixel = APadSrc.res.measuredValue.offsetYpixel;
                APadRes.res.measuredValue.maxMeanHeightDelta = APadSrc.res.measuredValue.maxMeanHeightDelta;//um
                APadRes.res.measuredValue.perArea = APadSrc.res.measuredValue.perArea;
                APadRes.res.measuredValue.perVol = APadSrc.res.measuredValue.perVol;
                APadRes.res.measuredValue.bridgeNo = APadSrc.res.measuredValue.bridgeNo;
                APadRes.res.measuredValue.fVAHRatioRes = APadSrc.res.measuredValue.fVAHRatioRes;
                //brdg
                APadRes.res.measuredValue.baseHeightByROIHisto = APadSrc.res.measuredValue.baseHeightByROIHisto;

                APadRes.spi2DSpec = new ImageProcessingCPP.SPI2DSpec();
                AParamsOp.SPI2DSpecDefault(ref APadRes.spi2DSpec);
                //}
                if (APadSrc.spi2DSpec != null)
                {

                    AParamsOp.SPI2DSpecCopy(APadSrc.spi2DSpec,
                        APadRes.spi2DSpec);
                }
                //if (APadRes.spi2DRes == null)
                //{
                APadRes.spi2DRes = new ImageProcessingCPP.SPI2DRes();
                AParamsOp.SPI2DResDefault(ref APadRes.spi2DRes);
                //}
                if (APadSrc.spi2DRes != null)
                {


                    AParamsOp.SPI2DResCopy(APadSrc.spi2DRes,
                        APadRes.spi2DRes);
                }
                APadRes.vahBigRoi = new ImageProcessingCPP.VAHBigRoi();
                AParamsOp.VAHBigRoiDefault(ref APadRes.vahBigRoi);
                AParamsOp.VAHBigRoiCopy(APadSrc.vahBigRoi, APadRes.vahBigRoi);


                //own
                //ShapeVector- vector

                if (APadRes.vector.vectorRoiPat1D != null)
                {
                    APadRes.vector.vectorRoiPat1D = (byte[])APadRes.vector.vectorRoiPat1D.Clone();
                    APadRes.vector.vectorCadPat1D = (byte[])APadRes.vector.vectorCadPat1D.Clone();
                }


                APadRes.vector.cShiftXmm = APadSrc.vector.cShiftXmm;
                APadRes.vector.cShiftYmm = APadSrc.vector.cShiftYmm;
                APadRes.vector.areaPerOnCadXY = APadSrc.vector.areaPerOnCadXY;

                APadRes.vector.cadPatMinX = APadSrc.vector.cadPatMinX;
                APadRes.vector.cadPatMaxX = APadSrc.vector.cadPatMaxX;
                APadRes.vector.cadPatMinY = APadSrc.vector.cadPatMinY;
                APadRes.vector.cadPatMaxY = APadSrc.vector.cadPatMaxY;
                APadRes.vector.vectorCadXPixels = APadSrc.vector.vectorCadXPixels;
                APadRes.vector.vectorCadYPixels = APadSrc.vector.vectorCadYPixels;

                APadRes.vector.fRealSizeXmm = APadSrc.vector.fRealSizeXmm;
                APadRes.vector.fRealSizeYmm = APadSrc.vector.fRealSizeYmm;





                AParamsOp.VAHSinglePadParamsDefault(ref APadRes.stVahSinglePadParams);
                //}
                AParamsOp.VAHSinglePadParamsCopy(APadSrc.stVahSinglePadParams, APadRes.stVahSinglePadParams);
                //get heights
                if (APadSrc.res.measuredValue.extMatrixData_1D != null)
                {
                    APadRes.res.measuredValue.extMatrixData_1D = (float[])APadSrc.res.measuredValue.extMatrixData_1D.Clone();
                    APadRes.res.measuredValue.shExtMatrixWidth = APadSrc.res.measuredValue.shExtMatrixWidth;
                    APadRes.res.measuredValue.shExtMatrixHeight = APadSrc.res.measuredValue.shExtMatrixHeight;
                }
                if (APadSrc.res.measuredValue.img2D_R_1D != null)
                {
                    APadRes.res.measuredValue.img2D_R_1D = (byte[])APadSrc.res.measuredValue.img2D_R_1D.Clone();
                    APadRes.res.measuredValue.img2D_G_1D = (byte[])APadSrc.res.measuredValue.img2D_G_1D.Clone();
                    APadRes.res.measuredValue.img2D_B_1D = (byte[])APadSrc.res.measuredValue.img2D_B_1D.Clone();
                    APadRes.res.measuredValue.proc3DGrayData_1D = (short[])APadSrc.res.measuredValue.proc3DGrayData_1D.Clone();
                    APadRes.res.measuredValue.iImg2DWidth = APadSrc.res.measuredValue.iImg2DWidth;
                    APadRes.res.measuredValue.iImg2DHeight = APadSrc.res.measuredValue.iImg2DHeight;
                }


            }
            catch (System.Exception ex)
            {
                iRet = -1;
            }
            return iRet;
        }
        /// <summary>
        /// 获取当前机器的MAC地址
        /// </summary>
        /// <returns></returns>
        public string GetMacAddress()
        {
            try
            {
                string mac = "";
                ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    if ((bool)mo["IPEnabled"] == true)
                    {
                        mac = mo["MacAddress"].ToString();
                        break;
                    }
                }
                moc = null;
                mc = null;
                return mac;
            }
            catch
            {
                return "unknow";
            }
            finally
            {
            }

        }
        public string GetStatusResultFrHUIZHOUBYD(byte AbyValue, byte AbyMode)//different appartment
        {
            string str = "P";
            if (AbyMode == 0)
            {
                switch (AbyValue)
                {
                    case 0:
                        str = "P";
                        break;
                    case 1:
                        str = "F";
                        break;
                    case 2:
                        str = "RPASS";
                        break;
                    case 4:
                        str = "S";
                        break;
                    default:
                        str = "F";
                        break;
                }
            }
            if (AbyMode == 1)//Q.F.2016.09.18
            {
                switch (AbyValue)
                {
                    case 0:
                        str = "PASS";
                        break;
                    case 1:
                        str = "NG";
                        break;
                    case 2:
                        str = "RPASS";
                        break;
                    case 4:
                        str = "S";
                        break;
                    default:
                        str = "NG";
                        break;
                }
            }
            return str;
        }
        /// <summary>
        /// atuoapp pcbid < AiPCBID, run old Appsetting, otherwise >= , read new appsetting
        /// </summary>
        /// <param name="AiPCBID"></param>
        /// <param name="AstrAppsettingFromUI"></param>
        /// <param name="AbNeedRenamed"></param>
       public void CreateAutoAPPAppsetting(int AiPCBID,String AstrAppsettingFromUI, bool AbNeedRenamed)
        {
            string strConfigPath = "";
            try
            {
                if (!Directory.Exists(RS_AUTOAPP_APPSETTING))
                {
                    Directory.CreateDirectory(RS_AUTOAPP_APPSETTING);
                }
                if (AbNeedRenamed)
                {
                   
                    strConfigPath = Path.Combine(RS_AUTOAPP_APPSETTING, AiPCBID + ".bin");
                    //@"D:\EYSPI\Bin\Config\AppSetting.bin"
                    //if (File.Exists(AstrAppsettingFromUI))
                    //{
                    //    File.Copy(AstrAppsettingFromUI, strConfigPath,true);
                    //}

                    File.Copy(AstrAppsettingFromUI, strConfigPath, true);


                }
                else
                {
                    String strFileName = Path.GetFileName(AstrAppsettingFromUI);
                    strConfigPath = Path.Combine(RS_AUTOAPP_APPSETTING, strFileName);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //Q.F.2018.03.22
        public void SavePadInfoAfterSaveFovImage(         
            InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            ref AppSettingData AappSettingData,
           ref InspectConfig.ConfigData AConfigData)
        {
            try
            {
                if (AappSettingData.stDataExpVT.bEnSaveFovImage
                    && String.IsNullOrEmpty(ABrdRes.strDataExportSaveFovImagePath) == false
                    && Directory.Exists(ABrdRes.strDataExportSaveFovImagePath)
                    && APads != null)
                {
                    int n = 0, iLength = APads.Length;
                    String strFirstLine = "PADID,FOVNO,FOVWIDTH,FOVHEIGHT,PIXELSIZEXUM,PIXELSIZEYUM,RECTX,RECTY,RECTWIDTH,RECTHEIGHT," + RS_LineEnd;                    
                    StringBuilder strPadInfo = new StringBuilder();
                    strPadInfo.Append(strFirstLine);
                    InspectMainLib.Pad pad = null;
                    for (n = 0; n < iLength; ++n)
                    {
                        pad = APads[n];
                        if (bPadIsSkip(pad))
                        {
                            continue;
                        }
                        strPadInfo.Append(pad.padID + RS_SPLIT); //padid
                        strPadInfo.Append((pad.fovNo + 1) + RS_SPLIT);//fovno + 1
                        strPadInfo.Append(AConfigData._imgWidth + RS_SPLIT);//fov WIDTH
                        strPadInfo.Append(AConfigData._imgHeight + RS_SPLIT);//fov HEIGHT
                        strPadInfo.Append(pad.imgInspectData.fPixelSizeX0um.ToString(RS_FLOATFORMAT_3Bit) + RS_SPLIT);//fov pixelsizeX in um
                        strPadInfo.Append(pad.imgInspectData.fPixelSizeY0um.ToString(RS_FLOATFORMAT_3Bit) + RS_SPLIT);//fov pixelsizeY in um                      
                        strPadInfo.Append(pad.imgInspectData.rectProcRoiOrgV.X + RS_SPLIT); //rect left and upper point pos
                        strPadInfo.Append(pad.imgInspectData.rectProcRoiOrgV.Y + RS_SPLIT);
                        strPadInfo.Append(pad.imgInspectData.rectProcRoiOrgV.Width + RS_SPLIT);//outer rectangle 
                        strPadInfo.Append(pad.imgInspectData.rectProcRoiOrgV.Height + RS_LineEnd);

                    }
                    String strboardBarcode = BarcodeDicision(ABrdRes.pcbBarcode,
                        AappSettingData,(byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                    string strFileNamePadInfo = Path.Combine(ABrdRes.strDataExportSaveFovImagePath, strboardBarcode+"_PAD"+RS_TXT_EXT);// ".Jpeg";
                    FileStream fs = new FileStream(strFileNamePadInfo, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(strPadInfo);
                    streamWrt.Close();
                    

                }
                
            }
            catch (System.Exception ex)
            {
            	
            }
        }
        //add by Peng 20180614
        public void CheckEXEAndDelete(String AstrExeName)
        {
            try
            {
                string proc = Path.GetFileNameWithoutExtension(AstrExeName);
                System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcessesByName(proc);
                if (processes.Length > 0)
                {
                    foreach (System.Diagnostics.Process p in processes)
                    {
                        if (p.ProcessName == "EXCEL")
                        {
                            p.Kill();
                        }
                    }
                    _imgBaseFunction.LogRecord(AstrExeName + " Has Beed Deleted.", false);
                }
            }
            catch (System.Exception ex)
            {

            }
        }

        //add by Peng 20180813
        public String GetSqueege(byte AbyLane, int AiCurrPCBID, string AstrBarcode, AppSettingData AappSettingData, SPCBoardRes ABrdRes, bool bIsIntraday, out string AstrSqueege)
        {
            string strMsg = string.Empty;
            AstrSqueege = string.Empty;
            string strSql = "";
            DateTime dtStartTime = ABrdRes.startTime;
            string strTpDate = dtStartTime.Date.ToString("yyyy-MM-dd");
            DateTime dtForZeroTime = Convert.ToDateTime(strTpDate + " 00:00:00");
            try
            {

                if (string.IsNullOrEmpty(AappSettingData.LineName) == false
                    && string.IsNullOrEmpty(AstrBarcode) == false
                    && AiCurrPCBID != 0)
                {
                    switch (AappSettingData.stSPCParams.bySPCDataBaseType)
                    {
                        case 1:
                            {
                                strSql = " SELECT BP.Squeege  " +
                                           " FROM " +
                                           "   main.TBBoard AS BP " +
                                           " WHERE " +
                                           "   BP.PCBID = ( " +
                                           "   SELECT " +
                                           "   MAX(PCBID) " +
                                          " FROM " +
                                          "  main.TBBoard AS pcb " +
                                          " WHERE " +
                                          " pcb.PCBID < '{0}' " +
                                          " AND pcb.LineNo = '{1}' " +
                                          " AND pcb.LaneNo = '{2}' " +
                                          " AND pcb.PCBBarcode = '{3}' ";
                                if (bIsIntraday)
                                {
                                    strSql += " AND pcb.StartTime >= '{4}' )";
                                    strSql = string.Format(strSql, AiCurrPCBID, AappSettingData.LineName, AbyLane, AstrBarcode, dtForZeroTime);
                                }
                                else
                                {
                                    strSql += ")";
                                    strSql = string.Format(strSql, AiCurrPCBID, AappSettingData.LineName, AbyLane, AstrBarcode);
                                }
                                break;
                            }
                        case 2:
                            {
                                strSql = " SELECT BP.Squeege " +
                                        " FROM " +
                                        "   spidb.TBBoard AS BP " +
                                        " WHERE " +
                                        "   BP.PCBID = ( " +
                                        "   SELECT " +
                                        "   MAX(PCBID) " +
                                       " FROM " +
                                       " spidb.TBBoard AS pcb " +
                                       " WHERE " +
                                       " pcb.PCBID < '{0}' " +
                                       " AND pcb.LineNo = '{1}' " +
                                       " AND pcb.LaneNo = '{2}' " +
                                       " AND pcb.PCBBarcode = '{3}' ";
                                if (bIsIntraday)
                                {
                                    strSql += " AND pcb.StartTime >= '{4}' )";
                                    strSql = string.Format(strSql, AiCurrPCBID, AappSettingData.LineName, AbyLane, AstrBarcode, dtForZeroTime);
                                }
                                else
                                {
                                    strSql += ")";
                                    strSql = string.Format(strSql, AiCurrPCBID, AappSettingData.LineName, AbyLane, AstrBarcode);
                                }
                                break;
                            }
                        case 3:
                            {
                                //V3 sql在此加入-----
                            }
                            break;
                        default:
                            break;
                    }
                    System.Data.DataTable dt = null;
                    if (string.IsNullOrEmpty(strSql) == false && AappSettingData.stSPCParams.bySPCDataBaseType == 2) //V2
                    {
                        DataBeanEx.MySQLBean mySqlBean = new DataBeanEx.MySQLBean();
                        dt = mySqlBean.GetDataTableFrSQL(strSql);
                    }
                    else if (string.IsNullOrEmpty(strSql) == false && AappSettingData.stSPCParams.bySPCDataBaseType == 1)//V1
                    {
                        string strSpcPath = @"D:\EYSPI\SPCData";
                        DataBeanEx.SQLiteBean sqLiteBean = new DataBeanEx.SQLiteBean();
                        //get path
                        if (dtStartTime != null)
                        {
                            int iTimePath = dtStartTime.Year;
                            strSpcPath += "\\" + iTimePath;
                            iTimePath = dtStartTime.Month;
                            strSpcPath += "\\" + iTimePath;
                            if (Directory.Exists(strSpcPath))
                            {
                                IEnumerable<FileInfo> list = null;
                                if (bIsIntraday)
                                {
                                    list = new DirectoryInfo(strSpcPath).GetFiles("*.sv1").Where(f => File.GetCreationTime(f.FullName).ToString(PubStaticParam.RS_FORMAT_DATE) == dtStartTime.ToString(PubStaticParam.RS_FORMAT_DATE));
                                }
                                else
                                {
                                    list = new DirectoryInfo(strSpcPath).GetFiles("*.sv1").Where(f => File.GetCreationTime(f.FullName) != null);
                                }
                                //file[0].
                                List<FileInfo> lstFileInfo = new List<FileInfo>();
                                if (list != null)
                                {
                                    foreach (FileInfo fi in list)
                                    {
                                        if (File.Exists(fi.FullName))
                                        {
                                            lstFileInfo.Add(fi);
                                        }
                                    }
                                }
                                if (lstFileInfo != null && lstFileInfo.Count > 0)
                                {
                                    lstFileInfo.Sort(new Comparison<FileInfo>(delegate(FileInfo a, FileInfo b)
                                    {
                                        return b.CreationTime.CompareTo(a.CreationTime);
                                    }));

                                    foreach (FileInfo filePath in lstFileInfo)
                                    {
                                        if (File.Exists(filePath.FullName))
                                        {
                                            dt = sqLiteBean.GetDataTableFrSQL(filePath.FullName, string.Empty, strSql);
                                            if (dt != null && dt.Rows.Count > 0)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        strMsg = "error:the sql statement is null!";
                    }
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        AstrSqueege = dt.Rows[0][0].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                strMsg += "( GetSqueege )" + e.Message.ToString();
            }
            return strMsg;
        }

        //add by Peng 20180816
        public bool CheckBarcodeIsExist(string AsBarcode, int AiPCBID, SPCBoardRes ABrdRes, AppSettingData AappSettingData, bool bIsIntraday)
        {
            bool bIsExistBarcode = false;

            string strSql = "SELECT " +
                            " pcb.PCBID " +
                            " FROM " +
                            "    spidb.TBBoard pcb " +
                            " WHERE " +
                            "    pcb.PCBID = '{0}' " +
                            " AND pcb.PCBBarcode = '{1}' ";
            System.Data.DataTable dt = null;
            try
            {
                DateTime dtStartTime = ABrdRes.startTime;
                string strTpDate = dtStartTime.Date.ToString("yyyy-MM-dd");
                DateTime dtForZeroTime = Convert.ToDateTime(strTpDate + " 00:00:00");
                if (string.IsNullOrEmpty(AsBarcode) == false &&
                    string.Equals(PubStaticParam.RS_NOREAD, AsBarcode, StringComparison.CurrentCultureIgnoreCase) == false
                    && AiPCBID != 0)
                {
                    switch (AappSettingData.stSPCParams.bySPCDataBaseType)
                    {
                        case 1:
                            {
                                strSql = "SELECT " +
                                        " pcb.PCBID " +
                                        " FROM " +
                                        "    main.TBBoard pcb " +
                                        " WHERE " +
                                        "    pcb.PCBID = '{0}' " +
                                        " AND pcb.PCBBarcode = '{1}' ";
                                if (bIsIntraday)
                                {
                                    strSql += " AND pcb.StartTime >= '{2}' ";
                                    strSql = string.Format(strSql, AiPCBID, AsBarcode, dtForZeroTime);
                                }
                                else
                                {
                                    strSql += " ";
                                    strSql = string.Format(strSql, AiPCBID, AsBarcode);
                                }
                                break;
                            }
                        case 2:
                            {
                                strSql = "SELECT " +
                                         " pcb.PCBID " +
                                         " FROM " +
                                         "    spidb.TBBoard pcb " +
                                         " WHERE " +
                                         "    pcb.PCBID = '{0}' " +
                                         " AND pcb.PCBBarcode = '{1}' ";

                                if (bIsIntraday)
                                {
                                    strSql += " AND pcb.StartTime >= '{2}' ";
                                    strSql = string.Format(strSql, AiPCBID, AsBarcode, dtForZeroTime);
                                }
                                else
                                {
                                    strSql += " ";
                                    strSql = string.Format(strSql, AiPCBID, AsBarcode);
                                }
                                break;
                            }
                        case 3:
                            {
                                //V3 sql在此加入-----
                            }
                            break;
                        default:
                            break;
                    }
                    if (string.IsNullOrEmpty(strSql) == false && AappSettingData.stSPCParams.bySPCDataBaseType == 2) //V2
                    {
                        DataBeanEx.MySQLBean mySqlBean = new DataBeanEx.MySQLBean();
                        dt = mySqlBean.GetDataTableFrSQL(strSql);
                    }
                    else if (string.IsNullOrEmpty(strSql) == false && AappSettingData.stSPCParams.bySPCDataBaseType == 1)//V1
                    {
                        string strSpcPath = @"D:\EYSPI\SPCData";
                        DataBeanEx.SQLiteBean sqLiteBean = new DataBeanEx.SQLiteBean();
                        //get path
                        if (dtStartTime != null)
                        {
                            int iTimePath = dtStartTime.Year;
                            strSpcPath += "\\" + iTimePath;
                            iTimePath = dtStartTime.Month;
                            strSpcPath += "\\" + iTimePath;
                            if (Directory.Exists(strSpcPath))
                            {
                                IEnumerable<FileInfo> list = null;
                                if (bIsIntraday)
                                {
                                    list = new DirectoryInfo(strSpcPath).GetFiles("*.sv1").Where(f => File.GetCreationTime(f.FullName).ToString(PubStaticParam.RS_FORMAT_DATE) == dtStartTime.ToString(PubStaticParam.RS_FORMAT_DATE));
                                }
                                else
                                {
                                    list = new DirectoryInfo(strSpcPath).GetFiles("*.sv1").Where(f => File.GetCreationTime(f.FullName) != null);
                                }
                                //file[0].
                                List<FileInfo> lstFileInfo = new List<FileInfo>();
                                if (list != null)
                                {
                                    foreach (FileInfo fi in list)
                                    {
                                        if (File.Exists(fi.FullName))
                                        {
                                            lstFileInfo.Add(fi);
                                        }
                                    }
                                }
                                if (lstFileInfo != null && lstFileInfo.Count > 0)
                                {
                                    lstFileInfo.Sort(new Comparison<FileInfo>(delegate(FileInfo a, FileInfo b)
                                    {
                                        return b.CreationTime.CompareTo(a.CreationTime);
                                    }));

                                    foreach (FileInfo filePath in lstFileInfo)
                                    {
                                        if (File.Exists(filePath.FullName))
                                        {
                                            dt = sqLiteBean.GetDataTableFrSQL(filePath.FullName, string.Empty, strSql);
                                            if (dt != null && dt.Rows.Count > 0)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        throw new  Exception( "error:the sql statement is null!");
                    }
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        string strPcbID = dt.Rows[0][0].ToString();
                        if (string.IsNullOrEmpty(strPcbID) == false)
                        {
                            bIsExistBarcode = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bIsExistBarcode;

        }
        /// <summary>
        /// Create By Xu In 2018_10_26
        /// Save Image Data To  ..FileName.imgdat
        /// </summary>
        /// <param name="strFileName"></param>
        /// <param name="stSaveImgData"></param>
        /// <returns></returns>
        public string SaveImg(string strFilePath, ST_SaveOrLoadImgData stSaveImgData)
        {
            string strMsg = string.Empty;
            Stream stream = null;
            FileStream fs = null;
            if (stSaveImgData.iImgFormat != 2)
                return strMsg + "SaveImgParamsErr";
            string strFileName = strFilePath + ".imgdat";
            try
            {
                int iLength = stSaveImgData.iHeight * stSaveImgData.iWidth;
                stream = new MemoryStream(stSaveImgData.byImgDataB);
                byte[] byDataHead = new byte[20];
                byDataHead[0] = 20;//HeadLength
                byDataHead[1] = 0;//是否加密
                byDataHead[2] = 2;//Width Height 所占的byte位数

                byDataHead[3] = (byte)(stSaveImgData.iWidth / 256);//高位
                byDataHead[4] = (byte)(stSaveImgData.iWidth % 256);//低位

                byDataHead[5] = (byte)(stSaveImgData.iHeight / 256);//高位
                byDataHead[6] = (byte)(stSaveImgData.iHeight % 256);//低位

                fs = new FileStream(strFileName, FileMode.Create);
                fs.Write(byDataHead, 0, 20);
                fs.Write(stSaveImgData.byImgDataR, 0, iLength);
                fs.Write(stSaveImgData.byImgDataG, 0, iLength);
                fs.Write(stSaveImgData.byImgDataB, 0, iLength);

               // fs.Close();
            }
            catch (Exception e)
            {
                strMsg += "SaveImgErr" + e.Message.ToString();
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
                if (stream != null)
                    stream.Dispose();
            }
            return strMsg;
        }
        /// <summary>
        /// Create By Xu In 2018_10_26
        /// Load Data From ..FileName.imgdat
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <param name="stSaveImgData"></param>
        /// <returns></returns>
        public string LoadImadat(string strFilePath, ST_SaveOrLoadImgData stSaveImgData)
        {
            string strMsg = string.Empty;
            Stream stream = null;
            if (stSaveImgData.iImgFormat != 2)
                return strMsg + "LoadImgParamsErr";
            string strFileName = strFilePath + ".imgdat";
            try
            {
                FileStream fs = new FileStream(strFileName, FileMode.OpenOrCreate, FileAccess.Read);
                byte[] byHeadData = new byte[20];
                fs.Read(byHeadData, 0, 20);
                if (byHeadData[0] != 20 || byHeadData[2] != 2)
                    return "Not Format .imgdat";
                stSaveImgData.iWidth = byHeadData[3] * 256 + byHeadData[4];
                stSaveImgData.iHeight = byHeadData[5] * 256 + byHeadData[6];
                int iLength = stSaveImgData.iHeight * stSaveImgData.iWidth;
                stSaveImgData.byImgDataR = new byte[iLength];
                stSaveImgData.byImgDataG = new byte[iLength];
                stSaveImgData.byImgDataB = new byte[iLength];

                fs.Position = 20;
                fs.Read(stSaveImgData.byImgDataR, 0, iLength);
                fs.Position = 20 + iLength;
                fs.Read(stSaveImgData.byImgDataG, 0, iLength);
                fs.Position = 20 + iLength * 2;
                fs.Read(stSaveImgData.byImgDataB, 0, iLength);
                fs.Close();
            }
            catch (Exception e)
            {
                strMsg += "LoadImgErr" + e.Message.ToString();
            }
            finally
            {
                if (stream != null)
                    stream.Dispose();
            }
            return strMsg;
        }

        public string[] SortArrayString(string[] AstrSrc, bool AbAscending)
        {
            
            String[] resFiles = null;
            if (AstrSrc != null && AstrSrc.Length > 0)
            {
                if (AbAscending == true)
                {
                    IEnumerable<string> sortAscendingQuery =
                              from str in AstrSrc
                              orderby str  //"ascending" is default,descending
                              select str;
                    resFiles = sortAscendingQuery.ToArray();
                }
                else
                {
                    IEnumerable<string> sortAscendingQuery =
                                from str in AstrSrc
                                orderby str descending //"ascending" is default,descending
                                select str;
                    resFiles = sortAscendingQuery.ToArray();

                }
                
            }
            return resFiles;
        }
        public static String GetStreamFrPad(InspectMainLib.Pad Apad, 
            AppLayerLib.AppSettingData Aappsetting,
            ImageFormat AImgFormat, 
            out byte[] AoutByRes)
        {
            String strMsg = String.Empty;
            AoutByRes = null;
            try
            {
                ImgCSCoreIM.ColorFactorParams stColorFactors = Aappsetting.stColorFactorParams;
                int iWidth = Apad.res.measuredValue.iImg2DWidth, iHeight = Apad.res.measuredValue.iImg2DHeight;
                if (iWidth * iHeight == 0)
                    return strMsg;
                Bitmap Result = new Bitmap(iWidth, iHeight, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                Rectangle rect = new Rectangle(0, 0, iWidth, iHeight);
                System.Drawing.Imaging.BitmapData bmpData = Result.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, Result.PixelFormat);
                IntPtr iPtr = bmpData.Scan0;
                int iStride = bmpData.Stride;
                int iBytes = iStride * iHeight;
                byte[] PixelValues = new byte[iBytes];
                int iPoint = 0;
                int offSet = iStride - iWidth * 3;
                byte byG = 0, byB = 0, byR = 0;
                //
                int iIndex = 0;
                short shValue = 0;
                short shColorPer = (short)(stColorFactors.byRGB2DFactorR * 1.28);
                for (int i = 0; i < iHeight; ++i)
                {
                    for (int j = 0; j < iWidth; ++j)
                    {
                        iIndex = i * iWidth + j;
                        if (Apad.res.measuredValue.proc3DGrayData_1D[iIndex] >= 300)
                        {
                            byG = Color.Blue.G;
                            byB = Color.Blue.B;
                            byR = Color.Blue.R;
                        }
                        else
                        {
                            byG = Apad.res.measuredValue.img2D_G_1D[iIndex];
                            byB = Apad.res.measuredValue.img2D_B_1D[iIndex];
                            byR = (byte)((Apad.res.measuredValue.img2D_R_1D[iIndex] * shColorPer) >> 7);
                        }
                        PixelValues[iPoint++] = byB;
                        PixelValues[iPoint++] = byG;
                        PixelValues[iPoint++] = byR;
                    }

                    iPoint += offSet;
                }

                //
                System.Runtime.InteropServices.Marshal.Copy(PixelValues, 0, iPtr, iBytes);
                Result.UnlockBits(bmpData);
                //if(Aappsetting.enPadDebug)
                //    Result.Save(@"D:\EYSPI\Bin\Debug\" + Apad.padID + ".bmp");
                strMsg = GetBytesByImage(Result, out AoutByRes);

            }
            catch (Exception ex)
            {
                strMsg = "GetStreamFrPad" + ex.ToString();
            }
            return strMsg;
        }
        public static String GetBytesByImage(Bitmap Abitmap, out byte[] AoutByRes)
        {
            String strMsg = String.Empty;
            AoutByRes = null;
            try
            {

                using (MemoryStream ms = new MemoryStream())
                {
                    //Bitmap bmp = new Bitmap(image);
                    Abitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    AoutByRes = new byte[ms.Length];
                    ms.Position = 0;
                    ms.Read(AoutByRes, 0, Convert.ToInt32(ms.Length));
                }

            }
            catch (System.Exception ex)
            {
                strMsg = "GetBytesByImage" + ex.ToString();
            }
            return strMsg;
        }
    }
}
