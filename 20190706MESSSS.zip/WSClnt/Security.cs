﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;

namespace WSClnt
{
    public class Security
    {

        private static byte[] RijndaelIV
        {
            get
            {
                return MD5StrToByte("sinictek | UI");
            }
        }

        /// <summary>
        /// Rijndael算法用到的key
        /// </summary>
        private static byte[] RijndaelKey
        {
            get
            {
                byte[] destinationArray = new byte[0x20];

                Array.Copy(MD5StrToByte("sinictek"), 0, destinationArray, 0, 0x10);
                Array.Copy(MD5ByteToByte(MD5StrToByte("UI")), 0, destinationArray, 0x10, 0x10);
                return destinationArray;
            }
        }


        public static byte[] MD5ByteToByte(byte[] bytesToEncrypt)
        {
            return ((HashAlgorithm)CryptoConfig.CreateFromName("MD5")).ComputeHash(bytesToEncrypt);
        }

        public static byte[] MD5StrToByte(string strToEncrypt)
        {
            return MD5ByteToByte(Encoding.UTF8.GetBytes(strToEncrypt));
        }

        /// <summary>
        /// 使用Rijndael算法解密字符串
        /// </summary>
        /// <param name="strToDecrypt"></param>
        /// <returns></returns>
        public static string RijndaelDecrypt(string strToDecrypt)
        {
            byte[] rijndaelKey = RijndaelKey;
            byte[] rijndaelIV = RijndaelIV;
            byte[] buffer = Convert.FromBase64String(strToDecrypt);
            byte[] buffer4 = new byte[buffer.Length];
            MemoryStream stream = new MemoryStream(buffer);
            RijndaelManaged managed = new RijndaelManaged();
            CryptoStream stream2 = new CryptoStream(stream, managed.CreateDecryptor(rijndaelKey, rijndaelIV), CryptoStreamMode.Read);
            try
            {
                stream2.Read(buffer4, 0, buffer4.Length);
            }
            catch (Exception exception)
            {

                stream.Close();
                stream2.Close();
                return string.Empty;
            }
            return Encoding.UTF8.GetString(buffer4);
        }

        /// <summary>
        /// 使用Rijndael算法加密字符串
        /// </summary>
        /// <param name="strToEncrypt"></param>
        /// <returns></returns>
        public static string RijndaelEncrypt(string strToEncrypt)
        {
            byte[] rijndaelKey = RijndaelKey;
            byte[] rijndaelIV = RijndaelIV;
            byte[] bytes = Encoding.UTF8.GetBytes(strToEncrypt);
            byte[] inArray = new byte[0];
            MemoryStream stream = new MemoryStream();
            RijndaelManaged managed = new RijndaelManaged();
            CryptoStream stream2 = new CryptoStream(stream, managed.CreateEncryptor(rijndaelKey, rijndaelIV), CryptoStreamMode.Write);
            try
            {
                stream2.Write(bytes, 0, bytes.Length);
                stream2.FlushFinalBlock();
                inArray = stream.ToArray();
            }
            catch (Exception exception)
            {

                stream.Close();
                stream2.Close();
                return string.Empty;
            }
            return Convert.ToBase64String(inArray);
        }


    }
}
