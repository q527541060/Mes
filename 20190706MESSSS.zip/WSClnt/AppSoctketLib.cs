﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Newtonsoft.Json;
using ImgCSCoreIM;
using System.IO;
using System.IO.Compression;

namespace WSClnt
{
    [Serializable]
    public struct StSocketTransport
    {
        public EN_SOCKET_HEADER Header;
        public string ServerIpAddress;
        public string LineName;
        public string DisplayContent;
        public StBoardLockAuth Auth;
        public StRVBoardLockToplist[] BoardLockToplist;
    }


    public enum EN_SOCKET_HEADER
    {
        NULL = 0,
        ACCEPT = 1,
        REGISTER = 2,
        TOPLIST = 3,
        AUTHORITY_CHECK = 4,
        AUTHORITY_PASS = 5,
        AUTHORITY_FAIL = 6
    }

    public delegate void DataSendCallBackFun(StSocketTransport stSocketTrans);

    public class SocketOperator
    {
        public static int R_TCP_SOCKET_PORT = 10050;


        public const string R_RETURN_ERROR = "ERROR";
        public const string R_RETURN_SUCCESS = "SUCCESS";

        SocketTCPServer _tcpServer;
        public StSocketTransport _StSocketTrans;
        SocketClientHandle _socketClient;
        public string _strSocketTrans = "";

        //public StSocketTransport ClinetReceivedSocketTrans;



        public SocketOperator()
        {
            _tcpServer = new SocketTCPServer(R_TCP_SOCKET_PORT);
            _tcpServer.DataReceived += new EventHandler<SocketEventArgs>(_tcpServer_DataReceived);
        }

        public void StartServer()
        {
            _tcpServer.Start();
        }

        public void StopServer()
        {
            _tcpServer.CloseAllClient();
            _tcpServer.Dispose();
        }

        public event EventHandler<SocketTransEventArgs> DataReceived;



        public DataSendCallBackFun _dataSendCallBackFun;



        private void CallBackReceived(StSocketTransport AstSocketTrans)
        {
            if (DataReceived != null)
            {
                DataReceived(this, new SocketTransEventArgs(AstSocketTrans));
            }
        }

        public void _tcpServer_DataReceived(object sender, SocketEventArgs e)
        {

            try
            {
                SocketClientHandle sc = e._handle;
                _socketClient = sc;
                byte[] bRreceive = sc._recvBuffer;                
                if (bRreceive != null && bRreceive.Length > 0)
                {
                    string sReceiveRawStr = "";
                    try
                    {
                        byte[] bRreceiveDecompress = SocketOperator.Decompress(bRreceive);
                        sReceiveRawStr = Encoding.Default.GetString(bRreceiveDecompress); 
                    }
                    catch (Exception exce) 
                    {
                        sReceiveRawStr = Encoding.Default.GetString(sc._recvBuffer);
                        
                    }
                    _StSocketTrans = JsonConvert.DeserializeObject<StSocketTransport>(sReceiveRawStr);
                }
                else
                {
                    _StSocketTrans = new StSocketTransport();
                    _StSocketTrans.Header = EN_SOCKET_HEADER.NULL;
                }
            }
            catch (Exception ex)
            {
                _StSocketTrans = new StSocketTransport();
                _StSocketTrans.Header = EN_SOCKET_HEADER.NULL;
                throw (new System.Exception("TcpServer dataReceive error" + ex.Message));
            }
            CallBackReceived(_StSocketTrans);
        }

        public string DoSendData(StSocketTransport AstSocketTrans)
        {
            string strAppFileDir = System.AppDomain.CurrentDomain.BaseDirectory;
            string strAppFileFullName = strAppFileDir + "\\log\\SocketLib_" + DateTime.Now.ToString("MMddHHmmss") + ".log";
            System.IO.FileStream logFileStm = new System.IO.FileStream(strAppFileFullName, System.IO.FileMode.Append);
            System.IO.StreamWriter logfileWrt = new System.IO.StreamWriter(logFileStm);

            try
            {
                if (_socketClient == null || _socketClient.IsConnect == false)
                {
                    _socketClient.Dispose();
                    return R_RETURN_ERROR + ": No client alived";
                }

                logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 1 start send data");
                string sObjectSerial = JsonConvert.SerializeObject(AstSocketTrans);
                logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 2 send data=" + sObjectSerial);
                byte[] bObjectSerialCompress = SocketOperator.Compress(Encoding.Default.GetBytes(sObjectSerial));
                logfileWrt.Flush();
                _socketClient.SendData(bObjectSerialCompress);
                logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 3 send data success");
                logfileWrt.Flush();

            }
            catch (Exception ex)
            {

                return R_RETURN_ERROR + ":" + ex.Message;
            }
            if (logfileWrt != null)
            {
                logfileWrt.Close();
                logFileStm.Close();
                logfileWrt.Dispose();
                logFileStm.Dispose();
            }

            return R_RETURN_SUCCESS;
        }

        public Socket RegisterClient(string AsSocketServerIp, ref Socket AsocketClient, string AsLineName, int AiConnectTimeOut)
        {
            try
            {
                if (SocketTCPServer.IsClientConnected(AsocketClient))
                {
                    return AsocketClient;
                }
                AsocketClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(AsSocketServerIp), SocketOperator.R_TCP_SOCKET_PORT);//服务器的IP和端口

                AsocketClient.Connect(ipep);
                StSocketTransport socketTran = new StSocketTransport();
                socketTran.Header = EN_SOCKET_HEADER.REGISTER;
                socketTran.ServerIpAddress = AsSocketServerIp;
                socketTran.LineName = AsLineName;
                //byte[] socketBytes = SocketOperator.Compress(Encoding.Default.GetBytes(JsonConvert.SerializeObject(socketTran)));
                byte[]socketBytes = Encoding.Default.GetBytes(JsonConvert.SerializeObject(socketTran));
                AsocketClient.Send(socketBytes);
                byte[] receiveBytes = new byte[1024 * 10];
                AsocketClient.ReceiveTimeout = AiConnectTimeOut;
                int recLength = AsocketClient.Receive(receiveBytes);
                if (recLength > 0)
                {
                    string sReceiveRawStr = "";
                    try
                    {
                        byte[] bReceiveDecompress = Decompress(receiveBytes);
                        sReceiveRawStr = Encoding.Default.GetString(bReceiveDecompress);
                        
                    }
                    catch (Exception exce) 
                    {
                        sReceiveRawStr = Encoding.Default.GetString(receiveBytes, 0, recLength);                        
                    }
                    socketTran = JsonConvert.DeserializeObject<StSocketTransport>(sReceiveRawStr);

                    if (socketTran.Header == EN_SOCKET_HEADER.ACCEPT)
                    {
                        AsocketClient.ReceiveTimeout = 0;
                        return AsocketClient;
                    }
                }
                return null;

            }
            catch (SocketException ex)
            {
                Console.WriteLine("unable to connect to server");
                return null;
            }
            catch (Exception exc)
            {
                Console.WriteLine("unable to connect to server");
                return null;
            }
        }

        public string CheckUserAuth(Socket Aclient, string AsUserName, string AsPassword)
        {
            if (!SocketTCPServer.IsClientConnected(Aclient)) return R_RETURN_ERROR;
            StSocketTransport socketTran = new StSocketTransport();
            socketTran.Header = EN_SOCKET_HEADER.AUTHORITY_CHECK;
            socketTran.Auth.UserName = AsUserName;
            socketTran.Auth.Password = AsPassword;
            byte[] socketBytes = Encoding.Default.GetBytes(SocketOperator.Compress(JsonConvert.SerializeObject(socketTran)));
            try
            {
                Aclient.Send(socketBytes);
            }
            catch (SocketException ex)
            {
                Console.WriteLine("CheckUserAuth:" + ex.Message);
                return R_RETURN_ERROR;
            }

            return R_RETURN_SUCCESS;
        }

        /// <summary>
        /// 客户端接收数据事件
        /// </summary>
        public event EventHandler<EventArgs> ClientReceivedData;



        public void ClientReceiveData(object AclientOjbect)
        {

            System.IO.FileStream logFileStm = null;
            System.IO.StreamWriter logfileWrt = null;

            string strAppFileDir = System.AppDomain.CurrentDomain.BaseDirectory;
            //string strAppFileFullName = strAppFileDir + "\\log\\SocketLib.log";
            string strAppFileFullName = strAppFileDir + "\\log\\SocketLib_" + DateTime.Now.ToString("MMddHHmmss") + ".log";
            logFileStm = new System.IO.FileStream(strAppFileFullName, System.IO.FileMode.Append);
            logfileWrt = new System.IO.StreamWriter(logFileStm);


            Socket Aclient = (Socket)AclientOjbect;
            
            while (SocketTCPServer.IsClientConnected(Aclient))
            {
                byte[] recevieBytes = new byte[1024 * 10];
                try
                {


                    logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 1 start receive data");
                    logfileWrt.Flush();

                    Aclient.ReceiveTimeout = 0;

                    int len = Aclient.Receive(recevieBytes);
                    StSocketTransport stSocketTrans = new StSocketTransport();
                    if (len > 0)
                    {
                        string sReceiveRawStr = "";
                        try
                        {
                            sReceiveRawStr = Encoding.Default.GetString(SocketOperator.Decompress(recevieBytes));
                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 2-1 receive compress data ");
                            
                        }
                        catch (Exception exce) 
                        {
                            sReceiveRawStr = Encoding.Default.GetString(recevieBytes);
                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 2-2 receive nucompress data ");
                            
                        }
                        logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 2 receive data info:" + sReceiveRawStr);
                        logfileWrt.Flush();

                        stSocketTrans = JsonConvert.DeserializeObject<StSocketTransport>(sReceiveRawStr);

                        if (stSocketTrans.Header == null)
                        {
                            logfileWrt.WriteLine(DateTime.Now.ToString() + ": Header is null");
                            logfileWrt.Flush();
                        }

                        if (stSocketTrans.BoardLockToplist == null)
                        {
                            logfileWrt.WriteLine(DateTime.Now.ToString() + ": BoardLockToplist is null");
                            logfileWrt.Flush();
                        }
                        else
                        {
                            logfileWrt.WriteLine(DateTime.Now.ToString() + ": BoardLockToplist length=" + stSocketTrans.BoardLockToplist.Length);
                            logfileWrt.Flush();
                        }

                        logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 3 convert data success");
                        logfileWrt.Flush();

                        if (_dataSendCallBackFun != null)
                        {
                            string clientRemoteIpPort = Aclient.RemoteEndPoint.ToString();

                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 4 start call back function");

                            stSocketTrans.ServerIpAddress = clientRemoteIpPort.Substring(0, clientRemoteIpPort.IndexOf(":"));

                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 5 ServerIpAddress=" + stSocketTrans.ServerIpAddress);

                            this._StSocketTrans = stSocketTrans;

                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 6 call back function");
                            logfileWrt.Flush();

                            //ClientReceivedData(this, new EventArgs());

                            this._strSocketTrans = SocketOperator.Compress(JsonConvert.SerializeObject(stSocketTrans));

                            _dataSendCallBackFun(stSocketTrans);

                            //ClientReceivedData(this.ClinetReceivedSocketTrans, new EventArgs());

                            logfileWrt.WriteLine(DateTime.Now.ToString() + ":step 7 call back function finish");
                            logfileWrt.Flush();
                        }
                    }
                    logfileWrt.Flush();
                    //logfileWrt.Dispose();
                }
                catch (SocketException ex)
                {
                    Console.WriteLine("ClientReceiveData:" + ex.Message);


                    //throw new Exception("Received Data (" + receiveDataStr + ") ",ex);
                }
                catch (ObjectDisposedException ode)
                {
                    Console.WriteLine("ObjectDisposedException");

                }
                catch (Exception exc)
                {
                    Console.WriteLine("Exception");

                }
            }

            if (logfileWrt != null)
            {
                logfileWrt.Close();
                logFileStm.Close();
                logfileWrt.Dispose();
                logFileStm.Dispose();
            }

        }

        public void DoCloseClient()
        {
            _tcpServer.Close(_socketClient);
        }


        public static byte[] Compress(byte[] inputBytes)
        {
            using (MemoryStream outStream = new MemoryStream())
            {
                using (GZipStream zipStream = new GZipStream(outStream, CompressionMode.Compress, true))
                {
                    zipStream.Write(inputBytes, 0, inputBytes.Length);
                    zipStream.Close();
                    return outStream.ToArray();
                }
            }
        }

        public static byte[] Decompress(byte[] inputBytes)
        {

            using (MemoryStream inputStream = new MemoryStream(inputBytes))
            {
                using (MemoryStream outStream = new MemoryStream())
                {
                    using (GZipStream zipStream = new GZipStream(inputStream, CompressionMode.Decompress))
                    {
                        zipStream.CopyTo(outStream);
                        zipStream.Close();
                        return outStream.ToArray();
                    }
                }
            }
        }

        public static string Compress(string input)
        {
            byte[] inputBytes = Encoding.Default.GetBytes(input);
            byte[] result = Compress(inputBytes);
            return Convert.ToBase64String(result);
        }

        public static string Decompress(string input)
        {
            byte[] inputBytes = Convert.FromBase64String(input);
            byte[] depressBytes = Decompress(inputBytes);
            return Encoding.Default.GetString(depressBytes);
        }
    }

    public class SocketTransEventArgs : EventArgs
    {
        public StSocketTransport _StSocketTrans;

        public SocketTransEventArgs(StSocketTransport AstSocketTrans)
        {
            this._StSocketTrans = AstSocketTrans;
        }
    }


}
