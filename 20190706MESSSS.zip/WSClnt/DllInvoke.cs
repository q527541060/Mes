﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Collections;

namespace WSClnt
{
    public class DllInvoke
    {
        [DllImport("kernel32.dll")]
        private extern static IntPtr LoadLibrary(String path);
        [DllImport("kernel32.dll")]
        private extern static IntPtr GetProcAddress(IntPtr lib, String funcName);
        [DllImport("kernel32.dll")]
        private extern static bool FreeLibrary(IntPtr lib);
        private IntPtr hLib;
        public DllInvoke() { }
        public DllInvoke(String DLLPath)
        {
            hLib = LoadLibrary(DLLPath);
        }
        ~DllInvoke()
        {
            FreeLibrary(hLib);
        }

        public Delegate InvokeNativeDll(String APIName, Type type)
        {
            IntPtr api = GetProcAddress(hLib, APIName);
            return (Delegate)Marshal.GetDelegateForFunctionPointer(api, type);
        }

        public object InvokeCLRDll(string sFileName, string sNamespace, string ClassName, string sProcName, object[] oParameters, ref string sErrorStr)
        {
            //sErrorStr = "DLL Call step-1";
            try
            { // 载入程序集
                Assembly MyAssembly = Assembly.LoadFrom(sFileName);
                //sErrorStr += "/step-2";
                Type[] type = MyAssembly.GetTypes();
                //sErrorStr += "/step-3";
                foreach (Type t in type)
                {// 查找要调用的命名空间及类
                   // sErrorStr += "/step-4_1"+t.Name;
                    if (t.Namespace.Equals(sNamespace) && t.Name.Equals(ClassName))                       
                    //if (t.Namespace ==sNamespace && t.Name==ClassName)
                    {// 查找要调用的方法并进行调用
                       // sErrorStr += "/step-4_2" + t.Namespace + " " + t.Name + "("+sNamespace+","+ClassName+")";
                        MethodInfo m = t.GetMethod(sProcName);
                      //  sErrorStr += "/step-4_3";
                        if (m != null)
                        {
                        //    sErrorStr += "/step-4_4";
                            object obj = Activator.CreateInstance(t);

                            return m.Invoke(obj, oParameters);
                        }
                        else
                        {
                       //     sErrorStr += "/step-4_5";
                            Console.WriteLine("Load library Error!");
                        }
                    }
                }
               // sErrorStr += "/step-5";
            }
            catch (System.NullReferenceException e)
            {
                Console.WriteLine(e.InnerException);
                sErrorStr += e.InnerException.ToString();
                //return (object)-1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.InnerException);
                sErrorStr += ex.InnerException.ToString();
                //return (object)-1;
            }
            return (object)"Dll Call Error!";
        }

        public object CreateType(string sFileName, string sNamespace, string sTypeName, Hashtable fieldValues)
        {
            object obj = null;
            try
            {
                Assembly MyAssembly = Assembly.LoadFrom(sFileName);
                Type[] type = MyAssembly.GetTypes();
                foreach (Type t in type)
                {
                    if (t.Namespace == sNamespace && t.Name == sTypeName)
                    {
                        obj = Activator.CreateInstance(t);
                        FieldInfo[] fInfo = t.GetFields();
                        foreach (FieldInfo fi in fInfo)
                        {
                            foreach (DictionaryEntry de in fieldValues)
                            {
                                if (fi.Name.Equals(de.Key))
                                {
                                    fi.SetValue(obj, de.Value);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return obj;
        }

        /// <summary>
        ///  add by Peng 20180813;
        ///  
        ///  重载InvokeCLRDll函数;    
        ///  参数可获取带有ref/out 引用参数的值
        ///  (例:parm: string Astr;  object[] oParameters=new[1]{Astr}  Type[] type = new Type[1]{typeof(string).MakeByRefType() }  则oParameters[0]值为引用参数值   );
        /// </summary>
        /// <param name="sFileName"></param>
        /// <param name="sNamespace"></param>
        /// <param name="ClassName"></param>
        /// <param name="sProcName"></param>
        /// <param name="oParameters"></param>
        /// <param name="ArrType"></param>
        /// <returns></returns>
        public object InvokeCLRDll(string sFileName, string sNamespace, string ClassName, string sProcName, ref object[] oParameters, ref string sErrorStr, Type[] ArrType)
        {
            try
            {
                Assembly MyAssembly = Assembly.LoadFrom(sFileName);
                Type[] type = MyAssembly.GetTypes();
                foreach (Type t in type)
                {
                    if (t.Namespace == sNamespace && t.Name == ClassName)
                    {
                        MethodInfo m = t.GetMethod(sProcName, ArrType);
                        if (m != null)
                        {
                            object obj = Activator.CreateInstance(t);
                            return m.Invoke(obj, oParameters);
                        }
                        else
                        {
                            Console.WriteLine("Load library Error!");
                        }
                    }
                }
            }
            catch (System.NullReferenceException e)
            {
                Console.WriteLine(e.InnerException);
                sErrorStr = e.InnerException.ToString();
                //return (object)-1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.InnerException);
                sErrorStr = ex.InnerException.ToString();
                //return (object)-1;
            }
            return (object)"Dll Call Error!";
        }


    }




}

