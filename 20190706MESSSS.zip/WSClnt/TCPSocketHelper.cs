﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;

namespace WSClnt
{
    public static class TCPSocketHelper
    {
        /// <summary>  
        /// 发送数据  
        /// </summary>  
        /// <param name="host"></param>  
        /// <param name="port"></param>  
        /// <param name="data"></param>  
        /// <returns></returns>  
        public static string Send(string host, int port, string data, Encoding encoding, bool sendHeader)
        {
            string result = string.Empty;
            string strLog = string.Empty;
            try
            {
                Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSocket.Connect(host, port);
                byte[] byParams = encoding.GetBytes(data);

                if (sendHeader)
                {
                    Int32 intDataLength = byParams.Length;
                    byte[] byLengthHeader = BitConverter.GetBytes(intDataLength);
                    clientSocket.Send(byLengthHeader);
                }
                clientSocket.Send(byParams);
                result = Receive(clientSocket, 5000 * 2,sendHeader); //5*2 seconds timeout.   
                DestroySocket(clientSocket);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        /// <summary>
        /// 只发送信号
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="data"></param>
        /// <param name="encoding"></param>
        /// <param name="sendHeader"></param>
        /// <returns></returns>
        public static string Send(string host, int port, string data, Encoding encoding, bool sendHeader, bool bIsJustSend)
        {
            string result = string.Empty;
            string strLog = string.Empty;
            try
            {
                Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSocket.Connect(host, port);
                byte[] byParams = encoding.GetBytes(data);

                if (sendHeader)
                {
                    Int32 intDataLength = byParams.Length;
                    byte[] byLengthHeader = BitConverter.GetBytes(intDataLength);
                    clientSocket.Send(byLengthHeader);
                }
                clientSocket.Send(byParams);
                if (bIsJustSend == false)
                {
                    result = Receive(clientSocket, 5000 * 2, sendHeader); //5*2 seconds timeout.   
                }
                DestroySocket(clientSocket);
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
            return result;
        }
        /// <summary>  
        /// 接收数据  
        /// </summary>  
        /// <param name="socket"></param>  
        /// <param name="timeout"></param>  
        /// <returns></returns>  
        public static string Receive(Socket socket, int timeout, bool sendHeader)
        {
            string result = string.Empty;
            try
            {
                socket.ReceiveTimeout = timeout;
                List<byte> data = new List<byte>();
                byte[] buffer = new byte[1024];
                int length = 0;
                while ((length = socket.Receive(buffer)) > 0)
                {
                    int j = 0;
                    if (sendHeader)
                        j = 4;
                    for (; j < length; j++)
                    {
                        data.Add(buffer[j]);
                    }
                    if (length < buffer.Length)
                    {
                        break;
                    }
                }
                if (data.Count > 0)
                {
                    result = Encoding.UTF8.GetString(data.ToArray(), 0, data.Count);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>  
        /// 销毁Socket对象  
        /// </summary>  
        /// <param name="socket"></param>  
        public static void DestroySocket(Socket socket)
        {
            try
            {
                if (socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                }
                socket.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
