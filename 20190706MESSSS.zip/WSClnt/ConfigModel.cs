﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WSClnt
{
    public class ConfigModel
    {
        public string MachineID { get; set; }
        public string GenerateTime { get; set; }
        public string LastEditTime { get; set; }

        public bool IsAllMachine { get; set; }
        public double ValidHours_All { get; set; }

        public List<FuncConfig> FuncConfigs { get; set; }
        public ConfigModel()
        {
            this.FuncConfigs = new List<FuncConfig>();
        }
    }

    public class FuncConfig
    {
        public string FuncName { get; set; }
        public bool Enabled { get; set; }
        public int ValidDays { get; set; }
        public bool NeverExpire { get; set; }
    }
}
