﻿using AppLayerLib;
using InspectMainLib;
using Model;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using ImgCSCoreIM;
using System.Windows.Forms;
/// <summary>
/// hanwha 类
/// </summary>
namespace hanwhaClass
{
    public class GENERAL
    {
        ///<summary>
        /// 
        ///</summary>
        public string UNIT { get; set; }

        public GENERAL()
        {
            UNIT = string.Empty;
        }
    }

    public class BLOCK
    {
        ///<summary>
        /// 
        ///</summary>
        public int ID { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public int Count { get; set; }

    }

    public class BLOCK_ARRAYCOUNT
    {
        ///<summary>
        /// 
        ///</summary>
        public BLOCK BLOCK { get; set; }

        public BLOCK_ARRAYCOUNT()
        {
            BLOCK = new BLOCK();
        }
    }

    public class USE
    {
        ///<summary>
        /// 
        ///</summary>
        public string BADMARKSTATUS { get; set; }

        public USE()
        {
            BADMARKSTATUS = string.Empty;
        }
    }

    public class ARRAYItem
    {
        ///<summary>
        /// 
        ///</summary>
        public int ID { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public string value { get; set; }

        public ARRAYItem()
        {
            value = string.Empty;
        }

    }

    public class BLOCKDetail
    {
        ///<summary>
        /// 
        ///</summary>
        public int ID { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public List<ARRAYItem> ARRAY { get; set; }

        public BLOCKDetail()
        {
            ARRAY = new List<ARRAYItem>();
        }
    }

    public class BADMARKSTATUS
    {
        ///<summary>
        /// 
        ///</summary>
        public BLOCKDetail BLOCKDetail { get; set; }

        public BADMARKSTATUS()
        {
            BLOCKDetail = new BLOCKDetail();
        }
    }

    public class BOARD
    {
        ///<summary>
        /// 
        ///</summary>
        public int PCBID { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public string PCBNAME { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public int SERIALNUMBER { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public string BARCODEDATA { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public int LANEID { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public BLOCK_ARRAYCOUNT BLOCK_ARRAYCOUNT { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public USE USE { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public BADMARKSTATUS BADMARKSTATUS { get; set; }

        public BOARD()
        {
            BLOCK_ARRAYCOUNT = new BLOCK_ARRAYCOUNT();
            USE = new USE();
            BADMARKSTATUS = new BADMARKSTATUS();
        }

    }

    public class TRANSFORTERFILE
    {
        ///<summary>
        /// 
        ///</summary>
        public GENERAL GENERAL { get; set; }
        ///<summary>
        /// 
        ///</summary>
        public BOARD BOARD { get; set; }

        public TRANSFORTERFILE()
        {
            GENERAL = new GENERAL();
            BOARD = new BOARD();
        }
    }

    public class HanwhaRoot
    {
        ///<summary>
        /// 
        ///</summary>
        public TRANSFORTERFILE TRANSFORTERFILE { get; set; }
        public HanwhaRoot()
        {
            TRANSFORTERFILE = new TRANSFORTERFILE();
        }

    }
}

/// <summary>
/// Compal 类
/// </summary>
namespace CompalClass
{
    [Serializable]
    public class SystemId
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string SPIVersion { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlText]
        public string text { get; set; }
    }
    public class Paste
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class Registration
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class Bridging
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class ImageFailures
    {
        /// <summary>
        /// 
        /// </summary>
        public Paste Paste { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Registration Registration { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Bridging Bridging { get; set; }

        public ImageFailures()
        {
            Paste = new Paste();
            Registration = new Registration();
            Bridging = new Bridging();
        }
    }
    public class LocationFailures
    {
        /// <summary>
        /// 
        /// </summary>
        public Paste Paste { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Registration Registration { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Bridging Bridging { get; set; }

        public LocationFailures()
        {
            Paste = new Paste();
            Registration = new Registration();
            Bridging = new Bridging();
        }

    }
    public class FeatureFailures
    {
        /// <summary>
        /// 
        /// </summary>
        public Paste Paste { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Registration Registration { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Bridging Bridging { get; set; }

        public FeatureFailures()
        {
            Paste = new Paste();
            Registration = new Registration();
            Bridging = new Bridging();
        }
    }
    public class Registration2
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string XOrigin { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string YOrigin { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string XOffset { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string YOffset { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Rotation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Scale { get; set; }
    }
    public class Diagnostics
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlElement("Registration")]
        public Registration2 Registration2 { get; set; }

        public Diagnostics()
        {
            Registration2 = new Registration2();
        }
    }
    public class PanelResult
    {
        /// <summary>
        /// 
        /// </summary>
        public ImageFailures ImageFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LocationFailures LocationFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public FeatureFailures FeatureFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Diagnostics Diagnostics { get; set; }

        public PanelResult()
        {
            ImageFailures = new ImageFailures();
            LocationFailures = new LocationFailures();
            FeatureFailures = new FeatureFailures();
            Diagnostics = new Diagnostics();
        }

    }
    public class ImageResult
    {
        /// <summary>
        /// 
        /// </summary>
        public LocationFailures LocationFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public FeatureFailures FeatureFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Diagnostics Diagnostics { get; set; }

        public ImageResult()
        {
            LocationFailures = new LocationFailures();
            FeatureFailures = new FeatureFailures();
            Diagnostics = new Diagnostics();
        }
    }
    public class HeightAvg
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class AreaAvg
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class VolumeAvg
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class HeightRange
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class AreaRange
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class VolumeRange
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Limit { get; set; }
    }
    public class LocationResult
    {
        /// <summary>
        /// 
        /// </summary>
        public HeightAvg HeightAvg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public AreaAvg AreaAvg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public VolumeAvg VolumeAvg { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public HeightRange HeightRange { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public AreaRange AreaRange { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public VolumeRange VolumeRange { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public FeatureFailures FeatureFailures { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Diagnostics Diagnostics { get; set; }

        public LocationResult()
        {
            HeightAvg = new HeightAvg();
            AreaAvg = new AreaAvg();
            VolumeAvg = new VolumeAvg();
            HeightRange = new HeightRange();
            AreaRange = new AreaRange();
            VolumeRange = new VolumeRange();
            FeatureFailures = new FeatureFailures();
            Diagnostics = new Diagnostics();
        }
    }
    public class Height
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class Area
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class Volume
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpFail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string UpWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Target { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowWarn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LowFail { get; set; }
    }
    public class Registration4
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string BoundaryStatus { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LongPct { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LongPctLimit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string ShortPct { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string ShortPctLimit { get; set; }
    }
    public class Registration3
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string XOffset { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string YOffset { get; set; }
    }
    public class Diagnostics3
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlElement("Registration")]
        public Registration3 Registration3 { get; set; }
        public Diagnostics3()
        {
            Registration3 = new Registration3();
        }
    }
    public class FeatureResult
    {
        /// <summary>
        /// 
        /// </summary>
        public Height Height { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Area Area { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Volume Volume { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement("Registration")]
        public Registration4 Registration4 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Bridging Bridging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement("Diagnostics")]
        public Diagnostics3 Diagnostics3 { get; set; }

        public FeatureResult()
        {
            Height = new Height();
            Area = new Area();
            Volume = new Volume();
            Registration4 = new Registration4();
            Bridging = new Bridging();
            Diagnostics3 = new Diagnostics3();
        }
    }
    public class Feature
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LogMode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string X { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Y { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public FeatureResult FeatureResult { get; set; }

        public Feature()
        {
            FeatureResult = new FeatureResult();
        }
    }
    public class Location
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Part { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Package { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string TestTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Id { get; set; }
        /// <summary>
        /// add by peng 20190611   ReworkError 不良代码
        /// </summary>
        [XmlAttribute]
        public string ReworkError { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LocationResult LocationResult { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement]
        public Feature[] Feature { get; set; }

        public Location()
        {
            LocationResult = new LocationResult();
        }
    }
    public class Image
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string TestTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ImageResult ImageResult { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement]
        public Location[] Location { get; set; }

        public Image()
        {
            ImageResult = new ImageResult();
        }
    }
    [Serializable]
    public class Panel
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string LotCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Device { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string NGCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string CarrierCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string PanelDefectPath { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string SqueegeeDir { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string PanelSizeX { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string PanelSizeY { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string PanelRotation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string StartTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string TestTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string CycleTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string Id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SRFFName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Units { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public PanelResult PanelResult { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlElement]
        public Image[] Image { get; set; }

        public Panel()
        {
            PanelResult = new PanelResult();
        }
    }
    [Serializable]
    public class Cyber_SPI_INFO
    {
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string xmlns_cyber { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string xmlns_xsi { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public string xsi_schemaLocation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public SystemId SystemId { get; set; }
        /// <summary>
        /// 
        /// </summary>     
        public Panel Panel { get; set; }

        public Cyber_SPI_INFO()
        {
            SystemId = new SystemId();
            Panel = new Panel();
        }
    }
}



namespace WSClnt
{
    public partial class DataExportJoch
    {
        private  Basefunction _wsBaseF;

        public DataExportJoch()
        {
            _wsBaseF = new Basefunction();
        }

        #region "Public Function"
   
      
        #endregion

        #region "品润 MES"
        ///<summary>
        /// 品润要求的MES格式如附件，文件名用主板条码_程式名.csv 命名。
        ///  如果没有主板条码，则用第一个拼板条码代替。
        ///  测试结果分为：GOOD/NG/PASS
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="Adict"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AbyLaneNo"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public String SaveBarcodeForPINRUN(
                    InspectMainLib.Pad[] APads,
                    SPCBoardRes ABrdRes,
                    ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                    AppSettingData AappSettingData,
                    AppMultiLan.AppLan Adict,
                    string AstrDir,  //export folder
                    byte AbyLaneNo,
                    string AstrClntName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            string strCSVFile = string.Empty;
            int iArrayCount = 0;
            try
            {
                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir =  PubStaticParam.RS_strTmpFileDir;

                DataTable dtPinRunBarcode = new DataTable();
                InitDataTableForPINRUN(ref dtPinRunBarcode, Adict);

                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }
                strCSVFile = Path.Combine(AstrDir, strboardBarcode + "_" + strJobName +  PubStaticParam.RS_CSV_EXT);

                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;

                if (!bISArrayPCB)
                {
                    DataRow dr = dtPinRunBarcode.NewRow();
                    dr[0] = strJobName;
                    dr[1] = strboardBarcode;
                    dr[2] = "--";
                    dr[3] = ABrdRes.jugResult.ToString();

                    dtPinRunBarcode.Rows.Add(dr);
                }
                else
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        //array 0 没有被使用.
                        if (i == 0 && bPosZeroISUsed == false)
                        {
                            continue;
                        }

                        DataRow dr = dtPinRunBarcode.NewRow();
                        dr[0] = strJobName;
                        dr[1] = strboardBarcode;
                        dr[2] = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                        int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                        string ArrayResult = string.Empty;

                        //switch (ArrayStatus)
                        //{
                        //    case 0: //Good
                        //        ArrayResult = "GOOD";
                        //        break;
                        //    case 1: //NG
                        //        ArrayResult = "NG";
                        //        break;
                        //    case 2://PASS
                        //        ArrayResult = "PASS";
                        //        break;
                        //    case 3: //Unmeasured
                        //        break;
                        //    case 4: //Skipped
                        //        break;
                        //    default:
                        //        break;
                        //}
                        if (ArrayStatus == -1)
                        {
                            ArrayResult = JudgeRes.Skipped.ToString().ToUpper();
                        }
                        else
                        {
                            ArrayResult = ((JudgeRes)(ArrayStatus)).ToString().ToUpper();
                        }

                        dr[3] = ArrayResult;
                        dr[4] = ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                        dtPinRunBarcode.Rows.Add(dr);
                    }

                }

                strMsg +=SaveData2File.SaveDataTable2CSVFile(dtPinRunBarcode, strCSVFile);
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(SaveBarcodeForPINRUN)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }



        public string InitDataTableForPINRUN(ref DataTable Adt, AppMultiLan.AppLan Adict)
        {
            string strReturn = string.Empty;
            try
            {
                //机种
                //Adt.Columns.Add("机种");
                //大板条码
                //Adt.Columns.Add("大板条码");
                //小板条码
                //Adt.Columns.Add("小板条码");
                //测试结果
                //Adt.Columns.Add("测试结果");
                //测试时间
                //Adt.Columns.Add("测试时间");

                //机种
                Adt.Columns.Add("Bar-No");
                //大板条码
                Adt.Columns.Add("Barcode-No");
                //小板条码
                Adt.Columns.Add("ArrayBarcode-No");
                //测试结果
                Adt.Columns.Add("Resule");
                //测试时间
                Adt.Columns.Add("Date-Time");

                Adt.EndInit();
            }
            catch (Exception ex)
            {
                strReturn += ex.Message.ToString();
                throw ex;
            }
            finally
            {

            }
            return strReturn;

        }
        #endregion

        #region "东莞杰拓（万利升）MES"
        ///<summary>
        /// 1. 文件名为整版PCB条码, 如果没有PCB条码则按当前日期完整格式(20170705090000)命名
        ///      a)      每行的第一个分号前的字符串为 为拼板条码，如果没有就显示程序名
        ///      b)     每行的第一个分号与第二个分号之间的字符串表示 拼板序号
        ///      c)      每行的第二个分号与第三个分号之间的字符串 PCB整版测试开始时间
        ///      d)     每行的第三个分号与第四个分号之间的字符串表示测试结果，“PASS”表示测试OK，“FALL”表示测试NG，，如序号4所示。 拼板的测试结果, SKIPED 不显示
        ///      e)      每行的第四个与第五个分号之间的字符串表示此笔测试记录中出现的不良代码确认为UI上自定义显示，有一个项目就显示一个项目，重复的就显示一个。
        ///      f)       文档到空行时结束如序号8所示。
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="Adict"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AbyLaneNo"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public String SaveBarcodeForJIETUO(
                    InspectMainLib.Pad[] APads,
                    SPCBoardRes ABrdRes,
                    ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                    AppSettingData AappSettingData,
                    AppMultiLan.AppLan Adict,
                    string AstrDir,  //export folder
                    byte AbyLaneNo,
                    string AstrClntName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            string strTXTFile = string.Empty;
            int iArrayCount = 0;
            string strTXTContents = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir =  PubStaticParam.RS_strTmpFileDir;


                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (String.Equals(strboardBarcode,  PubStaticParam.RS_NOREAD))
                    strboardBarcode = DateTime.Now.ToString(  PubStaticParam.RS_Format_DateTimeFileName);

                strTXTFile = Path.Combine(AstrDir, strboardBarcode +  PubStaticParam.RS_TXT_EXT);
                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }

                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;

                if (bISArrayPCB)
                {
                    strTXTContents = string.Empty;

                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        //array 0 没有被使用.
                        if (i == 0 && bPosZeroISUsed == false)
                        {
                            continue;
                        }

                        int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                        string ArrayResult = string.Empty;
                        switch (ArrayStatus)
                        {
                            case 0:
                            case 2://PASS
                                ArrayResult = "PASS";
                                break;
                            case 1: //FALL
                                ArrayResult = "FALL";
                                break;
                            default:
                                break;
                        }
                        if (string.IsNullOrEmpty(ArrayResult))
                        {
                            continue;
                        }

                        string strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                        if (string.IsNullOrEmpty(strArrayBarcode))
                            strArrayBarcode = strJobName;

                        strTXTContents += strArrayBarcode +  PubStaticParam.RS_SemicolonSplit;
                        strTXTContents += APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID.ToString() +  PubStaticParam.RS_SemicolonSplit;
                        strTXTContents += ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATETIME) +  PubStaticParam.RS_SemicolonSplit;
                        strTXTContents += ArrayResult +  PubStaticParam.RS_SemicolonSplit;
                        string strPadErrorCode = string.Empty, strArrayErrorCode = string.Empty;
                        if (ArrayResult == "FALL")
                        {
                            foreach (int intPadIndex in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices)
                            {
                                if (intPadIndex < APads.Length)
                                {
                                    if (APads[intPadIndex].isTmpSkipped == false)
                                    {
                                        strPadErrorCode = _wsBaseF.GetPadErrorCodeStr(APads[intPadIndex], AappSettingData) +  PubStaticParam.RS_CommaSplit;
                                        if (strArrayErrorCode.Contains(strPadErrorCode) == false)
                                        {
                                            strArrayErrorCode += strPadErrorCode;
                                        }
                                    }
                                }
                            }
                            if (strArrayErrorCode ==  PubStaticParam.RS_CommaSplit)
                                strArrayErrorCode = string.Empty;
                            else
                            {
                                if (strArrayErrorCode.EndsWith( PubStaticParam.RS_CommaSplit) && strArrayErrorCode.Length >= 2)
                                    strArrayErrorCode = strArrayErrorCode.Remove(strArrayErrorCode.Length - 1, 1);
                            }

                        }
                        strTXTContents += strArrayErrorCode +  PubStaticParam.RS_SemicolonSplit;
                        strTXTContents += PubStaticParam.RS_LineEnd;
                    }

                    if (!string.IsNullOrEmpty(strTXTContents))
                    {
                        strTXTContents += PubStaticParam.RS_LineEnd;
                        File.WriteAllText(strTXTFile, strTXTContents);
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(SaveBarcodeForJIETUO)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        #endregion

        #region "苏州维信 MES"
        ///
        /// 检查PCB前先判断Barcode是否正常. OK继续, 否则停机报警. 可以离线保存上发格式的文件
        /// 检查结果保存成文件. 后台上发上去.
        /// 更新测试结果. 本机的和维修工作站的. 保存成文件 后台更新上去
        /// 重要情况记录. 记录停机等的情况. 
        /// 
        private string RS_WEIXIN_CheckBarcoeDirectoryName = "WEIXIN_CheckBarcode";
        private string RS_WEIXIN_MESSaveResultDirectoryName = "WEIXIN_MESSaveResult";
        private string RS_WEIXIN_MESMachineUsageDirectoryName = "WEIXIN_MESMachineUsage";

        class MainInfos : Model.MainInfo
        {
            public string[] Result { get; set; }
        }

        ///<summary>
        ///  将Barcode信息上发到服务器并保存成文件. 
        ///  1.	产品条码不存在于系统  2.	当前Spec不正确   3.	当前设备未配置    4.	传入类型不正确
        ///</summary>
        ///<param name="AsBarCode"></param>
        ///<param name="AsLineNo"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorName"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AstrDir">export folder</param>
        ///<returns></returns>
        public string CheckBarcodeCanBeInspectedForWEIXIN(
                    AppSettingData AappSettingData,
                    string AsBarCode,
                    SPCBoardRes ABrdRes,
                    byte AbyLaneNo,
                    string AstrDir,
                    out byte[] arrByteBadMark)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            MainInfos mfeMainInfos = new MainInfos();
            Model.MainInfo mfeMainInfo = new Model.MainInfo();
            arrByteBadMark = null;
            try
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("CheckBarcodeCanBeInspectedForWEIXIN Start ");
                }

                if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strMacAddress))
                {
                    AappSettingData.stDataExpVT.strMacAddress = _wsBaseF.GetMacAddress();
                }
                if (!string.IsNullOrEmpty(AsBarCode))
                {
                    if (string.IsNullOrEmpty(AstrDir))
                        AstrDir = Path.Combine( PubStaticParam.RS_strTmpFileDir, RS_WEIXIN_CheckBarcoeDirectoryName);
                    else
                        AstrDir = Path.Combine(AstrDir, RS_WEIXIN_CheckBarcoeDirectoryName);

                    if (Directory.Exists(AstrDir) == false)
                    {
                        Directory.CreateDirectory(AstrDir);
                    }

                    AstrDir = Path.Combine(AstrDir, AsBarCode +  PubStaticParam.RS_TXT_EXT);

                    string strJobName = ABrdRes.jobName;
                    string strJobNameLasterWorld = string.Empty;
                    if (File.Exists(strJobName) || strJobName.Contains(":"))
                    {
                        strJobName = Path.GetFileNameWithoutExtension(strJobName);
                    }
                    strJobNameLasterWorld = strJobName.Remove(0, strJobName.Length - 1);

                    mfeMainInfos.Panel = mfeMainInfo.Panel = AsBarCode;
                    mfeMainInfos.Resource = mfeMainInfo.Resource = AappSettingData.LineName;
                    mfeMainInfos.Machine = mfeMainInfo.Machine = AappSettingData.stDataExpVT.strMachine;
                    mfeMainInfos.WorkArea = mfeMainInfo.WorkArea = AappSettingData.stDataExpVT.strWorkArea;
                    mfeMainInfos.TestType = mfeMainInfo.TestType = AappSettingData.stDataExpVT.strTestType;
                    mfeMainInfos.OperatorName = mfeMainInfo.OperatorName = AappSettingData.strDataExpOperator;
                    mfeMainInfos.OperatorType = mfeMainInfo.OperatorType = AappSettingData.stDataExpVT.strOperatorType;
                    mfeMainInfos.TrackType = mfeMainInfo.TrackType = AappSettingData.stDataExpVT.stDELaneParams[AbyLaneNo].strUserDefinedLaneName;
                    mfeMainInfos.Site = mfeMainInfo.Site = AappSettingData.stDataExpVT.strSite;
                    mfeMainInfos.Mac = mfeMainInfo.Mac = AappSettingData.stDataExpVT.strMacAddress;

                
                    mfeMainInfos.ProgramName = mfeMainInfo.ProgramName = strJobName;

                    if (AappSettingData.enPadDebug)
                    {
                        PubStaticParam._log.WriteDebug("上传数据到 CheckBaseInfo  ");
                    }
                    string[] arrReturn = MFlexEquipmentProject.EquipmentInterActive.CheckBaseInfo(mfeMainInfo);
                    if (AappSettingData.enPadDebug)
                    {
                        PubStaticParam._log.WriteDebug("获取返回数据 CheckBaseInfo  ");
                    }
                    if (arrReturn.Length > 0)
                    {
                        if (arrReturn[0] == "0")
                        {
                            //[OK|OK|OK|OK|OK|OK|OK|OK|OK]
                            string[] arrStrBadMark = arrReturn[1].ToString().Split('|');
                            int iBadMarkLength = arrStrBadMark.Length;
                            arrByteBadMark = new byte[iBadMarkLength];
                            for (int j = 0; j < iBadMarkLength; j++)
                            {
                                string strBadMark = arrStrBadMark[j];
                                if (strBadMark.Trim().ToUpper().Contains("NG") || 
                                    strBadMark.Trim().ToUpper().Contains("BK"))
                                {
                                    arrByteBadMark[j] = 1;
                                }
                                else
                                {
                                    arrByteBadMark[j] = 0;
                                }
                            } 
                        }
                        else
                        {
                            strMsg += arrReturn[1].ToString();
                        }

                        if (AappSettingData.enPadDebug)
                        {
                            PubStaticParam._log.WriteDebug("返回数据 CheckBaseInfo : " + arrReturn[1].ToString());
                        }
                    }
                    mfeMainInfos.Result = arrReturn;

                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeCanBeInspectedForWEIXIN)" + ex.Message.ToString();

                if (mfeMainInfos.Result == null)
                {
                    mfeMainInfos.Result = new string[] { strMsg };
                }
                else
                {
                    mfeMainInfos.Result[0] += strMsg;
                }
                PubStaticParam._log.WriteErr(ex);
            }
            finally
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("CheckBarcodeCanBeInspectedForWEIXIN SaveObject2JsonFile 开始: ");
                    JsonHelper.SaveObject2JsonFile(mfeMainInfos, AstrDir);
                    PubStaticParam._log.WriteDebug("CheckBarcodeCanBeInspectedForWEIXIN SaveObject2JsonFile 完成: ");
                }
            }
            return strMsg;
        }

        ///<summary>
        ///  将MESSaveResult上传到MES并保存成文件 Inspection Station
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="Adict"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string MESSaveResultInspectionStationForWEIXIN(
                    InspectMainLib.Pad[] APads,
                   SPCBoardRes ABrdRes,
                   ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                   AppSettingData AappSettingData,
                   AppMultiLan.AppLan Adict,
                   string AstrDir,  //export folder      
                   string AstrClntName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            int iArrayCount = 0;
            Model.MainInfo mfeMainInfo = new Model.MainInfo();

            try
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultInspectionStationForWEIXIN 开始 ");
                }
                if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strMacAddress))
                {
                    AappSettingData.stDataExpVT.strMacAddress = _wsBaseF.GetMacAddress();
                }
                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                    AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (!string.IsNullOrEmpty(strboardBarcode))
                {
                    if (string.IsNullOrEmpty(AstrDir))
                        AstrDir = Path.Combine( PubStaticParam.RS_strTmpFileDir, RS_WEIXIN_MESSaveResultDirectoryName);
                    else
                        AstrDir = Path.Combine(AstrDir, RS_WEIXIN_MESSaveResultDirectoryName);

                    if (Directory.Exists(AstrDir) == false)
                    {
                        Directory.CreateDirectory(AstrDir);
                    }

                    AstrDir = Path.Combine(AstrDir, strboardBarcode +  PubStaticParam.RS_TXT_EXT);

                    string strJobName = ABrdRes.jobName;
                    string strJobNameLasterWorld = string.Empty;
                    if (File.Exists(strJobName) || strJobName.Contains(":"))
                    {
                        strJobName = Path.GetFileNameWithoutExtension(strJobName);
                    }
                    strJobNameLasterWorld = strJobName.Remove(0, strJobName.Length - 1);

                    mfeMainInfo.Panel = strboardBarcode;
                    mfeMainInfo.Resource = AappSettingData.LineName;
                    mfeMainInfo.Machine = AappSettingData.stDataExpVT.strMachine;
                    mfeMainInfo.WorkArea = AappSettingData.stDataExpVT.strWorkArea;
                    //需求修改, 增加JobName最后一个字符.20180627 
                    mfeMainInfo.TestType = AappSettingData.stDataExpVT.strTestType+ strJobNameLasterWorld;
                    mfeMainInfo.OperatorName = AappSettingData.strDataExpOperator;
                    mfeMainInfo.OperatorType = AappSettingData.stDataExpVT.strOperatorType;
                    mfeMainInfo.TrackType = AappSettingData.stDataExpVT.stDELaneParams[ABrdRes.LaneNo].strUserDefinedLaneName;
                    mfeMainInfo.Site = AappSettingData.stDataExpVT.strSite;
                    mfeMainInfo.Mac = AappSettingData.stDataExpVT.strMacAddress;
                    mfeMainInfo.ProgramName = strJobName;

                    bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                    bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;

                    if (bISArrayPCB)
                    {
                        iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        string strArrayName = string.Empty;

                        Dictionary<string, string> dicSummarys = new Dictionary<string, string>();
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            //array 0 没有被使用.
                            if (i == 0 && bPosZeroISUsed == false)
                            {
                                continue;
                            }

                            int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                            string ArrayResult = string.Empty;
                            //ArrayStatus =-1 没有检测
                            switch (ArrayStatus)
                            {
                                case 0:
                                case 2://PASS
                                    ArrayResult = "PASS";
                                    break;
                                case 1: //FALL
                                    ArrayResult = "FALL";
                                    break;
                                default:
                                    break;
                            }
                            if (string.IsNullOrEmpty(ArrayResult))
                            {
                                continue;
                            }
                            strArrayName = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (dicSummarys.Keys.Contains(strArrayName) == false)
                            {
                                dicSummarys.Add(strArrayName, ArrayResult);
                            }
                        }

                        int iSummarysCount = dicSummarys.Count;
                        int iSummarysIndex = 0;
                        mfeMainInfo.PcsSummarys = new Summarys[iSummarysCount];

                        foreach (string strKeyName in dicSummarys.Keys)
                        {
                            Summarys s1 = new Summarys();
                            s1.PanelId = strboardBarcode;
                            s1.PcsSeq = strKeyName;
                            s1.TestResult = dicSummarys[strKeyName];
                            s1.OperatorName = AappSettingData.strDataExpOperator;
                            s1.VerifyResult = dicSummarys[strKeyName];
                            s1.VerifyOperatorName = "";
                            s1.VerifyTime = ABrdRes.opConfirmTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                            mfeMainInfo.PcsSummarys[iSummarysIndex] = s1;
                            iSummarysIndex++;
                        }


                        Dictionary<string, JudgeRes> dicPinNumber = new Dictionary<string, JudgeRes>();
                        Dictionary<string, string> dicPinErrorCode = new Dictionary<string, string>();

                        for (int i = 0; i < iArrayCount; i++)
                        {
                            //array 0 没有被使用.
                            if (i == 0 && bPosZeroISUsed == false)
                            {
                                continue;
                            }

                            int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                            string ArrayResult = string.Empty;
                            //ArrayStatus =-1 没有检测
                            switch (ArrayStatus)
                            {
                                case 0:
                                case 2://PASS
                                    ArrayResult = "PASS";
                                    break;
                                case 1: //FALL
                                    ArrayResult = "FALL";
                                    break;
                                default:
                                    break;
                            }
                            if (string.IsNullOrEmpty(ArrayResult))
                            {
                                continue;
                            }

                            int intComponentCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrComponentInfo.Length;

                            for (int j = 0; j < intComponentCount; j++)
                            {
                                int[] iArrPadList = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrComponentInfo[j].arrPadIndices;

                                foreach (int padIndex in iArrPadList)
                                {
                                    if (padIndex < APads.Length)
                                    {
                                        //Q.F.2017.09.08
                                        if (_wsBaseF.bPadIsSkip(APads[padIndex]))
                                            continue;

                                        // string strPinNumber = APads[padIndex].pinNumber;
                                        string strPinNumber = APads[padIndex].strArrayID + "_" + APads[padIndex].componentID + "_" + APads[padIndex].pinNumber;
                                        JudgeRes strResult = APads[padIndex].res.jugRes;
                                        string strErrorCode = string.Empty;

                                        if (strResult == JudgeRes.NG || strResult == JudgeRes.Pass)
                                        {
                                            strErrorCode = _wsBaseF.GetPadErrorCodeStr(APads[padIndex], AappSettingData) +  PubStaticParam.RS_SemicolonSplit;
                                        }

                                        if (dicPinNumber.Keys.Contains(strPinNumber) == false)
                                        {
                                            dicPinNumber.Add(strPinNumber, strResult);
                                        }
                                        else
                                        {
                                            JudgeRes jrValue = 0;
                                            if (dicPinNumber.TryGetValue(strPinNumber, out jrValue))
                                            {
                                                if (strResult != jrValue && jrValue == JudgeRes.Good)
                                                {
                                                    dicPinNumber[strPinNumber] = strResult;
                                                }

                                                if (strResult != JudgeRes.NG && jrValue == JudgeRes.Pass)
                                                {
                                                    dicPinNumber[strPinNumber] = strResult;
                                                }
                                            }
                                        }

                                        if (dicPinErrorCode.Keys.Contains(strPinNumber) == false)
                                        {
                                            dicPinErrorCode.Add(strPinNumber, strErrorCode);
                                        }
                                        else
                                        {
                                            string strError = string.Empty;
                                            if (dicPinErrorCode.TryGetValue(strPinNumber, out strError))
                                            {
                                                if (!string.IsNullOrEmpty(strErrorCode)
                                                    && strError.Contains(strErrorCode) == false)
                                                {
                                                    dicPinErrorCode[strPinNumber] += strErrorCode;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        string strPcsSeq = string.Empty;
                        string strPartSeq = string.Empty;
                        string strPinSeq = string.Empty;

                        int iPinNumberLength = dicPinNumber.Keys.Count;
                        int iPinNumberIndex = 0;
                        mfeMainInfo.PcsDetails = new Details[iPinNumberLength];

                        foreach (string strPinNumber in dicPinNumber.Keys)
                        {
                            Details d1 = new Details();
                            string[] arrPinName = strPinNumber.Split('_');
                            strPcsSeq = arrPinName[0];
                            if (arrPinName.Length == 3)
                            {
                                strPartSeq = arrPinName[1];
                                strPinSeq = arrPinName[2];
                            }

                            d1.PanelId = strboardBarcode;
                            d1.PcsSeq = strPcsSeq;
                            d1.PartSeq = strPartSeq;
                            d1.PinSeq = strPinSeq;
                            JudgeRes jrValue = 0;
                            dicPinNumber.TryGetValue(strPinNumber, out jrValue);
                            string strErrorCode = string.Empty;
                            dicPinErrorCode.TryGetValue(strPinNumber, out strErrorCode);

                            if (jrValue == JudgeRes.Good || jrValue == JudgeRes.Pass)
                            {
                                d1.TestResult = "PASS";
                            }
                            else
                            {
                                d1.TestResult = "FAIL";
                            }

                            d1.OperatorName = AappSettingData.strDataExpOperator;
                            d1.VerifyResult = d1.TestResult;
                            d1.VerifyOperatorName = "";
                            d1.VerifyTime = ABrdRes.opConfirmTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                            d1.DefectCode = strErrorCode;
                            d1.BubbleValue = "0"; //MIC气泡的百分比
                            d1.ImagePath = "";//
                            d1.Description = "";
                            d1.TestFile = "";
                            mfeMainInfo.PcsDetails[iPinNumberIndex] = d1;
                            iPinNumberIndex++;
                        }
                    }
                }
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MES_SaveResult 开始 ");
                }
                string[] arrReturn = MFlexEquipmentProject.EquipmentInterActive.MES_SaveResult(mfeMainInfo);
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MES_SaveResult 完成 ");
                }
                if (arrReturn.Length > 0)
                {
                    if (arrReturn[0] == "0")
                    {
                        //File.Delete(strFile);
                        // arrReturn[1].ToString();
                    }
                    else
                    {
                        strMsg += arrReturn[1].ToString();
                        strMsg += "\r\n" + AstrDir;
                    }

                    if (AappSettingData.enPadDebug)
                    {
                        PubStaticParam._log.WriteDebug("返回数据 MES_SaveResult : " + arrReturn[1].ToString());
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultInspectionStationForWEIXIN)" + ex.Message.ToString();
                PubStaticParam._log.WriteErr(ex);
            }
            finally
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultInspectionStationForWEIXIN SaveObject2JsonFile 开始 ");
                    JsonHelper.SaveObject2JsonFile(mfeMainInfo, AstrDir);
                    PubStaticParam._log.WriteDebug("MESSaveResultInspectionStationForWEIXIN SaveObject2JsonFile 完成 ");

                }
            }
            return strMsg;
        }

        ///<summary>
        /// 将MESSaveResult保存成文件Verification Station
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="Adict"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string MESSaveResultVerificationStationForWEIXIN(
                    InspectMainLib.Pad[] APads,
                   SPCBoardRes ABrdRes,
                   ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                   AppSettingData AappSettingData,
                   AppMultiLan.AppLan Adict,
                   string AstrDir,  //export folder      
                   string AstrClntName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            int iArrayCount = 0;
            Model.MainInfo mfeMainInfo = new Model.MainInfo();

            try
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN 开始");
                }
                if (string.IsNullOrEmpty(AappSettingData.stDataExpVT.strMacAddress))
                {
                    AappSettingData.stDataExpVT.strMacAddress = _wsBaseF.GetMacAddress();
                }
                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                    AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (!string.IsNullOrEmpty(strboardBarcode))
                {
                    if (string.IsNullOrEmpty(AstrDir))
                        AstrDir = Path.Combine(PubStaticParam.RS_strTmpFileDir, RS_WEIXIN_MESSaveResultDirectoryName);
                    else
                        AstrDir = Path.Combine(AstrDir, RS_WEIXIN_MESSaveResultDirectoryName);

                    if (Directory.Exists(AstrDir) == false)
                    {
                        Directory.CreateDirectory(AstrDir);
                    }

                    AstrDir = Path.Combine(AstrDir, strboardBarcode + PubStaticParam.RS_TXT_EXT);

                    string strJobName = ABrdRes.jobName;
                    string strJobNameLasterWorld = string.Empty;
                    if (File.Exists(strJobName) || strJobName.Contains(":"))
                    {
                        strJobName = Path.GetFileNameWithoutExtension(strJobName);
                    }
                    strJobNameLasterWorld = strJobName.Remove(0, strJobName.Length - 1);

                    mfeMainInfo.Panel = strboardBarcode;
                    mfeMainInfo.Resource = AappSettingData.LineName;
                    mfeMainInfo.Machine = AappSettingData.stDataExpVT.strMachine;
                    mfeMainInfo.WorkArea = AappSettingData.stDataExpVT.strWorkArea;
                    mfeMainInfo.TestType = AappSettingData.stDataExpVT.strTestType + strJobNameLasterWorld;
                    mfeMainInfo.OperatorName = AappSettingData.strDataExpOperator;
                    mfeMainInfo.OperatorType = AappSettingData.stDataExpVT.strOperatorType;
                    mfeMainInfo.TrackType = AappSettingData.stDataExpVT.stDELaneParams[ABrdRes.LaneNo].strUserDefinedLaneName;
                    mfeMainInfo.Site = AappSettingData.stDataExpVT.strSite;
                    mfeMainInfo.Mac = AappSettingData.stDataExpVT.strMacAddress;
                    mfeMainInfo.ProgramName = strJobName;

                    bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                    bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;

                    if (bISArrayPCB)
                    {
                        iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                        string strArrayName = string.Empty;

                        Dictionary<string, string> dicSummarys = new Dictionary<string, string>();
                        for (int i = 0; i < iArrayCount; i++)
                        {
                            //array 0 没有被使用.
                            if (i == 0 && bPosZeroISUsed == false)
                            {
                                continue;
                            }

                            int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                            string ArrayResult = string.Empty;
                            //ArrayStatus =-1 没有检测
                            switch (ArrayStatus)
                            {
                                case 0:
                                case 2://PASS
                                    ArrayResult = "PASS";
                                    break;
                                case 1: //FALL
                                    ArrayResult = "FALL";
                                    break;
                                default:
                                    break;
                            }
                            if (string.IsNullOrEmpty(ArrayResult))
                            {
                                continue;
                            }
                            strArrayName = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID;
                            if (dicSummarys.Keys.Contains(strArrayName) == false)
                            {
                                dicSummarys.Add(strArrayName, ArrayResult);
                            }
                        }

                        int iSummarysCount = dicSummarys.Count;
                        int iSummarysIndex = 0;
                        mfeMainInfo.PcsSummarys = new Summarys[iSummarysCount];

                        foreach (string strKeyName in dicSummarys.Keys)
                        {
                            Summarys s1 = new Summarys();
                            s1.PanelId = strboardBarcode;
                            s1.PcsSeq = strKeyName;
                            s1.TestResult = dicSummarys[strKeyName];
                            s1.OperatorName = AappSettingData.strDataExpOperator;
                            s1.VerifyResult = dicSummarys[strKeyName];
                            s1.VerifyOperatorName = "";
                            s1.VerifyTime = ABrdRes.opConfirmTime.ToString(PubStaticParam.RS_FORMAT_DATETIME);
                            mfeMainInfo.PcsSummarys[iSummarysIndex] = s1;
                            iSummarysIndex++;
                        }


                        Dictionary<string, JudgeRes> dicPinNumber = new Dictionary<string, JudgeRes>();
                        Dictionary<string, string> dicPinErrorCode = new Dictionary<string, string>();

                        for (int i = 0; i < iArrayCount; i++)
                        {
                            //array 0 没有被使用.
                            if (i == 0 && bPosZeroISUsed == false)
                            {
                                continue;
                            }

                            int ArrayStatus = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus;
                            string ArrayResult = string.Empty;
                            //ArrayStatus =-1 没有检测
                            switch (ArrayStatus)
                            {
                                case 0:
                                case 2://PASS
                                    ArrayResult = "PASS";
                                    break;
                                case 1: //FALL
                                    ArrayResult = "FALL";
                                    break;
                                default:
                                    break;
                            }
                            if (string.IsNullOrEmpty(ArrayResult))
                            {
                                continue;
                            }

                            int intComponentCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrComponentInfo.Length;

                            for (int j = 0; j < intComponentCount; j++)
                            {
                                int[] iArrPadList = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrComponentInfo[j].arrPadIndices;

                                foreach (int padIndex in iArrPadList)
                                {
                                    if (padIndex < APads.Length)
                                    {
                                        //Q.F.2017.09.08
                                        if (_wsBaseF.bPadIsSkip(APads[padIndex]))
                                            continue;

                                        // string strPinNumber = APads[padIndex].pinNumber;
                                        string strPinNumber = APads[padIndex].strArrayID + "_" + APads[padIndex].componentID + "_" + APads[padIndex].pinNumber;
                                        JudgeRes strResult = APads[padIndex].res.jugRes;
                                        string strErrorCode = string.Empty;

                                        if (strResult == JudgeRes.NG || strResult == JudgeRes.Pass)
                                        {
                                            strErrorCode = _wsBaseF.GetPadErrorCodeStr(APads[padIndex], AappSettingData) + PubStaticParam.RS_SemicolonSplit;
                                        }

                                        if (dicPinNumber.Keys.Contains(strPinNumber) == false)
                                        {
                                            dicPinNumber.Add(strPinNumber, strResult);
                                        }
                                        else
                                        {
                                            JudgeRes jrValue = 0;
                                            if (dicPinNumber.TryGetValue(strPinNumber, out jrValue))
                                            {
                                                if (strResult != jrValue && jrValue == JudgeRes.Good)
                                                {
                                                    dicPinNumber[strPinNumber] = strResult;
                                                }

                                                if (strResult != JudgeRes.NG && jrValue == JudgeRes.Pass)
                                                {
                                                    dicPinNumber[strPinNumber] = strResult;
                                                }
                                            }
                                        }

                                        if (dicPinErrorCode.Keys.Contains(strPinNumber) == false)
                                        {
                                            dicPinErrorCode.Add(strPinNumber, strErrorCode);
                                        }
                                        else
                                        {
                                            string strError = string.Empty;
                                            if (dicPinErrorCode.TryGetValue(strPinNumber, out strError))
                                            {
                                                if (!string.IsNullOrEmpty(strErrorCode)
                                                    && strError.Contains(strErrorCode) == false)
                                                {
                                                    dicPinErrorCode[strPinNumber] += strErrorCode;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        string strPcsSeq = string.Empty;
                        string strPartSeq = string.Empty;
                        string strPinSeq = string.Empty;

                        int iPinNumberLength = dicPinNumber.Keys.Count;
                        int iPinNumberIndex = 0;
                        mfeMainInfo.PcsDetails = new Details[iPinNumberLength];

                        foreach (string strPinNumber in dicPinNumber.Keys)
                        {
                            Details d1 = new Details();
                            string[] arrPinName = strPinNumber.Split('_');
                            strPcsSeq = arrPinName[0];
                            if (arrPinName.Length == 3)
                            {
                                strPartSeq = arrPinName[1];
                                strPinSeq = arrPinName[2];
                            }

                            d1.PanelId = strboardBarcode;
                            d1.PcsSeq = strPcsSeq;
                            d1.PartSeq = strPartSeq;
                            d1.PinSeq = strPinSeq;
                            JudgeRes jrValue = 0;
                            dicPinNumber.TryGetValue(strPinNumber, out jrValue);
                            string strErrorCode = string.Empty;
                            dicPinErrorCode.TryGetValue(strPinNumber, out strErrorCode);

                            if (jrValue == JudgeRes.Good || jrValue == JudgeRes.Pass)
                            {
                                d1.TestResult = "PASS";
                            }
                            else
                            {
                                d1.TestResult = "FAIL";
                            }

                            d1.OperatorName = AappSettingData.strDataExpOperator;
                            d1.VerifyResult = d1.TestResult;
                            d1.VerifyOperatorName = AappSettingData.strDataExpOperator;
                            d1.VerifyTime = ABrdRes.opConfirmTime.ToString(PubStaticParam.RS_FORMAT_DATETIME);
                            d1.DefectCode = strErrorCode;
                            d1.BubbleValue = "0"; //MIC气泡的百分比
                            d1.ImagePath = "";//
                            d1.Description = "";
                            d1.TestFile = "";
                            mfeMainInfo.PcsDetails[iPinNumberIndex] = d1;
                            iPinNumberIndex++;
                        }
                    }
                }
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN  MES_SaveResult 开始");
                }
                string[] arrReturn = MFlexEquipmentProject.EquipmentInterActive.MES_SaveResult(mfeMainInfo);
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN  MES_SaveResult 完成");
                }
                if (arrReturn.Length > 0)
                {
                    if (arrReturn[0] == "0")
                    {
                        //File.Delete(strFile);
                        // arrReturn[1].ToString();
                    }
                    else
                    {
                        strMsg += arrReturn[1].ToString();
                        strMsg += "\r\n" + AstrDir;
                    }

                    if (AappSettingData.enPadDebug)
                    {
                        PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN  MES_SaveResult 返回结果:" + arrReturn[1].ToString());
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultInspectionStationForWEIXIN)" + ex.Message.ToString();
                PubStaticParam._log.WriteErr(ex);
            }
            finally
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN  SaveObject2JsonFile 开始");
                    JsonHelper.SaveObject2JsonFile(mfeMainInfo, AstrDir);
                    PubStaticParam._log.WriteDebug("MESSaveResultVerificationStationForWEIXIN  SaveObject2JsonFile 结束");
                }
            }
            return strMsg;
        }
        ///<summary>
        /// 记录设备运行时间状况，遇到如下情况需要反馈给MES，IDLE（空闲未投料），人为停机（暂停，急停，保养），对停止设备进行分权限管控，若是无权限停止设备，需报警提示。
        ///</summary>
        ///<param name="AsLineNo"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorName"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AdtStartTime"></param>
        ///<param name="AdtEndTime"></param>
        ///<param name="AsShutDownType"></param>
        ///<param name="AstrDir"></param>
        ///<returns></returns>
        public String MESMachineUsageForWEIXIN(
                    string AsLineNo,
                    string AsMachine,
                    string AsWorkArea,
                    string AsTestType,
                    string AsOperatorName,
                    string AsOperatorType,
                    string AsTrackType,
                    string AsSite,
                    string AsMac,
                    DateTime AdtStartTime,
                    DateTime AdtEndTime,
                    string AsShutDownType,
                    string AstrDir,
                     AppSettingData AappSettingData)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            Model.MainInfo mfeMainInfo = new Model.MainInfo();
            try
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN  开始");
                }
                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir = Path.Combine( PubStaticParam.RS_strTmpFileDir, RS_WEIXIN_MESMachineUsageDirectoryName);
                else
                    AstrDir = Path.Combine(AstrDir, RS_WEIXIN_MESMachineUsageDirectoryName);

                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                AstrDir = Path.Combine(AstrDir, AdtStartTime.ToString( PubStaticParam.RS_FORMAT_DATETIME) +  PubStaticParam.RS_TXT_EXT);

                mfeMainInfo.Resource = AsLineNo;
                mfeMainInfo.Machine = AsMachine;
                mfeMainInfo.WorkArea = AsWorkArea;
                mfeMainInfo.TestType = AsTestType;
                mfeMainInfo.OperatorName = AsOperatorName;
                mfeMainInfo.Site = AsSite;
                mfeMainInfo.Mac = AsMac;

                mfeMainInfo.PcsSummarys = new Summarys[1];

                Summarys s1 = new Summarys();
                s1.StartTime = AdtStartTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                s1.EndTime = AdtEndTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                s1.ShutDownType = AsShutDownType;
                s1.OperatorName = AsOperatorName;
                mfeMainInfo.PcsSummarys[0] = s1;
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN MES_MachineUsage 开始");
                }
                string[] arrReturn = MFlexEquipmentProject.EquipmentInterActive.MES_MachineUsage(mfeMainInfo);
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN MES_MachineUsage 完成");
                }
                if (arrReturn.Length > 0)
                {
                    if (arrReturn[0] == "0")
                    {

                    }
                    else
                    {
                        strMsg += arrReturn[1].ToString();
                    }
                    if (AappSettingData.enPadDebug)
                    {
                        PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN MES_MachineUsage 返回值:" + arrReturn[1].ToString());
                    }

                }

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESMachineUsageForWEIXIN)" + ex.Message.ToString();
                PubStaticParam._log.WriteErr(ex); 
            }
            finally
            {
                if (AappSettingData.enPadDebug)
                {
                    PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN SaveObject2JsonFile 开始");
                    JsonHelper.SaveObject2JsonFile(mfeMainInfo, AstrDir);
                    PubStaticParam._log.WriteDebug("MESMachineUsageForWEIXIN SaveObject2JsonFile 完成");
                }
            }
            return strMsg;
        }

        #endregion

        #region "苏州元崧MES"
        ///
        ///  1. Job文件保存到一个固定的目录. 
        ///  2. 操作员扫描工单 UI 通过工单和操作员的ID 到服务器上下载Job文件到指定目录.
        ///  操作员ID 没有权限 提示无权限.  (客户接口)
        ///  下载文件错误提示. (客户接口)   下载完成  直接Load Job .   
        ///  3. 操作员修改Job , Job文件名不能修改.触发上传Job到服务器事件.
        ///  上传对应Job文件和相关参数,   操作员ID 没有权限  提示无权限.  (客户接口)
        ///  上传文件. (客户DLL接口)
        ///  4. checkbarcode    检查条码是否合法.  不合法弹窗报警
        ///  5. UpdataTestData  通过webserver接口上传测试结果数据到客户数据库
        ///  6. 检查员工编号是否有权限(客户接口)
        ///  7. 按富士康的机台信息上发到服务器

        private string RS_YuanSong_WebServerURL = "http://10.10.1.23:8018/LANDREXAOIService.asmx";
        private string RS_YuanSong_WebServerFuctionName_CheckBarCode = "CheckBarCode";
        private string RS_YuanSong_WebServerFuctionName_UpLoadTestData = "UpLoadTestData";

        private string RS_YuanSong_IniFilePath = "ini/OPRes.ini";
        private string RS_YuanSong_Section = "SFCDATA";
        private string RS_YuanSong_OP = "S-B-AOI";
        private string RS_YuanSong_RES = "S217-B-AOI";
        private string RS_YuanSong_LOT = "SMGP0191706677-1";
        private string RS_YuanSong_USERID = "LZM";
        private string RS_YuanSong_Line = "S217";
        private string RS_YuanSong_MCode = "S-BY-AS3421";
        private string RS_YuanSong_JobFile = "D:/EYSPI/Job/";
        private static readonly string _strLogPath = @"D:\EYSPI\Bin\SPILogs\Peng";

        private void GetBaseIniParam()
        {
            string strIniFilePath = Path.Combine(Environment.CurrentDirectory, RS_YuanSong_IniFilePath);
            try
            {
                if (File.Exists(strIniFilePath) == false)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(strIniFilePath));
                    string strOPResIniFilePath = Path.Combine(Environment.CurrentDirectory, "OPRes.ini");
                    if (File.Exists(strOPResIniFilePath))
                    {
                        File.Copy(strOPResIniFilePath, strIniFilePath);
                    }
                }

                if (File.Exists(strIniFilePath))
                {
                    RS_YuanSong_OP = INIFileHelper.ReadIniData(RS_YuanSong_Section, "OP",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_RES = INIFileHelper.ReadIniData(RS_YuanSong_Section, "RES",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_LOT = INIFileHelper.ReadIniData(RS_YuanSong_Section, "LOT",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_USERID = INIFileHelper.ReadIniData(RS_YuanSong_Section, "USERID",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_Line = INIFileHelper.ReadIniData(RS_YuanSong_Section, "Line",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_MCode = INIFileHelper.ReadIniData(RS_YuanSong_Section, "MCode",  PubStaticParam.RS_EMPTY, strIniFilePath);
                    RS_YuanSong_JobFile = INIFileHelper.ReadIniData(RS_YuanSong_Section, "JobFile",  PubStaticParam.RS_EMPTY, strIniFilePath);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }


        }

        ///<summary>
        ///  将Barcode信息上发到服务器验证
        ///  1.	产品条码不存在于系统  2.	当前Spec不正确   3.	当前设备未配置    4.	传入类型不正确
        ///</summary>
        ///<param name="AsBarCode"></param>
        ///<param name="AsLineNo"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorName"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AstrDir">export folder</param>
        ///<returns></returns>
        public string CheckBarcodeForYuanSong(
                ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                AppSettingData AappSettingData,
                     byte AbyLaneNo,
                    string AstrDir)
        {
            string strMsg = PubStaticParam.RS_EMPTY; string strContent = string.Empty;
            List<string> arrBarcode = new List<string>();
            try
            {
                int iBarcodeCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, AbyLaneNo);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                
                int iArrayCount = 0;
                if (bISArrayPCB)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    if (bPosZeroISUsed == false)
                    {
                        iArrayCount = iArrayCount - 1;
                    }
                }

                //主板
                if (iArrayCount == 0)
                {
                    arrBarcode.Add(APcbGeneralInfo.PanelResults[0].stArrayInfo.strBoardBarcode);
                }
                else
                {
                    if (iArrayCount != iBarcodeCount)
                    {
                        strMsg = string.Format("CheckBarcodeForYuanSong  Array Barcode Count ERROR! iArrayCount ={0}; iBarcodeCount ={1}", iArrayCount, iBarcodeCount);
                        return strMsg;
                    }

                    if (iBarcodeCount > 1)
                    {
                        for (int i = 0; i < iBarcodeCount; i++)
                        {
                            string strArryaBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            strArryaBarcode = _wsBaseF.BarcodeDicision(strArryaBarcode, AappSettingData, AbyLaneNo);

                            if (!string.IsNullOrEmpty(strArryaBarcode) && arrBarcode.Contains(strArryaBarcode) == false)
                            {
                                arrBarcode.Add(strArryaBarcode);
                            }
                        }
                    }
                }

                try
                {
                    GetBaseIniParam();
                }
                catch (Exception)
                {
                }

                foreach (string AsBarCode in arrBarcode)
                {
                    if (!string.IsNullOrEmpty(AsBarCode))
                    {

                        Hashtable htParams = new Hashtable();
                        htParams.Add("ASN", AsBarCode);
                        htParams.Add("Op", RS_YuanSong_OP);
                        htParams.Add("Res", RS_YuanSong_RES);
                        htParams.Add("Lot", RS_YuanSong_LOT);
                        htParams.Add("Uid", RS_YuanSong_USERID);

                        string strJsonFile = Path.Combine(AstrDir, AsBarCode + PubStaticParam.RS_JSon_EXT);
                        JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                        string strTmpUrlFile = Path.Combine(_strLogPath, "WebServiceURL_YUANSONG.log");
                        if (File.Exists(strTmpUrlFile))
                        {
                            RS_YuanSong_WebServerURL = File.ReadAllText(strTmpUrlFile, Encoding.Default);
                        }
                        else
                        {
                            File.WriteAllText(strTmpUrlFile, RS_YuanSong_WebServerURL, Encoding.Default);
                        }
                        strMsg = SoapOperator.DoSoapWebService(@RS_YuanSong_WebServerURL, RS_YuanSong_WebServerFuctionName_CheckBarCode, htParams);
                        // strMsg = "1";

                        //if (AsBarCode.Substring(AsBarCode.Length - 1, 1) == "5")
                        //{
                        //    strMsg = "条码未入系统...";
                        //}
                        if (string.IsNullOrEmpty(strMsg) || strMsg.Trim() == "1")
                        {
                            strMsg = string.Empty;
                        }
                        else if (string.IsNullOrEmpty(strMsg) == false && strMsg.Trim().Length > 1)
                        {
                            strMsg += "非空字符长度: " + strMsg.Trim().Length;
                            strContent += strMsg + "_[NG]sn:" + AsBarCode + "_";
                        }
                        if (AappSettingData.enPadDebug)
                        {
                            SaveLogsYouJiaInfo("CheckBarcodeForYuanSong  接口返回:", strMsg);
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                string strTmp = string.Empty;
                if (arrBarcode != null && arrBarcode.Count > 0)
                {
                    foreach(string str in arrBarcode)
                    {
                        strTmp += str + PubStaticParam.RS_CommaSplit;
                    }
                }
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeForYuanSong)" + ex.Message.ToString() + "[barcode]:" + strTmp;
            }
            finally
            {
                if (string.IsNullOrEmpty(strContent) == false)
                {
                    strMsg = strContent;
                }
            }
            return strMsg;
        }
        private void SaveLogsYouJiaInfo(string Akey, string Avalue)
        {
            string str = string.Empty;
            string strFilePath = _strLogPath;
            if (Directory.Exists(_strLogPath) == false)
            {
                Directory.CreateDirectory(_strLogPath);
            }
            string strFile = Path.Combine(strFilePath, "YuanSonglogs" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
            string strDateTime = DateTime.Now.ToString("yyyyMMdd HH:mm:ss");
            string strLog = "";
            try
            {
                if (!Directory.Exists(strFilePath))
                {
                    Directory.CreateDirectory(strFilePath);
                }
                if (!File.Exists(strFile))
                {
                    using (FileStream fs = new FileStream(strFile, FileMode.Create))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        strLog += "[    " + strDateTime + "   ]  " + Akey + " :" + Avalue + "\r\n " + "\r\n";
                        sw.Write(strLog);
                        sw.Close();
                    }
                }
                else
                {
                    using (FileStream fs = new FileStream(strFile, FileMode.Append))
                    {
                        StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                        strLog += "[    " + strDateTime + "   ]  " + Akey + " :" + Avalue + "\r\n " + "\r\n";
                        sw.Write(strLog);
                        sw.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///<summary>
        ///  将MESSaveResult上传到MES
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="Adict"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AsMachine"></param>
        ///<param name="AsWorkArea"></param>
        ///<param name="AsTestType"></param>
        ///<param name="AsOperatorType"></param>
        ///<param name="AsTrackType"></param>
        ///<param name="AsSite"></param>
        ///<param name="AsMac"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string MESSaveResultForYuanSong(
                    InspectMainLib.Pad[] APads,
                   SPCBoardRes ABrdRes,
                   ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                   AppSettingData AappSettingData,
                   string AstrDir,  //export folder      
                   string AstrClntName, out string strLog)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            string strTestData = string.Empty;
            string strS = "0", strU = "0", strP = "0", strF = "0";
            strLog = string.Empty + "\r\n";
            try
            {

                //get board barcode
                //string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                //                                    AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                //MessageBox.Show("load.. MESSaveResultForYuanSong ");
                int iBarcodeCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, (byte)ABrdRes.LaneNo);
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                Dictionary<string, int> arrBarcode = new Dictionary<string, int>();
                int iArrayCount = 0;
                string strLineNo = AappSettingData.LineName;

                if (bISArrayPCB)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    if (bPosZeroISUsed == false)
                    {
                        iArrayCount = iArrayCount - 1;
                    }
                }
                
                //主板
                if (iArrayCount == 0)
                {
                    arrBarcode.Add(APcbGeneralInfo.PanelResults[0].stArrayInfo.strBoardBarcode, 0);
                }
                else
                {
                    if (iArrayCount != iBarcodeCount)
                    {
                        strMsg = string.Format("MESSaveResultForYuanSong  Array Barcode Count ERROR! iArrayCount ={0}; iBarcodeCount ={1}", iArrayCount, iBarcodeCount);

                        strLog += "YUANSONG " + string.Format("MESSaveResultForYuanSong  Array Barcode Count ERROR! iArrayCount ={0}; iBarcodeCount ={1}", iArrayCount, iBarcodeCount) + "\r\n";

                        return strMsg;
                    }

                    if (iBarcodeCount > 1)
                    {
                        for (int i = 0; i < iBarcodeCount; i++)
                        {
                            string strArryaBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            if (!string.IsNullOrEmpty(strArryaBarcode) && arrBarcode.Keys.Contains(strArryaBarcode) == false)
                            {
                                arrBarcode.Add(strArryaBarcode, i);
                            }
                        }
                    }
                }

                try
                {
                    strLog += "YUANSONG START GetBaseIniParam : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";
                    GetBaseIniParam();
                    strLog += "YUANSONG END GetBaseIniParam : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";

                }
                catch (Exception)
                {
                }


                foreach (string AsBarCode in arrBarcode.Keys)
                {
                    strLog += "YUANSONG START Sent " + AsBarCode + " : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";

                    int ArrayIndex = arrBarcode[AsBarCode];
                    strTestData = string.Empty;
                    strS = "0"; strU = "0"; strP = "0"; strF = "0";
                    if (!string.IsNullOrEmpty(AsBarCode))
                    {
                        string strJobName = ABrdRes.jobName;
                        if (File.Exists(strJobName) || strJobName.Contains(":"))
                        {
                            strJobName = Path.GetFileNameWithoutExtension(strJobName);
                        }

                        //Model_ID
                        strTestData += strJobName +  PubStaticParam.RS_SemicolonSplit;
                        //SN 
                        strTestData += AsBarCode +  PubStaticParam.RS_SemicolonSplit;
                        //Line_ID 
                        strTestData += strLineNo +  PubStaticParam.RS_SemicolonSplit;
                        //Ship_ID  
                        strTestData += ABrdRes.pcbID.ToString() +  PubStaticParam.RS_SemicolonSplit;
                        //User_ID  
                        strTestData += RS_YuanSong_USERID +  PubStaticParam.RS_SemicolonSplit;
                        //Lot_ID  
                        strTestData += ABrdRes.lotNo +  PubStaticParam.RS_SemicolonSplit;
                        //yyyyMMdd
                        strTestData += ABrdRes.startTime.ToString("yyyyMMdd") +  PubStaticParam.RS_SemicolonSplit;
                        //HHmmss
                        strTestData += ABrdRes.startTime.ToString("HHmmss") +  PubStaticParam.RS_SemicolonSplit;
                        //Q.F.2018.03.20
                        short ArrayJudgeRes = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[ArrayIndex].shArrayStatusSameAsJudgeRes;//shArrayStatus;

                        if (ArrayJudgeRes == (short)JudgeRes.Skipped)
                        {
                            strS = "1";
                        }
                        //if (ArrayJudgeRes == (short)JudgeRes.Unmeasured)
                        //{
                        //    strU = "1";
                        //}
                        if (ArrayJudgeRes == (short)JudgeRes.Good || ArrayJudgeRes == (short)JudgeRes.Pass)
                        {
                            strP = "1";
                        }
                        
                        if (ArrayJudgeRes == (short)JudgeRes.NG)
                        {
                            strF = "1";
                        }
                        if (bISArrayPCB)
                        {
                            // s;u;p;f;
                            strTestData += strS + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strU + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strP + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strF + PubStaticParam.RS_SemicolonSplit;
                        }
                        else
                        {

                            if (ABrdRes.jugResult == JudgeRes.NG)
                            {
                                //strS = "1";
                                strP = "0";
                                strF = "1";
                            }
                            else
                            {
                                strP = "1";
                            }
                            strTestData += strS + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strU + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strP + PubStaticParam.RS_SemicolonSplit;
                            strTestData += strF + PubStaticParam.RS_SemicolonSplit;

                        }
                        //T/B
                        strTestData += "T" +  PubStaticParam.RS_SemicolonSplit;
                        //TotalComp
                        List<string> arrTotalErr = new List<string>();
                        string strError_Structures = string.Empty;

                        ImgCSCoreIM.ComponentInfo[] arrComponent = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[ArrayIndex].arrComponentInfo;
                        if (arrComponent != null && arrComponent.Length > 0)
                        {
                            foreach (ImgCSCoreIM.ComponentInfo component in arrComponent)
                            {
                                int[] arrPad = component.arrPadIndices;
                                foreach (int intPad in arrPad)
                                {
                                    Pad pad = APads[intPad];
                                    if (pad.check)
                                    {
                                        string strCompName = pad.strArrayID + "_" + pad.componentID;

                                        if (pad.res.jugRes == JudgeRes.NG)
                                        {
                                            if (arrTotalErr.Contains(strCompName) == false)
                                            {
                                                //CompName   
                                                strError_Structures += component.strComPonentID + PubStaticParam.RS_SemicolonSplit;
                                                //CompType 
                                                strError_Structures += pad.packageType + PubStaticParam.RS_SemicolonSplit;
                                                //ConfirmErrCode     
                                                strError_Structures += _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData) + PubStaticParam.RS_SemicolonSplit;
                                                //0	reserved
                                                strError_Structures += 0 + PubStaticParam.RS_SemicolonSplit;
                                                //0Dh
                                                strError_Structures += 0 + PubStaticParam.RS_SemicolonSplit;
                                                //0Ah
                                                strError_Structures += 0 + PubStaticParam.RS_SemicolonSplit;

                                                arrTotalErr.Add(strCompName);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            string strJsonFile = Path.Combine(AstrDir, AsBarCode + PubStaticParam.RS_JSon_EXT);
                            JsonHelper.SaveObject2JsonFile("ArrComponent_Is_Null", strJsonFile);
                        }

                        strTestData += arrComponent.Length.ToString() +  PubStaticParam.RS_SemicolonSplit;
                        strTestData += arrTotalErr.Count.ToString() +  PubStaticParam.RS_SemicolonSplit;

                        if (arrTotalErr.Count > 0)
                        {
                            strTestData += strError_Structures;
                        }

                        Hashtable htParams = new Hashtable();
                        htParams.Add("ATestData", strTestData);
                        htParams.Add("Op", RS_YuanSong_OP);
                        htParams.Add("Res", RS_YuanSong_RES);
                        htParams.Add("Lot", RS_YuanSong_LOT);
                        htParams.Add("Uid", RS_YuanSong_USERID);

                        if (AappSettingData.enPadDebug)
                        {
                            //MessageBox.Show(strTestData);
                            string strJsonFile = Path.Combine(AstrDir, AsBarCode +  PubStaticParam.RS_JSon_EXT);
                            strLog += "YUANSONG START SaveJson2File " + strJsonFile + ": " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";
                            JsonHelper.SaveObject2JsonFile(htParams, strJsonFile);
                            strLog += "YUANSONG End SaveJson2File " + strJsonFile + ": " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";
                        }
                        string strTmpUrlFile = Path.Combine(_strLogPath, "WebServiceURL_YUANSONG.log");
                        if (File.Exists(strTmpUrlFile))
                        {
                            RS_YuanSong_WebServerURL = File.ReadAllText(strTmpUrlFile, Encoding.Default);
                        }
                        else
                        {
                            File.WriteAllText(strTmpUrlFile, RS_YuanSong_WebServerURL, Encoding.Default);
                        }
                        strLog += "YUANSONG START SoapOperator.DoSoapWebService : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";
                        string sSoapResult = SoapOperator.DoSoapWebService(RS_YuanSong_WebServerURL, RS_YuanSong_WebServerFuctionName_UpLoadTestData, htParams);
                        strLog += "YUANSONG END SoapOperator.DoSoapWebService : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";

                        if (!string.IsNullOrEmpty(sSoapResult))
                        {
                            strMsg = sSoapResult;
                        }
                    }
                    strLog += "YUANSONG End Sent " + AsBarCode + " : " + DateTime.Now.ToString( PubStaticParam.RS_FORMAT_DATETIME) + "\r\n";
                    
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultForYuanSong)" + ex.Message.ToString();
            }
            finally
            {
                if (AappSettingData.enPadDebug)
                {
                    SaveLogsYouJiaInfo("MESSaveResultForYuanSong  接口返回:", strMsg);
                }
            }
            strLog += strMsg;
            return strMsg;
        }
        ///<summary>
        /// 根据参数下载Job文件到指定目录
        ///</summary>
        ///<param name="AsJobFile"></param>
        ///<param name="AsSetType"></param>
        ///<param name="AsSetKind"></param>
        ///<param name="AsSetLine"></param>
        ///<param name="AsUsername"></param>
        ///<param name="AsPassword"></param>
        ///<param name="AsSetLot">工单号</param>
        ///<param name="AsSetFOP"></param>
        ///<returns></returns>
        public string DownLoadJobForYuanSong(string AsJobFile, string AsSetType, string AsSetKind, string AsSetLine, string AsUsername, string AsPassword, string AsSetLot, string AsSetFOP, out string AsJobFileName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            AsJobFileName = string.Empty;
            try
            {
                try
                {
                    GetBaseIniParam();
                }
                catch (Exception)
                {
                }
                File_Down.FileDown FileDown = new File_Down.FileDown();

                strMsg = FileDown.DownLoad(AsJobFile, AsSetType, AsSetKind, AsSetLine, AsSetLot, RS_YuanSong_OP, AsUsername, AsPassword, AsSetFOP, RS_YuanSong_RES);
                if (strMsg.Trim().ToUpper().StartsWith("T;"))
                {
                    // T;xxx.jbn;
                    string[] arrMsg = strMsg.Split(';');
                    for (int i = 1; i < arrMsg.Length; i++)
                    {
                        AsJobFileName += Path.Combine(RS_YuanSong_JobFile, arrMsg[i]) + ";";
                    }
                    strMsg = string.Empty;
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(DownLoadJobForYuanSong)" + ex.Message.ToString();
            }
            finally
            {

            }
            return strMsg;

        }
        public string DownLoadJobForYuanSong2(string AsJobFile, string AsSetType, string AsSetKind,
            string AsSetLine, string AsUsername, string AsPassword,
            string AsSetLot, string AsSetFOP, out string AsJobFileName, AppSettingData AappSettingData)
        {
            String strMsg = PubStaticParam.RS_EMPTY;
            AsJobFileName = string.Empty;
            string strOP = string.Empty, strFOP = string.Empty, strRES = string.Empty;
            try
            {
                try
                {
                    string strA = "", strB = "", strC = "", strD = "", strE = "";

                    AsSetType = AappSettingData.stDataExpVT.strTestType; //2
                    AsSetKind = AappSettingData.stDataExpVT.strMachine;  //3
                    AsSetLine = AappSettingData.LineName;                //4
                    AsSetLot = AappSettingData.strLotNumber;             //5
                    strOP = AappSettingData.stDataExpVT.strOpSide; //6
                    AsUsername = AappSettingData.stDataExpVT.strCustomer;//7
                    AsPassword = AappSettingData.stDataExpVT.strOperatorPassword; //8
                    strFOP = AappSettingData.stDataExpVT.strSetFOP;       //9
                    strRES = AappSettingData.stDataExpVT.strRES;            //10
                    //SaveDownLoadIniParam(AsJobFile,);
                    GetBaseIniParam();
                }
                catch (Exception ec)
                {
                    return ec.Message;
                }
                DateTime startTime = DateTime.Now;
                File_Down.FileDown FileDown = new File_Down.FileDown();
                //add By Peng  20180621
                //AsJobFile = "E:\\download\\";   //@"E:/Download/"
                //MessageBox.Show("DownLoad start..." + RS_YuanSong_JobFile + "_" + AsSetType + "_" + AsSetKind + "_" + AsSetLine + "_" + AsSetLot + "_" + strOP + "_" + AsUsername + "_" + AsPassword + "_" + strFOP + "_" + strRES);
                strMsg = FileDown.DownLoad(RS_YuanSong_JobFile, AsSetType, AsSetKind, AsSetLine, AsSetLot, strOP, AsUsername, AsPassword, strFOP, strRES);
                //MessageBox.Show(strMsg);
                DateTime endTime = DateTime.Now;
                //add Peng 2018.05.22   获取当前下载job后 job的文件      
                System.Threading.Thread.Sleep(3000);
                AsJobFile = RS_YuanSong_JobFile;
                IEnumerable<string> list = Directory.GetFiles(AsJobFile).Where(p => File.GetLastWriteTime(p) >= startTime);
                
                foreach (string strJobfile in list)
                {
                    if (!string.IsNullOrEmpty(strJobfile))
                    {
                        AsJobFileName = strJobfile;
                    }
                }
                //if (!string.IsNullOrEmpty(strMsg))
                //{
                string file = @"D:\EYSPI\DataExport\" + "bosch_log.txt";
                using (FileStream fs = new FileStream(file, FileMode.Append))
                {
                    StreamWriter ws = new StreamWriter(fs, Encoding.Default);
                    ws.Write("[ " + DateTime.Now.ToString(PubStaticParam.RS_FORMAT_DATETIME) + " ]" + PubStaticParam.RS_LineEnd +
                        strMsg + PubStaticParam.RS_LineEnd +
                        "   AsJobFile:" + AsJobFile + PubStaticParam.RS_LineEnd +
                        "   AsSetType:" + AsSetType + PubStaticParam.RS_LineEnd +
                        "   AsSetKind:" + AsSetKind + PubStaticParam.RS_LineEnd +
                        "   AsSetLine:" + AsSetLine + PubStaticParam.RS_LineEnd +
                        "   AsSetLot:" + AsSetLot + PubStaticParam.RS_LineEnd +
                        "   RS_BOSCH_OP:" + strOP + PubStaticParam.RS_LineEnd +
                        "   AsJobFileName:  " + AsJobFileName + PubStaticParam.RS_LineEnd +
                        "   AsUsername:" + AsUsername + PubStaticParam.RS_LineEnd +
                        "   AsPassword:" + AsPassword + PubStaticParam.RS_LineEnd +
                        "   RS_BOSCH_MCode:" + strFOP + PubStaticParam.RS_LineEnd +
                        "   RS_BOSCH_RES:" + strRES + PubStaticParam.RS_LineEnd);
                    ws.Close();
                }
                //}
                MessageBox.Show(strMsg);
                if (File.Exists(AsJobFileName))
                {
                    //AsJobFileName = Path.GetFileNameWithoutExtension(AsJobFileName);
                    strMsg = string.Empty;
                }
                else
                {
                    return "error; the jobPath Unable to find DownLoadFile! JobFile：" + AsJobFileName;
                }

            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(DownLoadJobForYuanSong2)" + ex.Message.ToString();
                MessageBox.Show("下载异常.."+strMsg);
            }
            finally
            {

            }
            return strMsg;

        }
        ///<summary>
        /// 上传Job到服务器
        ///</summary>
        ///<param name="AsJobFile"></param>
        ///<param name="AsSetType"></param>
        ///<param name="AsSetKind"></param>
        ///<param name="AsSetLine"></param>
        ///<param name="AsSetLot"></param>
        ///<param name="AsUsername"></param>
        ///<param name="AsPassword"></param>
        ///<returns></returns>
        public string UpLoadJobForYuanSong(string AsJobFile, string AsSetType, string AsSetKind, string AsSetLine, string AsSetLot, string AsUsername, string AsPassword)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            try
            {
                try
                {
                    GetBaseIniParam();
                }
                catch (Exception)
                {
                }
                File_Down.FileDown FileDown = new File_Down.FileDown();

                strMsg = FileDown.UploadLoad(RS_YuanSong_JobFile, AsSetType, AsSetKind, AsSetLine, AsSetLot, RS_YuanSong_OP, AsUsername, AsPassword);
                if (strMsg.Trim().ToUpper().StartsWith("T;"))
                {
                    strMsg = string.Empty;
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(DownLoadJobForYuanSong)" + ex.Message.ToString();
            }
            finally
            {

            }
            return strMsg;

        }

        #endregion

        #region "爱斯福 MES" 

        // 定期写入对方数据库中指定的表.表内容字段麻烦工程师跟客户确认下.看需要什么数据
        //表结构和用户名密码 我们确定后提供给客户
        //数据库格式可能会升级, 建议用SQL SERVER 2012 测试.
        //功能集合到UI的AutoAPP

        #endregion

        #region "比亚迪二楼"

        ///<summary>
        /// 惠州比亚迪2楼新线MES输出格式要求如下：
        /// 命名规格：轨道—程序名—条码—时间戳.SPI.csv
        /// L-11714985-00-A0-B17070200148-20170702191805.SPI.csv
        /// Test status :是大板得测试结果
        /// Module是小板序列号        
        /// RegResult是小板对应点位的最终结果（N为FALL,P 未Pass, S 为叉板，RPass 为人工判定Pass.)
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string SaveDataFileForBYDSecond(
                InspectMainLib.Pad[] APads,
                SPCBoardRes ABrdRes,
                ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                AppSettingData AappSettingData,
                string AstrDir,
                string AstrClntName)
        {

            string strMsg =  PubStaticParam.RS_EMPTY;
            byte byResultMode = 3;
            try
            {

                //delete old tmp file
                string tmpFile =  PubStaticParam.RS_strTmpFileDir + "\\" +  PubStaticParam.RS_DataExportTempFile;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                //check dir
                if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                {
                    strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "No Folder!";
                    return strMsg;
                }


                int iLength = 0;
                string strStatusRes =  PubStaticParam.RS_EMPTY;

                string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (string.Equals(strboardBarcode,  PubStaticParam.RS_NOREAD))
                {
                    strboardBarcode =  PubStaticParam.RS_EMPTY;
                }

                int iBarcodeCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13                


                string strLinePre =  PubStaticParam.RS_EMPTY;
                StringBuilder strBldBoard = new StringBuilder();
                StringBuilder strBldPld = new StringBuilder();

                //first line      
                strLinePre = "SRFF File" + PubStaticParam.RS_ColonSplit + AappSettingData.stDataExpVT.strDataExpIPAddress;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                strLinePre = "Panel Name" + PubStaticParam.RS_ColonSplit + strJobName;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                strLinePre = "Units" + PubStaticParam.RS_ColonSplit + "Millimeters";
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                strLinePre = "Panel ID" + PubStaticParam.RS_ColonSplit + strboardBarcode;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                string strStartDate = ABrdRes.startTime.ToString("dd/MM/yyyy");
                strLinePre = "Start_Date" + PubStaticParam. RS_ColonSplit + strStartDate;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                //string strStartTime = ABrdRes.startTime.ToString("HH/mm/ss");
                //strLinePre = "Start_Time" + PubStaticParam. RS_ColonSplit + strStartTime;
                //strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                //End_Date : 19/18/33
                string strEndDate = ABrdRes.endTime.ToString("dd/MM/yyyy");
                strLinePre = "End_Date" + PubStaticParam. RS_ColonSplit + strEndDate;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);


                strLinePre = "Test status" + PubStaticParam. RS_ColonSplit + _wsBaseF.GetJudgeResult(ABrdRes.jugResult, AappSettingData);
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                bool bHasArray = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                string strStartTime = ABrdRes.startTime.ToString("HH:mm:ss");


                strBldPld.Append(
                                       "Date" + PubStaticParam. RS_ColonSplit
                                    + "Time" + PubStaticParam. RS_ColonSplit
                                    + "PanelId" + PubStaticParam. RS_ColonSplit
                                    + "Board" + PubStaticParam. RS_ColonSplit
                                    + "Module" + PubStaticParam. RS_ColonSplit
                                    + "Location" + PubStaticParam. RS_ColonSplit
                                     + "Feature" + PubStaticParam. RS_ColonSplit
                                    // + "PinNumber" + PubStaticParam. RS_ColonSplit

                                    + "HeightResult" + PubStaticParam. RS_ColonSplit
                                    + "Height" + PubStaticParam. RS_ColonSplit
                                    + "HeightUpFail" + PubStaticParam. RS_ColonSplit
                                    + "HeightLowFail" + PubStaticParam. RS_ColonSplit
                                    + "HeightTarget" + PubStaticParam. RS_ColonSplit

                                   + "AreaResult" + PubStaticParam. RS_ColonSplit
                                    + "Area" + PubStaticParam. RS_ColonSplit
                                    + "AreaUpFail" + PubStaticParam. RS_ColonSplit
                                    + "AreaLowFail" + PubStaticParam. RS_ColonSplit
                                    + "AreaTarget" + PubStaticParam. RS_ColonSplit

                                    + "VolumeResult" + PubStaticParam. RS_ColonSplit
                                    + "Volume" + PubStaticParam. RS_ColonSplit
                                    + "VolumeUpFail" + PubStaticParam. RS_ColonSplit
                                    + "VolumeLowFail" + PubStaticParam. RS_ColonSplit
                                    + "VolumeTarget" + PubStaticParam. RS_ColonSplit//stencilheight

                                    + "Valid" + PubStaticParam. RS_ColonSplit//padjudgeres
                                    + "RegResult" + PubStaticParam. RS_ColonSplit
                                    + "XOffset" + PubStaticParam. RS_ColonSplit
                                    + "YOffset" + PubStaticParam. RS_ColonSplit
                                    + "RegShort%" + PubStaticParam. RS_ColonSplit
                                    + "RegLong%" + PubStaticParam. RS_ColonSplit//
                                    + "RegShort%Fail" + PubStaticParam. RS_ColonSplit//
                                    + "RegLong%Fail" + PubStaticParam. RS_ColonSplit//
                                    + "BridgeResult" + PubStaticParam. RS_ColonSplit
                                    + "BridgeLength" + PubStaticParam. RS_ColonSplit
                                    + "BridgeFail" + PubStaticParam. RS_ColonSplit

                                    + "Print Speed" + PubStaticParam. RS_ColonSplit//
                                    + "Print Pressure" + PubStaticParam. RS_ColonSplit
                                    + "Snap off speed" + PubStaticParam. RS_ColonSplit
                                    + "Print direction" + PubStaticParam. RS_ColonSplit
                                    + "Squeegee use count" + PubStaticParam. RS_ColonSplit//
                                    + "Print gap" + PubStaticParam. RS_ColonSplit//
                                    + "Squeegee angle" + PubStaticParam. RS_ColonSplit//
                                    + "PCB quantity setting for solder paste replenishing  " + PubStaticParam. RS_ColonSplit//
                                    + "PCB count start from screen stencil auto-cleaning"
                                    //+ "Array" + PubStaticParam. RS_ColonSplit
                                    //+ "Review" + PubStaticParam. RS_ColonSplit//
                                    //+ "ErrorCode" + PubStaticParam. RS_ColonSplit//
                                    //+ "ErrorContent"
                                    + PubStaticParam.RS_LineEnd
                                    );

                iLength = APads.Length;

                bool bEnUserDefinedErrorCode = AappSettingData.bEnUserDefinedErrorCode == true
                   && AappSettingData.strUserDefinedErrorCodes != null;

                string strArrayBarcode = String.Empty;
                foreach (InspectMainLib.Pad pad in APads)
                {
                    if (_wsBaseF.bPadIsSkip(pad) == true)
                    {
                        continue;
                    }
                    //Date
                    strBldPld.Append(strStartDate + PubStaticParam. RS_ColonSplit);
                    //Time
                    strBldPld.Append(strStartTime + PubStaticParam. RS_ColonSplit);
                    //PanelId
                    strBldPld.Append(strboardBarcode + PubStaticParam. RS_ColonSplit);

                    //if (string.IsNullOrEmpty(strboardBarcode))//
                    //    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);
                    //else
                    //{
                    //    if (bHasArray == true
                    //    && AappSettingData.arrBarcodeSetting[ABrdRes.LaneNo].bUseExtBrcd == false)//Q.F.2016.10.25
                    //{
                    //    if (iBarcodeCount > 1)
                    //    {
                    //        strArrayBarcode =
                    //            _wsBaseF.BarcodeDicision(APcbGeneralInfo.PanelResults[0].arrStrBrcd[pad.arrayIDIndex].Trim(),
                    //            AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                    //        if (string.Equals(strArrayBarcode,  PubStaticParam.RS_NOREAD))
                    //        {
                    //            strArrayBarcode =  PubStaticParam.RS_EMPTY;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        strArrayBarcode = strboardBarcode;
                    //    }
                    //}
                    //else
                    //{
                    //    strArrayBarcode = strboardBarcode;//Q.F.2016.10.20
                    //}
                    //strBldPld.Append(strArrayBarcode + PubStaticParam. RS_ColonSplit);
                    //}

                    //Board 
                    strBldPld.Append("IMAGE 1" + PubStaticParam. RS_ColonSplit);
                    //Module
                    strBldPld.Append("Module 1" + PubStaticParam. RS_ColonSplit);
                    //Location
                    string strLocation = string.Empty;
                    if (string.IsNullOrEmpty(pad.componentID))
                    {
                        pad.componentID =  PubStaticParam.RS_NOREADNA;
                    }
                    else
                    {
                        strLocation = pad.componentID;
                    }
                    strBldPld.Append(strLocation + PubStaticParam. RS_ColonSplit);

                    //Feature              //PinNumber
                    string strFeature = string.Empty;
                    if (string.IsNullOrEmpty(pad.pinNumber))
                    {
                        strFeature = strLocation +PubStaticParam. RS_AtSplit + PubStaticParam.RS_NOREADNA;
                        //strBldPld.Append(pad.padID + PubStaticParam. RS_ColonSplit);
                    }
                    else
                    {
                        strFeature = strLocation + PubStaticParam.RS_AtSplit + pad.pinNumber;
                    }
                    strBldPld.Append(strFeature + PubStaticParam.RS_ColonSplit);

                    //HeightResult
                    if (pad.res.measuredValue.height < pad.spec.heightL
                        || pad.res.measuredValue.height > pad.spec.heightH)
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    }
                    else
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    }
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);

                    //Height//mm
                    strBldPld.Append((pad.res.measuredValue.height *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);
                    //HeightUpFail  //mm
                    strBldPld.Append((pad.spec.heightH *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);
                    //HeightLowFail//mm
                    strBldPld.Append((pad.spec.heightL *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);
                    //HeightTarget//mm
                    strBldPld.Append((pad.stencilHeight).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);

                    //AreaResult
                    if (pad.res.measuredValue.perArea < pad.spec.areaPerL
                        || pad.res.measuredValue.perArea > pad.spec.areaPerH)
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    }
                    else
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    }
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);

                    //Area
                    strBldPld.Append((pad.res.measuredValue.area *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //AreaUpFail
                    strBldPld.Append((pad.res.measuredValue.fCadArea * pad.spec.areaPerH *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //AreaLowFail
                    strBldPld.Append((pad.res.measuredValue.fCadArea * pad.spec.areaPerL *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //AreaTarget
                    strBldPld.Append((pad.res.measuredValue.fCadArea *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm

                    //VolumeResult
                    if (pad.res.measuredValue.perVol < pad.spec.volPerL
                        || pad.res.measuredValue.perVol > pad.spec.volPerH)
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    }
                    else
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    }
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);
                    //Volume
                    strBldPld.Append((pad.res.measuredValue.vol *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //VolumeUpFail
                    strBldPld.Append((pad.res.measuredValue.fCADVol * pad.spec.volPerH *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //VolumeLowFail
                    strBldPld.Append((pad.res.measuredValue.fCADVol * pad.spec.volPerL *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm
                    //VolumeTarget
                    strBldPld.Append((pad.res.measuredValue.fCADVol *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM *  PubStaticParam.RS_fUM2MM).ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//mm

                    //Valid
                    //strStatusRes = _wsBaseF.GetJudgeResult(pad.res.jugRes, AappSettingData);
                    //if (pad.res.jugRes == JudgeRes.Pass)
                    strStatusRes = _wsBaseF.GetStatusResultFrHUIZHOUBYD((byte)pad.res.jugRes, byResultMode);
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);

                    //RegResult    RegResult是小板对应点位的最终结果（N为FALL,P 未Pass, S 为叉板，RPass 为人工判定Pass.)
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);

                    //XOffset
                    strBldPld.Append(pad.res.measuredValue.offsetX.ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//
                    //YOffset
                    strBldPld.Append(pad.res.measuredValue.offsetY.ToString( PubStaticParam.RS_FLOATFORMAT_6Bit) + PubStaticParam. RS_ColonSplit);//

                    //RegShort%
                    strBldPld.Append( PubStaticParam.RS_ZERO + PubStaticParam. RS_ColonSplit);//
                                                              //RegLong%
                    strBldPld.Append( PubStaticParam.RS_ZERO + PubStaticParam. RS_ColonSplit);//
                    //RegShort%Fail
                    strBldPld.Append( PubStaticParam.RS_ZERO + PubStaticParam. RS_ColonSplit);//
                    //RegLong%Fail
                    strBldPld.Append( PubStaticParam.RS_ZERO + PubStaticParam. RS_ColonSplit);//
                    //BridgeResult
                    if (pad.res.measuredValue.bridgeNo > 0 && pad.checkBridge == true)
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.NG, AappSettingData);
                    }
                    else
                    {
                        strStatusRes = _wsBaseF.GetJudgeResult(JudgeRes.Good, AappSettingData);
                    }
                    strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);//
                    //BridgeLength
                    strBldPld.Append( PubStaticParam.RS_ZERO + PubStaticParam. RS_ColonSplit);//
                    //BridgeFail
                    strBldPld.Append( PubStaticParam.RS_NOREADNA + PubStaticParam. RS_ColonSplit);//

                    //Print Speed
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                                                               //Print Pressure
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                                                               //Snap off speed
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                                                               //Print direction
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                                                               //Squeegee use count
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                    //Print gap
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                    //Squeegee angle
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                    //PCB quantity setting for solder paste replenishing 
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                    //PCB count start from screen stencil auto-cleaning
                    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);// 

                    //strBldPld.Append(pad.strArrayID + PubStaticParam. RS_ColonSplit);//
                    // strStatusRes = GetStatusResultFrHUIZHOUBYD((byte)pad.res.jugRes, byResultModeForReview);
                    //for another 
                    //strBldPld.Append(pad.strArrayID + PubStaticParam. RS_ColonSplit);
                    //strStatusRes = _wsBaseF.GetJudgeResult(pad.res.jugRes, AappSettingData);
                    //strBldPld.Append(strStatusRes + PubStaticParam. RS_ColonSplit);//valid

                    //if (pad.res.jugRes == JudgeRes.Good)
                    //{
                    //    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam. RS_ColonSplit);//
                    //    strBldPld.Append( PubStaticParam.RS_EMPTY + PubStaticParam.RS_LineEnd);// 
                    //}
                    //else
                    //{
                    //    strStatusRes = pad.res.jugDefectType.ToString("g");
                    //    if (bEnUserDefinedErrorCode)
                    //    {
                    //        System.Int32.TryParse(AappSettingData.strUserDefinedErrorCodes[(byte)(pad.res.jugDefectType)],
                    //                            out iErrorCode);

                    //    }
                    //    else
                    //    {
                    //        iErrorCode = (byte)(pad.res.jugDefectType);
                    //    }
                    //    strBldPld.Append(iErrorCode + PubStaticParam. RS_ColonSplit);//
                    //    strBldPld.Append(strStatusRes + PubStaticParam.RS_LineEnd);// 

                    //}

                }


                strStartTime = ABrdRes.startTime.Year.ToString("0000")
                                + ABrdRes.startTime.Month.ToString("00")
                                + ABrdRes.startTime.Day.ToString("00")
                                + ABrdRes.startTime.Hour.ToString("00")
                                + ABrdRes.startTime.Minute.ToString("00")
                                + ABrdRes.startTime.Second.ToString("00");

                string  RS_CSV_EXT = ".spi.csv";
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Write(strBldPld);
                streamWrt.Close();
                string strLineNo = AappSettingData.LineName;
                string strFileName = AstrDir + strLineNo +  PubStaticParam.RS_MedianLineSplit + strJobName +  PubStaticParam.RS_MedianLineSplit + strboardBarcode +  PubStaticParam.RS_MedianLineSplit + strStartTime;

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName +  PubStaticParam.RS_CSV_EXT, true);
                }

            }
            catch (System.Exception ex)
            {
                strMsg =  PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }
        #endregion

        #region "深圳信恳"
        ///<summary>
        /// 和信恳讨论了下，根据客户的要求确定采用以下文本格式
        /// 1，文件采用TXT格式，
        /// 2，文件名以“条码_时间戳”命名。（时间戳年月日八位，时分秒六位）
        /// 3，文件内容如下图 
        /// 4，判定结果，我们整合一下输出两项PASS和NG
        ///</summary>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string SaveDataFileForSZXINKEN(
                     InspectMainLib.Pad[] APads,
                     SPCBoardRes ABrdRes,
                     ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                     AppSettingData AappSettingData,
                      AppMultiLan.AppLan Adict,
                     string AstrDir,
                     string AstrClntName)
        {

            string strMsg =  PubStaticParam.RS_EMPTY;
            string strTXTFileName = string.Empty;
            string strTXTContents;
            try
            {
                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir =  PubStaticParam.RS_strTmpFileDir;


                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                strTXTFileName = strboardBarcode +  PubStaticParam.RS_UnderLineSplit + ABrdRes.startTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName) +  PubStaticParam.RS_TXT_EXT;
                string strLineNo = AappSettingData.LineName;
                string strTXTFile = Path.Combine(AstrDir, strTXTFileName);
                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }
                strTXTContents = string.Empty;
                strTXTContents += "PName：" + strJobName + PubStaticParam.RS_LineEnd;
                strTXTContents += "Line NO.：" + strLineNo + PubStaticParam.RS_LineEnd;
                strTXTContents += "SN：" + strboardBarcode + PubStaticParam.RS_LineEnd;
                strTXTContents += "Data：" + ABrdRes.startTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_LineEnd;

                bool AbUseNGAsBadMark = false;
                int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, AbUseNGAsBadMark, Adict);
                string strBMInfo =  PubStaticParam.RS_EMPTY;
                for (int i = 0; i != aIInfo.Length; ++i)
                {
                    if (aIInfo[i] == 0)
                        strBMInfo += "0";
                    else
                        strBMInfo += "1";
                }
                strTXTContents += "BadMark：" + strBMInfo + PubStaticParam.RS_LineEnd;
                string strResult =  PubStaticParam.RS_EMPTY;
                if (ABrdRes.jugResult == JudgeRes.Good)
                {
                    strResult = "PASS";
                }
                else
                {
                    strResult = "NG";
                }
                strTXTContents += "Result：" + strResult + PubStaticParam.RS_LineEnd;

                if (!string.IsNullOrEmpty(strTXTContents))
                {
                    strTXTContents += PubStaticParam.RS_LineEnd;
                    File.WriteAllText(strTXTFile, strTXTContents);
                }
            }
            catch (System.Exception ex)
            {
                strMsg =  PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }
            finally
            {
            }

            return strMsg;

        }
        #endregion

        #region "普能达 Punda"
        /// <summary>
        ///    客户需求，一个程序，生成一个文件命名格式为：线别+日期+程序名。
        /// 内容为：序号，条码，日期（精确到秒）
        /// 每测试一片PCB需要进入此文件生成一条数据。类似我们的LOG文件。
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AbyLaneNo"></param>
        /// <param name="AiFileType">文件类型 0为txt 其他为csv</param>
        /// <param name="AstrClntName"></param>
        /// <returns></returns>
        public String SaveBarcodeForPunda(
                   InspectMainLib.Pad[] APads,
                   SPCBoardRes ABrdRes,
                   ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                   AppSettingData AappSettingData,
                   AppMultiLan.AppLan Adict,
                   string AstrDir,  //export folder
                   byte AbyLaneNo,
                   EM_FileExtType AiFileType,//Q.F.2019.08.06
                   string AstrClntName)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            string strCSVFile = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir =  PubStaticParam.RS_strTmpFileDir;

                DataTable dtPunda = new DataTable();
                InitDataTableForPunda(ref dtPunda, Adict);

                //get board barcode
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                              AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }
                string strLineNo = AappSettingData.LineName;
                string strStartTime = ABrdRes.startTime.ToString( PubStaticParam.RS_Format_DateTimeFileName);


                DataRow dr = dtPunda.NewRow();
                dr[0] = ABrdRes.pcbID;
                dr[1] = strboardBarcode;
                dr[2] = ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATETIME);
                dtPunda.Rows.Add(dr);
                switch (AiFileType)
                {
                    case EM_FileExtType.txt:
                        strCSVFile = Path.Combine(AstrDir, strLineNo + strStartTime + strJobName +  PubStaticParam.RS_TXT_EXT);
                        strMsg += SaveData2File.SaveDataTable2TXTFile(dtPunda, strCSVFile);
                        break;
                    default:
                        strCSVFile = Path.Combine(AstrDir, strLineNo + strStartTime + strJobName +  PubStaticParam.RS_CSV_EXT);
                        strMsg += SaveData2File. SaveDataTable2CSVFile(dtPunda, strCSVFile);
                        break;
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(SaveBarcodeForPunda)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        public string InitDataTableForPunda(ref DataTable Adt, AppMultiLan.AppLan Adict)
        {
            string strReturn = string.Empty;
            try
            {
                //序号
                Adt.Columns.Add("PCBID");
                //条码
                Adt.Columns.Add("Barcode");
                //测试时间
                Adt.Columns.Add("DateTime");

                Adt.EndInit();
            }
            catch (Exception ex)
            {
                strReturn += ex.Message.ToString();
                throw ex;
            }
            finally
            {

            }
            return strReturn;

        }

        #endregion

        #region "金锐显"
        //暂时用欣万达的模式

        #endregion

        #region "科莱昂 Sotrun"
        ///<summary>
        ///  检查产品 SN 的有效性及工序流程状态：
        ///</summary>
        ///<param name="WLID">工位 ID</param>
        ///<param name="WPID">工序 ID</param>
        ///<param name="OpSide">作业面（N-不区分作业面，B-背面，T-正面）</param>
        ///<param name="LineID">产线编号；</param>
        ///<param name="OpID">作业员工号；</param>
        ///<param name="BarCode">产品 SN；</param>
        ///<param name="Msg">相关信息；</param>
        ///<returns></returns>
        //[DllImport("MSLBarCode.dll", CharSet = CharSet.Ansi)]
        //private static extern int mslCheckIn(IntPtr WLID, IntPtr WPID, IntPtr OpSide, IntPtr LineID, IntPtr OpID, IntPtr BarCode, ref IntPtr Msg);
        [DllImport("MSLBarCode.dll")]
        public static extern int mslCheckIn(String WLID, String WPID, string OpSide, String LineID, String OpID,
                                               string BarCode, StringBuilder Msg);
        ///<summary>
        /// 上传 AOI 检测结果（作业员最终确认后的检测结果）
        /// SN:XXXXXXXX#TResult:Y#Remark:TTTTTTT#CheckTime:20161007093110
        /// #ProgramID:CCCCCCCC#CheckAllQty:150#FailQty:10
        /// #DefectPos1:PanelNo1:DefectDesc1:X1:Y1:A1
        /// #DefectPos2:PanelNo2:DefectDesc2:X2:Y2:A2……
        /// #DefectPosN:PanelNoN:DefectDescN:Xn:Yn:An
        /// SN	产品 SN
        ///  TResult 结果（Y/N）
        ///  Remark 检测结果说明
        ///  CheckTime 测试时间（格式：yyyyMMddhhmmss）
        ///  ProgramID 检测程序文件名及版本
        ///  CheckAllQty 检验零件总数
        ///  FailQty 不良零件数
        ///  DefectPos1/ DefectPos2……/ DefectPosN：不良位置
        ///  PanelNo1/ PanelNo2……/ PanelNoN：不良板号（不良板在整个拼板中的序号）
        ///  DefectDesc1/ DefectDesc2…/ DefectDescN：不良现象描述
        ///  X1/X2…/Xn、Y1/Y2…/Yn、A1/A2…/An：不良点位坐标
        ///  举例：检测 OK 的SN:B175301000001#TResult:Y#Remark: #CheckTime:20161007093110#ProgramID:B51-17V17052701#CheckAllQty:150#FailQty: 0
        ///  检测 NG 的SN:B175301000002#TResult:N#Remark: #CheckTime:20161007093110#ProgramID:B51-17V17052701#CheckAllQty:150#FailQty:2#C1_1:1: BRIDGE:257.56:28.45:270.00#R10:1: Under Height:257.56:50.45:270.00
        ///</summary>
        ///<param name="WLID">工位 ID</param>
        ///<param name="WPID">工序 ID</param>
        ///<param name="OpSide">作业面（N-不区分作业面，B-背面，T-正面）</param>
        ///<param name="LineID">产线编号；</param>
        ///<param name="OpID">作业员工号；</param>
        ///<param name="BarCode">产品 SN；</param>
        ///<param name="Msg">相关信息；</param>
        ///<returns></returns>
        //[DllImport("MSLBarCode.dll", CharSet = CharSet.Ansi)]
        //private static extern int mslTestResultUpload(IntPtr WLID, IntPtr WPID, IntPtr OpSide, IntPtr LineID, IntPtr OpID, IntPtr BarCode, ref IntPtr Msg);
        [DllImport("MSLBarCode.dll")]
        public static extern int mslTestResultUpload(String WLID, String WPID, string OpSide, String LineID, String OpID, string BarCode, StringBuilder Msg);


        /// <summary>
        /// ruili mes
        /// </summary>
        /// <param name="WLID"></param>
        /// <param name="WPID"></param>
        /// <param name="OpSide"></param>
        /// <param name="LineID"></param>
        /// <param name="OpID"></param>
        /// <param name="Pwd"></param>
        /// <param name="Msg"></param>
        /// <returns></returns>
        [DllImport("MSLBarCode.dll")]
        public static extern int mslLogin(string WLID, string WPID, string OpSide, string LineID, string OpID, string Pwd, StringBuilder Msg);

        [DllImport("MSLBarCode.dll")]
        public static extern int mslTestResultUpload(string WLID, string WPID, string OpSide, string LineID, string OpID, string BarCode, string WONO, StringBuilder Msg);

        [DllImport("MSLBarCode.dll")]
        public static extern int mslCheckIn(string WLID, string WPID, string OpSide, string LineID, string OpID, string BarCode, string WONO, StringBuilder Msg);

        /// <summary>
        /// 登录接口; 设置界面save参数时使用; 验证操作员 密码
        /// </summary>
        /// <param name="WLID"></param>
        /// <param name="WPID"></param>
        /// <param name="OpSide"></param>
        /// <param name="LineID"></param>
        /// <param name="OpID"></param>
        /// <param name="Pwd"></param>
        /// <param name="Msg"></param>
        /// <returns></returns>
        public String MslLoginForSotrun(AppSettingData AappSettingData)
        {
            string strMsg = string.Empty;
            int iReturn = 0;
            try
            {
                // 
                if ((ENM_SotrunExportFormat)AappSettingData.stDataExpVT.byExportFormat == ENM_SotrunExportFormat.FactorySotrun)
                {
                    return strMsg;
                }
                //switch ((ENM_SotrunExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                //{
                //    case ENM_SotrunExportFormat.Sotrun_FactorySotrun:
                //        {

                //        }
                //}
                StringBuilder Msg = new StringBuilder();
                String WLID = AappSettingData.stDataExpVT.strMachine;
                String WPID = AappSettingData.stDataExpVT.strProductID;
                String OpSide = AappSettingData.stDataExpVT.strOpSide;
                String LineID = AappSettingData.LineName;
                String OpID = AappSettingData.strDataExpOperator;
                String Pwd = AappSettingData.stDataExpVT.strOperatorPassword;

                iReturn = mslLogin(WLID, WPID, OpSide, LineID, OpID, Pwd, Msg);
                
                if (iReturn == 0)
                {
                    strMsg = string.Empty;
                }
                else
                {
                    strMsg = Msg.ToString();
                }

            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeForSotrun)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;

        }

        ///<summary>
        /// 检查产品 SN 的有效性及工序流程状态：
        ///</summary>
        ///<param name="AsBarcode">条码</param>
        ///<param name="AsWLID">工位 ID</param>
        ///<param name="AsWPID">工序 ID</param>
        ///<param name="AsOpSide">作业面（N-不区分作业面，B-背面，T-正面）</param>
        ///<param name="AsLineID">产线编号；</param>
        ///<param name="AsOpID">作业员工号；</param>
        ///<returns></returns>
        public String CheckBarcodeForSotrun(string AsBarcode, string AsWLID, string AsWPID, string AsOpSide, string AsLineID, string AsOpID,AppSettingData AappSettingData)
        {
            string strMsg = string.Empty;
            int iReturn = 0;
            try
            {
                string WLID, WPID, OpSide, LineID, OpID, BarCode;
                StringBuilder Msg = new StringBuilder();
                WLID = AsWLID;
                WPID = AsWPID;
                OpSide = AsOpSide;
                LineID = AsLineID;
                OpID = AsOpID;
                BarCode = AsBarcode;

                switch ((ENM_SotrunExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                {
                    case ENM_SotrunExportFormat.FactorySotrun:
                        {
                            iReturn = mslCheckIn(WLID, WPID, OpSide, LineID, OpID, BarCode, Msg);
                            break;
                        }
                    case ENM_SotrunExportFormat.FactoryRuiLi:
                        {
                            iReturn = mslCheckIn(WLID, WPID, OpSide, LineID, OpID, BarCode,AappSettingData.strLotNumber, Msg);
                            break;
                        }
                    default:
                        break;
                }
              
              //  strMsg = Msg.ToString();
              //  if (String.IsNullOrEmpty(strMsg))
              //  {
              //      strMsg = "Check Barcode For Sotrun Return EMPTY";
              //  }
              //else  if (strMsg.ToUpper().Trim() == "OK")
              //  {
              //      strMsg = string.Empty;
              //  }
              if (iReturn == 0)
              {
                  strMsg = string.Empty;
              }
              else
              {
                  strMsg = Msg.ToString();
              }

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeForSotrun)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        ///<summary>
        /// 上传 AOI 检测结果（作业员最终确认后的检测结果）
        ///</summary>
        ///<param name="AsWLID"></param>
        ///<param name="AsWPID"></param>
        ///<param name="AsOpSide"></param>
        ///<param name="AsOpID"></param>
        ///<param name="APads"></param>
        ///<param name="ABrdRes"></param>
        ///<param name="APcbGeneralInfo"></param>
        ///<param name="AappSettingData"></param>
        ///<param name="AstrDir"></param>
        ///<param name="AstrClntName"></param>
        ///<returns></returns>
        public string MESSaveResultForSotrun(
             string AsWLID, string AsWPID, string AsOpSide, string AsOpID,
                        InspectMainLib.Pad[] APads,
                       SPCBoardRes ABrdRes,
                       ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                       AppSettingData AappSettingData,
                       string AstrDir,  //export folder      
                       string AstrClntName)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            try
            {
                //get board barcode
                string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                    AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                string WLID, WPID, OpSide, LineID, OpID, BarCode;
                StringBuilder Msg = new StringBuilder();

                WLID = AsWLID;
                WPID = AsWPID;
                OpSide = AsOpSide;
                LineID = AappSettingData.LineName;
                OpID = AsOpID;
                BarCode = strboardBarcode;

                //SN:XXXXXXXX#TResult:Y#Remark:TTTTTTT#CheckTime:20161007093110
                //#ProgramID:CCCCCCCC#CheckAllQty:150#FailQty:10
                //#DefectPos1:PanelNo1:DefectDesc1:X1:Y1:A1
                //#DefectPos2:PanelNo2:DefectDesc2:X2:Y2:A2
                //……
                //#DefectPosN:PanelNoN:DefectDescN:Xn:Yn:An

                //       检测OK 的
                //    SN: B175301000001#TResult:Y#Remark: #CheckTime:20161007093110 
                //    #ProgramID:B51-17V17052701#CheckAllQty:150#FailQty: 0 
                //检测NG 的
                //    SN:B175301000002#TResult:N#Remark: #CheckTime:20161007093110 
                //    #ProgramID:B51-17V17052701#CheckAllQty:150#FailQty:2 
                //    #C1_1:1: BRIDGE:257.56:28.45:270.00 
                //    #R10:1: Under Height:257.56:50.45:270.00 

                strMsg += "SN:" + strboardBarcode + "#";
                string strResult = string.Empty;
                if (ABrdRes.jugResult == JudgeRes.NG)
                {
                    strResult = "N";
                }
                else
                {
                    strResult = "Y";
                }
                strMsg += "TResult:" + strResult + "#";
                strMsg += "Remark:" + string.Empty + "#";

                strMsg += "CheckTime:" + ABrdRes.startTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName) + "#";

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }
                strMsg += "ProgramID:" + strJobName + "#";

                int iCheckAllQty = 0, iFailQty = 0;
                List<string> listQTY = new List<string>();
                Dictionary<string, string> listFailQTY = new Dictionary<string, string>();

                string strComponentID = string.Empty, strDicValue = string.Empty;
                foreach (Pad pad in APads)
                {
                    if (string.IsNullOrEmpty(pad.componentID) || _wsBaseF.bPadIsSkip(pad))
                        continue;

                    strComponentID = pad.componentID + ":" + pad.strArrayID;

                    if (listQTY.Contains(strComponentID) == false)
                    {
                        listQTY.Add(strComponentID);
                    }

                    if (listFailQTY.Keys.Contains(strComponentID) == false)
                    {
                        if (pad.res.jugRes == JudgeRes.NG)
                        {
                            //    #C1_1:1: BRIDGE:257.56:28.45:270.00 
                            strDicValue = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData) + ":"
                                + pad.posXmm.ToString() + ":"
                                + pad.posYmm.ToString() + ":"
                                + pad.rotationDegOrg;
                            listFailQTY.Add(strComponentID, strDicValue);
                        }
                    }

                }

                iCheckAllQty = listQTY.Count;
                iFailQty = listFailQTY.Count;
                strMsg += "CheckAllQty:" + iCheckAllQty.ToString() + "#";
                strMsg += "FailQty:" + iFailQty.ToString();
                if (iFailQty > 0)
                {
                    foreach (string key in listFailQTY.Keys)
                    {
                        strMsg += "#" + key + ":" + listFailQTY[key];
                    }
                }
                Msg.Append(strMsg);
                if (AappSettingData.enPadDebug)
                {
                    string strJsonFile = Path.Combine( PubStaticParam.RS_strTmpFileDir, "Sotrun_" + strboardBarcode +  PubStaticParam.RS_JSon_EXT);
                    JsonHelper.SaveObject2JsonFile(Msg.ToString(), strJsonFile);
                }
                //add by peng 20190428  
                switch ((ENM_SotrunExportFormat)AappSettingData.stDataExpVT.byExportFormat)
                {
                    case ENM_SotrunExportFormat.FactorySotrun:
                        {
                            mslTestResultUpload(WLID, WPID, OpSide, LineID, OpID, BarCode, Msg);
                            break;
                        }
                    case ENM_SotrunExportFormat.FactoryRuiLi:
                        {
                            mslTestResultUpload(WLID, WPID, OpSide, LineID, OpID, BarCode,AappSettingData.strLotNumber, Msg);
                            break;
                        }
                    default:
                        break;
                }

                strMsg = Msg.ToString();
                if (strMsg.ToUpper().Trim() == "OK")
                {
                    strMsg = string.Empty;
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveResultForSotrun)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;

        }
        #endregion

        #region "三星贴片机 bad mark file hanwha"



        /// <summary>
        /// 轨道1 导出BadMarkFile
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AconfigData"></param>
        /// <param name="AstrTemp"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <returns></returns>
        public string MESSaveBadMarkFileForHanwhaLane1(
                      InspectMainLib.Pad[] APads,
                     SPCBoardRes ABrdRes,
                     ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                     AppSettingData AappSettingData,
                       AppMultiLan.AppLan Adict,
                        InspectConfig.ConfigData AconfigData,
                     string AstrTemp,  //export folder     
                      string AstrDir,  //export folder      
                     string AstrClntName)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            string strJsonFileName = string.Empty;
            try
            {
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                            AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                strJsonFileName = strboardBarcode +  PubStaticParam.RS_UnderLineSplit + ABrdRes.LaneNo.ToString() +  PubStaticParam.RS_JSon_EXT;
                string strJsonFile = Path.Combine(AstrTemp, strJsonFileName);
                if (Directory.Exists(AstrTemp) == false)
                {
                    Directory.CreateDirectory(AstrTemp);
                }

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }

                bool AbUseNGAsBadMark = false;
                //badmark  0 没有  1 有
                int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, AbUseNGAsBadMark, Adict);

                hanwhaClass.HanwhaRoot hanwhaRoot = new hanwhaClass.HanwhaRoot();

                String strUnit = "mm";
                if (AappSettingData.useMMUnit == false
                    && AappSettingData.useMilUnit == false)
                {
                    strUnit = "um";
                }
                else if (AappSettingData.useMilUnit == true)
                {
                    strUnit = "mil";
                }
                hanwhaRoot.TRANSFORTERFILE.GENERAL.UNIT = strUnit;
                hanwhaRoot.TRANSFORTERFILE.BOARD.PCBID = ABrdRes.processedPCBNumber;
                hanwhaRoot.TRANSFORTERFILE.BOARD.PCBNAME = strJobName;
                hanwhaRoot.TRANSFORTERFILE.BOARD.SERIALNUMBER = 5;
                hanwhaRoot.TRANSFORTERFILE.BOARD.BARCODEDATA = strboardBarcode;
                hanwhaRoot.TRANSFORTERFILE.BOARD.LANEID = 0;

                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayCount = 0;
                if (bISArrayPCB)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    if (bPosZeroISUsed == false)
                    {
                        iArrayCount = iArrayCount - 1;
                    }
                }

                hanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.ID = 1;
                hanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.Count = iArrayCount;
                string strBadMarkStatus = "False";
                hanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ID = 1;
                for (int i = 0; i < iArrayCount; i++)
                {
                    int ArrayStatus = aIInfo[i];
                    string strArrayResult = string.Empty;

                    switch (ArrayStatus)
                    {
                        case 0:
                            strArrayResult = "False";
                            break;
                        case 1:
                            strArrayResult = "True";
                            strBadMarkStatus = strArrayResult;
                            break;
                        default:
                            break;
                    }
                    if (string.IsNullOrEmpty(strArrayResult))
                    {
                        continue;
                    }
                    hanwhaClass.ARRAYItem aRRAYItem = new hanwhaClass.ARRAYItem();
                    aRRAYItem.ID = i + 1;
                    aRRAYItem.value = strArrayResult;
                    hanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ARRAY.Add(aRRAYItem);
                }
                hanwhaRoot.TRANSFORTERFILE.BOARD.USE.BADMARKSTATUS = strBadMarkStatus;

                JsonHelper.SaveObject2JsonFile(hanwhaRoot, strJsonFile);

                if (AconfigData._conv3StageMode == false)
                {
                    string strXMLFileName = strboardBarcode + PubStaticParam.RS_XML_EXT;
                    string strXMLFile = Path.Combine(AstrDir, strXMLFileName);
                    if (Directory.Exists(AstrDir) == false)
                    {
                        Directory.CreateDirectory(AstrDir);
                    }
                    SaveHanwhaRoot2XML(hanwhaRoot, strXMLFile);
                    File.Delete(strJsonFile);
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveBadMarkFileForHanwhaLane1)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }
        /// <summary>
        ///  轨道2 导出BadMarkFile文件
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AstrTemp"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <returns></returns>
        public string MESSaveBadMarkFileForHanwhaLane2(
                   InspectMainLib.Pad[] APads,
                  SPCBoardRes ABrdRes,
                  ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                  AppSettingData AappSettingData,
                    AppMultiLan.AppLan Adict,
                    string AstrTemp,
                  string AstrDir,  //export folder      
                  string AstrClntName)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            string strJsonFileName = string.Empty;
            try
            {
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                            AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                //读取一轨保存的记录
                hanwhaClass.HanwhaRoot hanwhaRoot = new hanwhaClass.HanwhaRoot();
                string strJsonContent = string.Empty;

                strJsonFileName = strboardBarcode +  PubStaticParam.RS_UnderLineSplit + "0" +  PubStaticParam.RS_JSon_EXT;
                string strJsonFile = Path.Combine(AstrTemp, strJsonFileName);
                if (File.Exists(strJsonFile) == false)
                {
                    strMsg = " Data for LaneNo 1 is missing !";
                    return strMsg;
                }
                else
                {
                    strJsonContent = File.ReadAllText(strJsonFile);
                }

                if (string.IsNullOrEmpty(strJsonContent))
                {
                    strMsg = " Data for LaneNo 1 is Empty !";
                    return strMsg;
                }
                var anonymous = new hanwhaClass.HanwhaRoot();
                hanwhaRoot = JsonConvert.DeserializeAnonymousType<hanwhaClass.HanwhaRoot>(strJsonContent, anonymous);
                if (string.IsNullOrEmpty(hanwhaRoot.TRANSFORTERFILE.GENERAL.UNIT))
                {
                    strMsg = " Data for LaneNo 1  Deserialize ERROR !";
                    return strMsg;
                }

                string strXMLFileName = strboardBarcode + PubStaticParam.RS_XML_EXT;
                string strXMLFile = Path.Combine(AstrDir, strXMLFileName);
                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                //string strJobName = ABrdRes.jobName;
                //if (File.Exists(strJobName) || strJobName.Contains(":"))
                //{
                //    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                //}

                bool AbUseNGAsBadMark = false;
                int[] aIInfo = _wsBaseF.GenMountSystemInfo(ABrdRes, APads, AappSettingData, APcbGeneralInfo, AbUseNGAsBadMark, Adict);

                //hanwhaRoot.TRANSFORTERFILE.BOARD.PCBID = ABrdRes.processedPCBNumber;
                //hanwhaRoot.TRANSFORTERFILE.BOARD.PCBNAME += "|" + strJobName;
                //hanwhaRoot.TRANSFORTERFILE.BOARD.SERIALNUMBER = 5;
                //hanwhaRoot.TRANSFORTERFILE.BOARD.BARCODEDATA = strboardBarcode;
                //hanwhaRoot.TRANSFORTERFILE.BOARD.LANEID = 0;

                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayCount = 0;
                if (bISArrayPCB)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    if (bPosZeroISUsed == false)
                    {
                        iArrayCount = iArrayCount - 1;
                    }
                }

                // hanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.ID = 1;
                // hanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.Count += iArrayCount;
                string strBadMarkStatus = "False";
                // hanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ID = 1;
                int iLane1ArrayCount = hanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ARRAY.Count;

                if (iArrayCount != iLane1ArrayCount)
                {
                    strMsg = "Lane 1 and lane 2  array count error!";
                }

                for (int i = 0; i < iArrayCount; i++)
                {
                    int ArrayStatus = aIInfo[i];
                    string strArrayResult = string.Empty;

                    switch (ArrayStatus)
                    {
                        case 0:
                            strArrayResult = "False";
                            break;
                        case 1:
                            {
                                strArrayResult = "True";
                                strBadMarkStatus = strArrayResult;
                                if (i < iLane1ArrayCount)
                                    hanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ARRAY[i].value = strArrayResult;
                            }
                            break;
                        default:
                            break;
                    }
                    if (string.IsNullOrEmpty(strArrayResult))
                    {
                        continue;
                    }
                }
                if (strBadMarkStatus == "True")
                {
                    hanwhaRoot.TRANSFORTERFILE.BOARD.USE.BADMARKSTATUS = strBadMarkStatus;
                }

                SaveHanwhaRoot2XML(hanwhaRoot, strXMLFile);
                File.Delete(strJsonFile);
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveBadMarkFileForHanwhaLane2)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        /// <summary>
        /// 将Hanwha结构体导出XML格式文件
        /// </summary>
        /// <param name="AhanwhaRoot"></param>
        /// <param name="strXMLFile"></param>
        private void SaveHanwhaRoot2XML(hanwhaClass.HanwhaRoot AhanwhaRoot, string strXMLFile)
        {
            try
            {
                StringBuilder sbContent = new StringBuilder();

                sbContent.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                sbContent.AppendLine("<TRANSFORTERFILE>");
                sbContent.AppendLine("<GENERAL>");
                sbContent.AppendLine(string.Format("<UNIT>{0}</UNIT>", AhanwhaRoot.TRANSFORTERFILE.GENERAL.UNIT));
                sbContent.AppendLine("</GENERAL>");
                sbContent.AppendLine("<BOARD>");
                sbContent.AppendLine(string.Format("<PCBID>{0}</PCBID>", AhanwhaRoot.TRANSFORTERFILE.BOARD.PCBID));
                sbContent.AppendLine(string.Format("<PCBNAME>{0}</PCBNAME>", AhanwhaRoot.TRANSFORTERFILE.BOARD.PCBNAME));
                sbContent.AppendLine(string.Format("<SERIALNUMBER>{0}</SERIALNUMBER>", AhanwhaRoot.TRANSFORTERFILE.BOARD.SERIALNUMBER));
                sbContent.AppendLine(string.Format("<BARCODEDATA>{0}</BARCODEDATA>", AhanwhaRoot.TRANSFORTERFILE.BOARD.BARCODEDATA));
                sbContent.AppendLine(string.Format("<LANEID>{0}</LANEID>", AhanwhaRoot.TRANSFORTERFILE.BOARD.LANEID));
                sbContent.AppendLine("<BLOCK_ARRAYCOUNT>");
                sbContent.AppendLine(string.Format("<BLOCK ID=\"{0}\">{1}</BLOCK>",
                                        AhanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.ID,
                                        AhanwhaRoot.TRANSFORTERFILE.BOARD.BLOCK_ARRAYCOUNT.BLOCK.Count));
                sbContent.AppendLine("</BLOCK_ARRAYCOUNT>");
                sbContent.AppendLine("<USE>");
                sbContent.AppendLine(string.Format("<BADMARKSTATUS>{0}</BADMARKSTATUS>",
                                        AhanwhaRoot.TRANSFORTERFILE.BOARD.USE.BADMARKSTATUS));
                sbContent.AppendLine("</USE>");
                sbContent.AppendLine("<BADMARKSTATUS>");
                sbContent.AppendLine(string.Format("<BLOCK ID=\"{0}\">",
                                        AhanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ID));

                foreach (hanwhaClass.ARRAYItem arrayItem in AhanwhaRoot.TRANSFORTERFILE.BOARD.BADMARKSTATUS.BLOCKDetail.ARRAY)
                {
                    sbContent.AppendLine(string.Format("<ARRAY ID=\"{0}\">{1}</ARRAY>",
                                     arrayItem.ID,
                                     arrayItem.value));
                }
                sbContent.AppendLine("</BLOCK>");
                sbContent.AppendLine("</BADMARKSTATUS>");
                sbContent.AppendLine("</BOARD>");
                sbContent.AppendLine("</TRANSFORTERFILE>");
                File.WriteAllText(strXMLFile, sbContent.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }





        #endregion

        #region "昆山柏特"
        ///<summary>
        /// 昆山柏特 检查Barcode
        ///</summary>
        ///<param name="isn"></param>
        ///<returns></returns>
        //[DllImport("MES.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        //private static extern IntPtr CheckIsnStatus(String isn);

        ///<summary>
        /// 昆山柏特 检查Barcode  OK 返回0  其他的返回错误信息
        ///</summary>
        ///<param name="AappSettingData"></param>
        ///<param name="AsBarCode"></param>
        ///<param name="AbyLaneNo"></param>
        ///<param name="AstrDir"></param>
        ///<param name="arrByteBadMark"></param>
        ///<returns></returns>
        //public string CheckBarcodeForBurt(
        //           AppSettingData AappSettingData,
        //           string AsBarCode)
        //{
        //    string strMsg =  PubStaticParam.RS_EMPTY;
        //    try
        //    {

        //        if (!string.IsNullOrEmpty(AsBarCode))
        //        {
        //            IntPtr ptrret = new IntPtr();
        //            ptrret = CheckIsnStatus(AsBarCode);
        //            strMsg = Marshal.PtrToStringAuto(ptrret);
        //            if (strMsg.Trim() == "0")
        //            {
        //                strMsg = string.Empty;
        //            }
        //        }
        //    }
        //    catch (System.Exception ex)
        //    {
        //        strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeForBurt)" + ex.Message.ToString();
        //    }
        //    finally
        //    {
        //    }
        //    return strMsg;
        //}

        public string CheckBarcodeForBurt(
            AppSettingData AappSettingData,
             SPCBoardRes ABrdRes,
            string AstrURL,
            string AsBarCode)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            try
            {
                //Q.F.2017.12.06
                if (string.IsNullOrEmpty(AstrURL))
                {
                    strMsg = "error:parameter error";//Q.F.2017.04.07
                    return strMsg;
                }
                if (!string.IsNullOrEmpty(AsBarCode) && !string.IsNullOrEmpty(AstrURL))
                {

                    string strJobName= ABrdRes.jobName;
                    if (!string.IsNullOrEmpty(strJobName))
                    {
                        strJobName = Path.GetFileNameWithoutExtension(strJobName);
                    }
                    if (AstrURL.EndsWith("\\") == false)
                    {
                        AstrURL += "\\";
                    }
                    strMsg = Request_Rest(AstrURL + AsBarCode+"\\"+ strJobName);
                    if (strMsg.Trim() == "0")
                    {
                        strMsg = string.Empty;
                    }
                }
            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(CheckBarcodeForBurt)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        private string Request_Rest(string url)
        {
            HttpWebRequest request;
            HttpWebResponse response = null;
            StreamReader reader;
            StringBuilder sbSource;
            string address = url;
            try
            {
                if (address == null)
                {
                    throw new ArgumentNullException("address");
                }

                request = WebRequest.Create(address) as HttpWebRequest;
                request.UserAgent = ".NET Sample";
                request.Method = "GET";
                request.KeepAlive = false;
                request.Timeout = 30 * 1000;
                response = request.GetResponse() as HttpWebResponse;
                if (request.HaveResponse == true && response != null)
                {
                    reader = new StreamReader(response.GetResponseStream());
                    sbSource = new StringBuilder(reader.ReadToEnd());
                    string returnStr = Regex.Unescape(sbSource.ToString());
                    returnStr = returnStr.Replace("{\"result\":[\"", "");
                    returnStr = returnStr.Replace("\"]}", "");
                    return returnStr;
                }
            }
            catch (WebException wex)
            {
                if (wex.Response != null)
                {
                    using (HttpWebResponse errorResponse = (HttpWebResponse)wex.Response)
                    {
                        return errorResponse.StatusDescription;
                    }
                }
            }
            finally
            {
                if (response != null) { response.Close(); }
            }
            return "-1";
        }
        #endregion

        #region "昆山仁宝 Compal"


        /// <summary>
        /// 昆山仁宝 Compal 生成XML文件上传到对方mes
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AconfigData"></param>
        /// <param name="AstrTemp"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <param name="OstrLog"></param>
        /// <returns></returns>
        public string MESSaveXMLFileForCompal(
                         InspectMainLib.Pad[] APads,
                        SPCBoardRes ABrdRes,
                        ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                        AppSettingData AappSettingData,
                          AppMultiLan.AppLan Adict,
                           InspectConfig.ConfigData AconfigData,
                        string AstrTemp,  //export folder     
                         string AstrDir,  //export folder      
                       string AstrClntName, out string OstrLog)
        {
            string strMsg = PubStaticParam.RS_EMPTY;
            OstrLog = string.Empty + "\r\n";
            try
            {
                string strSystemUserName = Environment.UserName;
                string strMachineName = Environment.MachineName;
                string strVersion = AconfigData._strUIVersion; // Assembly.GetExecutingAssembly().GetName().Version.ToString();
                string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                string strJobName = ABrdRes.jobName;
                string strLineNo = AappSettingData.LineName;
                string strTestTime = ABrdRes.endTime.ToString(PubStaticParam.RS_FORMAT_DATETIME_EU);

                float fRate = PubStaticParam.RS_fUM2MM;
                string strUnit = "Millimeter";
                if (AappSettingData.useMMUnit == false
                    && AappSettingData.useMilUnit == false)
                {
                    strUnit = "Micrometer"; //um
                    fRate = 1f;
                }
                else if (AappSettingData.useMilUnit == true)
                {
                    strUnit = "Miltary";
                    fRate = PubStaticParam.RS_fUM2Mil;
                }

                CompalClass.Cyber_SPI_INFO cyber_SPI_INFO = new CompalClass.Cyber_SPI_INFO();
                //if (AappSettingData.enPadDebug)
                //{
                //    OstrLog += " new CompalClass.Cyber_SPI_INFO " + "\r\n";
                //}
                cyber_SPI_INFO.xmlns_cyber = "http://www.cyberoptics.com/SPI/measure";
                cyber_SPI_INFO.xmlns_xsi = "http://www.w3.org/2000/10/XMLSchemainstance";
                cyber_SPI_INFO.xsi_schemaLocation = "http://www.cyberoptics.com/SPI/measure c:/xml/Measure.xsd";
                cyber_SPI_INFO.UserName = strSystemUserName;
                cyber_SPI_INFO.SystemId.SPIVersion = strVersion;
                cyber_SPI_INFO.SystemId.text = strMachineName;
                //pannel name 
                cyber_SPI_INFO.Panel.Name = ABrdRes.pcbID.ToString();
                cyber_SPI_INFO.Panel.LotCode = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.Device = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.NGCode = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.Code = strboardBarcode;
                cyber_SPI_INFO.Panel.CarrierCode = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelDefectPath = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.SqueegeeDir = ABrdRes.squeegeDir.ToString();

                cyber_SPI_INFO.Panel.PanelSizeX = (APcbGeneralInfo.boardWidthMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelSizeY = (APcbGeneralInfo.boardHeightMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelRotation = APcbGeneralInfo.rotationDeg.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.StartTime = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATETIME_EU);
                cyber_SPI_INFO.Panel.TestTime = strTestTime;
                cyber_SPI_INFO.Panel.CycleTime = (ABrdRes.endTime - ABrdRes.startTime).TotalSeconds.ToString();

                string strStatus = "";
                string strNGCode = PubStaticParam.RS_NOREADNA;
                switch (ABrdRes.jugResult)
                {
                    case JudgeRes.Good:
                    case JudgeRes.Pass:
                        strStatus = "P";
                        break;
                    case JudgeRes.NG:
                        strStatus = "F";
                        break;
                    case JudgeRes.Skipped:
                        strStatus = PubStaticParam.RS_NOREADNA;
                        break;
                    default:
                        strStatus = "P";
                        break;
                }
                cyber_SPI_INFO.Panel.Status = strStatus;
                cyber_SPI_INFO.Panel.Id = ABrdRes.pcbID.ToString();

                cyber_SPI_INFO.Panel.SRFFName = strJobName;
                cyber_SPI_INFO.Panel.Units = strUnit;

                string strPanelFeaturePasteStatus = strStatus, strPanelFeatureRegistrStatus = strStatus, strPanelFeatureBridgingStatus = strStatus;
                int iPanelFeaturePasteValue = 0, iPanelFeatureRegistrValue = 0, iPanelFeatureBridgingValue = 0;

                //image ArrayPCB
                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayCount = 0;

                if (bISArrayPCB)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                    if (bPosZeroISUsed == false)
                    {
                        iArrayCount = iArrayCount - 1;
                    }
                }

                if (iArrayCount > 0)
                {
                    cyber_SPI_INFO.Panel.Image = new CompalClass.Image[iArrayCount];
                    //if (AappSettingData.enPadDebug)
                    //{
                    //    OstrLog += string.Format("new CompalClass.Image[{0}] ", iArrayCount) + "\r\n";
                    //}
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        string strImageFeaturePasteStatus = strStatus, strImageFeatureRegistrStatus = strStatus, strImageFeatureBridgingStatus = strStatus;
                        int iImageFeaturePasteValue = 0, iImageFeatureRegistrValue = 0, iImageFeatureBridgingValue = 0;
                        cyber_SPI_INFO.Panel.Image[i] = new CompalClass.Image();

                        int j = i;
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                            //j = j + 1;
                        }
                        //if (AappSettingData.enPadDebug)
                        //{
                        //    OstrLog += string.Format(" cyber_SPI_INFO.Panel.Image[{0}]  ; arrSingleArrayInfo[{1}]  ", i, j) + "\r\n";
                        //}
                        string strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                        if (i != (iArrayCount - 1) && (string.IsNullOrEmpty(strArrayBarcode) ||
                                string.Equals(PubStaticParam.RS_NOREAD, strArrayBarcode, StringComparison.CurrentCultureIgnoreCase)))
                        {
                            strArrayBarcode = strboardBarcode;
                        }
                        if (string.IsNullOrEmpty(strArrayBarcode) ||
                                string.Equals(PubStaticParam.RS_NOREAD, strArrayBarcode, StringComparison.CurrentCultureIgnoreCase))
                        {
                            strArrayBarcode = "";
                        }
                        cyber_SPI_INFO.Panel.Image[i].Name = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].strArrayID;
                        cyber_SPI_INFO.Panel.Image[i].Code = strArrayBarcode;// APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].strArrayBarcode;
                        cyber_SPI_INFO.Panel.Image[i].TestTime = strTestTime;

                        string strArrayStatus = "";
                        switch (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].shArrayStatusSameAsJudgeRes)//shArrayStatus) //Q.F.2018.03.20
                        {
                            case (short)JudgeRes.Good:
                            case (short)JudgeRes.Pass:
                                strArrayStatus = "P";
                                break;
                            case (short)JudgeRes.NG:
                                strArrayStatus = "F";
                                break;
                            case (short)JudgeRes.Skipped:
                                strArrayStatus = PubStaticParam.RS_NOREADNA;
                                break;

                            default:
                                strArrayStatus = "P";
                                break;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].shArrayStatusSameAsJudgeRes == 3) continue;
                        cyber_SPI_INFO.Panel.Image[i].Status = strArrayStatus;
                        cyber_SPI_INFO.Panel.Image[i].Id = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].strArrayID.ToString();

                        //local Component 元器件
                        int iArrayComponentCount = 0;
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo != null)
                        {
                            iArrayComponentCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo.Length;
                        }
                        if (iArrayComponentCount > 0)
                        {
                            cyber_SPI_INFO.Panel.Image[i].Location = new CompalClass.Location[iArrayComponentCount];
                            //if (AappSettingData.enPadDebug)
                            //{
                            //    OstrLog += string.Format("new CompalClass.Location[{0}]", iArrayComponentCount) + "\r\n";
                            //}
                            for (int c = 0; c < iArrayComponentCount; c++)
                            {
                                cyber_SPI_INFO.Panel.Image[i].Location[c] = new CompalClass.Location();
                                //if (AappSettingData.enPadDebug)
                                //{
                                //    OstrLog += string.Format("cyber_SPI_INFO.Panel.Image[i].Location[{0}] ", c) + "\r\n";
                                //}

                                cyber_SPI_INFO.Panel.Image[i].Location[c].Name = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo[c].strComPonentID;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].Part = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].Package = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].Code = "";//"";
                                cyber_SPI_INFO.Panel.Image[i].Location[c].TestTime = strTestTime;

                                string strComponentStatus = PubStaticParam.RS_NOREADNA;
                                string strPadStatus = PubStaticParam.RS_NOREADNA;
                                if (strStatus != PubStaticParam.RS_NOREADNA)
                                {
                                    strComponentStatus = "P";
                                    // strPadStatus = strStatus;
                                }

                                Double fLocationResultHeightAvgValue = 0f;
                                Double fLocationResultHeightAvgUpFail = 0f;
                                Double fLocationResultHeightAvgUpWarn = 0f;
                                Double fLocationResultHeightAvgLowFail = 0f;
                                Double fLocationResultHeightAvgLowWarn = 0f;

                                Double fLocationResultAreaAvgValue = 0f;
                                Double fLocationResultAreaAvgUpFail = 0f;
                                Double fLocationResultAreaAvgUpWarn = 0f;
                                Double fLocationResultAreaAvgLowFail = 0f;
                                Double fLocationResultAreaAvgLowWarn = 0f;

                                Double fLocationResultVolumeAvgValue = 0f;
                                Double fLocationResultVolumeAvgUpFail = 0f;
                                Double fLocationResultVolumeAvgUpWarn = 0f;
                                Double fLocationResultVolumeAvgLowFail = 0f;
                                Double fLocationResultVolumeAvgLowWarn = 0f;

                                string strLocalFeaturePasteStatus = strStatus, strLocalFeatureRegistrStatus = strStatus, strLocalFeatureBridgingStatus = strStatus;
                                int iLocalFeaturePasteValue = 0, iLocalFeatureRegistrValue = 0, iLocalFeatureBridgingValue = 0;

                                //Feature
                                int iArrayComponentPadCount = 0;
                                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo[c].arrPadIndices != null)
                                {
                                    iArrayComponentPadCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo[c].arrPadIndices.Length;
                                }
                                string strErrorcode = string.Empty;
                                if (iArrayComponentPadCount > 0)
                                {

                                    cyber_SPI_INFO.Panel.Image[i].Location[c].Feature = new CompalClass.Feature[iArrayComponentPadCount];
                                    //if (AappSettingData.enPadDebug)
                                    //{
                                    //    OstrLog += string.Format("new CompalClass.Feature[{0}] ", iArrayComponentPadCount) + "\r\n";
                                    //}
                                    int p = 0;
                                    strErrorcode = string.Empty;
                                    foreach (int iPad in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[j].arrComponentInfo[c].arrPadIndices)
                                    {
                                        if (_wsBaseF.bPadIsSkip(APads[iPad])) continue;
                                        int iHeightAvgIndex = 0, iAreaAvgIndex = 0, iVolAvgIndex = 0;
                                        //if (strStatus != "P" || strStatus != PubStaticParam.RS_NOREADNA)
                                        //{

                                        if (APads[iPad].res.jugRes == JudgeRes.NG)
                                        {
                                            strPadStatus = "F";
                                            strComponentStatus = "F";
                                            strErrorcode = _wsBaseF.GetPadErrorCodeStr(APads[iPad], AappSettingData);
                                            switch (APads[iPad].res.jugDefectType)
                                            {
                                                case DefectType.Bridge:
                                                    strLocalFeatureBridgingStatus = "F";
                                                    iLocalFeatureBridgingValue++;

                                                    strImageFeatureBridgingStatus = "F";
                                                    iImageFeatureBridgingValue++;

                                                    strPanelFeatureBridgingStatus = "F";
                                                    iPanelFeatureBridgingValue++;
                                                    break;
                                                case DefectType.ShiftX:
                                                case DefectType.ShiftY:
                                                    strLocalFeatureRegistrStatus = "F";
                                                    iLocalFeatureRegistrValue++;

                                                    strImageFeatureRegistrStatus = "F";
                                                    iImageFeatureRegistrValue++;

                                                    strPanelFeatureRegistrStatus = "F";
                                                    iPanelFeatureRegistrValue++;
                                                    break;
                                                case DefectType.OverHeight:
                                                case DefectType.LowHeight:
                                                case DefectType.OverArea:
                                                case DefectType.LowArea:
                                                    strLocalFeaturePasteStatus = "F";
                                                    iLocalFeaturePasteValue++;

                                                    strImageFeaturePasteStatus = "F";
                                                    iImageFeaturePasteValue++;

                                                    strPanelFeaturePasteStatus = "F";
                                                    iPanelFeaturePasteValue++;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            //  break;
                                        }
                                        else if (APads[iPad].res.jugRes == JudgeRes.Good || APads[iPad].res.jugRes == JudgeRes.Pass)
                                        {
                                            strPadStatus = "P";
                                            //strComponentStatus = "P";
                                            strLocalFeaturePasteStatus = "P";
                                            strLocalFeatureRegistrStatus = "P";
                                            strLocalFeatureBridgingStatus = "P";
                                        }
                                        //}
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p] = new CompalClass.Feature();
                                        //if (AappSettingData.enPadDebug)
                                        //{
                                        //    OstrLog += string.Format("cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[{0}]  ", p) + "\r\n";
                                        //}
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].Name = APads[iPad].padID.ToString();
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].LogMode = PubStaticParam.RS_NOREADNA;
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].Status = strPadStatus;
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].Id = APads[iPad].padID.ToString();
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].X = (APads[iPad].sizeXmmNew * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                        cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].Y = (APads[iPad].sizeYmmNew * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                        //cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].ReworkError = strErrorcode;
                                        #region ' //FeatureResult'

                                        if (APads[iPad].checkHeight && strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Status = strPadStatus;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Value = (APads[iPad].res.measuredValue.height * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.UpFail = (APads[iPad].spec.heightH * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.UpWarn = (APads[iPad].spec.fAlarmHeightU * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Target = (APads[iPad].stencilHeight * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.LowFail = (APads[iPad].spec.heightL * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.LowWarn = (APads[iPad].spec.fAlarmHeightL * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);

                                            fLocationResultHeightAvgValue = (fLocationResultHeightAvgValue * (iHeightAvgIndex) + APads[iPad].res.measuredValue.height * fRate) / (iHeightAvgIndex + 1);
                                            fLocationResultHeightAvgUpFail = (fLocationResultHeightAvgUpFail * (iHeightAvgIndex) + APads[iPad].spec.heightH * fRate) / (iHeightAvgIndex + 1);
                                            fLocationResultHeightAvgUpWarn = (fLocationResultHeightAvgUpWarn * (iHeightAvgIndex) + APads[iPad].spec.fAlarmHeightU * fRate) / (iHeightAvgIndex + 1);
                                            fLocationResultHeightAvgLowFail = (fLocationResultHeightAvgLowFail * (iHeightAvgIndex) + APads[iPad].spec.heightL * fRate) / (iHeightAvgIndex + 1);
                                            fLocationResultHeightAvgLowWarn = (fLocationResultHeightAvgLowWarn * (iHeightAvgIndex) + APads[iPad].spec.fAlarmHeightL * fRate) / (iHeightAvgIndex + 1);

                                            iHeightAvgIndex++;
                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Status = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Value = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.UpFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.UpWarn = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.Target = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.LowFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Height.LowWarn = PubStaticParam.RS_NOREADNA;

                                        }

                                        if (APads[iPad].checkArea && strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Status = strPadStatus;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Value = (APads[iPad].res.measuredValue.area * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.UpFail = (APads[iPad].res.measuredValue.area * APads[iPad].spec.areaPerH * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.UpWarn = (APads[iPad].res.measuredValue.area * APads[iPad].spec.fAlarmAreaU * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Target = (APads[iPad].res.measuredValue.fCadArea * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.LowFail = (APads[iPad].res.measuredValue.area * APads[iPad].spec.areaPerL * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.LowWarn = (APads[iPad].res.measuredValue.area * APads[iPad].spec.fAlarmAreaL * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);


                                            fLocationResultAreaAvgValue = (fLocationResultAreaAvgValue * (iAreaAvgIndex) + APads[iPad].res.measuredValue.area * fRate) / (iAreaAvgIndex + 1);
                                            fLocationResultAreaAvgUpFail = (fLocationResultAreaAvgUpFail * (iAreaAvgIndex) + APads[iPad].res.measuredValue.area * APads[iPad].spec.areaPerH * fRate * fRate) / (iAreaAvgIndex + 1);
                                            fLocationResultAreaAvgUpWarn = (fLocationResultAreaAvgUpWarn * (iAreaAvgIndex) + APads[iPad].res.measuredValue.area * APads[iPad].spec.fAlarmAreaU * fRate * fRate) / (iAreaAvgIndex + 1);
                                            fLocationResultAreaAvgLowFail = (fLocationResultAreaAvgLowFail * (iAreaAvgIndex) + APads[iPad].res.measuredValue.area * APads[iPad].spec.areaPerL * fRate * fRate) / (iAreaAvgIndex + 1);
                                            fLocationResultAreaAvgLowWarn = (fLocationResultAreaAvgLowWarn * (iAreaAvgIndex) + APads[iPad].res.measuredValue.area * APads[iPad].spec.fAlarmAreaL * fRate * fRate) / (iAreaAvgIndex + 1);

                                            iAreaAvgIndex++;

                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Status = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Value = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.UpFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.UpWarn = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.Target = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.LowFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Area.LowWarn = PubStaticParam.RS_NOREADNA;
                                        }

                                        if (APads[iPad].checkVol && strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Status = strPadStatus;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Value = (APads[iPad].res.measuredValue.vol * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.UpFail = (APads[iPad].res.measuredValue.vol * APads[iPad].spec.volPerH * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.UpWarn = (APads[iPad].res.measuredValue.vol * APads[iPad].spec.fAlarmVolU * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Target = (APads[iPad].res.measuredValue.fCADVol * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.LowFail = (APads[iPad].res.measuredValue.vol * APads[iPad].spec.volPerL * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.LowWarn = (APads[iPad].res.measuredValue.vol * APads[iPad].spec.fAlarmVolL * fRate * fRate * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);

                                            fLocationResultVolumeAvgValue = (fLocationResultVolumeAvgValue * (iVolAvgIndex) + APads[iPad].res.measuredValue.vol * fRate * fRate * fRate) / (iVolAvgIndex + 1);
                                            fLocationResultVolumeAvgUpFail = (fLocationResultVolumeAvgUpFail * (iVolAvgIndex) + APads[iPad].res.measuredValue.vol * APads[iPad].spec.volPerH * fRate * fRate * fRate) / (iVolAvgIndex + 1);
                                            fLocationResultVolumeAvgUpWarn = (fLocationResultVolumeAvgUpWarn * (iVolAvgIndex) + APads[iPad].res.measuredValue.vol * APads[iPad].spec.fAlarmVolU * fRate * fRate * fRate) / (iVolAvgIndex + 1);
                                            fLocationResultVolumeAvgLowFail = (fLocationResultVolumeAvgLowFail * (iVolAvgIndex) + APads[iPad].res.measuredValue.vol * APads[iPad].spec.volPerL * fRate * fRate * fRate) / (iVolAvgIndex + 1);
                                            fLocationResultVolumeAvgLowWarn = (fLocationResultVolumeAvgLowWarn * (iVolAvgIndex) + APads[iPad].res.measuredValue.vol * APads[iPad].spec.fAlarmVolL * fRate * fRate * fRate) / (iVolAvgIndex + 1);
                                            iVolAvgIndex++;
                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Status = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Value = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.UpFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.UpWarn = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.Target = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.LowFail = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Volume.LowWarn = PubStaticParam.RS_NOREADNA;
                                        }

                                        //Registration4
                                        if (strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.Status = strPadStatus;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.BoundaryStatus = "0";
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.LongPct = (APads[iPad].res.measuredValue.fOffsetXOrgMM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.LongPctLimit = (APads[iPad].spec.shiftXH * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.ShortPct = (APads[iPad].res.measuredValue.fOffsetYOrgMM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.ShortPctLimit = (APads[iPad].spec.shiftYH * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.Status = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.BoundaryStatus = "0";
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.LongPct = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.LongPctLimit = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.ShortPct = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Registration4.ShortPctLimit = PubStaticParam.RS_NOREADNA;

                                        }

                                        //需要确认  joch  這是在講短路測試，Value是指兩焊盤短路的寬度。 Limit是我們設定的標準值，短路寬度大於limit就會報錯短路
                                        if (APads[iPad].checkBridge && strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Status = strPadStatus;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Value = (APads[iPad].spec.brdgDistance * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Limit = (APads[iPad].spec.brdgMinWidth * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Status = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Value = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Bridging.Limit = PubStaticParam.RS_NOREADNA;
                                        }

                                        //Diagnostics3  Registration3
                                        if (strPadStatus != PubStaticParam.RS_NOREADNA)
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Diagnostics3.Registration3.XOffset = (APads[iPad].res.measuredValue.offsetX * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Diagnostics3.Registration3.YOffset = (APads[iPad].res.measuredValue.offsetY * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                        }
                                        else
                                        {
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Diagnostics3.Registration3.XOffset = PubStaticParam.RS_NOREADNA;
                                            cyber_SPI_INFO.Panel.Image[i].Location[c].Feature[p].FeatureResult.Diagnostics3.Registration3.YOffset = PubStaticParam.RS_NOREADNA;
                                        }
                                        #endregion
                                        p++;

                                    }//End   ForEach Pad
                                }
                                cyber_SPI_INFO.Panel.Image[i].Location[c].Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].Id = c.ToString();
                                cyber_SPI_INFO.Panel.Image[i].Location[c].ReworkError = strErrorcode;

                                #region  //LocationResult  元器件统计结果
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.Value = fLocationResultHeightAvgValue.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.UpFail = fLocationResultHeightAvgUpFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.UpWarn = fLocationResultHeightAvgUpWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.LowFail = fLocationResultHeightAvgLowFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightAvg.LowWarn = fLocationResultHeightAvgLowWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.Value = fLocationResultAreaAvgValue.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.UpFail = fLocationResultAreaAvgUpFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.UpWarn = fLocationResultAreaAvgUpWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.LowFail = fLocationResultAreaAvgLowFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaAvg.LowWarn = fLocationResultAreaAvgLowWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.Value = fLocationResultVolumeAvgValue.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.UpFail = fLocationResultVolumeAvgUpFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.UpWarn = fLocationResultVolumeAvgUpWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.LowFail = fLocationResultVolumeAvgLowFail.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeAvg.LowWarn = fLocationResultVolumeAvgLowWarn.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightRange.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightRange.Value = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.HeightRange.Limit = PubStaticParam.RS_NOREADNA;

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaRange.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaRange.Value = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.AreaRange.Limit = PubStaticParam.RS_NOREADNA;

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeRange.Status = strComponentStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeRange.Value = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.VolumeRange.Limit = PubStaticParam.RS_NOREADNA;

                                //FeatureFailures 焊盘测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Paste.Status = strLocalFeaturePasteStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Paste.Value = iLocalFeaturePasteValue.ToString();
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Paste.Limit = "0";

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Registration.Status = strLocalFeatureRegistrStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Registration.Value = iLocalFeatureRegistrValue.ToString();
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Registration.Limit = "0";

                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Bridging.Status = strLocalFeatureBridgingStatus;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Bridging.Value = iLocalFeatureBridgingValue.ToString();
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.FeatureFailures.Bridging.Limit = "0";
                                //Diagnostics Registration2
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.XOrigin = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.XOffset = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.YOrigin = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.YOffset = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.Rotation = PubStaticParam.RS_NOREADNA;
                                cyber_SPI_INFO.Panel.Image[i].Location[c].LocationResult.Diagnostics.Registration2.Scale = PubStaticParam.RS_NOREADNA;
                                #endregion

                            }  //End For Component

                        }


                        #region  //ImageResult
                        //LocationFailures 元器件零件测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Paste.Status = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Paste.Value = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Paste.Limit = "0";

                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Registration.Status = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Registration.Value = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Registration.Limit = "0";

                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Bridging.Status = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Bridging.Value = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.LocationFailures.Bridging.Limit = "0";

                        //FeatureFailures 焊盘测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Paste.Status = strImageFeaturePasteStatus;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Paste.Value = iImageFeaturePasteValue.ToString();
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Paste.Limit = "0";

                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Registration.Status = strImageFeatureRegistrStatus;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Registration.Value = iImageFeatureRegistrValue.ToString();
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Registration.Limit = "0";

                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Bridging.Status = strImageFeatureBridgingStatus;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Bridging.Value = iImageFeatureBridgingValue.ToString();
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.FeatureFailures.Bridging.Limit = "0";

                        //Registration 拼板的XY坐标 偏移 角度 比例(Scale)?
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.XOrigin = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.YOrigin = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.XOffset = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.YOffset = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.Rotation = PubStaticParam.RS_NOREADNA;
                        cyber_SPI_INFO.Panel.Image[i].ImageResult.Diagnostics.Registration2.Scale = PubStaticParam.RS_NOREADNA;
                        #endregion
                    }//End FOR PAD
                }//  if (iArrayCount > 0)

                #region  //PanelResult
                //ImageFailures拼板测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路

                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Paste.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Paste.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Paste.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Registration.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Registration.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Registration.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Bridging.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Bridging.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.ImageFailures.Bridging.Limit = "0";

                //LocationFailures 元器件零件测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Paste.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Paste.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Paste.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Registration.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Registration.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Registration.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Bridging.Status = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Bridging.Value = PubStaticParam.RS_NOREADNA;
                cyber_SPI_INFO.Panel.PanelResult.LocationFailures.Bridging.Limit = "0";

                //FeatureFailures 焊盘测试结果  Paste status—代表高度/面積/體積 Registration status—代表偏移  Bridging status---代表短路
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Paste.Status = strPanelFeaturePasteStatus;
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Paste.Value = iPanelFeaturePasteValue.ToString();
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Paste.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Registration.Status = strPanelFeatureRegistrStatus;
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Registration.Value = iPanelFeatureRegistrValue.ToString();
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Registration.Limit = "0";

                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Bridging.Status = strPanelFeatureBridgingStatus;
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Bridging.Value = iPanelFeatureBridgingValue.ToString();
                cyber_SPI_INFO.Panel.PanelResult.FeatureFailures.Bridging.Limit = "0";
                //Registration
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.XOrigin = (APcbGeneralInfo.boardWidthMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.YOrigin = (APcbGeneralInfo.boardHeightMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.XOffset = (APcbGeneralInfo.boardOffsetXMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.YOffset = (APcbGeneralInfo.boardOffsetYMM * PubStaticParam.RS_fMM2UM * fRate).ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.Rotation = APcbGeneralInfo.rotationDeg.ToString(PubStaticParam.RS_FLOATFORMAT_4Bit);
                cyber_SPI_INFO.Panel.PanelResult.Diagnostics.Registration2.Scale = PubStaticParam.RS_NOREADNA;
                #endregion

                string strXMLFile = Path.Combine(AstrDir, Path.GetFileNameWithoutExtension(strJobName) + "." + strboardBarcode + PubStaticParam.RS_XML_EXT);

                string strXMLTempFile = Path.Combine(AstrTemp, Path.GetFileNameWithoutExtension(strJobName) + "." + strboardBarcode + PubStaticParam.RS_XML_EXT);
                XMLHelper.SaveObj2XMLFile(cyber_SPI_INFO, strXMLFile, strXMLTempFile);
            }
            catch (System.Exception ex)
            {
                strMsg += PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveXMLFileForCompal)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        #endregion

        #region "三迪光 3DTechco"
        public string SaveDataFileFor3DTechco(
            InspectMainLib.Pad[] APads,
            SPCBoardRes ABrdRes,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
            AppSettingData AappSettingData,
            string AstrDir,
            string AstrClntName,
            out string OstrLog)
        {

            string strMsg =  PubStaticParam.RS_EMPTY;
            OstrLog =  PubStaticParam.RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile =  PubStaticParam.RS_strTmpFileDir + "\\" +  PubStaticParam.RS_DataExportTempFile;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                //check dir
                if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                {
                    strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }


                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayCount = 0;
                string strArrayBarcode =  PubStaticParam.RS_EMPTY;
                string strLineNo = AappSettingData.LineName;
                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                string strArrayStatus =  PubStaticParam.RS_EMPTY;


                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }

                if (bISArrayPCB && iArrayCount > 0)
                {
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            switch (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatus)
                            {
                                case (int)JudgeRes.NG:
                                    strArrayStatus = "NG";
                                    break;
                                default:
                                    strArrayStatus = "OK";
                                    break;
                            }

                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                            string strLinePre =  PubStaticParam.RS_EMPTY;
                            StringBuilder strBldBoard = new StringBuilder();
                            StringBuilder strBldPld = new StringBuilder();

                            strLinePre = "Model name" +  PubStaticParam.RS_CommaSplit + "Line number";
                            strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                            strLinePre = strJobName +  PubStaticParam.RS_CommaSplit + strLineNo;
                            strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                            strLinePre = "Status" +  PubStaticParam.RS_CommaSplit + strArrayStatus;
                            strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                            //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                            strBldPld.Append(
                                                     "PadID" +  PubStaticParam.RS_CommaSplit
                                                  + "ComponentID" +  PubStaticParam.RS_CommaSplit
                                                  + "Type" +  PubStaticParam.RS_CommaSplit
                                                  + "Area(%)" +  PubStaticParam.RS_CommaSplit
                                                  + "Height" +  PubStaticParam.RS_CommaSplit
                                                  + "Volume(%)" +  PubStaticParam.RS_CommaSplit
                                                   + "XOffset" +  PubStaticParam.RS_CommaSplit
                                                    + "YOffset" +  PubStaticParam.RS_CommaSplit
                                                  + "PadSize(X)" +  PubStaticParam.RS_CommaSplit
                                                  + "PadSize(Y)" +  PubStaticParam.RS_CommaSplit
                                                  + "Area" +  PubStaticParam.RS_CommaSplit
                                                  + "Height(%)" +  PubStaticParam.RS_CommaSplit
                                                 + "Volume" +  PubStaticParam.RS_CommaSplit
                                                  + "Result" +  PubStaticParam.RS_CommaSplit
                                                  + "Errcode" +  PubStaticParam.RS_CommaSplit
                                                  + "PinNum" +  PubStaticParam.RS_CommaSplit
                                                  + "Barcode" +  PubStaticParam.RS_CommaSplit
                                                  + "Date" +  PubStaticParam.RS_CommaSplit
                                                  + "Time" +  PubStaticParam.RS_CommaSplit
                                                  + "ArrayID"
                                                  + PubStaticParam.RS_LineEnd
                                                  );

                            foreach (int iPadIndex in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices)
                            {
                                //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                                Pad pad = APads[iPadIndex];

                                if (_wsBaseF.bPadIsSkip(pad))
                                {
                                    continue;
                                }

                                //PadID
                                strBldPld.Append(pad.padID +  PubStaticParam.RS_CommaSplit);
                                //ComponentID
                                strBldPld.Append(pad.componentID +  PubStaticParam.RS_CommaSplit);
                                //Type
                                strBldPld.Append( PubStaticParam.RS_EMPTY +  PubStaticParam.RS_CommaSplit);
                                //Area(%)
                                strBldPld.Append(pad.res.measuredValue.perArea +  PubStaticParam.RS_CommaSplit);
                                //Height
                                strBldPld.Append(pad.res.measuredValue.height +  PubStaticParam.RS_CommaSplit);
                                //Volume(%)
                                strBldPld.Append(pad.res.measuredValue.perVol +  PubStaticParam.RS_CommaSplit);
                                //XOffset
                                strBldPld.Append(pad.res.measuredValue.fOffsetXOrgMM +  PubStaticParam.RS_CommaSplit);
                                //YOffset
                                strBldPld.Append(pad.res.measuredValue.fOffsetYOrgMM +  PubStaticParam.RS_CommaSplit);
                                //PadSize(X)
                                strBldPld.Append(pad.sizeXmmNew +  PubStaticParam.RS_CommaSplit);
                                //PadSize(Y)
                                strBldPld.Append(pad.sizeYmmNew +  PubStaticParam.RS_CommaSplit);
                                //Area
                                strBldPld.Append(pad.res.measuredValue.area +  PubStaticParam.RS_CommaSplit);
                                //Height(%)
                                strBldPld.Append(pad.res.measuredValue.perHeight +  PubStaticParam.RS_CommaSplit);
                                //Volume
                                strBldPld.Append(pad.res.measuredValue.vol +  PubStaticParam.RS_CommaSplit);
                                //Result
                                strBldPld.Append(pad.res.jugRes +  PubStaticParam.RS_CommaSplit);
                                //Errcode
                                string strErrcode =  PubStaticParam.RS_EMPTY;
                                if (pad.res.jugRes == JudgeRes.NG)
                                {
                                    strErrcode = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData);
                                }
                                strBldPld.Append(strErrcode +  PubStaticParam.RS_CommaSplit);
                                //PinNum
                                strBldPld.Append(pad.pinNumber +  PubStaticParam.RS_CommaSplit);
                                //Barcode
                                strBldPld.Append(pad.stBarcodeRes +  PubStaticParam.RS_CommaSplit);
                                //Date
                                strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATE) +  PubStaticParam.RS_CommaSplit);
                                //Time
                                strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_TIME) +  PubStaticParam.RS_CommaSplit);
                                //ArrayID
                                strBldPld.Append(pad.strArrayID +  PubStaticParam.RS_CommaSplit);
                            }

                            string strFileName = strArrayStatus +  PubStaticParam.RS_UnderLineSplit + strArrayBarcode +  PubStaticParam.RS_TXT_EXT;
                            strFileName = Path.Combine(AstrDir, strFileName);
                            FileStream fs = new FileStream(tmpFile, FileMode.Create);
                            System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                            streamWrt.Write(strBldBoard);
                            streamWrt.Write(strBldPld);
                            streamWrt.Close();

                            if (File.Exists(tmpFile))
                            {
                                File.Copy(tmpFile, strFileName, true);
                            }
                        }
                    }
                }
                else
                {

                    strArrayBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);
                    string strLinePre =  PubStaticParam.RS_EMPTY;
                    StringBuilder strBldBoard = new StringBuilder();
                    StringBuilder strBldPld = new StringBuilder();

                    strLinePre = "Model name" +  PubStaticParam.RS_CommaSplit + "Line number";
                    strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                    strLinePre = strJobName +  PubStaticParam.RS_CommaSplit + strLineNo;
                    strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                    strLinePre = "Board Status" +  PubStaticParam.RS_CommaSplit + strArrayStatus;
                    strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                    //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                    strBldPld.Append(
                                             "PadID" +  PubStaticParam.RS_CommaSplit
                                          + "ComponentID" +  PubStaticParam.RS_CommaSplit
                                          + "Type" +  PubStaticParam.RS_CommaSplit
                                          + "Area(%)" +  PubStaticParam.RS_CommaSplit
                                          + "Height" +  PubStaticParam.RS_CommaSplit
                                          + "Volume(%)" +  PubStaticParam.RS_CommaSplit
                                           + "XOffset" +  PubStaticParam.RS_CommaSplit
                                            + "YOffset" +  PubStaticParam.RS_CommaSplit
                                          + "PadSize(X)" +  PubStaticParam.RS_CommaSplit
                                          + "PadSize(Y)" +  PubStaticParam.RS_CommaSplit
                                          + "Area" +  PubStaticParam.RS_CommaSplit
                                          + "Height(%)" +  PubStaticParam.RS_CommaSplit
                                         + "Volume" +  PubStaticParam.RS_CommaSplit
                                          + "Result" +  PubStaticParam.RS_CommaSplit
                                          + "Errcode" +  PubStaticParam.RS_CommaSplit
                                          + "PinNum" +  PubStaticParam.RS_CommaSplit
                                          + "Barcode" +  PubStaticParam.RS_CommaSplit
                                          + "Date" +  PubStaticParam.RS_CommaSplit
                                          + "Time" +  PubStaticParam.RS_CommaSplit
                                          + "ArrayID"
                                          + PubStaticParam.RS_LineEnd
                                          );

                    foreach (Pad pad in APads)
                    {
                        //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                        if (_wsBaseF.bPadIsSkip(pad))
                        {
                            continue;
                        }
                        //PadID
                        strBldPld.Append(pad.padID +  PubStaticParam.RS_CommaSplit);
                        //ComponentID
                        strBldPld.Append(pad.componentID +  PubStaticParam.RS_CommaSplit);
                        //Type
                        strBldPld.Append( PubStaticParam.RS_EMPTY +  PubStaticParam.RS_CommaSplit);
                        //Area(%)
                        strBldPld.Append(pad.res.measuredValue.perArea +  PubStaticParam.RS_CommaSplit);
                        //Height
                        strBldPld.Append(pad.res.measuredValue.height +  PubStaticParam.RS_CommaSplit);
                        //Volume(%)
                        strBldPld.Append(pad.res.measuredValue.perVol +  PubStaticParam.RS_CommaSplit);
                        //XOffset
                        strBldPld.Append(pad.res.measuredValue.fOffsetXOrgMM +  PubStaticParam.RS_CommaSplit);
                        //YOffset
                        strBldPld.Append(pad.res.measuredValue.fOffsetYOrgMM +  PubStaticParam.RS_CommaSplit);
                        //PadSize(X)
                        strBldPld.Append(pad.sizeXmmNew +  PubStaticParam.RS_CommaSplit);
                        //PadSize(Y)
                        strBldPld.Append(pad.sizeYmmNew +  PubStaticParam.RS_CommaSplit);
                        //Area
                        strBldPld.Append(pad.res.measuredValue.area +  PubStaticParam.RS_CommaSplit);
                        //Height(%)
                        strBldPld.Append(pad.res.measuredValue.perHeight +  PubStaticParam.RS_CommaSplit);
                        //Volume
                        strBldPld.Append(pad.res.measuredValue.vol +  PubStaticParam.RS_CommaSplit);
                        //Result
                        strBldPld.Append(pad.res.jugRes +  PubStaticParam.RS_CommaSplit);
                        //Errcode
                        string strErrcode =  PubStaticParam.RS_EMPTY;
                        if (pad.res.jugRes == JudgeRes.NG)
                        {
                            strErrcode = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData);
                        }
                        strBldPld.Append(strErrcode +  PubStaticParam.RS_CommaSplit);
                        //PinNum
                        strBldPld.Append(pad.pinNumber +  PubStaticParam.RS_CommaSplit);
                        //Barcode
                        strBldPld.Append(pad.stBarcodeRes +  PubStaticParam.RS_CommaSplit);
                        //Date
                        strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATE) +  PubStaticParam.RS_CommaSplit);
                        //Time
                        strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_TIME) +  PubStaticParam.RS_CommaSplit);
                        //ArrayID
                        strBldPld.Append(pad.strArrayID +  PubStaticParam.RS_CommaSplit);
                    }

                    string strFileName = strArrayStatus +  PubStaticParam.RS_UnderLineSplit + strArrayBarcode +  PubStaticParam.RS_TXT_EXT;
                    strFileName = Path.Combine(AstrDir, strFileName);
                    FileStream fs = new FileStream(tmpFile, FileMode.Create);
                    System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                    streamWrt.Write(strBldBoard);
                    streamWrt.Write(strBldPld);
                    streamWrt.Close();

                    if (File.Exists(tmpFile))
                    {
                        File.Copy(tmpFile, strFileName, true);
                    }
                }

            }
            catch (System.Exception ex)
            {
                strMsg =  PubStaticParam.RS_DATAEXPORTMsg + "(" + AstrClntName + ")" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        #endregion

        #region "兆驰 szmtc"

        /// <summary>
        /// 获取保存Pad的图片的目录位置 并将此字段赋值给 ABrdRes.strDataExportSavePadImagePath 
        /// </summary>
        /// <param name="AappSettingData"></param>
        /// <param name="AstrDir"></param>
        /// <param name="ABrdRes"></param>
        /// <returns></returns>
        public string GetDataExportSavePadImagePath(AppSettingData AappSettingData, string AstrDir, ref SPCBoardRes ABrdRes)
        {
            try
            {
                string strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                    AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                //AstrDir\ABrdRes.pcbBarcode\Image 
                string strImagePath = Path.Combine(AstrDir, strboardBarcode, "Image");
                Directory.CreateDirectory(strImagePath);
                ABrdRes.strDataExportSavePadImagePath = strImagePath;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {

            }
            return string.Empty;
        }

        /// <summary>
        /// 轨道1 导出数据文件CSV
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AconfigData"></param>
        /// <param name="AstrTemp"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <returns></returns>
        public string MESSaveDataFileForSZMTCLane1(
                      InspectMainLib.Pad[] APads,
                     SPCBoardRes ABrdRes,
                     ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                     AppSettingData AappSettingData,
                       AppMultiLan.AppLan Adict,
                        InspectConfig.ConfigData AconfigData,
                     string AstrTemp,  //export folder     
                      string AstrDir,  //export folder      
                      string AstrClntName)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            try
            {
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                           AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                string strCSVFileName = strboardBarcode +  PubStaticParam.RS_UnderLineSplit + ABrdRes.LaneNo.ToString() +  PubStaticParam.RS_CSV_EXT;
                string strCSVFile = Path.Combine(AstrTemp, strCSVFileName);
                if (Directory.Exists(AstrTemp) == false)
                {
                    Directory.CreateDirectory(AstrTemp);
                }

                //check dir
                if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                {
                    strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }


                bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                int iArrayCount = 0;
                string strArrayBarcode =  PubStaticParam.RS_EMPTY;
                string strLineNo = AappSettingData.LineName;
                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                string strArrayStatus =  PubStaticParam.RS_EMPTY;
                float fAUSL = 0f, fALSL = 0f, fACPK = 0f, fVUSL = 0f, fVLSL = 0f, fVCPK = 0f, fHUSL = 0f, fHLSL = 0f, fHCPK = 0f;
                if (ABrdRes.stPcbMRes.Count > 0)
                {
                fAUSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[0].fMax;
                fALSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[0].fMin;
                fACPK = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[0].fCPK;

                fVUSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[1].fMax;
                fVLSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[1].fMin;
                fVCPK = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[1].fCPK;

                fHUSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[2].fMax;
                fHLSL = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[2].fMin;
                fHCPK = ABrdRes.stPcbMRes[ABrdRes.stPcbMRes.Count - 1].aStPcbMSPCRes[2].fCPK;
                }
                string strLinePre =  PubStaticParam.RS_EMPTY;

                StringBuilder strBldBoard = new StringBuilder();
                StringBuilder strBldPld = new StringBuilder();

                strLinePre = "Model name" +  PubStaticParam.RS_CommaSplit + "Line number" +
                     PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "体积" +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "面积" +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "高度";
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                strLinePre = strJobName +  PubStaticParam.RS_CommaSplit + strLineNo +
                     PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "USL" +  PubStaticParam.RS_CommaSplit + "LSL" +  PubStaticParam.RS_CommaSplit + "CPK" +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "USL" +  PubStaticParam.RS_CommaSplit + "LSL" +  PubStaticParam.RS_CommaSplit + "CPK" +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    "USL" +  PubStaticParam.RS_CommaSplit + "LSL" +  PubStaticParam.RS_CommaSplit + "CPK";
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                strLinePre = "Board Status" +  PubStaticParam.RS_CommaSplit + strArrayStatus +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit+
                     fVUSL +  PubStaticParam.RS_CommaSplit + fVLSL +  PubStaticParam.RS_CommaSplit + fVCPK +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                   fAUSL +  PubStaticParam.RS_CommaSplit + fALSL +  PubStaticParam.RS_CommaSplit + fACPK +  PubStaticParam.RS_CommaSplit +  PubStaticParam.RS_CommaSplit +
                    fHUSL +  PubStaticParam.RS_CommaSplit + fHLSL +  PubStaticParam.RS_CommaSplit + fHCPK;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo != null)
                {
                    iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                }

                if (bISArrayPCB && iArrayCount > 0)
                {
                    for (int i = 0; i < iArrayCount; i++)
                    {
                        if (bPosZeroISUsed == false && i == 0)
                        {
                            continue;
                        }
                        if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked &&
                            APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].arrIPadIndices != null)
                        {
                            strArrayStatus = Enum.GetName(typeof(JudgeRes), APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].shArrayStatusSameAsJudgeRes); //Q.F.2018.03.20
                            strArrayBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;

                            //  ArrayID,1,Array Status, SKIPPED, Array Barcode,ABarcode1
                            strLinePre = "ArrayID" +  PubStaticParam.RS_CommaSplit + APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayID +  PubStaticParam.RS_CommaSplit +
                                "Array Status" +  PubStaticParam.RS_CommaSplit + strArrayStatus +  PubStaticParam.RS_CommaSplit +
                                     " Array Barcode" +  PubStaticParam.RS_CommaSplit + strArrayBarcode +  PubStaticParam.RS_CommaSplit;
                            strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                        }
                    }

                }


                //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                strBldPld.Append(
                                         "PadID" +  PubStaticParam.RS_CommaSplit
                                      + "ComponentID" +  PubStaticParam.RS_CommaSplit
                                      + "Type" +  PubStaticParam.RS_CommaSplit
                                      + "Area(%)" +  PubStaticParam.RS_CommaSplit
                                      + "Height" +  PubStaticParam.RS_CommaSplit
                                      + "Volume(%)" +  PubStaticParam.RS_CommaSplit
                                       + "XOffset" +  PubStaticParam.RS_CommaSplit
                                        + "YOffset" +  PubStaticParam.RS_CommaSplit
                                      + "PadSize(X)" +  PubStaticParam.RS_CommaSplit
                                      + "PadSize(Y)" +  PubStaticParam.RS_CommaSplit
                                      + "Area" +  PubStaticParam.RS_CommaSplit
                                      + "Height(%)" +  PubStaticParam.RS_CommaSplit
                                     + "Volume" +  PubStaticParam.RS_CommaSplit
                                      + "Result" +  PubStaticParam.RS_CommaSplit
                                      + "Errcode" +  PubStaticParam.RS_CommaSplit
                                      + "PinNum" +  PubStaticParam.RS_CommaSplit
                                      + "Barcode" +  PubStaticParam.RS_CommaSplit
                                      + "Date" +  PubStaticParam.RS_CommaSplit
                                      + "Time" +  PubStaticParam.RS_CommaSplit
                                      + "ArrayID"
                                      + PubStaticParam.RS_LineEnd
                                      );

                foreach (Pad pad in APads)
                {
                    //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                    if (_wsBaseF.bPadIsSkip(pad))
                    {
                        continue;
                    }
                    //PadID
                    strBldPld.Append(pad.padID +  PubStaticParam.RS_CommaSplit);
                    //ComponentID
                    strBldPld.Append(pad.componentID +  PubStaticParam.RS_CommaSplit);
                    //Type
                    strBldPld.Append( PubStaticParam.RS_EMPTY +  PubStaticParam.RS_CommaSplit);
                    //Area(%)
                    strBldPld.Append(pad.res.measuredValue.perArea +  PubStaticParam.RS_CommaSplit);
                    //Height
                    strBldPld.Append(pad.res.measuredValue.height +  PubStaticParam.RS_CommaSplit);
                    //Volume(%)
                    strBldPld.Append(pad.res.measuredValue.perVol +  PubStaticParam.RS_CommaSplit);
                    //XOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetXOrgMM +  PubStaticParam.RS_CommaSplit);
                    //YOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetYOrgMM +  PubStaticParam.RS_CommaSplit);
                    //PadSize(X)
                    strBldPld.Append(pad.sizeXmmNew +  PubStaticParam.RS_CommaSplit);
                    //PadSize(Y)
                    strBldPld.Append(pad.sizeYmmNew +  PubStaticParam.RS_CommaSplit);
                    //Area
                    strBldPld.Append(pad.res.measuredValue.area +  PubStaticParam.RS_CommaSplit);
                    //Height(%)
                    strBldPld.Append(pad.res.measuredValue.perHeight +  PubStaticParam.RS_CommaSplit);
                    //Volume
                    strBldPld.Append(pad.res.measuredValue.vol +  PubStaticParam.RS_CommaSplit);
                    //Result
                    strBldPld.Append(pad.res.jugRes +  PubStaticParam.RS_CommaSplit);
                    //Errcode
                    string strErrcode =  PubStaticParam.RS_EMPTY;
                    if (pad.res.jugRes == JudgeRes.NG)
                    {
                        strErrcode = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData);
                    }
                    strBldPld.Append(strErrcode +  PubStaticParam.RS_CommaSplit);
                    //PinNum
                    strBldPld.Append(pad.pinNumber +  PubStaticParam.RS_CommaSplit);
                    //Barcode
                    strBldPld.Append(pad.stBarcodeRes +  PubStaticParam.RS_CommaSplit);
                    //Date
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATE) +  PubStaticParam.RS_CommaSplit);
                    //Time
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_TIME) +  PubStaticParam.RS_CommaSplit);
                    //ArrayID
                    strBldPld.Append(pad.strArrayID + PubStaticParam.RS_LineEnd);
                }


                string strFileName = strboardBarcode +  PubStaticParam.RS_CSV_EXT;

                AstrDir  = Path.Combine(AstrDir, strboardBarcode);
                Directory.CreateDirectory(AstrDir);

                strFileName = Path.Combine(AstrDir, strFileName);

                FileStream fs = new FileStream(strCSVFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Write(strBldPld);
                streamWrt.Close();

                if (File.Exists(strCSVFile))
                {
                    File.Copy(strCSVFile, strFileName, true);
                }               

            }
            catch (System.Exception ex)
            {
                strMsg =  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveDataFileForSZMTCLane1 |" + AstrClntName + ")" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }


        /// <summary>
        ///  轨道2 导出数据文件CSV
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="Adict"></param>
        /// <param name="AstrTemp"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <returns></returns>
        public string MESSaveDataFileForSZMTCLane2(
                   InspectMainLib.Pad[] APads,
                  SPCBoardRes ABrdRes,
                  ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                  AppSettingData AappSettingData,
                    AppMultiLan.AppLan Adict,
                    InspectConfig.ConfigData AconfigData,
                    string AstrTemp,
                  string AstrDir,  //export folder      
                  string AstrClntName)
        {
            string strMsg =  PubStaticParam.RS_EMPTY;
            string strCSVFileName = string.Empty;
            try
            {
                String strboardBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode,
                                                            AappSettingData, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13

                //读取一轨保存的记录 
                strCSVFileName = strboardBarcode +  PubStaticParam.RS_UnderLineSplit + "0" +  PubStaticParam.RS_CSV_EXT;
                string strCSVFile = Path.Combine(AstrTemp, strCSVFileName);
                if (File.Exists(strCSVFile) == false)
                {
                    strMsg = " Data for LaneNo 1 is missing !";
                    return strMsg;
                }

                StringBuilder strBldPld = new StringBuilder();
                foreach (Pad pad in APads)
                {
                    //PadID, ComponentID, Type, Area(%), Height, Volume(%), XOffset, YOffset, PadSize(X), PadSize(Y), Area, Height(%), Volume, Result, Errcode, PinNum, Barcode, Date, Time, ArrayID
                    if (_wsBaseF.bPadIsSkip(pad))
                    {
                        continue;
                    }
                    //PadID
                    strBldPld.Append(pad.padID +  PubStaticParam.RS_CommaSplit);
                    //ComponentID
                    strBldPld.Append(pad.componentID +  PubStaticParam.RS_CommaSplit);
                    //Type
                    strBldPld.Append( PubStaticParam.RS_EMPTY +  PubStaticParam.RS_CommaSplit);
                    //Area(%)
                    strBldPld.Append(pad.res.measuredValue.perArea +  PubStaticParam.RS_CommaSplit);
                    //Height
                    strBldPld.Append(pad.res.measuredValue.height +  PubStaticParam.RS_CommaSplit);
                    //Volume(%)
                    strBldPld.Append(pad.res.measuredValue.perVol +  PubStaticParam.RS_CommaSplit);
                    //XOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetXOrgMM +  PubStaticParam.RS_CommaSplit);
                    //YOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetYOrgMM +  PubStaticParam.RS_CommaSplit);
                    //PadSize(X)
                    strBldPld.Append(pad.sizeXmmNew +  PubStaticParam.RS_CommaSplit);
                    //PadSize(Y)
                    strBldPld.Append(pad.sizeYmmNew +  PubStaticParam.RS_CommaSplit);
                    //Area
                    strBldPld.Append(pad.res.measuredValue.area +  PubStaticParam.RS_CommaSplit);
                    //Height(%)
                    strBldPld.Append(pad.res.measuredValue.perHeight +  PubStaticParam.RS_CommaSplit);
                    //Volume
                    strBldPld.Append(pad.res.measuredValue.vol +  PubStaticParam.RS_CommaSplit);
                    //Result
                    strBldPld.Append(pad.res.jugRes +  PubStaticParam.RS_CommaSplit);
                    //Errcode
                    string strErrcode =  PubStaticParam.RS_EMPTY;
                    if (pad.res.jugRes == JudgeRes.NG)
                    {
                        strErrcode = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData);
                    }
                    strBldPld.Append(strErrcode +  PubStaticParam.RS_CommaSplit);
                    //PinNum
                    strBldPld.Append(pad.pinNumber +  PubStaticParam.RS_CommaSplit);
                    //Barcode
                    strBldPld.Append(pad.stBarcodeRes +  PubStaticParam.RS_CommaSplit);
                    //Date
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATE) +  PubStaticParam.RS_CommaSplit);
                    //Time
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_TIME) +  PubStaticParam.RS_CommaSplit);
                    //ArrayID
                    strBldPld.Append(pad.strArrayID + PubStaticParam.RS_LineEnd);
                }

                string strFileName = strboardBarcode +  PubStaticParam.RS_CSV_EXT;

                AstrDir = Path.Combine(AstrDir, strboardBarcode);
                Directory.CreateDirectory(AstrDir);

                strFileName = Path.Combine(AstrDir, strFileName);

                FileStream fs = new FileStream(strCSVFile, FileMode.Append);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldPld);
                streamWrt.Close();

                if (File.Exists(strCSVFile))
                {
                    File.Copy(strCSVFile, strFileName, true);
                    File.Delete(strCSVFile);
                }

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESSaveDataFileForSZMTCLane2)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        /// <summary>
        /// 记录设备运行时间状况，遇到如下情况需要反馈给MES，IDLE（空闲未投料），人为停机（暂停，急停，保养），对停止设备进行分权限管控，若是无权限停止设备，需报警提示。
        /// </summary>
        /// <param name="AstrJobName"></param>
        /// <param name="AdtRecTime"></param>
        /// <param name="AstrStatusCode"></param>
        /// <param name="AstrStatusDesc"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AappSettingData"></param>
        /// <returns></returns>
        public String MESMachineUsageForSZMTC(
            string AstrJobName,
                     DateTime AdtRecTime,
                     string AstrStatusCode,
                    string AstrStatusDesc,
                    string AstrDir,
                     AppSettingData AappSettingData)
        {
            String strMsg =  PubStaticParam.RS_EMPTY;
            try
            {

                if (string.IsNullOrEmpty(AstrDir))
                    AstrDir =  PubStaticParam.RS_strTmpFileDir;

                if (Directory.Exists(AstrDir) == false)
                {
                    Directory.CreateDirectory(AstrDir);
                }

                AstrDir = Path.Combine(AstrDir, AstrJobName + "##" + AdtRecTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName) +  PubStaticParam.RS_CSV_EXT);
                //RecTime,StatusCode,StatusDesc
                // 2017 - 8 - 30 10:2:9,BNDERR_MissingDie,丢晶
                string strLinePre =  PubStaticParam.RS_EMPTY;
                StringBuilder strBldBoard = new StringBuilder();

                strLinePre = "RecTime" +  PubStaticParam.RS_CommaSplit + "StatusCode" +  PubStaticParam.RS_CommaSplit + "StatusDesc";
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                strLinePre = AdtRecTime.ToString( PubStaticParam.RS_FORMAT_DATETIME) +  PubStaticParam.RS_CommaSplit + AstrStatusCode +
                     PubStaticParam.RS_CommaSplit + AstrStatusDesc +  PubStaticParam.RS_CommaSplit;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);


                FileStream fs = new FileStream(AstrDir, FileMode.Append);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Close();

            }
            catch (System.Exception ex)
            {
                strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "(MESMachineUsageForSZMTC)" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }

        #endregion

        #region " 郑州富士康 foxconn"
        /// <summary>
        /// L051F	【樓棟樓層】：L051F，L061F…		
        /// S04	【線別】：S01，S02…		
        /// SPI	【設備名稱】：AOI，SPI
        /// TRI	【設備型號】：TRI，KY，HL，JET…		
        /// T2001250379-001	【設備編號】：設備出廠編號
        ///  SPI	【工站】：SPI		
        /// 20161117023736	【測試時間】		
        /// F3YGXD664705Z1	【條碼】		
        /// 【元件名稱】	【料號】	【面積百分比】	【高度值】	【體積百分比】	【X偏移量】	【Y偏移量】	【PAD尺寸X】	【PAD尺寸Y】	【面積值】	【高度百分比】	【體積值】	【測試結果】	【PAD編號】	【條碼】	【測試日期】	【測試時間】	【分板號】
        /// Compname Type    Area(%) Height Volume(%)   XOffset YOffset PadSize(X)  PadSize(Y)  Area Height(%)   Volume Result  PinNum Barcode Date Time    Board
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <param name="OstrLog"></param>
        /// <returns></returns>
        public string SaveDataFileForZZFoxConn(
         InspectMainLib.Pad[] APads,
         SPCBoardRes ABrdRes,
         ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
         AppSettingData AappSettingData,
         string AstrDir,
         string AstrClntName,
         out string OstrLog)
        {

            string strMsg =  PubStaticParam.RS_EMPTY;
            OstrLog =  PubStaticParam.RS_EMPTY;
            try
            {
                //delete old tmp file
                string tmpFile =  PubStaticParam.RS_strTmpFileDir + "\\" +  PubStaticParam.RS_DataExportTempFile;
                if (File.Exists(tmpFile))
                {
                    File.Delete(tmpFile);
                }
                //check dir
                if (_wsBaseF.DirCheck(ref AstrDir) == -1)
                {
                    strMsg +=  PubStaticParam.RS_DATAEXPORTMsg + "No Folder!" + AstrDir;
                    return strMsg;
                }
                AstrDir = Path.Combine(AstrDir, ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATE), "Machine_Result");


                string strPCBBarcode =  PubStaticParam.RS_EMPTY;
                string strLineNo = AappSettingData.LineName;
                string strJobName = Path.GetFileNameWithoutExtension(ABrdRes.jobName);
                string strArrayStatus =  PubStaticParam.RS_EMPTY;

                strPCBBarcode = _wsBaseF.BarcodeDicision(ABrdRes.pcbBarcode, AappSettingData, (byte)ABrdRes.LaneNo);

                string strLinePre =  PubStaticParam.RS_EMPTY;
                StringBuilder strBldBoard = new StringBuilder();
                StringBuilder strBldPld = new StringBuilder();

                //【樓棟樓層】
                strLinePre = AappSettingData.stDataExpVT.strCustomer;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // S04	【線別】：S01，S02…		
                strLinePre = strLineNo;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // SPI	【設備名稱】：AOI，SPI
                //strLinePre = "SPI";
                strLinePre = AappSettingData.stDataExpVT.strTestType;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // TRI	【設備型號】：TRI，KY，HL，JET…		
                strLinePre = AappSettingData.stDataExpVT.strMachine;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // T2001250379-001	【設備編號】：設備出廠編號
                strLinePre = AappSettingData.stDataExpVT.strProductID;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // SPI	【工站】：SPI		
                strLinePre = "SPI";
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // 20161117023736	【測試時間】
                strLinePre = ABrdRes.startTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName);
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);
                // F3YGXD664705Z1	【條碼】		
                strLinePre = strPCBBarcode;
                strBldBoard.Append(strLinePre + PubStaticParam.RS_LineEnd);

                // 【元件名稱】	【料號】	【面積百分比】	【高度值】	【體積百分比】	【X偏移量】	【Y偏移量】	【PAD尺寸X】	【PAD尺寸Y】	【面積值】	【高度百分比】	【體積值】	【測試結果】	【PAD編號】	【條碼】	【測試日期】	【測試時間】	【分板號】
                // Compname Type    Area(%) Height Volume(%)   XOffset YOffset PadSize(X)  PadSize(Y)  Area Height(%)   Volume Result  PinNum Barcode Date Time    Board
                strBldPld.Append(
                                            "ComponentID" +  PubStaticParam.RS_CommaSplit
                                          + "Type" +  PubStaticParam.RS_CommaSplit
                                          + "Area(%)" +  PubStaticParam.RS_CommaSplit
                                          + "Height" +  PubStaticParam.RS_CommaSplit
                                          + "Volume(%)" +  PubStaticParam.RS_CommaSplit
                                           + "XOffset" +  PubStaticParam.RS_CommaSplit
                                            + "YOffset" +  PubStaticParam.RS_CommaSplit
                                          + "PadSize(X)" +  PubStaticParam.RS_CommaSplit
                                          + "PadSize(Y)" +  PubStaticParam.RS_CommaSplit
                                          + "Area" +  PubStaticParam.RS_CommaSplit
                                          + "Height(%)" +  PubStaticParam.RS_CommaSplit
                                         + "Volume" +  PubStaticParam.RS_CommaSplit
                                          + "Result" +  PubStaticParam.RS_CommaSplit
                                          + "PinNum" +  PubStaticParam.RS_CommaSplit
                                          + "Barcode" +  PubStaticParam.RS_CommaSplit
                                          + "Date" +  PubStaticParam.RS_CommaSplit
                                          + "Time" +  PubStaticParam.RS_CommaSplit
                                          + "ArrayID"
                                          + PubStaticParam.RS_LineEnd
                                          );

                foreach (Pad pad in APads)
                {
                    //Compname Type    Area(%) Height Volume(%)   XOffset YOffset PadSize(X)  PadSize(Y)  Area Height(%)   Volume Result  PinNum Barcode Date Time    Board
                    if (_wsBaseF.bPadIsSkip(pad))
                    {
                        continue;
                    }
                    //ComponentID
                    strBldPld.Append(pad.componentID +  PubStaticParam.RS_CommaSplit);
                    //Type
                    strBldPld.Append( PubStaticParam.RS_EMPTY +  PubStaticParam.RS_CommaSplit);
                    //Area(%)
                    strBldPld.Append(pad.res.measuredValue.perArea*100 +  PubStaticParam.RS_CommaSplit);
                    //Height
                    strBldPld.Append(pad.res.measuredValue.height +  PubStaticParam.RS_CommaSplit);
                    //Volume(%)
                    strBldPld.Append(pad.res.measuredValue.perVol * 100 + PubStaticParam.RS_CommaSplit);
                    //XOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetXOrgMM +  PubStaticParam.RS_CommaSplit);
                    //YOffset
                    strBldPld.Append(pad.res.measuredValue.fOffsetYOrgMM +  PubStaticParam.RS_CommaSplit);
                    //PadSize(X)
                    strBldPld.Append(pad.sizeXmmNew +  PubStaticParam.RS_CommaSplit);
                    //PadSize(Y)
                    strBldPld.Append(pad.sizeYmmNew +  PubStaticParam.RS_CommaSplit);
                    //Area
                    strBldPld.Append(pad.res.measuredValue.area +  PubStaticParam.RS_CommaSplit);
                    //Height(%)
                    strBldPld.Append(pad.res.measuredValue.perHeight * 100 + PubStaticParam.RS_CommaSplit);
                    //Volume
                    strBldPld.Append(pad.res.measuredValue.vol +  PubStaticParam.RS_CommaSplit);
                    //Result
                    string strErrcode =  PubStaticParam.RS_EMPTY;
                    if (pad.res.jugRes == JudgeRes.NG | pad.res.jugRes == JudgeRes.Pass)
                    {
                        strErrcode = _wsBaseF.GetPadErrorCodeStr(pad, AappSettingData);
                    }
                    else
                    {
                        strErrcode = "PASS";
                    }
                    strBldPld.Append(strErrcode +  PubStaticParam.RS_CommaSplit);
                    //PinNum
                    strBldPld.Append(pad.pinNumber +  PubStaticParam.RS_CommaSplit);
                    //Barcode
                    strBldPld.Append(strPCBBarcode + PubStaticParam.RS_CommaSplit);
                    //Date
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_DATE) +  PubStaticParam.RS_CommaSplit);
                    //Time
                    strBldPld.Append(ABrdRes.startTime.ToString( PubStaticParam.RS_FORMAT_TIME) +  PubStaticParam.RS_CommaSplit);
                    //ArrayID
                    strBldPld.Append(pad.strArrayID + PubStaticParam.RS_LineEnd);
                }

                //◆【文件名稱】：設備名稱_樓層線別_設備型號_條碼_測試時間.csv，示例：SPI_L051FS02_HL_F3YH6TF64609LT_20171108181526.csv
                string strFileName = "SPI" +  PubStaticParam.RS_UnderLineSplit +
                                             AappSettingData.stDataExpVT.strCustomer + strLineNo +  PubStaticParam.RS_UnderLineSplit +
                                              AappSettingData.stDataExpVT.strMachine +  PubStaticParam.RS_UnderLineSplit +
                                              strPCBBarcode +  PubStaticParam.RS_UnderLineSplit +
                                               ABrdRes.startTime.ToString(  PubStaticParam.RS_Format_DateTimeFileName) + 
                                               PubStaticParam.RS_CSV_EXT;

                Directory.CreateDirectory(AstrDir);
                strFileName = Path.Combine(AstrDir, strFileName);
                FileStream fs = new FileStream(tmpFile, FileMode.Create);
                System.IO.StreamWriter streamWrt = new StreamWriter(fs, Encoding.Default);
                streamWrt.Write(strBldBoard);
                streamWrt.Write(strBldPld);
                streamWrt.Close();

                if (File.Exists(tmpFile))
                {
                    File.Copy(tmpFile, strFileName, true);
                    File.Delete(tmpFile);
                }

            }
            catch (System.Exception ex)
            {
                strMsg =  PubStaticParam.RS_DATAEXPORTMsg + "(SaveDataFileForZZFoxConn" + AstrClntName + ")" + ex.Message.ToString();
            }
            finally
            {
            }
            return strMsg;
        }
        #endregion

        #region " 聚飞"
        /// <summary>
        /// 1，在Default格式上增加一个工单号栏位。
        /// 2，用Autoreport方式。每个班生成一个报表。文件名用日期加保存时间。内容如附件。
        /// 其中运行时间，故障时间等如果暂时没有办法输出就先空着
        /// 客户端设备为L1200两段测试的。怎么将同一块PCB的文件合成一个。需要考虑。   
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <param name="OstrLog"></param>
        /// <returns></returns>

        #endregion

        #region " 友佳"
        /// <summary>
        /// 光宝差不多   
        /// </summary>
        /// <param name="APads"></param>
        /// <param name="ABrdRes"></param>
        /// <param name="APcbGeneralInfo"></param>
        /// <param name="AappSettingData"></param>
        /// <param name="AstrDir"></param>
        /// <param name="AstrClntName"></param>
        /// <param name="OstrLog"></param>
        /// <returns></returns>

        #endregion

        #region "Printer/SPI  XML Conversion"
        public Print2SPI.Data GetPrint2SPIXML(string strPrint2SPIXMLFile)
        {
            Print2SPI.Data RReturn = new Print2SPI.Data();
            try
            {
                RReturn= XMLHelper.ReadXMLFile2Obj<Print2SPI.Data>(strPrint2SPIXMLFile);
            }
            catch (Exception ex)
            {
                throw ex;
             }
            return RReturn;
        }

        public string MESSaveXMLFileForSPI2Print(
                       InspectMainLib.Pad[] APads,
                      SPCBoardRes ABrdRes,
                      ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo,
                      AppSettingData AappSettingData,
                        AppMultiLan.AppLan Adict,
                         InspectConfig.ConfigData AconfigData,
                         Print2SPI.Data Print2SPI,
                      string AstrTemp,  //export folder     
                       string AstrDir,  //export folder      
                     string AstrClntName)
        {
            string strMsg = PubStaticParam.RS_EMPTY;
            SPI2Print.Data SPI2Print = new SPI2Print.Data();

            string RS_Brcd_NoBarcode = "NOREAD";
            string RS_Brcd_NoBarcodeDEK = "NO_CODE";
            string RS_FLOATFORMAT_4Bit = "0.0000";
            string RS_FLOATFORMAT_6Bit = "0.000000";
            try
            {
                SPI2Print.Message.version = AconfigData._strUIVersion;
                SPI2Print.Message.Date_and_Time = DateTime.Now.ToString(PubStaticParam.RS_FORMAT_DATETIME_ISO8601, DateTimeFormatInfo.InvariantInfo);
                SPI2Print.Equipment.version = Print2SPI.Equipment.version;
                SPI2Print.Equipment.reference = Print2SPI.Equipment.reference;
                SPI2Print.Equipment.Name = "SPI";

                string strJobName = ABrdRes.jobName;
                if (File.Exists(strJobName) || strJobName.Contains(":"))
                {
                    strJobName = Path.GetFileNameWithoutExtension(strJobName);
                }

                SPI2Print.Process.Product_ID = strJobName;
                //bool bISArrayPCB = APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB;
                //bool bPosZeroISUsed = APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed;
                //if (bISArrayPCB)
                //{
                //    foreach (ImgCSCoreIM.SingleArrayInfo ArrayInfo in APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo)
                //    {
                //        if (ArrayInfo.bChecked)
                //        {
                //            SPI2Print.Process.Panel_ID.Panel.Add(ArrayInfo.strArrayBarcode);
                //        }
                //    }
                //}
                //Q.F.2018.03.06
                int iBarcodeCount = _wsBaseF.IHasBarcode(ref AappSettingData, ref APcbGeneralInfo, (byte)ABrdRes.LaneNo);//Q.F.2017.04.13
                int iArrayCount = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo.Length;
                int i = 0;
                string strBarcode = RS_Brcd_NoBarcodeDEK;
                if (iBarcodeCount > 1)
                {
                    iBarcodeCount = APcbGeneralInfo.PanelResults[0].arrStrBrcd.Length;
                    if (APcbGeneralInfo.PanelResults[0].stArrayInfo.bISArrayPCB == true
                        && APcbGeneralInfo.PanelResults[0].stArrayInfo.bPosZeroISUsed == false)
                    {
                        iBarcodeCount--;
                    }
                }
                if (iBarcodeCount >= 1)
                {
                    if (iBarcodeCount == 1)
                    {
                        strBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.strBoardBarcode;
                        if (String.IsNullOrEmpty(strBarcode)
                            || String.Equals(strBarcode, RS_Brcd_NoBarcode, StringComparison.InvariantCultureIgnoreCase))
                        {
                            strBarcode = RS_Brcd_NoBarcodeDEK;
                        }
                        SPI2Print.Process.Panel_ID.Panel.Add(strBarcode);
                    }
                    else
                    {
                        for (i = 0; i < iArrayCount; ++i)
                        {
                            if (APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].bChecked)
                            {
                                strBarcode = APcbGeneralInfo.PanelResults[0].stArrayInfo.arrSingleArrayInfo[i].strArrayBarcode;
                                if (String.IsNullOrEmpty(strBarcode)
                                    || String.Equals(strBarcode, RS_Brcd_NoBarcode, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    strBarcode = RS_Brcd_NoBarcodeDEK;
                                }
                                SPI2Print.Process.Panel_ID.Panel.Add(strBarcode);
                            }
                        }
                    }
                }

                SPI2Print.Process.Batch_Count = "1"; // 清洗刮刀后第几片
                SPI2Print.Process.Panel_Status = "Inspected";
                SPI2Print.Process.Inspected_Date_and_Time = ABrdRes.startTime.ToString(PubStaticParam.RS_FORMAT_DATETIME_ISO8601, DateTimeFormatInfo.InvariantInfo);
                SPI2Print.Process.Direction = Print2SPI.Process.Print_Direction;
                SPI2Print.Process.Units.Distance = Print2SPI.Process.Units.Distance;
                SPI2Print.Process.Units.Angle = Print2SPI.Process.Units.Angle;
                SPI2Print.Process.Units.Time = Print2SPI.Process.Units.Time;
                SPI2Print.Process.Units.Stretch = "%";

                //SPI2Print.Process.Offset_Correction.X = Print2SPI.Process.Offset.X;
                //SPI2Print.Process.Offset_Correction.Y = Print2SPI.Process.Offset.Y;
                //SPI2Print.Process.Offset_Correction.Theta.CoR_X = Print2SPI.Process.Offset.Theta.CoR_X;
                //SPI2Print.Process.Offset_Correction.Theta.CoR_Y = Print2SPI.Process.Offset.Theta.CoR_Y;
                //SPI2Print.Process.Offset_Correction.Theta.text = Print2SPI.Process.Offset.Theta.text;
                //SPI2Print.Process.Offset_Correction.Stretch= "0.0";

                //Q.F.2018.03.06
                SPI2Print.Process.Offset_Correction.X = ABrdRes.stPrinterSystemRes.fOffsetY.ToString(RS_FLOATFORMAT_6Bit);
                SPI2Print.Process.Offset_Correction.Y = ABrdRes.stPrinterSystemRes.fOffsetY.ToString(RS_FLOATFORMAT_6Bit);
                SPI2Print.Process.Offset_Correction.Theta.CoR_X = ABrdRes.stPrinterSystemRes.fCoRX.ToString(RS_FLOATFORMAT_6Bit);
                SPI2Print.Process.Offset_Correction.Theta.CoR_Y = ABrdRes.stPrinterSystemRes.fCoRY.ToString(RS_FLOATFORMAT_6Bit);
                SPI2Print.Process.Offset_Correction.Theta.text = ABrdRes.stPrinterSystemRes.fTheta.ToString(RS_FLOATFORMAT_6Bit);
                SPI2Print.Process.Offset_Correction.Stretch = ABrdRes.stPrinterSystemRes.fStretch.ToString("0.0"); 


                //SPI2Print.Process.Fiducials.count = Print2SPI.Process.Fiducials.count;
                //foreach (Print2SPI.Fiducial P2Sfiducial in Print2SPI.Process.Fiducials.Fiducial)
                //{
                //    SPI2Print.Fiducial S2Pfiducial = new SPI2Print.Fiducial();
                //    //X 偏移值
                //    S2Pfiducial.Name = P2Sfiducial.Name;
                //    S2Pfiducial.X.Origin = "353.2387";
                //    S2Pfiducial.X.text = "352.6945";
                //    S2Pfiducial.Y.Origin = "38.1000";
                //    S2Pfiducial.Y.text = "37.1964";
                //    SPI2Print.Process.Fiducials.Fiducial.Add(S2Pfiducial);
                //}
                //Q.F.2018.03.06
               
                int iFidCount = ABrdRes.stPrinterSystemRes.aFLstMarkXOrg.Count;
                SPI2Print.Process.Fiducials.count = iFidCount.ToString();// Print2SPI.Process.Fiducials.count;
                for (i = 1; i <= iFidCount; ++i)
                {
                    //if (i == 3) break;
                    SPI2Print.Fiducial S2Pfiducial = new SPI2Print.Fiducial();                   
                    S2Pfiducial.Name = "Fid " + i;
                    S2Pfiducial.X.Origin = ABrdRes.stPrinterSystemRes.aFLstMarkXOrg[i - 1].ToString(RS_FLOATFORMAT_4Bit);
                    S2Pfiducial.X.text = ABrdRes.stPrinterSystemRes.aFLstMarkXReal[i - 1].ToString(RS_FLOATFORMAT_4Bit);
                    S2Pfiducial.Y.Origin = ABrdRes.stPrinterSystemRes.aFLstMarkYOrg[i - 1].ToString(RS_FLOATFORMAT_4Bit);
                    S2Pfiducial.Y.text = ABrdRes.stPrinterSystemRes.aFLstMarkYReal[i - 1].ToString(RS_FLOATFORMAT_4Bit);
                    SPI2Print.Process.Fiducials.Fiducial.Add(S2Pfiducial);


                }


                int iWarningNum = 0,  iWarningVolumeNum = 0, iWarningHeightNum = 0, iWarningAreaNum = 0, iWarningBridgeNum = 0, iWarningNoPasteNum = 0;
                int iAlarmNum = 0,  iAlarmVolumeNum = 0, iAlarmHeightNum = 0, iAlarmAreaNum = 0, iAlarmBridgeNum = 0, iAlarmNoPasteNum = 0;
                int iTotalNum = 0;
                //foreach (Pad pad in APads)
                //{
                //    if (pad.check && !pad.bUseAsPosMark && !pad.bUseAsBadMark)
                //    {
                //        iTotalNum++;
                //        switch (pad.res.jugRes)
                //        {
                //            case JudgeRes.NG:
                //                iWarningNum++;

                //                break;
                //            case JudgeRes.Pass:

                //            default:
                //                break;
                //        }                      
                //    }
                //}

                SPI2Print.Process.Warning.TotalNum = iWarningNum.ToString();
                SPI2Print.Process.Warning.DefectNum = iWarningNum.ToString();
                SPI2Print.Process.Warning.Volume.Num = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Volume.High = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Volume.Low = iWarningVolumeNum.ToString();

                SPI2Print.Process.Warning.Height.Num = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Height.High = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Height.Low = iWarningVolumeNum.ToString();

                SPI2Print.Process.Warning.Area.Num = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Area.High = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.Area.Low = iWarningVolumeNum.ToString();

                SPI2Print.Process.Warning.Bridge = iWarningVolumeNum.ToString();
                SPI2Print.Process.Warning.NoPaste = iWarningVolumeNum.ToString();

                SPI2Print.Process.Alarm.TotalNum = iAlarmNum.ToString();
                SPI2Print.Process.Alarm.DefectNum = iAlarmNum.ToString();
                SPI2Print.Process.Alarm.Volume.Num = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Volume.High = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Volume.Low = iAlarmVolumeNum.ToString();

                SPI2Print.Process.Alarm.Height.Num = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Height.High = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Height.Low = iAlarmVolumeNum.ToString();

                SPI2Print.Process.Alarm.Area.Num = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Area.High = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.Area.Low = iAlarmVolumeNum.ToString();

                SPI2Print.Process.Alarm.Bridge = iAlarmVolumeNum.ToString();
                SPI2Print.Process.Alarm.NoPaste = iAlarmVolumeNum.ToString();

                AstrDir = Path.Combine(AstrDir, ABrdRes.startTime.ToString(PubStaticParam.RS_Format_DateTimeFileName) + PubStaticParam.RS_XML_EXT);
                XMLHelper.SaveObj2XMLFile<SPI2Print.Data>(SPI2Print, AstrDir);
            }
            catch (Exception ex)
            {
                strMsg += ex.ToString();
            }

            return strMsg;
        }

        #endregion

        //
    }
}
