﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO = Microsoft.Office.Interop.Access.Dao;
using System.Data;
using System.Threading;
using System.Diagnostics;
using ImgCSCoreIM;
using InspectMainLib;
using AppLayerLib;
using System.Windows.Forms;
namespace WSClnt
{
    public class RealtimeAccessHelper
    {
        private static string _strRealTimeDBPath = "D:\\EYSPI\\RealTimeAccessData\\RealTime.mdb";
        private static readonly string RS_FORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss";
        private Basefunction _baseF = new Basefunction();
        private static int _iBrcdMaxLength = 45;
        public static int InsertPadmeasureData(DataTable Adt)
        {
            DAO.DBEngine dbEngine = new DAO.DBEngine();
            DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");

            DAO.Recordset rs = db.OpenRecordset("tbPadmeasure");
            DAO.Field[] myFields = new DAO.Field[21];

            myFields[0] = rs.Fields["PCBID"];
            myFields[1] = rs.Fields["PadID"];
            myFields[2] = rs.Fields["LineNo"];
            myFields[3] = rs.Fields["JobIndex"];
            myFields[4] = rs.Fields["PadIndex"];
            myFields[5] = rs.Fields["ABSHeight"];
            myFields[6] = rs.Fields["ABSArea"];
            myFields[7] = rs.Fields["ABSVolume"];
            myFields[8] = rs.Fields["ShiftX"];
            myFields[9] = rs.Fields["ShiftY"];
            myFields[10] = rs.Fields["PerHeight"];
            myFields[11] = rs.Fields["PerArea"];
            myFields[12] = rs.Fields["PerVolume"];
            myFields[13] = rs.Fields["ABSShape"];
            myFields[14] = rs.Fields["BridgeType"];
            myFields[15] = rs.Fields["DefectType"];
            myFields[16] = rs.Fields["JudgeRes"];
            myFields[17] = rs.Fields["BaseType"];
            myFields[18] = rs.Fields["ArrayIDIndex"];
            myFields[19] = rs.Fields["PadArea"];
            myFields[20] = rs.Fields["InsertTime"];

            int intReturn = 0;
            for (int i = 0; i < Adt.Rows.Count; i++)
            {
                rs.AddNew();

                myFields[0].Value = Adt.Rows[i]["PCBID"].ToString();
                myFields[1].Value = Adt.Rows[i]["PadID"].ToString();
                myFields[2].Value = Adt.Rows[i]["LineNo"].ToString();
                myFields[3].Value = Adt.Rows[i]["JobIndex"].ToString();
                myFields[4].Value = Adt.Rows[i]["PadIndex"].ToString();
                myFields[5].Value = Adt.Rows[i]["ABSHeight"].ToString();
                myFields[6].Value = Adt.Rows[i]["ABSArea"].ToString();
                myFields[7].Value = Adt.Rows[i]["ABSVolume"].ToString();
                myFields[8].Value = Adt.Rows[i]["ShiftX"].ToString();
                myFields[9].Value = Adt.Rows[i]["ShiftY"].ToString();
                myFields[10].Value = Adt.Rows[i]["PerHeight"].ToString();
                myFields[11].Value = Adt.Rows[i]["PerArea"].ToString();
                myFields[12].Value = Adt.Rows[i]["PerVolume"].ToString();
                myFields[13].Value = Adt.Rows[i]["ABSShape"].ToString();
                myFields[14].Value = Adt.Rows[i]["BridgeType"].ToString();
                myFields[15].Value = Adt.Rows[i]["DefectType"].ToString();
                myFields[16].Value = Adt.Rows[i]["JudgeRes"].ToString();
                myFields[17].Value = Adt.Rows[i]["BaseType"].ToString();
                myFields[18].Value = Adt.Rows[i]["ArrayIDIndex"].ToString();
                myFields[19].Value = Adt.Rows[i]["PadArea"].ToString();
                myFields[20].Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                rs.Update();
                intReturn++;
            }

            rs.Close();
            db.Close();

            return intReturn;

        }
        
        public static int InsertBoard(DataTable Adt)
        {
            DAO.DBEngine dbEngine = new DAO.DBEngine();
            DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");

            DAO.Recordset rs = db.OpenRecordset("tbBoard");
            DAO.Field[] myFields = new DAO.Field[7];

            myFields[0] = rs.Fields["PCBID"];
            myFields[1] = rs.Fields["PCBBarcode"];
            myFields[2] = rs.Fields["StartTime"];
            myFields[3] = rs.Fields["EndTime"];
            myFields[4] = rs.Fields["JobIndex"];
            myFields[5] = rs.Fields["InspectTimeStamp"];
            myFields[6] = rs.Fields["LineNo"];
 

            int intReturn = 0;
            for (int i = 0; i < Adt.Rows.Count; i++)
            {
                rs.AddNew();

                myFields[0].Value = Adt.Rows[i]["PCBID"].ToString();
                myFields[1].Value = Adt.Rows[i]["PCBBarcode"].ToString();
                DateTime dtTemp;
                if (DateTime.TryParse(Adt.Rows[i]["StartTime"].ToString(),out dtTemp))
                    myFields[2].Value=dtTemp.ToString("yyyy-MM-dd HH:mm:ss");
                if (DateTime.TryParse(Adt.Rows[i]["EndTime"].ToString(), out dtTemp))
                    myFields[3].Value = dtTemp.ToString("yyyy-MM-dd HH:mm:ss");
                myFields[4].Value = Adt.Rows[i]["JobIndex"].ToString();
                if (DateTime.TryParse(Adt.Rows[i]["InspectTimeStamp"].ToString(), out dtTemp))
                    myFields[5].Value = dtTemp.ToString("yyyy-MM-dd HH:mm:ss");
                myFields[6].Value = Adt.Rows[i]["LineNo"].ToString();
               
                rs.Update();
                intReturn++;
            }

            rs.Close();
            db.Close();

            return intReturn;

        }
      
        public static int TranJobDataToAccess(ref DataBean.StJobData AstJobData )
        {
            int iJobIndex = -1;
            string strJobName = "";
            string strJobVersion = "";
            try
            {
                int iSleepTime = 200;
                int iDBErrorCode = -1;
                int iRtnCode = 0;
                //
                bool bHasJobExisted = true;

                string[] arrStrTableName = new string[] {   "TBSimplePad",     "TBPadConditionParams" };
                int iTableNum = arrStrTableName.Length;
                DataTable[] arrDttbUpdate = new DataTable[iTableNum];
                string[] arrStrSQLUpateTable = new string[iTableNum];
                int iTableIndex = 0;
                int iIndexSerNo = 0;
                DataRow drow;
                //
                string strSQL = string.Empty;
                string strSQLUpdate = "SELECT * FROM {0} WHERE 1 <> 1";
                string strSQLSelectJobIndex = "SELECT SerNo FROM TBJobInfo WHERE JobName = '{0}' AND JobVersion = '{1}'";
                string strSQLInsertJobInfo = "INSERT INTO TBJobInfo(JobName, CreateTime, LastSaveTime, JobVersion, LineNo) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')";
                string strSQLSelectTBSimplePad = "SELECT COUNT(A.PadID) FROM TBSimplePad AS A INNER JOIN TBJobInfo AS B ON A.JobIndex = B.SerNo WHERE B.SerNo = {0}";
                string strSQLDeleteJobData = "DELETE FROM {0} WHERE JobIndex = {1}";

                strJobName = AstJobData.Generals[0].JobName;
                strJobVersion = AstJobData.Generals[0].JobVersion;
                string strLineNo = AstJobData.Generals[0].LineNo;
                string strFieldValue = string.Empty;
                //
                //strFieldValue = GetFieldValueFrSQL(AstrHost, AstrDatabaseName, AstrDBUser, AstrDBPass, "SELECT COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE table_schema='spidb' AND TABLE_NAME = 'TBMark' AND COLUMN_NAME = 'Type'");
                //if (strFieldValue == null) return iDBErrorCode;
                //if (string.IsNullOrEmpty(strFieldValue)) ExecuteNonQuerySQL(AstrHost, AstrDatabaseName, AstrDBUser, AstrDBPass, "ALTER TABLE TBMark DROP PRIMARY KEY, ADD PRIMARY KEY(JobIndex, ID, Type)");
                //
                strFieldValue = AccessDBHelper.GetFieldValueFrAccess(string.Format(strSQLSelectJobIndex, strJobName, strJobVersion));
             //   if (strFieldValue == null) return iDBErrorCode;
                //
                if (string.IsNullOrEmpty(strFieldValue))
                {
                    bHasJobExisted = false;
                    strSQL = string.Format(strSQLInsertJobInfo, strJobName, AstJobData.Generals[0].CreatDateTime.ToString(RS_FORMAT_DATETIME), AstJobData.Generals[0].LastSaveTime.ToString(RS_FORMAT_DATETIME), strJobVersion, strLineNo);
                    iRtnCode = iDBErrorCode;
                    if (AccessDBHelper.ExecuteNonQuery(strSQL))
                    {
                        iRtnCode = 0;
                        Thread.Sleep(iSleepTime);
                        strFieldValue = AccessDBHelper.GetFieldValueFrAccess( string.Format(strSQLSelectJobIndex, strJobName, strJobVersion));
                    }
                }
                //
               // if (iRtnCode < 0) return iDBErrorCode;
                //
                iJobIndex = Convert.ToInt32(strFieldValue);
                strFieldValue = AccessDBHelper.GetFieldValueFrAccess( string.Format(strSQLSelectTBSimplePad, iJobIndex));
                if (Convert.ToInt32(strFieldValue) == 0)
                {
                    bHasJobExisted = false;
                    for (int i = 0; i < iTableNum; i++) {
                        AccessDBHelper.ExecuteNonQuery(string.Format(strSQLDeleteJobData, arrStrTableName[i], iJobIndex));
                    }
                   
                }
                //
             //   if (bHasJobExisted) return iJobIndex;
                //
                //for (int i = 0; i < iTableNum; i++) { arrStrSQLUpateTable[i] = string.Format(strSQLUpdate, arrStrTableName[i]); }
                //arrDttbUpdate = GetDataTableFrSQL(AstrHost, AstrDatabaseName, AstrDBUser, AstrDBPass, arrStrSQLUpateTable);
                //if (arrDttbUpdate == null)
                //{
                //    if (bHasJobExisted == false)
                //    {
                //        strSQL = "DELETE FROM TBJobInfo WHERE JobName = '{0}' AND JobVersion = '{1}'";
                //        strSQL = string.Format(strSQL, strJobName, strJobVersion);
                //        ExecuteNonQuerySQL(AstrHost, AstrDatabaseName, AstrDBUser, AstrDBPass, strSQL);
                //    }
                //    return iDBErrorCode;
                //}
                //Table TBBareBoard
                
                //Table TBFovPath
               
                //Table TBGeneral
                
                //Table TBMark
                
                //Table TBSimplePad
                iTableIndex = 4;
                iIndexSerNo = 0;
                if (AstJobData.SimplePads != null && AstJobData.SimplePads.Length > 0)
                {
                    DAO.DBEngine dbEngine = new DAO.DBEngine();
                    DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");
                    DAO.Recordset rs = db.OpenRecordset("TBSimplePad");
                    DAO.Field[] myFields = new DAO.Field[35];

                    myFields[0] = rs.Fields["JobIndex"];
                    myFields[1] = rs.Fields["IndexSerNo"];
                    myFields[2] = rs.Fields["PadID"];
                    myFields[3] = rs.Fields["PosXmm"];
                    myFields[4] = rs.Fields["PosYmm"];
                    myFields[5] = rs.Fields["Rotation"];
                    myFields[6] = rs.Fields["ShapeID"];
                    myFields[7] = rs.Fields["ShapeIDIndex"];
                    myFields[8] = rs.Fields["SizeXmm"];
                    myFields[9] = rs.Fields["SizeYmm"];
                    myFields[10] = rs.Fields["ShapeScaleX"];
                    myFields[11] = rs.Fields["ShapeScaleY"];
                    myFields[12] = rs.Fields["BadMarkID"];
                    myFields[13] = rs.Fields["SpecIndex"];
                    myFields[14] = rs.Fields["FovNo"];
                    myFields[15] = rs.Fields["MainCheck"];
                    myFields[16] = rs.Fields["BoardID"];
                    myFields[17] = rs.Fields["BlockID"];
                    myFields[18] = rs.Fields["ComponentID"];
                    myFields[19] = rs.Fields["PackageType"];
                    myFields[20] = rs.Fields["PinNumber"];
                    myFields[21] = rs.Fields["PadGroup"];
                    myFields[22] = rs.Fields["ArrayID"];
                    myFields[23] = rs.Fields["GlobalMarkGroup"];
                    myFields[24] = rs.Fields["ArrayIDIndex"];
                    myFields[25] = rs.Fields["UseAsBadMark"];
                    myFields[26] = rs.Fields["CmdStatus"];
                    myFields[27] = rs.Fields["UseMask"];
                    myFields[28] = rs.Fields["RotationDegOrg"];
                    myFields[29] = rs.Fields["BrdgVectorIndex"];
                    myFields[30] = rs.Fields["SizeXmmNew"];
                    myFields[31] = rs.Fields["SizeYmmNew"];
                    myFields[32] = rs.Fields["PadParamsIndex"];
                    myFields[33] = rs.Fields["PadCndtParamsIndex"];
                    myFields[34] = rs.Fields["UseAsPosMark"];
                    foreach (DataBean.StSimplePad stSimplePad in AstJobData.SimplePads)
                    {
                        rs.AddNew();
                        
                        myFields[0].Value = iJobIndex;
                        myFields[1].Value = iIndexSerNo;
                        myFields[2].Value = stSimplePad.PadID;
                        myFields[3].Value = stSimplePad.PosXmm;
                        myFields[4].Value = stSimplePad.PosYmm;
                        myFields[5].Value = stSimplePad.Rotation;
                        myFields[6].Value = stSimplePad.ShapeID;
                        myFields[7].Value = stSimplePad.ShapeIDIndex;
                        myFields[8].Value = stSimplePad.SizeXmm;
                        myFields[9].Value = stSimplePad.SizeYmm;
                        myFields[10].Value = stSimplePad.ShapeScaleX;
                        myFields[11].Value = stSimplePad.ShapeScaleY;
                        myFields[12].Value = stSimplePad.BadMarkID;
                        myFields[13].Value = stSimplePad.SpecIndex;
                        myFields[14].Value = stSimplePad.FovNo;
                        myFields[15].Value = stSimplePad.Check;
                        myFields[16].Value = stSimplePad.BoardID;
                        myFields[17].Value = stSimplePad.BlockID;
                        myFields[18].Value = stSimplePad.ComponentID;
                        myFields[19].Value = stSimplePad.PackageType;
                        myFields[20].Value = stSimplePad.PinNumber;
                        myFields[21].Value = stSimplePad.PadGroup;
                        myFields[22].Value = stSimplePad.ArrayID;
                        myFields[23].Value = stSimplePad.GlobalMarkGroup;
                        myFields[24].Value = stSimplePad.ArrayIDIndex;
                        myFields[25].Value = stSimplePad.UseAsBadMark;
                        myFields[26].Value = stSimplePad.CmdStatus;
                        myFields[27].Value = stSimplePad.UseMask;
                        myFields[28].Value = stSimplePad.RotationDegOrg;
                        myFields[29].Value = stSimplePad.BrdgVectorIndex;
                        myFields[30].Value = stSimplePad.SizeXmmNew;
                        myFields[31].Value = stSimplePad.SizeYmmNew;
                        myFields[32].Value = stSimplePad.PadParamsIndex;
                        myFields[33].Value = stSimplePad.PadCndtParamsIndex;
                        myFields[34].Value = stSimplePad.UseAsPosMark;
                       //drow["PadLocalGroupPadIndex"] = DoSerializeObject(stSimplePad.PadLocalGroupPadIndex);
                         
                        rs.Update();
                        iIndexSerNo++;
                    }

                    rs.Close();
                    db.Close();
                }

              
                


                //Table TBShape
                 
                //Table TBMarksPack
               
                //Table TBPCBPanels
               
                //Table TBPadConditionParams
                iTableIndex = 8;
                iIndexSerNo = 0;
                if (AstJobData.PadConditionParams != null && AstJobData.PadConditionParams.Length > 0)
                {
                    DAO.DBEngine dbEngine = new DAO.DBEngine();
                    DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");
                    DAO.Recordset rs = db.OpenRecordset("TBPadConditionParams");
                    DAO.Field[] myFields = new DAO.Field[37];

                    myFields[0] = rs.Fields["JobIndex"];
                    myFields[1] = rs.Fields["IndexSerNo"];
                    myFields[2] = rs.Fields["CheckHeight"];
                    myFields[3] = rs.Fields["CheckVol"];
                    myFields[4] = rs.Fields["CheckArea"];
                    myFields[5] = rs.Fields["CheckOffset"];
                    myFields[6] = rs.Fields["CheckShape"];
                    myFields[7] = rs.Fields["CheckStencilHeight"];
                    myFields[8] = rs.Fields["CheckBridge"];
                    myFields[9] = rs.Fields["Check2DSpec"];
                    myFields[10] = rs.Fields["HeightU"];
                    myFields[11] = rs.Fields["HeightL"];
                    myFields[12] = rs.Fields["AreaU"];
                    myFields[13] = rs.Fields["AreaL"];
                    myFields[14] = rs.Fields["VolU"];
                    myFields[15] = rs.Fields["VolL"];
                    myFields[16] = rs.Fields["ShiftDataType"];
                    myFields[17] = rs.Fields["ShiftXU"];
                    myFields[18] = rs.Fields["ShiftYU"];
                    myFields[19] = rs.Fields["RawShiftXU"];
                    myFields[20] = rs.Fields["RawShiftYU"];
                    myFields[21] = rs.Fields["ShapeDeltaU"];
                    myFields[22] = rs.Fields["StencilHeight"];
                    myFields[23] = rs.Fields["BridgeWidth"];
                    myFields[24] = rs.Fields["BridgeLength"];
                    myFields[25] = rs.Fields["BridgeHeight"];
                    myFields[26] = rs.Fields["VAHBlob"];
                    myFields[27] = rs.Fields["VAHRatio"];
                    myFields[28] = rs.Fields["PadHeightSingleUM"];
                    myFields[29] = rs.Fields["BridgeCheckType"];
                    myFields[30] = rs.Fields["GerberAreaPer"];
                    myFields[31] = rs.Fields["ShiftMode"];
                    myFields[32] = rs.Fields["VAHRatioThresh"];
                    myFields[33] = rs.Fields["VAHHRatio"];
                    myFields[34] = rs.Fields["VAHWRatio"];
                    myFields[35] = rs.Fields["PadBarcodeSetting"];
                    myFields[36] = rs.Fields["UseAsShiftCheck"];
                  

                    foreach (DataBean.StPadConditionParams stPadConditionParams in AstJobData.PadConditionParams)
                    {
                        rs.AddNew();
                        myFields[0].Value = iJobIndex;
                        myFields[1].Value = iIndexSerNo;
                        myFields[2].Value = stPadConditionParams.CheckHeight;
                        myFields[3].Value = stPadConditionParams.CheckVol;
                        myFields[4].Value = stPadConditionParams.CheckArea;
                        myFields[5].Value = stPadConditionParams.CheckOffset;
                        myFields[6].Value = stPadConditionParams.CheckShape;
                        myFields[7].Value = stPadConditionParams.CheckStencilHeight;
                        myFields[8].Value = stPadConditionParams.CheckBridge;
                        myFields[9].Value = stPadConditionParams.Check2DSpec;
                        myFields[10].Value = stPadConditionParams.HeightU;
                        myFields[11].Value = stPadConditionParams.HeightL;
                        myFields[12].Value = stPadConditionParams.AreaU;
                        myFields[13].Value = stPadConditionParams.AreaL;
                        myFields[14].Value = stPadConditionParams.VolU;
                        myFields[15].Value = stPadConditionParams.VolL;
                        myFields[16].Value = stPadConditionParams.ShiftDataType;
                        myFields[17].Value = stPadConditionParams.ShiftXU;
                        myFields[18].Value = stPadConditionParams.ShiftYU;
                        myFields[19].Value = stPadConditionParams.RawShiftXU;
                        myFields[20].Value = stPadConditionParams.RawShiftYU;
                        myFields[21].Value = stPadConditionParams.ShapeDeltaU;
                        myFields[22].Value = stPadConditionParams.StencilHeight;
                        myFields[23].Value = stPadConditionParams.BridgeWidth;
                        myFields[24].Value = stPadConditionParams.BridgeLength;
                        myFields[25].Value = stPadConditionParams.BridgeHeight;
                        //myFields["SPI2DSpec"] = DoSerializeObject(stPadConditionParams.SPI2DSpec);
                        //myFields["PadMask"] = DoSerializeObject(stPadConditionParams.PadMask);
                        myFields[26].Value = stPadConditionParams.VAHBlob;
                        myFields[27].Value = stPadConditionParams.VAHRatio;
                        myFields[28].Value = stPadConditionParams.PadHeightSingleUM;
                        myFields[29].Value = stPadConditionParams.BridgeCheckType;
                        myFields[30].Value = stPadConditionParams.GerberAreaPer;
                        myFields[31].Value = stPadConditionParams.ShiftMode;
                        myFields[32].Value = stPadConditionParams.VAHRatioThresh;
                        myFields[33].Value = stPadConditionParams.VAHHRatio;
                        myFields[34].Value = stPadConditionParams.VAHWRatio;
                        myFields[35].Value = stPadConditionParams.PadBarcodeSetting;
                        myFields[36].Value = stPadConditionParams.UseAsShiftCheck;
                        rs.Update();
                        iIndexSerNo++;
                    }

                    rs.Close();
                    db.Close();
                }
                
            }
            catch (Exception ex)
            {
                string strSQL = "DELETE FROM TBJobInfo WHERE JobName = '{0}' AND JobVersion = '{1}'";
                strSQL = string.Format(strSQL, strJobName, strJobVersion);
                AccessDBHelper.ExecuteNonQuery(strSQL);
                iJobIndex = -1;
                throw ex;
            }
            //
            return iJobIndex;
        }

    
        public int TransPCBINfoToAccess(ref Pad[] APads, string[] AarrStrBrcd,
            SPCBoardRes ABrdRes, AppSettingData AappSettingData,
            InspectConfig.ConfigData AConfigData,
            ImgCSCoreIM.PCBGeneralInfo APcbGeneralInfo
            )
        {


            //if (_bHasInstalledMySQL == false)
            //    return 0;
            if (ABrdRes == null)
            {
               // _imgBinCSBaseF.LogRecord(" TransPCBINfoToAccess BrdRes Empty", false);
                return 0;
            }
            byte byLaneNo = (byte)ABrdRes.LaneNo;
            String strMsg = "TransPCBINfoToAccess Lane " + byLaneNo + ":";
           
            try
            {
                
                
                Stopwatch stopW = new Stopwatch();         
                stopW.Reset();
                stopW.Start();
                //TBBoard
                TransToAccess_tbBoard(ref ABrdRes, AappSettingData);
                //TBPadMeasure
                if ( ABrdRes.jugResult != JudgeRes.Skipped ||
                      ABrdRes.jugResult != JudgeRes.Unmeasured)
                {

                    if (AappSettingData.stUIOperations.bEnSPCVSaveImageAsFile == false)
                    {
                        TransToDataTable(ref APads, ref ABrdRes, AappSettingData, AConfigData);
 
                    }                    

                }


                stopW.Stop();
                strMsg += "Time:" + stopW.ElapsedMilliseconds.ToString();
                
               

            }
            catch (Exception ex)
            {
                strMsg += "; Error:" + ex.Message.ToString();
            }
            //_imgBinCSBaseF.LogRecord(strMsg, false);
            
            return 0;
        }

        //TBBoard
       
        private int TransToAccess_tbBoard(ref SPCBoardRes ABrdRes, AppSettingData AappSettingData)
        {
            try
            {

                DAO.DBEngine dbEngine = new DAO.DBEngine();
                DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");

                DAO.Recordset rs = db.OpenRecordset("tbBoard");
                DAO.Field[] myFields = new DAO.Field[7];

                myFields[0] = rs.Fields["PCBID"];
                myFields[1] = rs.Fields["PCBBarcode"];
                myFields[2] = rs.Fields["StartTime"];
                myFields[3] = rs.Fields["EndTime"];
                myFields[4] = rs.Fields["JobIndex"];
                myFields[5] = rs.Fields["InspectTimeStamp"];
                myFields[6] = rs.Fields["LineNo"];

                rs.AddNew();

                myFields[0].Value = ABrdRes.pcbID;
                myFields[1].Value = GetStrByMaxLength(ABrdRes.pcbBarcode);
                myFields[2].Value = ABrdRes.startTime.ToString("yyyy-MM-dd HH:mm:ss");
                myFields[3].Value = ABrdRes.endTime.ToString("yyyy-MM-dd HH:mm:ss");
                myFields[4].Value = 0; ;// _aIJobIndices[ABrdRes.LaneNo];
                myFields[5].Value = ABrdRes.startTime.ToString("yyyy-MM-dd HH:mm:ss");
                myFields[6].Value = AappSettingData.LineName.Trim();

                rs.Update();

                rs.Close();
                db.Close();



            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error in save Access data Board table!->" + ex.ToString());
                return 1043;
            }
            finally
            {
            }
            return 0;
        }


        //TBPadMeasure
    
        private int TransToDataTable(ref Pad[] APads, ref SPCBoardRes ABrdRes, AppSettingData AappSettingData,
             InspectConfig.ConfigData AConfigData)
        {
            String strMsg = String.Empty;
            try
            {
                if (APads == null || APads.Length == 0)
                    return -1;
                bool bUse1DImage = false;
                if (AConfigData._VAHMsrPara_bFastMode == true && AConfigData._checkGage == false)
                { bUse1DImage = true; }

                DataRow drData = null;
                bool bSave2DImage = false;
                bool bSave3DImage = false;
                int iSaveCount = 0;
                int iSaveCountReal = 0;
                int iImgWidth = 0, iImgHeight = 0, iImgLength = 0, j = 0;
                short shColorPer = 0;
                
                ImgCSCoreIM.ColorFactorParams stColorFactors = AappSettingData.stColorFactorParams;


                DAO.DBEngine dbEngine = new DAO.DBEngine();
                DAO.Database db = dbEngine.OpenDatabase(_strRealTimeDBPath, false, false, "MS Access;PWD=123");
                DAO.Recordset rs = db.OpenRecordset("tbPadmeasure");
                DAO.Field[] myFields = new DAO.Field[21];
                myFields[0] = rs.Fields["PCBID"];
                myFields[1] = rs.Fields["PadID"];
                myFields[2] = rs.Fields["LineNo"];
                myFields[3] = rs.Fields["JobIndex"];
                myFields[4] = rs.Fields["PadIndex"];
                myFields[5] = rs.Fields["ABSHeight"];
                myFields[6] = rs.Fields["ABSArea"];
                myFields[7] = rs.Fields["ABSVolume"];
                myFields[8] = rs.Fields["ShiftX"];
                myFields[9] = rs.Fields["ShiftY"];
                myFields[10] = rs.Fields["PerHeight"];
                myFields[11] = rs.Fields["PerArea"];
                myFields[12] = rs.Fields["PerVolume"];
                myFields[13] = rs.Fields["ABSShape"];
                myFields[14] = rs.Fields["BridgeType"];
                myFields[15] = rs.Fields["DefectType"];
                myFields[16] = rs.Fields["JudgeRes"];
                myFields[17] = rs.Fields["BaseType"];
                myFields[18] = rs.Fields["ArrayIDIndex"];
                myFields[19] = rs.Fields["PadArea"];
                myFields[20] = rs.Fields["InsertTime"];


                for (int i = 0; i< APads.Length;i++)
                {

                    if (_baseF.bPadIsSkip(APads[i]))
                        continue;

                    rs.AddNew();
 
                    APads[i].res.measuredValue.perHeight = APads[i].res.measuredValue.height /
                        (APads[i].stencilHeight * 1000);
 
                    if (string.IsNullOrEmpty(AappSettingData.LineName))
                        AappSettingData.LineName = "";
                  

                    myFields[0].Value = ABrdRes.pcbID;

                    myFields[1].Value = APads[i].padID;
                    myFields[2].Value = AappSettingData.LineName.Trim();

                    myFields[3].Value = 0; // _aIJobIndices[ABrdRes.LaneNo];
                    myFields[4].Value = i;
                    myFields[5].Value = APads[i].res.measuredValue.height;
                    myFields[6].Value = APads[i].res.measuredValue.area;
                    myFields[7].Value = APads[i].res.measuredValue.vol;
                  
                    myFields[8].Value = APads[i].res.measuredValue.offsetX;
                    myFields[9].Value = APads[i].res.measuredValue.offsetY;
                    myFields[10].Value = APads[i].res.measuredValue.perHeight;
                    myFields[11].Value = APads[i].res.measuredValue.perArea;
                    myFields[12].Value = APads[i].res.measuredValue.perVol;
                    myFields[13].Value = APads[i].res.measuredValue.maxMeanHeightDelta;
                    myFields[14].Value = APads[i].res.measuredValue.bridgeType;
                    myFields[15].Value = Convert.ToInt32(APads[i].res.jugDefectType);
                    myFields[16].Value = Convert.ToInt32(APads[i].res.jugRes);
                    myFields[17].Value = APads[i].baseType;


                    myFields[18].Value = APads[i].arrayIDIndex;
                    myFields[19].Value = APads[i].spi2DRes.sPadAreaPerc;
                    myFields[20].Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    rs.Update();
                }

            }
            catch (System.Exception ex)
            {
                
                strMsg += "Trans Pad To Access Error:" + ex.ToString();
                return 1043;
            }
            finally
            {
                //if (!string.IsNullOrEmpty(strMsg))
                //    _imgBinCSBaseF.LogRecord(  strMsg, false);
            }
            return 0;
        }
        private String GetStrByMaxLength(String AstrSrc)
        {
            String strRes;
            if (String.IsNullOrEmpty(AstrSrc))
            {
                strRes = "";
            }
            else
            {
                if (AstrSrc.Length > _iBrcdMaxLength)
                {
                    strRes = AstrSrc.Substring(0, _iBrcdMaxLength - 1);
                }
                else
                {
                    strRes = AstrSrc;
                }
            }
            return strRes;
        }

    }
}
